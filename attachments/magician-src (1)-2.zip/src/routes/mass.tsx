import { useEffect, useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { BarChart3, Bookmark, Clock, Heart, Link2, MessageCircle, RefreshCw, Search, Share2, Upload, Zap } from "lucide-react";
import { Authed } from "@/components/gate";
import {
  completeMassBatch,
  getCatalog,
  getWallet,
  listMassBatches,
  liveEngagementRates,
  submitMassBatch,
  type BundleRow,
  type MassBatchRow,
} from "@/lib/panel.functions";
import { inr } from "@/lib/money";
import { usdQtyToPaise } from "@/lib/fx";

export const Route = createFileRoute("/mass")({
  component: () => (
    <Authed>
      <Mass />
    </Authed>
  ),
});

type ExtraKey = "likes" | "comments" | "shares" | "saves" | "reposts";

type LinkRow = {
  link: string;
  views: string;
  extras: Record<ExtraKey, { on: boolean; qty: string }>;
};

const FRAMES = [
  { id: "1-3 days", label: "1-3 days", hours: 72 },
  { id: "Under 24 hours", label: "Under 24 hours", hours: 24 },
  { id: "7-14 days", label: "7-14 days", hours: 14 * 24 },
  { id: "Custom date", label: "Custom date", hours: 0 },
] as const;

const EXTRA_META: { key: ExtraKey; label: string; icon: typeof Heart; igOnly?: boolean; tt?: boolean }[] = [
  { key: "likes", label: "Likes", icon: Heart },
  { key: "comments", label: "Comments", icon: MessageCircle, igOnly: true },
  { key: "shares", label: "Shares", icon: Share2 },
  { key: "saves", label: "Saves", icon: Bookmark },
  { key: "reposts", label: "Reposts", icon: RefreshCw, igOnly: true },
];

const FLOORS: Record<string, number> = { views: 100, likes: 10, comments: 10, shares: 10, saves: 50, reposts: 10 };

function blankExtras(views = "10000"): LinkRow["extras"] {
  const base = Number(views) || 0;
  const n = (ratio: number) => String(Math.max(1, Math.round(base * ratio)));
  return {
    likes: { on: true, qty: n(0.03) },
    comments: { on: true, qty: n(0.001) },
    shares: { on: true, qty: n(0.005) },
    saves: { on: true, qty: n(0.008) },
    reposts: { on: true, qty: n(0.008) },
  };
}

function parseLinks(text: string) {
  const found: string[] = [];
  for (const raw of text.split(/\n+/)) {
    const cell = raw.split(/[,;\t]/)[0]?.trim().replace(/^"|"$/g, "") ?? "";
    if (/^https?:\/\//i.test(cell) && !found.includes(cell)) found.push(cell);
  }
  return found;
}

function priceOf(views: number, extras: Record<string, number>, live: Record<string, number>) {
  let sum = 0;
  if (views > 0 && live.views) sum += usdQtyToPaise(live.views, views);
  for (const [key, qty] of Object.entries(extras)) {
    if (!qty || !live[key]) continue;
    sum += usdQtyToPaise(live[key], qty);
  }
  return sum;
}

function Mass() {
  const [tab, setTab] = useState<"create" | "batches">("create");
  const [bundles, setBundles] = useState<BundleRow[]>([]);
  const [bundleId, setBundleId] = useState("bundle-ig");
  const [name, setName] = useState("");
  const [text, setText] = useState("");
  const [rows, setRows] = useState<LinkRow[]>([]);
  const [views, setViews] = useState("10000");
  const [live, setLive] = useState<Record<string, number>>({});
  const [frame, setFrame] = useState<(typeof FRAMES)[number]["id"]>("1-3 days");
  const [customDate, setCustomDate] = useState("");
  const [defaults, setDefaults] = useState(blankExtras());
  const [batches, setBatches] = useState<MassBatchRow[]>([]);
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("all");
  const [openId, setOpenId] = useState<string | null>(null);
  const [balance, setBalance] = useState(0);
  const [note, setNote] = useState("");
  const [pending, setPending] = useState(false);

  function loadBatches() {
    listMassBatches().then(setBatches).catch(() => setBatches([]));
    getWallet().then((wallet) => setBalance(wallet.balance_paise)).catch(() => setBalance(0));
  }

  useEffect(() => {
    getCatalog().then((catalog) => setBundles(catalog.bundles)).catch(() => setBundles([]));
    loadBatches();
  }, []);

  const bundle = bundles.find((item) => item.id === bundleId) ?? bundles.find((item) => item.platform === "instagram");
  const instagram = (bundle?.platform ?? "instagram") === "instagram";
  const extras = EXTRA_META.filter((item) => instagram || !item.igOnly);

  useEffect(() => {
    const platform = bundle?.platform || (bundleId === "bundle-tt" ? "tiktok" : "instagram");
    liveEngagementRates({ data: platform }).then(setLive).catch(() => setLive({}));
  }, [bundle?.platform, bundleId]);

  function onText(next: string) {
    setText(next);
    const links = parseLinks(next);
    setRows((current) =>
      links.map((link) => current.find((row) => row.link === link) ?? { link, views, extras: structuredClone(defaults) }),
    );
  }

  const total = rows.reduce((sum, row) => {
    const picked = Object.fromEntries(
      extras.filter((item) => row.extras[item.key].on).map((item) => [item.key, Number(row.extras[item.key].qty) || 0]),
    );
    return sum + priceOf(Number(row.views) || 0, picked, live);
  }, 0);
  const hours = useMemo(() => {
    if (frame !== "Custom date") return FRAMES.find((item) => item.id === frame)?.hours ?? 72;
    const end = new Date(`${customDate}T23:59:00`).getTime();
    if (!customDate || Number.isNaN(end)) return 0;
    return Math.max(1, Math.round((end - Date.now()) / 3600000));
  }, [frame, customDate]);

  async function submit() {
    if (rows.some((row) => row.views === "" || Number(row.views) < FLOORS.views)) {
      setNote("Views khali hai ya 100 se kam. Below 100 not allowed.");
      return;
    }
    for (const row of rows) {
      for (const item of extras) {
        if (!row.extras[item.key].on) continue;
        const raw = row.extras[item.key].qty;
        if (raw === "") {
          setNote(`${item.label} khali hai. Minimum ${FLOORS[item.key]} allowed hai.`);
          return;
        }
        if (Number(raw) < FLOORS[item.key]) {
          setNote(`Below ${FLOORS[item.key]} not allowed for ${item.label}.`);
          return;
        }
      }
    }
    if (!live.views) {
      setNote("Live rate unavailable. Engagement APIs mein provider save karo.");
      return;
    }
    if (rows.length === 0) {
      setNote("Kam se kam 1 valid link daalo.");
      return;
    }
    if (frame === "Custom date" && hours < 1) {
      setNote("Custom date choose karo.");
      return;
    }
    if (balance < total) {
      setNote("Wallet does not cover this batch. Add credit first.");
      return;
    }
    setPending(true);
    setNote("");
    try {
      const result = await submitMassBatch({
        data: {
          bundleId: bundle?.id ?? bundleId,
          campaignName: name,
          timeframe: frame === "Custom date" ? `Custom · ${customDate}` : frame,
          intervalHours: hours,
          links: rows.map((row) => ({
            link: row.link,
            views: Number(row.views),
            extras: Object.fromEntries(
              extras.filter((item) => row.extras[item.key].on && Number(row.extras[item.key].qty) > 0).map((item) => [item.key, Number(row.extras[item.key].qty)]),
            ),
          })),
        },
      });
      setNote(`${result.placed} placed · ${result.failed} failed · ${inr(result.total_paise)}.`);
      setText("");
      setRows([]);
      setTab("batches");
      loadBatches();
    } catch (err: unknown) {
      setNote(err instanceof Error ? err.message : "Batch stopped.");
    } finally {
      setPending(false);
    }
  }

  const shown = batches.filter((batch) => {
    const named = batch.campaign_name.toLowerCase().includes(query.trim().toLowerCase());
    const statusOk = status === "all" || batch.status === status || (status === "failed" && batch.status === "partial");
    return named && statusOk;
  });
  const completed = batches.filter((batch) => batch.status === "completed").length;
  const processing = batches.filter((batch) => batch.status === "processing").length;
  const failed = batches.filter((batch) => batch.status === "failed" || batch.status === "partial").length;
  const rate = batches.length ? Math.round((completed / batches.length) * 100) : 0;

  return (
    <div className="mx-auto max-w-xl space-y-4 pb-16">
      <div className="grid grid-cols-2 rounded-2xl bg-[#eef3f8] p-1">
        <button type="button" onClick={() => setTab("create")} className={`inline-flex h-11 items-center justify-center gap-2 rounded-xl text-[14px] font-semibold ${tab === "create" ? "bg-white shadow-sm" : "text-[#64748b]"}`}>
          <Zap className="size-4" /> Create
        </button>
        <button type="button" onClick={() => setTab("batches")} className={`inline-flex h-11 items-center justify-center gap-2 rounded-xl text-[14px] font-semibold ${tab === "batches" ? "bg-white shadow-sm" : "text-[#64748b]"}`}>
          <Clock className="size-4" /> Batches
        </button>
      </div>

      {tab === "create" ? (
        <div className="space-y-3">
          <section className="rounded-3xl border border-[#f3e3c3] bg-[#fffaf3] p-4 text-center">
            <p className="font-semibold text-[#1f2937]"><span className="mr-1 text-amber-500">✦</span> Mass Order — Bulk Engagement</p>
            <p className="mt-1 text-[12px] leading-relaxed text-[#64748b]">Multiple links ek saath order karo. Paste karo ya CSV/TXT file upload karo, har link customize karo, batch me submit karo aur history me track karo.</p>
          </section>

          <section className="rounded-3xl border border-[#e7eef6] bg-white p-4">
            <p className="flex items-center gap-2 font-semibold"><span className="text-[#64748b]">◎</span> Apna Bundle</p>
            <select
              value={bundle?.id ?? bundleId}
              onChange={(event) => setBundleId(event.target.value)}
              className="mt-2 h-11 w-full rounded-xl border border-[#e7eef6] bg-[#f3f7fb] px-3 text-[14px]"
            >
              <option value="bundle-ig">ig (Instagram • 5 items)</option>
              <option value="bundle-tt">TikTok • 4 items</option>
            </select>
            <p className="mt-2 text-[12px] text-[#94a3b8]">
              {instagram ? "Views, likes, shares, saves, reposts." : "Views, likes, shares, saves. Reposts nahi hai."}
            </p>
            <p className="mt-3 text-[11px] font-semibold tracking-[0.14em] text-[#94a3b8]">CAMPAIGN NAME (OPTIONAL)</p>
            <input value={name} onChange={(event) => setName(event.target.value)} placeholder="e.g. Diwali Reels Mega Campaign 2026" className="mt-1 h-11 w-full rounded-xl bg-[#e7f0f8] px-3 text-[14px] outline-none" />
          </section>

          <section className="rounded-3xl border border-[#e7eef6] bg-white p-4">
            <div className="mb-2 flex items-center justify-between">
              <p className="flex items-center gap-2 font-semibold"><Link2 className="size-4" /> Links</p>
              <label className="inline-flex cursor-pointer items-center gap-1 rounded-full border border-[#e7eef6] px-3 py-1 text-[12px] font-semibold">
                <Upload className="size-3.5" /> Upload CSV / TXT
                <input
                  type="file"
                  accept=".csv,.txt,text/plain"
                  className="hidden"
                  onChange={async (event) => {
                    const file = event.target.files?.[0];
                    if (!file) return;
                    onText(`${text}\n${await file.text()}`);
                    event.target.value = "";
                  }}
                />
              </label>
            </div>
            <textarea
              value={text}
              onChange={(event) => onText(event.target.value)}
              placeholder={"Ek line par ek link.\nhttps://instagram.com/p/abc\nhttps://instagram.com/p/xyz\n\nYa CSV upload karo (first column = link)."}
              className="h-36 w-full resize-y rounded-2xl border border-[#e7eef6] p-3 text-[13px] outline-none"
            />
            <p className="mt-2 text-[12px] text-[#94a3b8]">{rows.length} valid link(s)</p>

            <p className="mt-4 text-[11px] font-semibold tracking-[0.14em] text-[#94a3b8]">DEFAULT BASE QUANTITY (VIEWS)</p>
            <input
              value={views}
              inputMode="numeric"
              onChange={(event) => setViews(event.target.value.replace(/[^\d]/g, ""))}
              className="mt-1 h-11 w-full rounded-xl bg-[#e7f0f8] px-3 text-[15px] outline-none"
            />
            {views !== "" && Number(views) < 100 && <p className="mt-1 text-[12px] font-semibold text-rose-600">Below 100 not allowed</p>}

            <p className="mt-4 text-[11px] font-semibold tracking-[0.14em] text-[#94a3b8]">DEFAULT TIMEFRAME</p>
            <select value={frame} onChange={(event) => setFrame(event.target.value as (typeof FRAMES)[number]["id"])} className="mt-1 h-11 w-full rounded-xl border border-[#e7eef6] bg-white px-3">
              {FRAMES.map((item) => <option key={item.id}>{item.label}</option>)}
            </select>
            {frame === "Custom date" && (
              <input type="date" value={customDate} onChange={(event) => setCustomDate(event.target.value)} className="mt-2 h-11 w-full rounded-xl bg-[#e7f0f8] px-3" />
            )}

            <p className="mt-4 text-[11px] font-semibold tracking-[0.14em] text-[#94a3b8]">DEFAULT EXTRA ENGAGEMENT (OPTIONAL)</p>
            <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
              {extras.map((item) => (
                <label key={item.key} className="flex items-center gap-2 rounded-2xl border border-[#eef2f6] px-3 py-2 text-[13px]">
                  <input
                    type="checkbox"
                    checked={defaults[item.key].on}
                    onChange={() => setDefaults((current) => ({ ...current, [item.key]: { ...current[item.key], on: !current[item.key].on } }))}
                  />
                  <item.icon className="size-3.5 text-[#64748b]" />
                  <span className="flex-1">{item.label}</span>
                  <input
                    value={defaults[item.key].qty}
                    inputMode="numeric"
                    onChange={(event) => {
                      const qty = event.target.value.replace(/[^\d]/g, "");
                      setDefaults((current) => ({ ...current, [item.key]: { ...current[item.key], qty } }));
                    }}
                    className="h-8 w-16 rounded-full bg-[#eef5fb] text-center text-[13px] font-semibold outline-none"
                  />
                  {defaults[item.key].on && defaults[item.key].qty !== "" && Number(defaults[item.key].qty) < FLOORS[item.key] && <span className="text-[11px] font-semibold text-rose-600">min {FLOORS[item.key]}</span>}
                </label>
              ))}
            </div>
            <p className="mt-2 text-[11px] text-[#94a3b8]">Defaults sirf naye links par apply hote hain. Existing rows ko edit karke per-link override karo.</p>

            {rows.length > 0 && (
              <div className="mt-3 max-h-64 space-y-2 overflow-auto">
                {rows.map((row) => (
                  <div key={row.link} className="rounded-2xl bg-[#f8fafc] p-3 text-[12px]">
                    <p className="truncate font-semibold">{row.link}</p>
                    <label className="mt-2 flex items-center gap-2">
                      Views
                      <input
                        value={row.views}
                        inputMode="numeric"
                        onChange={(event) => {
                          const next = event.target.value.replace(/[^\d]/g, "");
                          setRows((current) => current.map((item) => item.link === row.link ? { ...item, views: next } : item));
                        }}
                        className="h-8 w-24 rounded-lg bg-white px-2"
                      />
                      {row.views !== "" && Number(row.views) < 100 && <span className="text-rose-600">min 100</span>}
                    </label>
                    <div className="mt-2 grid grid-cols-2 gap-2">
                      {extras.map((item) => (
                        <label key={item.key} className="flex items-center gap-1">
                          <input
                            type="checkbox"
                            checked={row.extras[item.key].on}
                            onChange={() => setRows((current) => current.map((entry) => entry.link === row.link ? { ...entry, extras: { ...entry.extras, [item.key]: { ...entry.extras[item.key], on: !entry.extras[item.key].on } } } : entry))}
                          />
                          {item.label}
                          <input
                            value={row.extras[item.key].qty}
                            inputMode="numeric"
                            onChange={(event) => {
                              const qty = event.target.value.replace(/[^\d]/g, "");
                              setRows((current) => current.map((entry) => entry.link === row.link ? { ...entry, extras: { ...entry.extras, [item.key]: { ...entry.extras[item.key], qty } } } : entry));
                            }}
                            className="h-7 w-14 rounded-lg bg-white text-center"
                          />
                        </label>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>

          {rows.length === 0 && (
            <p className="flex items-center gap-2 rounded-2xl border border-[#f3e3c3] bg-[#fff8e8] px-3 py-3 text-[13px] text-amber-800">
              <Clock className="size-4" /> Kam se kam 1 valid link daalo.
            </p>
          )}
          <section className="rounded-3xl border border-[#e7eef6] bg-white p-4 text-center">
            <p className="text-[14px] text-[#64748b]">{rows.length} order(s) ready • Total {inr(total)}</p>
            <button type="button" disabled={pending || rows.length === 0} onClick={submit} className="mt-3 inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-[#5aa2f3] text-[15px] font-semibold text-white disabled:opacity-60">
              <Zap className="size-4" /> {pending ? "Submitting…" : "Submit All Orders"}
            </button>
          </section>
          {note && <p className="text-center text-[13px] text-[#334155]">{note}</p>}
        </div>
      ) : (
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <Stat label="TOTAL BATCHES" value={String(batches.length)} />
            <Stat label="COMPLETED" value={String(completed)} tone="text-emerald-500" />
            <Stat label="PROCESSING" value={String(processing)} />
            <Stat label="FAILED / PARTIAL" value={String(failed)} tone="text-rose-500" />
            <Stat label="SUCCESS RATE" value={`${rate}%`} tone="text-orange-500" />
          </div>
          <section className="space-y-2 rounded-3xl border border-[#e7eef6] bg-white p-3">
            <label className="flex h-11 items-center gap-2 rounded-xl bg-[#e7f0f8] px-3 text-[#94a3b8]">
              <Search className="size-4" />
              <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search by campaign name..." className="w-full bg-transparent text-[14px] text-[#0f172a] outline-none" />
            </label>
            <select value={status} onChange={(event) => setStatus(event.target.value)} className="h-11 w-full rounded-xl border border-[#e7eef6] bg-white px-3 text-[14px]">
              <option value="all">All statuses</option>
              <option value="completed">Completed</option>
              <option value="processing">Processing</option>
              <option value="failed">Failed / partial</option>
            </select>
            <button type="button" onClick={loadBatches} className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-[#e7eef6] text-[14px] font-semibold">
              <RefreshCw className="size-4" /> Refresh
            </button>
          </section>
          {shown.length === 0 ? (
            <section className="grid min-h-40 place-items-center rounded-3xl border border-[#e7eef6] bg-white px-6 py-10 text-center text-[14px] text-[#94a3b8]">
              <div>
                <BarChart3 className="mx-auto mb-3 size-6" />
                No batches yet. Create one from the "Create" tab.
              </div>
            </section>
          ) : (
            shown.map((batch) => (
              <article key={batch.id} className="rounded-3xl border border-[#e7eef6] bg-white p-4">
                <button type="button" onClick={() => setOpenId(openId === batch.id ? null : batch.id)} className="w-full text-left">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-semibold">{batch.campaign_name}</p>
                      <p className="text-[12px] text-[#94a3b8]">{batch.platform} · {batch.timeframe} · {new Date(batch.created_at).toLocaleString("en-IN", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}</p>
                    </div>
                    <span className={`rounded-full px-2 py-1 text-[11px] font-bold uppercase ${batch.status === "completed" ? "bg-emerald-50 text-emerald-600" : batch.status === "processing" ? "bg-sky-50 text-sky-600" : "bg-rose-50 text-rose-600"}`}>{batch.status}</span>
                  </div>
                  <p className="mt-2 text-[13px] text-[#334155]">{batch.placed_count}/{batch.link_count} links · {inr(batch.total_paise)}</p>
                </button>
                {openId === batch.id && (
                  <div className="mt-3 space-y-2 border-t border-[#eef2f6] pt-3 text-[12px]">
                    {batch.links.map((link) => (
                      <div key={link.link} className="rounded-xl bg-[#f8fafc] px-3 py-2">
                        <p className="truncate font-semibold">{link.link}</p>
                        <p className="text-[#64748b]">{link.order_number ?? "No order"} · {link.status} · {inr(link.total_paise)}</p>
                        {link.error && <p className="text-rose-600">{link.error}</p>}
                      </div>
                    ))}
                    {batch.status === "processing" && (
                      <button
                        type="button"
                        onClick={async () => {
                          await completeMassBatch({ data: batch.id });
                          loadBatches();
                        }}
                        className="h-10 w-full rounded-xl bg-[#111827] text-[13px] font-semibold text-white"
                      >
                        Mark batch complete
                      </button>
                    )}
                    <p className="text-[#94a3b8]">YoYoMedia already has the placed links. Mark complete only updates this desk.</p>
                  </div>
                )}
              </article>
            ))
          )}
        </div>
      )}
    </div>
  );
}

function Stat({ label, value, tone = "text-[#0f172a]" }: { label: string; value: string; tone?: string }) {
  return (
    <div className="rounded-2xl border border-[#e7eef6] bg-white px-4 py-3">
      <p className="text-[11px] font-semibold tracking-[0.14em] text-[#94a3b8]">{label}</p>
      <p className={`mt-1 text-[28px] font-semibold ${tone}`}>{value}</p>
    </div>
  );
}
