import { useEffect, useState, type ReactNode } from "react";
import { useRouter } from "@tanstack/react-router";
import {
  Activity,
  Brain,
  Calendar,
  Eye,
  Heart,
  Instagram,
  Link2,
  Lock,
  Music2,
  Pencil,
  Rocket,
  Send,
  Settings2,
  Share2,
  ShieldCheck,
  Bookmark,
  Clock,
  RefreshCw,
  ShieldAlert,
  Sparkles,
  Sprout,
  Wallet,
  X,
  Zap,
} from "lucide-react";
import { askPanelAi, engagementFloors, getCatalog, getWallet, placeOrder, type BundleItem, type BundleRow } from "@/lib/panel.functions";
import { inr } from "@/lib/money";
import {
  DEFAULT_PACE,
  GROWTH_FAMILIES,
  TEMPLATE_COUNT,
  autoRuns,
  answerOrganic,
  bestOrganicMix,
  buildRuns,
  planDrops,
  PROVIDER_MIN,
  curvePoints,
  formatDuration,
  growthSeries,
  growthTemplate,
  organicOpening,
  perRunSpread,
  ratioReport,
  riskLabel,
  windowHours,
  type Pace,
} from "@/lib/organic";

const VISIBLE = ["views", "likes", "shares", "reposts", "saves"];
const PRESETS = [10000, 50000, 100000, 500000, 1000000];
const CURVE_SERIES = [
  { key: "views", label: "Views", Icon: Eye, stroke: "#60a5fa", dot: "#2563eb", wash: "#93c5fd" },
  { key: "likes", label: "Likes", Icon: Heart, stroke: "#5eead4", dot: "#0f766e", wash: "#99f6e4" },
  { key: "saves", label: "Saves", Icon: Bookmark, stroke: "#fbbf24", dot: "#d97706", wash: "#fde68a" },
  { key: "shares", label: "Shares", Icon: Share2, stroke: "#3b82f6", dot: "#1d4ed8", wash: "#bfdbfe" },
] as const;
const TYPE_TONE: Record<string, { title: string; icon: string }> = {
  views: { title: "text-[#0f172a]", icon: "text-sky-500" },
  likes: { title: "text-emerald-600", icon: "text-rose-500" },
  shares: { title: "text-[#2563eb]", icon: "text-[#2563eb]" },
  reposts: { title: "text-emerald-600", icon: "text-emerald-500" },
  saves: { title: "text-amber-600", icon: "text-amber-500" },
};

const ICONS: Record<string, typeof Eye> = {
  views: Eye,
  likes: Heart,
  shares: Share2,
  reposts: RefreshCw,
  saves: Bookmark,
};

function lineQty(item: BundleItem, base: number, overrides: Record<string, number>) {
  if (overrides[item.engagement_type] != null) return overrides[item.engagement_type];
  if (item.is_base) return base;
  return Math.round((base * item.ratio_bps) / 10000);
}

function linePrice(item: BundleItem, quantity: number) {
  const rate = item.price_per_10k_paise || item.price_per_1k_paise * 10;
  return Math.max(1, Math.round((quantity * rate) / 10000));
}

function Switch({ on, onClick }: { on: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      onClick={onClick}
      className={`relative h-7 w-12 shrink-0 rounded-full transition ${on ? "bg-[#3b82f6]" : "bg-[#dbe4ee]"}`}
    >
      <span className={`absolute top-0.5 size-6 rounded-full bg-white shadow transition ${on ? "left-5" : "left-0.5"}`} />
    </button>
  );
}

export function EngagementConsole() {
  const router = useRouter();
  const [bundles, setBundles] = useState<BundleRow[]>([]);
  const [platform, setPlatform] = useState<"instagram" | "tiktok">("instagram");
  const [link, setLink] = useState("");
  const [base, setBase] = useState(10000);
  const [custom, setCustom] = useState("10000");
  const [enabled, setEnabled] = useState<string[]>(VISIBLE);
  const [overrides, setOverrides] = useState<Record<string, number>>({});
  const [pace, setPace] = useState<Record<string, Pace>>({});
  const [open, setOpen] = useState<string | null>(null);
  const [runsOpen, setRunsOpen] = useState<string | null>(null);
  const [draw, setDraw] = useState(false);
  const [curves, setCurves] = useState<Record<string, number[]>>({
    views: [0.02, 1],
    likes: [0.02, 1],
    saves: [0.02, 1],
    shares: [0.02, 1],
  });
  const [curveKey, setCurveKey] = useState("views");
  const [drag, setDrag] = useState<number | null>(null);
  const [preview, setPreview] = useState(true);
  const [pattern, setPattern] = useState(223);
  const [picker, setPicker] = useState(false);
  const [family, setFamily] = useState<string>("random-walk");
  const [algo, setAlgo] = useState(true);
  const [ratiosOn, setRatiosOn] = useState(true);
  const [ask, setAsk] = useState(false);
  const [chat, setChat] = useState<{ role: "user" | "assistant"; text: string; apply?: boolean; mix?: Record<string, number> | null }[]>([]);
  const [aiPending, setAiPending] = useState(false);
  const [mixNote, setMixNote] = useState("");
  const [draft, setDraft] = useState("");
  const [floors, setFloors] = useState<Record<string, number>>({ views: 100, likes: 10, shares: 10, saves: 50, reposts: 10 });
  const [qtyText, setQtyText] = useState<Record<string, string>>({});
  const [hourText, setHourText] = useState<Record<string, string>>({});
  const [runsText, setRunsText] = useState<Record<string, string>>({});
  const [balance, setBalance] = useState(0);
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  useEffect(() => {
    engagementFloors({ data: platform })
      .then((next) => setFloors((current) => ({ ...current, ...next })))
      .catch(() => undefined);
  }, [platform]);

  useEffect(() => {
    if (!ratiosOn || base < 100) return;
    setOverrides(bestOrganicMix(base, floors));
    setQtyText({});
    setEnabled((current) => Array.from(new Set([...current, "likes", "shares", "reposts", "saves"])));
    setMixNote("Ratio set. Jo number provider minimum se neeche tha, woh minimum pe chipak gaya.");
  }, [base, ratiosOn, floors]);

  useEffect(() => {
    getCatalog()
      .then((catalog) => setBundles(catalog.bundles))
      .catch((err: unknown) => setError(err instanceof Error ? err.message : "Catalog failed."));
    getWallet()
      .then((wallet) => setBalance(wallet.balance_paise))
      .catch(() => setBalance(0));
  }, []);

  const bundle = bundles.find((item) => item.platform === platform) ?? bundles[0];
  const cards = (bundle?.items ?? []).filter((item) => VISIBLE.includes(item.engagement_type) && (item.is_base || enabled.includes(item.engagement_type) || VISIBLE.includes(item.engagement_type)));
  const shown = cards.filter((item) => VISIBLE.includes(item.engagement_type));

  const qtyOf = (item: BundleItem) => {
    const on = item.is_base || enabled.includes(item.engagement_type);
    if (!on) return 0;
    const floor = floors[item.engagement_type] ?? (item.is_base ? 100 : 1);
    return Math.min(item.max_quantity, Math.max(floor, lineQty(item, base, overrides)));
  };

  const active = shown.filter((item) => item.is_base || enabled.includes(item.engagement_type));
  const quantities = Object.fromEntries(active.map((item) => [item.engagement_type, qtyOf(item)]));
  const totalPaise = active.reduce((sum, item) => sum + linePrice(item, qtyOf(item)), 0);
  const totalQty = active.reduce((sum, item) => sum + qtyOf(item), 0);
  const report = ratioReport(quantities);
  const canPay = balance >= totalPaise && totalPaise > 0;

  function setBaseQty(next: number) {
    const value = Math.max(100, Math.min(10_000_000, Math.floor(next) || 100));
    setBase(value);
    setCustom(String(value));
    setQtyText({});
    setRatiosOn(true);
    setOverrides(bestOrganicMix(value, floors));
    setEnabled((current) => Array.from(new Set([...current, "likes", "shares", "reposts", "saves"])));
  }

  function paceFor(type: string): Pace {
    return pace[type] ?? DEFAULT_PACE;
  }

  function patchPace(type: string, next: Partial<Pace>) {
    setPace((current) => {
      const prev = current[type] ?? DEFAULT_PACE;
      return { ...current, [type]: { ...prev, ...next } };
    });
  }

  function applyMix(mix?: Record<string, number> | null) {
    const next = mix && Object.keys(mix).length ? mix : bestOrganicMix(base);
    setOverrides((current) => ({ ...current, ...next }));
    setQtyText({});
    setEnabled((current) => Array.from(new Set([...current, "likes", "shares", "reposts", "saves"])));
    return next;
  }

  async function askOrganic(question: string) {
    const text = question.trim();
    if (!text || aiPending) return;
    const viewsPace = paceFor("views");
    const runs = viewsPace.runsMode === "manual" && viewsPace.runs > 0 ? viewsPace.runs : autoRuns(Math.max(quantities.views || base, 1), "views");
    const hours = windowHours(viewsPace, runs);
    const finish = new Date(Date.now() + hours * 3600 * 1000).toLocaleString("en-IN", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
    setChat((current) => [...current, { role: "user", text }]);
    setDraft("");
    setAiPending(true);
    const local = () => answerOrganic(text, { quantities, health: report.health, botting: report.botting, hours, runs, peak: viewsPace.peak, finish });
    try {
      const result = await askPanelAi({
        data: {
          question: text,
          context: `Link pasted: ${/^https?:\/\//.test(link.trim())}. Views ${quantities.views || base}, likes ${quantities.likes || 0}, shares ${quantities.shares || 0}, saves ${quantities.saves || 0}, reposts ${quantities.reposts || 0}. Health ${report.health}/100. Botting risk ${report.botting}%. Runs ${runs}. Window ${hours.toFixed(1)} hours. Peak ${viewsPace.peak ? "on" : "off"}. Finish ${finish}.`,
        },
      });
      setChat((current) => [...current, { role: "assistant", text: result.text, apply: result.apply, mix: result.mix }]);
    } catch {
      setChat((current) => [...current, { role: "assistant", text: local(), apply: /ratio|suggest|best|mix/i.test(text) }]);
    } finally {
      setAiPending(false);
    }
  }

  function openAssistant() {
    const linkReady = /^https?:\/\//.test(link.trim());
    setChat([{ role: "assistant", text: organicOpening({ linkReady, quantities, botting: report.botting }) }]);
    setDraft("");
    setAsk(true);
  }

  async function submit() {
    if (!bundle) return;
    setError("");
    if (!/^https?:\/\//.test(link.trim())) {
      setError("Please enter a valid link.");
      return;
    }
    if (!custom || Number(custom) < (floors.views || 100)) {
      setError(`Below ${floors.views || 100} not allowed.`);
      return;
    }
    for (const item of active) {
      if (item.is_base) continue;
      const floor = floors[item.engagement_type] ?? 1;
      const raw = qtyText[item.engagement_type];
      if (raw !== undefined && (raw === "" || Number(raw) < floor)) {
        setError(`Below ${floor} not allowed.`);
        return;
      }
      const current = paceFor(item.engagement_type);
      if (current.window === "custom") {
        const hoursRaw = hourText[item.engagement_type] ?? String(current.customHours || "");
        if (hoursRaw === "" || Number(hoursRaw) < 1) {
          setError("Below 1 not allowed.");
          return;
        }
      }
      if (current.runsMode === "manual") {
        const runsRaw = runsText[item.engagement_type] ?? String(current.runs || "");
        const chunk = floors[item.engagement_type] ?? 10;
        const maxRuns = Math.max(1, Math.floor(Math.max(qtyOf(item), 1) / chunk));
        if (runsRaw === "" || Number(runsRaw) < 1) {
          setError("Below 1 not allowed.");
          return;
        }
        if (Number(runsRaw) > maxRuns) {
          setError(`Above ${maxRuns} not allowed.`);
          return;
        }
      }
    }
    if (!canPay) {
      setError("Insufficient balance.");
      return;
    }
    setPending(true);
    try {
      const viewsPace = paceFor("views");
      const delivery: Record<string, { hours: number; runs: number; variance: number; peak: boolean; curve: number[] }> = {};
      for (const item of active) {
        const current = paceFor(item.engagement_type);
        const lineRuns = current.runsMode === "manual" && current.runs > 0
          ? current.runs
          : autoRuns(Math.max(quantities[item.engagement_type] || base, 1), item.engagement_type);
        delivery[item.engagement_type] = {
          hours: windowHours(current, lineRuns),
          runs: lineRuns,
          variance: current.variance,
          peak: current.peak,
          curve: curves[item.engagement_type] ?? curves.views ?? [0.02, 1],
        };
      }
      const viewsRuns = delivery.views?.runs ?? autoRuns(quantities.views || base, "views");
      await placeOrder({
        data: {
          bundleId: bundle.id,
          link: link.trim(),
          baseQuantity: base,
          organic: algo,
          intervalHours: Math.max(1, Math.round((delivery.views?.hours ?? windowHours(viewsPace, viewsRuns)) / Math.max(1, viewsRuns))),
          variancePercent: viewsPace.variance,
          enabledTypes: active.map((item) => item.engagement_type),
          quantities,
          delivery,
        },
      });
      await router.navigate({ to: "/engagement-orders" });
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Order failed.");
    } finally {
      setPending(false);
    }
  }

  const curvePointsFor = curves[curveKey] ?? [0.02, 1];
  const curveTone = CURVE_SERIES.find((series) => series.key === curveKey) ?? CURVE_SERIES[0];

  return (
    <div className="mx-auto max-w-xl space-y-4 pb-24">
      <section className="rounded-[28px] border border-[#e7eef6] bg-white p-5 shadow-sm">
        <div className="mb-3 flex items-start justify-between">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-[#f4f7fb] px-3 py-1 text-[10px] font-semibold tracking-[0.16em] text-[#64748b]">
            <span className="size-1.5 rounded-full bg-emerald-400" /> ENGAGEMENT CONSOLE
          </span>
          <span className="grid size-10 place-items-center rounded-2xl bg-[#e8f1ff] text-[#3b82f6]">
            <Rocket className="size-4" />
          </span>
        </div>
        <h1 className="font-['Playfair_Display',Georgia,serif] text-[34px] leading-none font-bold text-[#1e3a5f]">
          Organic <span className="italic text-[#2458c5]">Full Engagement</span>
        </h1>
        <p className="mt-2 max-w-sm text-[13px] text-[#64748b]">
          One link — every engagement type, dispatched with humanlike organic pacing.
        </p>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <ToggleCard
            on={algo}
            tone="emerald"
            title="AI Organic Algorithm"
            badge="ACTIVE"
            text="Unique S-curve · Random variance · Anti-bot"
            icon={<Brain className="size-4" />}
            onClick={() => setAlgo((value) => !value)}
          />
          <ToggleCard
            on={ratiosOn}
            tone="blue"
            title="AI Smart Ratios"
            badge="AUTO"
            text="Optimized for platform algorithms"
            icon={<Sparkles className="size-4" />}
            onClick={() => {
              setRatiosOn((value) => {
                const next = !value;
                if (next) {
                  setOverrides(bestOrganicMix(base, floors));
                  setEnabled((current) => Array.from(new Set([...current, "likes", "shares", "reposts", "saves"])));
                }
                return next;
              });
            }}
          />
        </div>
      </section>

      <section className="rounded-[24px] border border-[#e7eef6] bg-white p-4 shadow-sm">
        <h2 className="mb-3 flex items-center gap-2 text-[15px] font-semibold">
          <Rocket className="size-4 text-[#64748b]" /> Select Platform
        </h2>
        <div className="flex gap-2">
          <PlatformButton active={platform === "instagram"} onClick={() => setPlatform("instagram")} icon={<Instagram className="size-4" />} label="INSTAGRAM" gradient="from-emerald-400 via-teal-400 to-violet-500" />
          <PlatformButton active={platform === "tiktok"} onClick={() => setPlatform("tiktok")} icon={<Music2 className="size-4" />} label="TIKTOK" gradient="from-cyan-300 to-emerald-300" />
        </div>
      </section>

      <section className="rounded-[24px] border border-[#e7eef6] bg-white p-4 shadow-sm">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-[15px] font-semibold">
            <Link2 className="size-4 text-[#64748b]" /> Video/Post Link
          </h2>
          <button type="button" onClick={openAssistant} className="inline-flex items-center gap-1 rounded-full border border-amber-200 bg-amber-50 px-3 py-1 text-[12px] font-semibold text-amber-700">
            <Sparkles className="size-3.5" /> Ask AI
          </button>
        </div>
        <input
          value={link}
          onChange={(event) => setLink(event.target.value)}
          placeholder={platform === "tiktok" ? "https://tiktok.com/..." : "https://instagram.com/..."}
          className="h-12 w-full rounded-2xl border border-transparent bg-[#eef5fb] px-4 text-[14px] outline-none focus:border-[#93c5fd]"
        />
      </section>

      <section className="rounded-[24px] border border-[#e7eef6] bg-white p-4 shadow-sm">
        <h2 className="mb-3 flex items-center gap-2 text-[15px] font-semibold">
          <Eye className="size-4 text-[#64748b]" /> Base Views Quantity
        </h2>
        <div className="flex flex-wrap gap-2">
          {PRESETS.map((preset) => (
            <button
              key={preset}
              type="button"
              onClick={() => setBaseQty(preset)}
              className={`h-10 min-w-14 rounded-xl px-3 text-[13px] font-semibold ${base === preset ? "bg-[#111827] text-white" : "bg-[#f3f6fa] text-[#334155]"}`}
            >
              {preset >= 1000000 ? "1M" : `${preset / 1000}K`}
            </button>
          ))}
        </div>
        <label className="mt-3 flex items-center gap-2 text-[13px] text-[#64748b]">
          or custom:
          <input
            value={custom}
            inputMode="numeric"
            onChange={(event) => {
              const raw = event.target.value.replace(/[^\d]/g, "");
              setCustom(raw);
              const next = Number(raw);
              if (next >= (floors.views || 100)) setBaseQty(Math.min(10_000_000, next));
            }}
            className="h-10 w-28 rounded-xl bg-[#eef5fb] px-3 font-semibold text-[#0f172a] outline-none"
          />
          views
        </label>
        {custom !== "" && Number(custom) < (floors.views || 100) && <p className="mt-2 text-[12px] font-semibold text-rose-600">Below {floors.views || 100} not allowed</p>}
        {mixNote && custom !== "" && Number(custom) >= (floors.views || 100) && <p className="mt-2 text-[12px] text-[#1d4ed8]">{mixNote}</p>}
      </section>

      <section>
        <div className="mb-2 flex items-end justify-between">
          <div>
            <h2 className="text-[18px] font-semibold">Engagement Breakdown</h2>
            <p className="text-[13px] text-[#64748b]">Customize organic settings per type</p>
          </div>
          <span className="rounded-full bg-[#111827] px-3 py-1 text-[12px] font-semibold text-white">{active.length} active</span>
        </div>
        <div className="space-y-3">
          {shown.map((item) => {
            const on = item.is_base || enabled.includes(item.engagement_type);
            const quantity = on ? qtyOf(item) : 0;
            const requested = paceFor(item.engagement_type).runsMode === "manual" && paceFor(item.engagement_type).runs > 0
              ? paceFor(item.engagement_type).runs
              : autoRuns(Math.max(quantity, 1), item.engagement_type);
            const currentPace = paceFor(item.engagement_type);
            const hours = windowHours(currentPace, requested);
            const rows = planDrops({
              quantity,
              type: item.engagement_type,
              runs: requested,
              hours,
              curve: curves[item.engagement_type] ?? curves.views,
              variance: currentPace.variance,
              peak: currentPace.peak,
              min: floors[item.engagement_type],
            });
            const runs = rows.length || requested;
            const floor = floors[item.engagement_type] ?? (item.is_base ? 100 : 1);
            const qtyRaw = item.is_base ? custom : (qtyText[item.engagement_type] ?? String(quantity));
            const Icon = ICONS[item.engagement_type] ?? Eye;
            const tone = TYPE_TONE[item.engagement_type] ?? TYPE_TONE.views;
            const risk = riskLabel(currentPace.variance);
            const spread = perRunSpread(quantity, runs, currentPace.variance);
            const chunk = floors[item.engagement_type] ?? PROVIDER_MIN[item.engagement_type] ?? 10;
            const maxRuns = Math.max(1, Math.floor(Math.max(quantity, 1) / chunk));
            const manual = paceFor(item.engagement_type).runsMode === "manual";
            return (
              <article key={item.engagement_type} className="rounded-[24px] border border-[#e7eef6] bg-white p-4 shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <Icon className={`size-4 ${tone.icon}`} />
                      <p className={`font-semibold ${tone.title}`}>{item.name.replace(/^(Stage|House|Aisle|Pocket|Cue) /, "") || item.engagement_type}</p>
                      {item.is_base && <span className="rounded bg-[#111827] px-1.5 py-0.5 text-[9px] font-bold text-white">BASE</span>}
                    </div>
                    <p className="mt-1 text-[11px] font-semibold tracking-wide text-[#3b82f6]">
                      <Sparkles className="mr-1 inline size-3" />
                      {runs} RUNS · {formatDuration(hours).replace("~", "~").toUpperCase()} · min {chunk}/order
                    </p>
                    <p className="text-[11px] text-[#94a3b8]">Min: {(floors[item.engagement_type] ?? item.min_quantity).toLocaleString("en-IN")} • Max: {item.max_quantity.toLocaleString("en-IN")}</p>
                  </div>
                  <input
                    disabled={!on}
                    value={qtyRaw}
                    inputMode="numeric"
                    onChange={(event) => {
                      const raw = event.target.value.replace(/[^\d]/g, "");
                      if (item.is_base) {
                        setCustom(raw);
                        const next = Number(raw);
                        if (raw !== "" && next >= floor) setBaseQty(Math.min(10_000_000, next));
                        return;
                      }
                      setQtyText((current) => ({ ...current, [item.engagement_type]: raw }));
                      setRatiosOn(false);
                      const next = Number(raw);
                      if (raw !== "" && next >= floor) {
                        setOverrides((current) => ({ ...current, [item.engagement_type]: Math.min(item.max_quantity, next) }));
                      }
                    }}
                    className="h-10 w-24 rounded-full border border-[#e7eef6] bg-white text-center text-[13px] font-semibold outline-none"
                  />
                  <span className="w-16 text-right text-[13px] font-semibold text-[#64748b]">{on ? inr(linePrice(item, quantity)) : "—"}</span>
                  <Switch
                    on={on}
                    onClick={() => {
                      if (item.is_base) return;
                      setEnabled((current) => current.includes(item.engagement_type) ? current.filter((type) => type !== item.engagement_type) : [...current, item.engagement_type]);
                    }}
                  />
                </div>
                {on && qtyRaw !== "" && Number(qtyRaw) < floor && <p className="mt-2 text-[12px] font-semibold text-rose-600">Below {floor} not allowed</p>}
                <button type="button" onClick={() => setOpen(open === item.engagement_type ? null : item.engagement_type)} className="mx-auto mt-3 flex items-center gap-1 text-[11px] font-semibold tracking-wide text-[#94a3b8]">
                  <Settings2 className="size-3" /> SETTINGS {open === item.engagement_type ? "▴" : "▾"}
                </button>
                {open === item.engagement_type && (
                  <div className="mt-3 space-y-3 border-t border-[#eef2f6] pt-3 text-[13px]">
                    <p className="text-[11px] font-semibold tracking-wide text-[#94a3b8]">DELIVERY TIME</p>
                    <div className="flex flex-wrap gap-2">
                      {(["auto", "6h", "12h", "24h", "48h", "custom"] as const).map((window) => (
                        <button key={window} type="button" onClick={() => patchPace(item.engagement_type, { window })} className={`rounded-full px-3 py-1 text-[12px] font-semibold ${paceFor(item.engagement_type).window === window ? "bg-[#111827] text-white" : "bg-[#f3f6fa]"}`}>
                          {window === "auto" ? "Auto" : window === "custom" ? "Custom" : window}
                        </button>
                      ))}
                    </div>
                    {paceFor(item.engagement_type).window === "custom" && (
                      <label className="block">
                        <span className="flex items-center gap-2">
                          <input
                            inputMode="numeric"
                            value={hourText[item.engagement_type] ?? String(paceFor(item.engagement_type).customHours || "")}
                            placeholder="hours"
                            onChange={(event) => {
                              const raw = event.target.value.replace(/[^\d]/g, "");
                              setHourText((current) => ({ ...current, [item.engagement_type]: raw }));
                              const next = Number(raw);
                              if (raw !== "" && next >= 1) patchPace(item.engagement_type, { window: "custom", customHours: Math.min(24 * 30, next) });
                            }}
                            className="h-10 w-24 rounded-xl bg-[#f3f6fa] px-3 text-[14px] font-semibold outline-none"
                          />
                          <span className="text-[12px] text-[#64748b]">hours. This line finishes in {formatDuration(hours).replace("~", "")}.</span>
                        </span>
                        {(hourText[item.engagement_type] ?? "") !== "" && Number(hourText[item.engagement_type]) < 1 && <p className="mt-1 text-[12px] font-semibold text-rose-600">Below 1 not allowed</p>}
                      </label>
                    )}
                    <div className="flex items-center justify-between">
                      <p className="text-[11px] font-semibold tracking-wide text-[#94a3b8]">NUMBER OF RUNS</p>
                      <p className="text-[11px] text-[#94a3b8]">max {maxRuns} ({quantity.toLocaleString("en-IN")} ÷ {chunk})</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button type="button" onClick={() => { setRunsText((current) => { const next = { ...current }; delete next[item.engagement_type]; return next; }); patchPace(item.engagement_type, { runsMode: "auto", runs: 0 }); }} className={`h-10 rounded-xl px-4 font-semibold ${manual ? "bg-[#f3f6fa] text-[#334155]" : "bg-[#111827] text-white"}`}>Auto</button>
                      <input
                        inputMode="numeric"
                        value={runsText[item.engagement_type] ?? (manual ? String(paceFor(item.engagement_type).runs || "") : "")}
                        placeholder={manual ? "runs" : `${runs} runs (auto)`}
                        onChange={(event) => {
                          const raw = event.target.value.replace(/[^\d]/g, "");
                          setRunsText((current) => ({ ...current, [item.engagement_type]: raw }));
                          if (raw === "") {
                            patchPace(item.engagement_type, { runsMode: "manual", runs: 0 });
                            return;
                          }
                          const next = Number(raw);
                          if (next >= 1 && next <= maxRuns) patchPace(item.engagement_type, { runsMode: "manual", runs: next });
                        }}
                        className="h-10 min-w-0 flex-1 rounded-xl bg-[#f3f6fa] px-3 font-semibold text-[#0f172a] outline-none placeholder:font-medium placeholder:text-[#94a3b8]"
                      />
                    </div>
                    {runsText[item.engagement_type] !== undefined && runsText[item.engagement_type] !== "" && Number(runsText[item.engagement_type]) < 1 && <p className="text-[12px] font-semibold text-rose-600">Below 1 not allowed</p>}
                    {runsText[item.engagement_type] !== undefined && Number(runsText[item.engagement_type]) > maxRuns && <p className="text-[12px] font-semibold text-rose-600">Above {maxRuns} not allowed</p>}
                    <div className="flex items-center justify-between">
                      <p className="text-[11px] font-semibold tracking-wide text-[#94a3b8]">RANDOM VARIANCE</p>
                      <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[11px] font-bold text-amber-700">±{paceFor(item.engagement_type).variance}%</span>
                    </div>
                    <input type="range" min={10} max={50} value={paceFor(item.engagement_type).variance} onChange={(event) => patchPace(item.engagement_type, { variance: Number(event.target.value) })} className="w-full accent-amber-500" />
                    <div className={`rounded-2xl border p-3 ${risk.tone === "amber" ? "border-amber-200 bg-amber-50" : risk.tone === "rose" ? "border-rose-200 bg-rose-50" : "border-emerald-200 bg-emerald-50"}`}>
                      <div className="mb-2 flex items-center justify-between font-semibold">
                        <span>Detection Risk</span>
                        <span className="rounded-full bg-white px-2 py-0.5 text-[11px]">{risk.label}</span>
                      </div>
                      <div className="h-2 overflow-hidden rounded-full bg-white">
                        <div className="h-full rounded-full bg-amber-400" style={{ width: `${paceFor(item.engagement_type).variance * 1.6}%` }} />
                      </div>
                      <p className="mt-2 text-[12px] text-amber-700">{risk.hint}</p>
                    </div>
                    <div className="flex items-center justify-between rounded-2xl bg-[#f8fafc] px-3 py-2">
                      <span>Per run:</span>
                      <span>-{spread} to +{spread}</span>
                    </div>
                    <div
                      role="switch"
                      aria-checked={paceFor(item.engagement_type).peak}
                      onClick={() => patchPace(item.engagement_type, { peak: !paceFor(item.engagement_type).peak })}
                      className={`flex w-full cursor-pointer items-center justify-between rounded-2xl px-3 py-2 text-left ${paceFor(item.engagement_type).peak ? "bg-amber-50 ring-1 ring-amber-200" : "bg-[#f4f7fb]"}`}
                    >
                      <div>
                        <p className="flex items-center gap-1 text-[12px] font-semibold tracking-wide text-[#334155]">
                          <Lock className="size-3.5" /> PEAK HOURS BOOST
                          {paceFor(item.engagement_type).peak && <span className="rounded-full bg-amber-500 px-1.5 text-[10px] font-bold text-white">ON</span>}
                        </p>
                        <p className="text-[11px] text-[#94a3b8]">{paceFor(item.engagement_type).peak ? "Bigger drops between 6–11 PM IST" : "More during 6-11 PM IST"}</p>
                      </div>
                      <span className={`relative h-7 w-12 shrink-0 rounded-full transition ${paceFor(item.engagement_type).peak ? "bg-[#3b82f6]" : "bg-[#dbe4ee]"}`}>
                        <span className={`absolute top-0.5 size-6 rounded-full bg-white shadow transition ${paceFor(item.engagement_type).peak ? "left-5" : "left-0.5"}`} />
                      </span>
                    </div>
                    <div className="rounded-2xl bg-[#f8fafc] p-3">
                      <p className="mb-2 flex items-center gap-1 font-semibold"><Calendar className="size-4" /> Schedule Preview</p>
                      <div className="grid grid-cols-3 gap-2 text-center">
                        <Stat n={String(rows.length)} l="orders" />
                        <Stat n={formatDuration(hours / Math.max(1, runs))} l="interval" />
                        <Stat n={rows[rows.length - 1]?.at.toLocaleString("en-IN", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }) ?? ""} l="finish" />
                      </div>
                      <button type="button" onClick={() => setRunsOpen(runsOpen === item.engagement_type ? null : item.engagement_type)} className="mt-3 flex w-full items-center justify-center gap-1 text-[12px] font-semibold text-[#64748b]">
                        <span className="tracking-widest text-[#cbd5e1]">≡</span> {rows.length} YoYoMedia orders {runsOpen === item.engagement_type ? "▴" : "▾"}
                      </button>
                      {runsOpen === item.engagement_type && (
                        <ol className="mt-2 max-h-56 space-y-2 overflow-auto text-[12px]">
                          {rows.map((row, index) => (
                            <li key={index} className="flex items-center justify-between gap-2">
                              <span className="flex items-center gap-2">
                                <span className="grid size-5 place-items-center rounded-full bg-[#111827] text-[10px] font-bold text-white">{index + 1}</span>
                                {index === 0 ? "places now" : row.at.toLocaleString("en-IN", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}
                              </span>
                              <span className="font-semibold text-[#0f172a]">+{row.amount.toLocaleString("en-IN")}</span>
                            </li>
                          ))}
                        </ol>
                      )}
                    </div>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      </section>

      <section className="rounded-[24px] border border-[#e7eef6] bg-white p-4 shadow-sm">
        <div className="mb-1 flex items-center justify-between">
          <h2 className="flex items-center gap-2 font-semibold">
            <Pencil className="size-4" /> Draw Your Growth Curve
            {draw && <span className="rounded-full bg-[#dbeafe] px-2 py-0.5 text-[10px] font-bold text-[#1d4ed8]">Draw Mode ON</span>}
          </h2>
          <label className="flex items-center gap-2 text-[12px] text-[#64748b]">
            {draw ? "Drawing" : "View Only"}
            <Switch on={draw} onClick={() => setDraw((value) => !value)} />
          </label>
        </div>
        <p className="mb-3 text-[12px] text-[#94a3b8]">{draw ? "Click to add points · Drag to adjust · Double-click to remove" : "Turn Drawing on, then drag the dots on the line you select."}</p>
        <div className="mb-3 flex flex-wrap gap-2">
          {CURVE_SERIES.map((series) => {
            const activeSeries = curveKey === series.key;
            return (
              <button
                key={series.key}
                type="button"
                onClick={() => {
                  setCurveKey(series.key);
                  setDrag(null);
                }}
                className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[12px] font-semibold ${activeSeries ? "text-[#0f172a]" : "border-[#e7eef6] bg-white text-[#64748b]"}`}
                style={activeSeries ? { borderColor: series.stroke, background: "#fff", boxShadow: `inset 0 0 0 1px ${series.stroke}` } : undefined}
              >
                <series.Icon className="size-3.5" style={{ color: series.dot }} />
                {series.label}
                <span className="grid size-5 place-items-center rounded-full text-[10px] font-bold text-white" style={{ background: series.dot }}>{(curves[series.key] ?? []).length}</span>
              </button>
            );
          })}
        </div>
        <Curve
          points={curvePointsFor}
          draw={draw}
          color={curveTone.stroke}
          wash={curveTone.wash}
          dot={curveTone.dot}
          onChange={(next) => setCurves((current) => ({ ...current, [curveKey]: next }))}
          drag={drag}
          setDrag={setDrag}
        />
        {draw && (
          <div className="mt-3 flex flex-wrap gap-2">
            <Preset label="Viral Spike" onClick={() => setCurves((current) => ({ ...current, [curveKey]: curvePoints("viral") }))} />
            <Preset label="Steady Growth" onClick={() => setCurves((current) => ({ ...current, [curveKey]: curvePoints("steady") }))} />
            <Preset label="S-Curve" onClick={() => setCurves((current) => ({ ...current, [curveKey]: curvePoints("s") }))} />
            <Preset label="Double Peak" onClick={() => setCurves((current) => ({ ...current, [curveKey]: curvePoints("double") }))} />
            <button type="button" onClick={() => setCurves((current) => ({ ...current, [curveKey]: [0.02, 1] }))} className="ml-auto inline-flex items-center text-[12px] font-semibold text-[#64748b]"><RefreshCw className="mr-1 size-3" />Reset</button>
          </div>
        )}
        <div className="mt-3 flex flex-wrap gap-3 text-[12px] text-[#64748b]">
          <span className="inline-flex items-center gap-1"><span className="size-2 rounded-full bg-[#60a5fa]" /> {(quantities.views ?? 0).toLocaleString("en-IN")}</span>
          <span className="inline-flex items-center gap-1"><Heart className="size-3 text-rose-400" /> {(quantities.likes ?? 0).toLocaleString("en-IN")}</span>
          <span className="inline-flex items-center gap-1"><Bookmark className="size-3 text-amber-400" /> {(quantities.saves ?? 0).toLocaleString("en-IN")}</span>
          <span className="inline-flex items-center gap-1"><Share2 className="size-3 text-sky-500" /> {(quantities.shares ?? 0).toLocaleString("en-IN")}</span>
        </div>
      </section>

      <button type="button" onClick={() => setPreview((value) => !value)} className="mx-auto flex items-center gap-2 rounded-full border border-[#e7eef6] bg-white px-4 py-2 text-[13px] font-semibold text-[#64748b]">
        <Eye className="size-4" /> {preview ? "Hide delivery preview" : "Show delivery preview"}
      </button>

      {preview && (
        <Delivery
          pattern={pattern}
          picker={picker}
          family={family}
          onFamily={setFamily}
          onTogglePicker={() => setPicker((value) => !value)}
          onPattern={(id) => {
            setPattern(id);
            setFamily(growthTemplate(id).name);
            setPicker(false);
          }}
          onNew={() => {
            const next = 1 + Math.floor(Math.random() * TEMPLATE_COUNT);
            setPattern(next);
            setFamily(growthTemplate(next).name);
          }}
          quantities={quantities}
          pace={pace}
        />
      )}

      {report.off && (
        <section className="rounded-[24px] border border-amber-200 bg-amber-50 p-4 text-[13px]">
          <p className="font-semibold text-amber-800">
            <ShieldAlert className="mr-1 inline size-4" /> Ratios look off — order will still place
            <span className="ml-2 rounded-full bg-white px-2 py-0.5 text-[11px]">Botting {report.botting}% · Health {report.health}/100</span>
          </p>
          <div className="mt-2 flex flex-wrap gap-2">
            {report.checks.map((check) => (
              <span key={check.key} className="rounded-full bg-white px-2 py-1 text-[11px]">{check.label}: {check.pct.toFixed(2)}%</span>
            ))}
          </div>
          <ul className="mt-2 list-disc pl-5 text-[12px] text-amber-900">
            {report.suggestions.map((line) => <li key={line}>{line}</li>)}
          </ul>
          <p className="mt-2 text-[12px] text-amber-800">Tip: Instagram's organic norms are ~4–10% likes, ~0.3–1.5% comments per view. Stay close to these for the most natural-looking growth.</p>
        </section>
      )}

      <section className="rounded-[24px] border border-[#e7eef6] bg-white p-4 shadow-sm">
        <p className="text-[28px] font-bold text-[#2458c5]">{inr(totalPaise)} <span className="text-[16px] font-semibold text-[#64748b]">total</span></p>
        <p className="text-[13px] text-[#64748b]">{totalQty.toLocaleString("en-IN")} engagements • {active.length} types</p>
        <div className="mt-3 flex items-center gap-3">
          <div className="text-[12px]">
            <p className="flex items-center gap-1 text-[#64748b]"><Wallet className="size-3" /> Balance: {inr(balance)}</p>
            {!canPay && <p className="font-semibold text-rose-500">Insufficient balance</p>}
          </div>
          <button type="button" disabled={!canPay || pending} onClick={submit} className="h-11 flex-1 rounded-xl bg-[#3b82f6] text-[14px] font-semibold text-white disabled:opacity-60">
            {pending ? "Placing…" : `Place Order — ${inr(totalPaise)}`}
          </button>
        </div>
        {error && <p className="mt-2 text-[13px] text-rose-600">{error}</p>}
      </section>

      {ask && (
        <div className="fixed inset-0 z-40 grid place-items-center bg-black/25 p-4" onClick={() => setAsk(false)}>
          <div className="flex max-h-[88vh] w-full max-w-[440px] flex-col overflow-hidden rounded-[28px] border border-[#e7eef6] bg-white shadow-2xl" onClick={(event) => event.stopPropagation()}>
            <div className="flex items-start justify-between px-5 pt-5">
              <div>
                <p className="flex items-center gap-2 font-['Playfair_Display',Georgia,serif] text-[22px] font-semibold text-[#1f2937]">
                  <Sparkles className="size-4 text-amber-500" /> Organic AI Assistant
                </p>
                <p className="mt-1 text-[13px] text-[#64748b]">Analyzes your link and gives real-time engagement guidance.</p>
              </div>
              <button type="button" onClick={() => setAsk(false)} className="grid size-8 place-items-center rounded-full text-[#94a3b8] hover:bg-[#f4f7fb]" aria-label="Close">
                <X className="size-4" />
              </button>
            </div>
            <div className="mt-4 border-t border-[#eef2f6] px-5 py-3">
              <div className="flex flex-wrap items-center gap-2 text-[12px] font-semibold">
                <span className="rounded-full border border-[#e7eef6] px-3 py-1 lowercase">{platform}</span>
                <span className="rounded-full border border-[#e7eef6] px-3 py-1 text-[#94a3b8]">{platform === "tiktok" ? <Music2 className="size-3.5" /> : "—"}</span>
                {/^https?:\/\//.test(link.trim()) ? (
                  <span className="max-w-[180px] truncate rounded-full bg-emerald-50 px-3 py-1 text-emerald-700">{link.trim()}</span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-amber-500"><ShieldAlert className="size-3.5" /> paste a link</span>
                )}
              </div>
              <div className="mt-2 flex flex-wrap gap-2 text-[13px] font-semibold text-[#334155]">
                <span className="inline-flex items-center gap-1 rounded-full border border-[#e7eef6] px-3 py-1"><Eye className="size-3.5 text-[#64748b]" /> {(quantities.views ?? 0).toLocaleString("en-IN")} Views</span>
                <span className="inline-flex items-center gap-1 rounded-full border border-[#e7eef6] px-3 py-1"><Heart className="size-3.5 text-rose-400" /> {(quantities.likes ?? 0).toLocaleString("en-IN")} Likes</span>
              </div>
              <p className="mt-2 flex items-center gap-1 text-[13px] text-[#334155]">
                <ShieldCheck className="size-3.5 text-amber-500" /> Health: <b>{report.health}/100</b>
                <span className="text-[#94a3b8]">•</span> Botting risk: <b>{report.botting}%</b>
              </p>
            </div>
            <div className="flex-1 space-y-3 overflow-auto border-t border-[#eef2f6] px-5 py-4">
              {chat.map((message, index) => (
                <div key={index} className={message.role === "user" ? "ml-8 rounded-2xl bg-[#111827] px-3 py-2 text-[13px] text-white" : "rounded-2xl bg-[#eef5fb] px-3 py-3 text-[13px] leading-relaxed whitespace-pre-line text-[#1e293b]"}>
                  {message.text}
                  {message.apply && (
                    <button
                      type="button"
                      onClick={() => {
                        const next = applyMix(message.mix);
                        setChat((current) => [...current, { role: "assistant", text: `Applied ${next.likes.toLocaleString("en-IN")} likes, ${next.saves.toLocaleString("en-IN")} saves, ${next.shares.toLocaleString("en-IN")} shares, ${next.reposts.toLocaleString("en-IN")} reposts.` }]);
                      }}
                      className="mt-2 rounded-full bg-white px-3 py-1 text-[12px] font-semibold text-[#2458c5]"
                    >
                      Apply this mix
                    </button>
                  )}
                </div>
              ))}
              {aiPending && <p className="text-[12px] text-[#64748b]">Asking the free model…</p>}
              <div className="flex flex-wrap gap-2">
                {["Is this safe?", "How long will delivery take?", "How many more likes should I add?", "Suggest the best ratio"].map((prompt) => (
                  <button key={prompt} type="button" onClick={() => askOrganic(prompt)} className="rounded-full border border-amber-200 px-3 py-1 text-[12px] font-semibold text-amber-700">
                    {prompt}
                  </button>
                ))}
              </div>
            </div>
            <form
              className="flex items-center gap-2 border-t border-[#eef2f6] px-4 py-3"
              onSubmit={(event) => {
                event.preventDefault();
                askOrganic(draft);
              }}
            >
              <input
                value={draft}
                onChange={(event) => setDraft(event.target.value)}
                placeholder="Type your question..."
                className="h-11 min-w-0 flex-1 rounded-full bg-[#e8f1fb] px-4 text-[13px] outline-none"
              />
              <button type="submit" className="grid size-11 place-items-center rounded-full bg-[#e7b38a] text-white" aria-label="Send">
                <Send className="size-4" />
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

function ToggleCard({ on, title, badge, text, icon, tone, onClick }: { on: boolean; title: string; badge: string; text: string; icon: ReactNode; tone: "emerald" | "blue"; onClick: () => void }) {
  const wash = tone === "emerald" ? "border-emerald-100 bg-emerald-50/70" : "border-sky-100 bg-sky-50/70";
  return (
    <div className={`flex items-center gap-3 rounded-2xl border p-3 ${wash}`}>
      <span className="grid size-9 place-items-center rounded-full bg-white text-[#0f766e]">{icon}</span>
      <div className="min-w-0 flex-1">
        <p className="text-[13px] font-semibold">{title} <span className="ml-1 rounded-full bg-emerald-100 px-1.5 text-[9px] text-emerald-700">{badge}</span></p>
        <p className="text-[11px] text-[#64748b]">{text}</p>
      </div>
      <Switch on={on} onClick={onClick} />
    </div>
  );
}

function PlatformButton({ active, onClick, icon, label, gradient }: { active: boolean; onClick: () => void; icon: ReactNode; label: string; gradient: string }) {
  return (
    <button type="button" onClick={onClick} className={`inline-flex h-11 items-center gap-2 rounded-full px-4 text-[12px] font-bold tracking-wide ${active ? `bg-gradient-to-r ${gradient} text-white` : "bg-[#f3f6fa] text-[#64748b]"}`}>
      {icon} {label}
    </button>
  );
}

function Stat({ n, l }: { n: string; l: string }) {
  return (
    <div className="rounded-2xl bg-white p-2">
      <p className="text-[16px] font-bold">{n}</p>
      <p className="text-[11px] text-[#94a3b8]">{l}</p>
    </div>
  );
}

function Preset({ label, onClick }: { label: string; onClick: () => void }) {
  return <button type="button" onClick={onClick} className="rounded-full bg-[#f3f6fa] px-3 py-1 text-[12px] font-semibold">{label}</button>;
}

function Curve({ points, draw, color, wash, dot, onChange, drag, setDrag }: { points: number[]; draw: boolean; color: string; wash: string; dot: string; onChange: (next: number[]) => void; drag: number | null; setDrag: (index: number | null) => void }) {
  const w = 520;
  const h = 210;
  const padL = 36;
  const padR = 12;
  const padT = 16;
  const padB = 22;
  const coords = points.map((y, index) => {
    const x = padL + (index / Math.max(1, points.length - 1)) * (w - padL - padR);
    const py = padT + (1 - y) * (h - padT - padB);
    return { x, py };
  });
  const d = coords.map((point, index) => `${index === 0 ? "M" : "L"}${point.x},${point.py}`).join(" ");
  const gradId = `wash-${dot.replace("#", "")}`;
  return (
    <div className="relative overflow-hidden rounded-2xl bg-[#f8fbfe]">
      <svg
        viewBox={`0 0 ${w} ${h}`}
        className="h-56 w-full touch-none"
        onClick={(event) => {
          if (!draw) return;
          const rect = event.currentTarget.getBoundingClientRect();
          const y = 1 - ((event.clientY - rect.top) / rect.height - padT / h) / ((h - padT - padB) / h);
          onChange([...points, Math.min(1, Math.max(0.02, y))].slice(0, 8));
        }}
        onMouseMove={(event) => {
          if (drag == null) return;
          const rect = event.currentTarget.getBoundingClientRect();
          const y = 1 - ((event.clientY - rect.top) / rect.height - padT / h) / ((h - padT - padB) / h);
          const next = points.slice();
          next[drag] = Math.min(1, Math.max(0.02, y));
          onChange(next);
        }}
        onMouseUp={() => setDrag(null)}
        onMouseLeave={() => setDrag(null)}
        onTouchMove={(event) => {
          if (drag == null) return;
          const touch = event.touches[0];
          const rect = event.currentTarget.getBoundingClientRect();
          const y = 1 - ((touch.clientY - rect.top) / rect.height - padT / h) / ((h - padT - padB) / h);
          const next = points.slice();
          next[drag] = Math.min(1, Math.max(0.02, y));
          onChange(next);
        }}
        onTouchEnd={() => setDrag(null)}
      >
        <text x={4} y={padT + 4} fontSize="11" fill="#94a3b8">100%</text>
        <text x={8} y={(padT + h - padB) / 2 + 4} fontSize="11" fill="#94a3b8">50%</text>
        <text x={(padL + w - padR) / 2} y={h - 4} textAnchor="middle" fontSize="11" fill="#94a3b8">50%</text>
        <text x={w - padR} y={h - 4} textAnchor="end" fontSize="11" fill="#94a3b8">100%</text>
        <path d={`${d} L${w - padR},${h - padB} L${padL},${h - padB} Z`} fill={`url(#${gradId})`} opacity="0.55" />
        <path d={d} fill="none" stroke={color} strokeWidth="7" strokeLinecap="round" strokeLinejoin="round" />
        {draw && coords.map((point, index) => (
          <circle
            key={index}
            cx={point.x}
            cy={point.py}
            r="8"
            fill="#fff"
            stroke={dot}
            strokeWidth="2.5"
            onMouseDown={(event) => {
              event.stopPropagation();
              setDrag(index);
            }}
            onClick={(event) => event.stopPropagation()}
            onTouchStart={(event) => {
              event.stopPropagation();
              setDrag(index);
            }}
            onDoubleClick={(event) => {
              event.stopPropagation();
              if (points.length > 2) onChange(points.filter((_, item) => item !== index));
            }}
          />
        ))}
        <defs>
          <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={wash} />
            <stop offset="100%" stopColor="#ffffff" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

const PREVIEW_TYPES = [
  { key: "views", label: "Views", Icon: Eye, tint: "text-[#7c5c3a]" },
  { key: "likes", label: "Likes", Icon: Heart, tint: "text-rose-500" },
  { key: "saves", label: "Saves", Icon: Bookmark, tint: "text-[#3b82f6]" },
  { key: "shares", label: "Shares", Icon: Share2, tint: "text-[#2563eb]" },
  { key: "reposts", label: "Reposts", Icon: RefreshCw, tint: "text-[#0ea5e9]" },
] as const;

function axisTicks(max: number) {
  const steps = 4;
  return Array.from({ length: steps + 1 }, (_, index) => Math.round((max * index) / steps));
}

function axisLabel(value: number) {
  if (value >= 1000) {
    const compact = value / 1000;
    return Number.isInteger(compact) ? `${compact}K` : `${compact.toFixed(1)}K`;
  }
  return String(value);
}

function Delivery({
  pattern,
  picker,
  family,
  onFamily,
  onTogglePicker,
  onPattern,
  onNew,
  quantities,
  pace,
}: {
  pattern: number;
  picker: boolean;
  family: string;
  onFamily: (name: string) => void;
  onTogglePicker: () => void;
  onPattern: (id: number) => void;
  onNew: () => void;
  quantities: Record<string, number>;
  pace: Record<string, Pace>;
}) {
  const template = growthTemplate(pattern);
  const series = growthSeries(pattern);
  const views = quantities.views ?? 0;
  const lines = [
    { key: "views", color: "#60a5fa", qty: views },
    { key: "likes", color: "#86efac", qty: quantities.likes ?? 0 },
    { key: "saves", color: "#facc15", qty: quantities.saves ?? 0 },
    { key: "shares", color: "#38bdf8", qty: quantities.shares ?? 0 },
  ];
  const width = 640;
  const height = 230;
  const left = 36;
  const right = 8;
  const top = 12;
  const bottom = 28;
  const ticks = axisTicks(Math.max(views, 1));
  const pathFor = (qty: number) =>
    series.points
      .map((point, index) => {
        const x = left + (index / (series.points.length - 1)) * (width - left - right);
        const y = top + (1 - point) * (height - top - bottom);
        const scaled = views > 0 ? (qty / views) * point : 0;
        const yy = top + (1 - Math.min(1, scaled)) * (height - top - bottom);
        return { x, y: qty === views ? y : yy };
      });
  const viewPts = pathFor(views);
  const d = viewPts.map((point, index) => `${index === 0 ? "M" : "L"}${point.x.toFixed(1)},${point.y.toFixed(1)}`).join(" ");
  const area = `${d} L${viewPts[viewPts.length - 1]?.x ?? width},${height - bottom} L${left},${height - bottom} Z`;
  const stamps = buildRuns(Math.max(views, 1), 8, 20, new Date(), windowHours(pace.views ?? DEFAULT_PACE, autoRuns(Math.max(views, 1), "views")), pattern);
  const cards = PREVIEW_TYPES.map((type) => {
    const qty = quantities[type.key] ?? 0;
    const current = pace[type.key] ?? DEFAULT_PACE;
    const runs = current.runsMode === "manual" && current.runs > 0 ? current.runs : autoRuns(Math.max(qty, 1), type.key);
    return { ...type, qty, runs: qty > 0 ? runs : 0, window: current.window === "auto" ? "Auto" : current.window === "custom" ? `${current.customHours}h` : current.window, variance: current.variance };
  }).filter((card) => card.qty > 0 || card.key === "views");
  const total = Object.values(quantities).reduce((sum, value) => sum + value, 0);
  const runSum = cards.reduce((sum, card) => sum + card.runs, 0);
  const hours = Math.max(...cards.map((card) => windowHours(pace[card.key] ?? DEFAULT_PACE, Math.max(card.runs, 1))), 0.1);
  const familyIds = Array.from({ length: 8 }, (_, index) => {
    const base = GROWTH_FAMILIES.indexOf(family as (typeof GROWTH_FAMILIES)[number]);
    const slot = base < 0 ? 0 : base;
    return slot + 1 + index * GROWTH_FAMILIES.length;
  }).filter((id) => id <= TEMPLATE_COUNT);

  return (
    <section className="space-y-3">
      <div className="rounded-[28px] border border-[#e7eef6] bg-white p-4 shadow-sm">
        <div className="flex items-start justify-between gap-3">
          <div className="flex gap-3">
            <span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-[#e8f1ff] text-[#3b82f6]">
              <Activity className="size-5" />
            </span>
            <div>
              <p className="text-[18px] font-bold text-[#0f172a]">Live Organic Growth Preview</p>
              <p className="text-[12px] text-[#94a3b8]">Bursts + pauses • Service-wise natural steps</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button type="button" onClick={onNew} className="inline-flex h-9 items-center gap-1 rounded-full border border-[#e7eef6] px-3 text-[12px] font-semibold text-[#334155]">
              <RefreshCw className="size-3.5" /> New Pattern
            </button>
            <span className="inline-flex h-9 items-center gap-1 rounded-full border border-[#e7eef6] px-3 text-[12px] font-semibold text-[#64748b]">
              <Sparkles className="size-3.5" /> {template.organic}% Organic
            </span>
          </div>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2 text-[13px]">
          <span className="text-[#94a3b8]"># Template:</span>
          <input
            value={pattern}
            onChange={(event) => {
              const next = Math.max(1, Math.min(TEMPLATE_COUNT, Number(event.target.value) || 1));
              onPattern(next);
            }}
            className="h-8 w-16 rounded-full border border-[#e7eef6] bg-white text-center font-semibold outline-none"
          />
          <button type="button" onClick={onTogglePicker} className="h-8 rounded-full border border-[#dbe7f5] bg-[#f8fbff] px-3 text-[12px] font-semibold text-[#334155]">
            #{template.id} • {template.name}
          </button>
          <span className="ml-auto text-[12px] text-[#94a3b8]">{TEMPLATE_COUNT}+ patterns</span>
        </div>

        {picker && (
          <div className="mt-3 rounded-2xl bg-[#f8fafc] p-3">
            <div className="flex flex-wrap gap-2">
              {GROWTH_FAMILIES.map((name) => (
                <button
                  key={name}
                  type="button"
                  onClick={() => onFamily(name)}
                  className={`rounded-full px-3 py-1 text-[12px] font-semibold ${family === name ? "bg-[#111827] text-white" : "bg-white text-[#334155]"}`}
                >
                  {name}
                </button>
              ))}
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {familyIds.map((id) => (
                <button key={id} type="button" onClick={() => onPattern(id)} className={`rounded-full px-3 py-1 text-[12px] font-semibold ${id === template.id ? "bg-[#3b82f6] text-white" : "bg-white"}`}>
                  #{id} • {family}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="mt-3 flex flex-wrap items-center gap-2 text-[12px] font-semibold">
          <span className="inline-flex items-center gap-1 rounded-full bg-[#3b82f6] px-3 py-1 text-white">
            <Zap className="size-3.5" /> {total.toLocaleString("en-IN")} total
          </span>
          <span className="inline-flex items-center gap-1 rounded-full bg-[#f1f5f9] px-3 py-1 text-[#334155]">
            <Activity className="size-3.5" /> {runSum} runs
          </span>
          <span className="inline-flex items-center gap-1 rounded-full bg-[#f1f5f9] px-3 py-1 text-[#334155]">
            <Clock className="size-3.5" /> {formatDuration(hours)}
          </span>
        </div>
        <div className="mt-2 flex flex-wrap gap-2 text-[12px] text-[#64748b]">
          <span className="inline-flex items-center gap-1 rounded-full bg-[#f8fafc] px-2 py-1"><span className="size-2 rounded-full bg-[#60a5fa]" /> {(quantities.views ?? 0).toLocaleString("en-IN")}</span>
          <span className="inline-flex items-center gap-1 rounded-full bg-[#f8fafc] px-2 py-1"><Heart className="size-3 text-rose-400" /> {(quantities.likes ?? 0).toLocaleString("en-IN")}</span>
          <span className="inline-flex items-center gap-1 rounded-full bg-[#f8fafc] px-2 py-1"><Bookmark className="size-3 text-amber-400" /> {(quantities.saves ?? 0).toLocaleString("en-IN")}</span>
          <span className="inline-flex items-center gap-1 rounded-full bg-[#f8fafc] px-2 py-1"><Share2 className="size-3 text-sky-400" /> {(quantities.shares ?? 0).toLocaleString("en-IN")}</span>
        </div>

        <svg viewBox={`0 0 ${width} ${height}`} className="mt-2 h-64 w-full">
          {ticks.map((tick) => {
            const y = top + (1 - tick / Math.max(views, 1)) * (height - top - bottom);
            return (
              <g key={tick}>
                <line x1={left} x2={width - right} y1={y} y2={y} stroke="#eef2f6" />
                <text x={left - 6} y={y + 4} textAnchor="end" fontSize="11" fill="#94a3b8">{axisLabel(tick)}</text>
              </g>
            );
          })}
          <path d={area} fill="url(#growthWash)" />
          <path d={d} fill="none" stroke="#7eb6f6" strokeWidth="2.4" />
          {lines.slice(1).map((line) => {
            const pts = pathFor(line.qty);
            const lineD = pts.map((point, index) => `${index === 0 ? "M" : "L"}${point.x.toFixed(1)},${point.y.toFixed(1)}`).join(" ");
            return <path key={line.key} d={lineD} fill="none" stroke={line.color} strokeWidth="1.6" />;
          })}
          {stamps.map((stamp, index) => (
            <text key={index} x={left + (index / Math.max(1, stamps.length - 1)) * (width - left - right)} y={height - 8} textAnchor="middle" fontSize="10" fill="#94a3b8">
              {stamp.at.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", hour12: false })}
            </text>
          ))}
          <defs>
            <linearGradient id="growthWash" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#93c5fd" stopOpacity="0.55" />
              <stop offset="100%" stopColor="#ffffff" stopOpacity="0.05" />
            </linearGradient>
          </defs>
        </svg>
        <div className="mt-1 flex justify-center gap-4 text-[12px] text-[#64748b]">
          <span className="inline-flex items-center gap-1"><span className="size-2 rounded-full bg-[#60a5fa]" /> Views</span>
          <span className="inline-flex items-center gap-1"><span className="size-2 rounded-full bg-[#86efac]" /> Likes</span>
          <span className="inline-flex items-center gap-1"><span className="size-2 rounded-full bg-[#facc15]" /> Saves</span>
          <span className="inline-flex items-center gap-1"><span className="size-2 rounded-full bg-[#38bdf8]" /> Shares</span>
        </div>
      </div>

      <div className="rounded-[28px] border border-[#e7eef6] bg-white p-4 shadow-sm">
        <p className="text-[18px] font-bold"><Sprout className="mr-1 inline size-4 text-emerald-500" /> Per-Type Organic Delivery Preview</p>
        <p className="text-[13px] text-[#64748b]">Each type has its own organic settings</p>
        <div className="mt-3 flex flex-wrap gap-2 text-[12px] font-semibold">
          <span className="inline-flex items-center gap-1 rounded-full bg-[#111827] px-3 py-1 text-white"><Zap className="size-3.5" /> {total.toLocaleString("en-IN")}</span>
          <span className="inline-flex items-center gap-1 rounded-full bg-[#f1f5f9] px-3 py-1"><Clock className="size-3.5" /> {runSum} runs</span>
          <span className="inline-flex items-center gap-1 rounded-full bg-[#f1f5f9] px-3 py-1"><Clock className="size-3.5" /> {formatDuration(hours)}</span>
        </div>
        <div className="mt-3 grid grid-cols-5 gap-2">
          {cards.map((card) => (
            <div key={card.key} className="rounded-2xl bg-[#f4f7fb] px-2 py-3 text-center">
              <card.Icon className={`mx-auto size-4 ${card.tint}`} />
              <p className="mt-1 text-[16px] font-bold">{card.runs}</p>
              <p className="text-[11px] text-[#94a3b8]">{card.window}</p>
            </div>
          ))}
        </div>
        <div className="mt-3 rounded-2xl bg-[#f4f7fb] p-3">
          <p className="mb-2 text-[13px] font-semibold text-[#334155]">Per-Type Settings</p>
          <ul className="grid gap-1 text-[13px] sm:grid-cols-2">
            {cards.map((card) => (
              <li key={card.key} className="flex items-center gap-2">
                <card.Icon className={`size-3.5 ${card.tint}`} />
                <span>{card.label}: {card.window} · ±{card.variance}%</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}

