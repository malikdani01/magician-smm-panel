import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Authed } from "@/components/gate";
import { adminBindings, adminSaveBindings } from "@/lib/admin.functions";

export const Route = createFileRoute("/admin/engagement")({
  component: () => (
    <Authed>
      <EngagementApis />
    </Authed>
  ),
});

const TYPES = ["views", "likes", "saves", "shares", "reposts"] as const;

type Row = { slot: string; api_url: string; api_key: string; service_id: string; pick_mode: string; min_quantity: number };

function EngagementApis() {
  const [rows, setRows] = useState<Row[]>([]);
  const [platform, setPlatform] = useState<"instagram" | "tiktok">("instagram");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    adminBindings()
      .then((list) => setRows(list.filter((row) => row.slot !== "single")))
      .catch((err: unknown) => setNote(err instanceof Error ? err.message : "Could not load."));
  }, []);

  function patch(slot: string, next: Partial<Row>) {
    setRows((current) => current.map((row) => (row.slot === slot ? { ...row, ...next } : row)));
  }

  return (
    <div className="mx-auto max-w-xl space-y-4">
      <header>
        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#2563eb]">Admin</p>
        <h1 className="text-[28px] font-bold">Full engagement APIs</h1>
        <p className="text-[13px] text-[#64748b]">Pehle platform chuno. Instagram aur TikTok alag save hote hain. Service ID type karo, ya Random — API khud matching service uthayegi.</p>
      </header>
      <div className="grid grid-cols-2 gap-2">
        {(["instagram", "tiktok"] as const).map((item) => (
          <button key={item} type="button" onClick={() => setPlatform(item)} className={`h-11 rounded-xl text-[13px] font-bold uppercase ${platform === item ? "bg-[#2563eb] text-white" : "bg-white text-[#334155]"}`}>
            {item}
          </button>
        ))}
      </div>
      {TYPES.map((type) => {
        const slot = `${platform}:${type}`;
        const row = rows.find((item) => item.slot === slot);
        if (!row) return null;
        const random = row.pick_mode === "random";
        return (
          <section key={slot} className="rounded-[24px] border border-[#e7eef6] bg-white p-4 shadow-sm">
            <h2 className="font-semibold capitalize">{type}</h2>
            <div className="mt-3 grid gap-2">
              <input value={row.api_url} onChange={(event) => patch(slot, { api_url: event.target.value })} placeholder="Provider API URL" className="h-11 rounded-xl border border-[#e7eef6] px-3 text-[13px] outline-none" />
              <input value={row.api_key} onChange={(event) => patch(slot, { api_key: event.target.value })} placeholder="API key" className="h-11 rounded-xl border border-[#e7eef6] px-3 text-[13px] outline-none" />
              <div className="grid grid-cols-2 gap-2">
                <button type="button" onClick={() => patch(slot, { pick_mode: "fixed" })} className={`h-10 rounded-xl text-[12px] font-bold ${!random ? "bg-[#0f172a] text-white" : "bg-[#f3f6fa]"}`}>Type service ID</button>
                <button type="button" onClick={() => patch(slot, { pick_mode: "random", service_id: "" })} className={`h-10 rounded-xl text-[12px] font-bold ${random ? "bg-[#2563eb] text-white" : "bg-[#f3f6fa]"}`}>Pick random</button>
              </div>
              {!random && (
                <input value={row.service_id} onChange={(event) => patch(slot, { service_id: event.target.value.replace(/[^\d]/g, "") })} placeholder="Service ID" className="h-11 rounded-xl border border-[#e7eef6] px-3 text-[13px] outline-none" />
              )}
              {random && <p className="text-[12px] text-[#64748b]">Order place hote waqt is API se {type} ki service random choose hogi.</p>}
              <label className="block text-[12px] font-semibold text-[#334155]">
                Minimum quantity
                <input
                  inputMode="numeric"
                  value={row.min_quantity}
                  onChange={(event) => patch(slot, { min_quantity: Math.max(1, Number(event.target.value.replace(/[^\d]/g, "")) || 1) })}
                  className="mt-1 h-11 w-full rounded-xl border border-[#e7eef6] px-3 text-[13px] outline-none"
                />
              </label>
              <p className="text-[11px] text-[#94a3b8]">Ratio isse neeche nahi jayega. Provider change karo to yahi number badal do. Random pick pe bhi yeh minimum lagega.</p>
            </div>
          </section>
        );
      })}
      <button
        type="button"
        disabled={busy}
        onClick={async () => {
          setBusy(true);
          setNote("");
          try {
            const current = await adminBindings();
            const single = current.find((row) => row.slot === "single");
            await adminSaveBindings({ data: single ? [...rows, single] : rows });
            setNote(`${platform} configuration saved.`);
          } catch (err: unknown) {
            setNote(err instanceof Error ? err.message : "Save failed.");
          } finally {
            setBusy(false);
          }
        }}
        className="h-12 w-full rounded-xl bg-[#2563eb] text-[14px] font-bold text-white disabled:opacity-60"
      >
        {busy ? "Saving…" : `Save ${platform} configuration`}
      </button>
      {note && <p className="text-center text-[13px] text-[#1e3a8a]">{note}</p>}
    </div>
  );
}
