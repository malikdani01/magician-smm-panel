import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Authed } from "@/components/gate";
import { adminAddService, adminFetchProvider, adminProviders, adminSaveProvider, adminSaveService, adminServices } from "@/lib/admin.functions";
import { inr } from "@/lib/money";

export const Route = createFileRoute("/admin/services")({
  component: () => (
    <Authed>
      <ServicesDesk />
    </Authed>
  ),
});

type Row = {
  id: string;
  source: string;
  provider_service_id: string;
  platform: string;
  category: string;
  name: string;
  description: string;
  price_per_1k_paise: number;
  min_quantity: number;
  max_quantity: number;
  drip_allowed: boolean;
  enabled: boolean;
};

const blank = {
  provider_service_id: "",
  platform: "instagram",
  category: "",
  name: "",
  description: "",
  price_per_1k_paise: 100,
  min_quantity: 10,
  max_quantity: 100000,
  drip_allowed: false,
  enabled: true,
};

function ServicesDesk() {
  const [query, setQuery] = useState("");
  const [rows, setRows] = useState<Row[]>([]);
  const [total, setTotal] = useState(0);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [edit, setEdit] = useState<Row | null>(null);
  const [adding, setAdding] = useState(false);
  const [draft, setDraft] = useState(blank);
  const [providers, setProviders] = useState<{ id: string; name: string; api_url: string; api_key: string; enabled: boolean; last_error: string; last_sync: string | null }[]>([]);
  const [draftProvider, setDraftProvider] = useState({ id: "", name: "", api_url: "https://yoyomedia.in/api/v2", api_key: "", enabled: true });

  function load(next = query) {
    adminServices({ data: next }).then((result) => {
      setRows(result.services);
      setTotal(result.total);
    }).catch((err: unknown) => setNote(err instanceof Error ? err.message : "Could not load services."));
  }

  useEffect(() => {
    load("");
    adminProviders().then(setProviders).catch(() => setProviders([]));
  }, []);

  async function saveAndFetch(provider = draftProvider) {
    setBusy(true);
    setNote("");
    try {
      const saved = await adminSaveProvider({ data: provider });
      const result = await adminFetchProvider({ data: saved.id });
      setNote(`${provider.name || "Provider"}: ${result.total.toLocaleString("en-IN")} services. Added ${result.added}, updated ${result.updated}. Enabled rows show on single order.`);
      setDraftProvider({ id: "", name: "", api_url: "https://yoyomedia.in/api/v2", api_key: "", enabled: true });
      setProviders(await adminProviders());
      load(query);
    } catch (err: unknown) {
      setNote(err instanceof Error ? err.message : "Fetch failed.");
      setProviders(await adminProviders().catch(() => providers));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <header>
        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#2563eb]">Admin</p>
        <h1 className="text-[28px] font-bold text-[#0f172a]">Services</h1>
        <p className="text-[13px] text-[#64748b]">{total.toLocaleString("en-IN")} on the book. User single order only shows enabled rows.</p>
      </header>
      <section className="rounded-[24px] border border-[#dbeafe] bg-white p-4 shadow-sm">
        <h2 className="font-semibold">Single order providers</h2>
        <p className="mt-1 text-[12px] text-[#64748b]">Har provider ki API alag save hoti hai. Fetch ke baad uski services yahan aati hain. Jo row enabled hai, wahi user ke single order mein dikhegi, aur order usi provider pe jayega.</p>
        <ul className="mt-3 space-y-2">
          {providers.map((provider) => (
            <li key={provider.id} className="rounded-xl bg-[#f8fafc] px-3 py-2 text-[12px]">
              <b>{provider.name}</b> · {provider.enabled ? "on" : "off"} {provider.last_error ? `· ${provider.last_error}` : ""}
              <div className="mt-1 flex gap-2">
                <button type="button" onClick={() => setDraftProvider(provider)} className="font-semibold text-[#2563eb]">Edit</button>
                <button type="button" disabled={busy} onClick={() => saveAndFetch(provider)} className="font-semibold text-[#0f766e]">Fetch again</button>
              </div>
            </li>
          ))}
        </ul>
        <div className="mt-3 grid gap-2">
          <input value={draftProvider.name} onChange={(event) => setDraftProvider({ ...draftProvider, name: event.target.value })} placeholder="Provider name" className="h-11 rounded-xl border border-[#e7eef6] px-3 text-[13px] outline-none" />
          <input value={draftProvider.api_url} onChange={(event) => setDraftProvider({ ...draftProvider, api_url: event.target.value })} placeholder="API URL" className="h-11 rounded-xl border border-[#e7eef6] px-3 text-[13px] outline-none" />
          <input value={draftProvider.api_key} onChange={(event) => setDraftProvider({ ...draftProvider, api_key: event.target.value })} placeholder="API key" className="h-11 rounded-xl border border-[#e7eef6] px-3 text-[13px] outline-none" />
          <button type="button" disabled={busy} onClick={() => saveAndFetch()} className="h-11 rounded-xl bg-[#2563eb] text-[13px] font-bold text-white disabled:opacity-60">{busy ? "Fetching…" : "Save and fetch services"}</button>
          <button type="button" onClick={() => setDraftProvider({ id: "", name: "", api_url: "https://yoyomedia.in/api/v2", api_key: "", enabled: true })} className="h-10 rounded-xl border text-[12px] font-semibold">Add another API</button>
        </div>
      </section>
      <div className="flex gap-2">
        <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search id, name, category" className="h-11 flex-1 rounded-xl border border-[#e7eef6] px-3 text-[13px] outline-none" />
        <button type="button" onClick={() => load(query)} className="rounded-xl border bg-white px-4 text-[13px] font-semibold">Search</button>
        <button type="button" onClick={() => setAdding((value) => !value)} className="rounded-xl bg-[#0f172a] px-4 text-[13px] font-semibold text-white">Add service</button>
      </div>
      {adding && (
        <form
          className="grid gap-2 rounded-[24px] border border-[#e7eef6] bg-white p-4"
          onSubmit={async (event) => {
            event.preventDefault();
            setBusy(true);
            try {
              await adminAddService({ data: draft });
              setDraft(blank);
              setAdding(false);
              load(query);
            } catch (err: unknown) {
              setNote(err instanceof Error ? err.message : "Could not add.");
            } finally {
              setBusy(false);
            }
          }}
        >
          <p className="font-semibold">Custom service</p>
          <div className="grid gap-2 sm:grid-cols-2">
            <input required value={draft.provider_service_id} onChange={(event) => setDraft({ ...draft, provider_service_id: event.target.value })} placeholder="Service ID" className="h-10 rounded-xl border px-3 text-[13px]" />
            <input required value={draft.name} onChange={(event) => setDraft({ ...draft, name: event.target.value })} placeholder="Service title" className="h-10 rounded-xl border px-3 text-[13px]" />
            <input value={draft.category} onChange={(event) => setDraft({ ...draft, category: event.target.value })} placeholder="Category" className="h-10 rounded-xl border px-3 text-[13px]" />
            <input value={draft.platform} onChange={(event) => setDraft({ ...draft, platform: event.target.value })} placeholder="Platform" className="h-10 rounded-xl border px-3 text-[13px]" />
            <input value={draft.price_per_1k_paise} onChange={(event) => setDraft({ ...draft, price_per_1k_paise: Number(event.target.value) })} placeholder="Price per 1k in paise" className="h-10 rounded-xl border px-3 text-[13px]" />
            <input value={draft.description} onChange={(event) => setDraft({ ...draft, description: event.target.value })} placeholder="Description" className="h-10 rounded-xl border px-3 text-[13px]" />
            <input value={draft.min_quantity} onChange={(event) => setDraft({ ...draft, min_quantity: Number(event.target.value) })} placeholder="Minimum" className="h-10 rounded-xl border px-3 text-[13px]" />
            <input value={draft.max_quantity} onChange={(event) => setDraft({ ...draft, max_quantity: Number(event.target.value) })} placeholder="Maximum" className="h-10 rounded-xl border px-3 text-[13px]" />
          </div>
          <label className="flex items-center gap-2 text-[13px]"><input type="checkbox" checked={draft.drip_allowed} onChange={(event) => setDraft({ ...draft, drip_allowed: event.target.checked })} /> Drip-feed allowed</label>
          <label className="flex items-center gap-2 text-[13px]"><input type="checkbox" checked={draft.enabled} onChange={(event) => setDraft({ ...draft, enabled: event.target.checked })} /> Enabled</label>
          <button className="h-10 rounded-xl bg-[#2563eb] text-[13px] font-bold text-white">Save custom service</button>
        </form>
      )}
      {note && <p className="rounded-xl bg-[#eff6ff] px-3 py-2 text-[13px] text-[#1e3a8a]">{note}</p>}
      <ul className="space-y-2">
        {rows.map((row) => (
          <li key={row.id} className="rounded-2xl border border-[#e7eef6] bg-white p-3">
            {edit?.id === row.id ? (
              <EditForm
                row={edit}
                onChange={setEdit}
                onCancel={() => setEdit(null)}
                onSave={async () => {
                  if (!edit) return;
                  await adminSaveService({ data: edit });
                  setEdit(null);
                  load(query);
                }}
              />
            ) : (
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-[13px] font-semibold">{row.name}</p>
                  <p className="text-[12px] text-[#64748b]">#{row.provider_service_id} · {row.platform} · {row.category}</p>
                  <p className="text-[12px] text-[#334155]">{inr(row.price_per_1k_paise)} / 1k · {row.min_quantity}–{row.max_quantity} · {row.enabled ? "enabled" : "disabled"} · drip {row.drip_allowed ? "on" : "off"}</p>
                </div>
                <button type="button" onClick={() => setEdit(row)} className="rounded-lg border px-3 py-1 text-[12px] font-semibold">Edit</button>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

function EditForm({ row, onChange, onSave, onCancel }: { row: Row; onChange: (row: Row) => void; onSave: () => void; onCancel: () => void }) {
  return (
    <div className="grid gap-2">
      <input value={row.name} onChange={(event) => onChange({ ...row, name: event.target.value })} className="h-10 rounded-xl border px-3 text-[13px]" />
      <input value={row.category} onChange={(event) => onChange({ ...row, category: event.target.value })} className="h-10 rounded-xl border px-3 text-[13px]" />
      <textarea value={row.description} onChange={(event) => onChange({ ...row, description: event.target.value })} className="min-h-16 rounded-xl border px-3 py-2 text-[13px]" />
      <div className="grid grid-cols-3 gap-2">
        <input value={row.price_per_1k_paise} onChange={(event) => onChange({ ...row, price_per_1k_paise: Number(event.target.value) })} className="h-10 rounded-xl border px-3 text-[13px]" />
        <input value={row.min_quantity} onChange={(event) => onChange({ ...row, min_quantity: Number(event.target.value) })} className="h-10 rounded-xl border px-3 text-[13px]" />
        <input value={row.max_quantity} onChange={(event) => onChange({ ...row, max_quantity: Number(event.target.value) })} className="h-10 rounded-xl border px-3 text-[13px]" />
      </div>
      <label className="flex items-center gap-2 text-[13px]"><input type="checkbox" checked={row.enabled} onChange={(event) => onChange({ ...row, enabled: event.target.checked })} /> Service enabled</label>
      <label className="flex items-center gap-2 text-[13px]"><input type="checkbox" checked={row.drip_allowed} onChange={(event) => onChange({ ...row, drip_allowed: event.target.checked })} /> User can use drip-feed</label>
      <div className="flex gap-2">
        <button type="button" onClick={onSave} className="h-10 rounded-xl bg-[#2563eb] px-4 text-[13px] font-bold text-white">Save</button>
        <button type="button" onClick={onCancel} className="h-10 rounded-xl border px-4 text-[13px]">Cancel</button>
      </div>
    </div>
  );
}
