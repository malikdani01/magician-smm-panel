import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Authed } from "@/components/gate";
import { getWallet, type TxnRow } from "@/lib/panel.functions";
import { listPaymentGateways, myPaymentClaims, submitPaymentClaim } from "@/lib/admin.functions";
import { inr } from "@/lib/money";

export const Route = createFileRoute("/wallet")({
  component: () => (
    <Authed>
      <WalletPage />
    </Authed>
  ),
});

const CHIPS = [10000, 50000, 100000, 500000];

function WalletPage() {
  const [balance, setBalance] = useState(0);
  const [rows, setRows] = useState<TxnRow[]>([]);
  const [amount, setAmount] = useState(500);
  const [gateways, setGateways] = useState<{ id: string; name: string; account_title: string; account_number: string; ifsc: string; instructions: string; qr_image: string }[]>([]);
  const [gatewayId, setGatewayId] = useState("");
  const [filter, setFilter] = useState("All");
  const [note, setNote] = useState("");
  const [pending, setPending] = useState(false);
  const [shot, setShot] = useState("");
  const [reference, setReference] = useState("");
  const [claims, setClaims] = useState<{ id: string; amount_paise: number; status: string; created_at: string }[]>([]);

  function load() {
    getWallet().then((wallet) => {
      setBalance(wallet.balance_paise);
      setRows(wallet.transactions);
    });
    listPaymentGateways().then((rows) => {
      setGateways(rows);
      setGatewayId((current) => current || rows[0]?.id || "");
    }).catch(() => setGateways([]));
    myPaymentClaims().then(setClaims).catch(() => setClaims([]));
  }
  useEffect(load, []);

  const shown = rows.filter((row) => {
    if (filter === "Deposits") return row.amount_paise > 0;
    if (filter === "Orders") return row.amount_paise < 0;
    if (filter === "Refunds") return row.kind === "refund";
    return true;
  });

  async function pay() {
    if (!shot) {
      setNote("Payment ka screenshot upload karo.");
      return;
    }
    setPending(true);
    setNote("");
    try {
      const result = await submitPaymentClaim({ data: { amountPaise: Math.round(amount * 100), screenshot: shot, reference, gatewayId } });
      setNote(`${result.id} mil gaya. Aapka fund 10 minute mein update ho jayega, admin screenshot check karega.`);
      setShot("");
      setReference("");
      load();
    } catch (err: unknown) {
      setNote(err instanceof Error ? err.message : "Could not send the screenshot.");
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="mx-auto max-w-xl space-y-4">
      <div className="flex items-end justify-between">
        <div>
          <p className="text-[11px] font-semibold tracking-[0.18em] text-[#3b82f6]">VAULT</p>
          <h1 className="font-['Playfair_Display',Georgia,serif] text-[40px] leading-none">Wallet</h1>
        </div>
        <span className="rounded-full bg-emerald-50 px-3 py-1 text-[12px] font-semibold text-emerald-700">Secure</span>
      </div>
      <div className="rounded-3xl bg-gradient-to-r from-[#2563eb] to-[#60a5fa] p-5 text-white">
        <p className="text-[11px] tracking-widest">BALANCE</p>
        <p className="text-[32px] font-bold">{inr(balance)} <span className="text-[12px]">INR</span></p>
        <div className="mt-3 flex gap-2 text-[12px]">
          <span className="rounded-full bg-white/20 px-3 py-1">IN {inr(rows.filter((row) => row.amount_paise > 0).reduce((s, row) => s + row.amount_paise, 0))}</span>
          <span className="rounded-full bg-white/20 px-3 py-1">OUT {inr(Math.abs(rows.filter((row) => row.amount_paise < 0).reduce((s, row) => s + row.amount_paise, 0)))}</span>
        </div>
      </div>
      <p className="text-[11px] font-semibold tracking-widest text-[#94a3b8]">ADD FUNDS</p>
      <h2 className="text-[18px] font-semibold">Choose payment method</h2>
      {gateways.length === 0 ? <p className="text-[13px] text-[#94a3b8]">Admin ne abhi koi payment method on nahi kiya.</p> : (
        <div className="grid grid-cols-2 gap-2">
          {gateways.map((gate) => (
            <button key={gate.id} type="button" onClick={() => setGatewayId(gate.id)} className={`h-11 rounded-xl text-[13px] font-semibold ${gatewayId === gate.id ? "bg-[#3b82f6] text-white" : "bg-white"}`}>{gate.name}</button>
          ))}
        </div>
      )}
      {(() => {
        const gate = gateways.find((item) => item.id === gatewayId);
        if (!gate) return null;
        return (
      <section className="rounded-3xl border border-[#e7eef6] bg-white p-4">
        <p className="font-semibold">{gate.name}</p>
        <p className="text-[13px] text-[#334155]">{gate.account_title}</p>
        {gate.account_number && <p className="text-[13px]">Account / wallet: <b>{gate.account_number}</b></p>}
        {gate.ifsc && <p className="text-[13px]">IFSC: <b>{gate.ifsc}</b></p>}
        {gate.instructions && <p className="mt-1 text-[12px] text-[#64748b]">{gate.instructions}</p>}
        <p className="mt-3 text-[11px] font-semibold tracking-widest text-[#94a3b8]">AMOUNT</p>
        <div className="mt-1 flex items-center rounded-2xl bg-[#f8fafc] px-3">
          <span>₹</span>
          <input value={amount} onChange={(event) => setAmount(Number(event.target.value) || 0)} className="h-12 w-full bg-transparent px-2 text-[20px] font-semibold outline-none" />
          <span className="text-[12px] text-[#94a3b8]">INR</span>
        </div>
        <div className="mt-3 grid grid-cols-4 gap-2">
          {CHIPS.map((chip) => (
            <button key={chip} type="button" onClick={() => setAmount(chip / 100)} className={`h-10 rounded-xl text-[13px] font-semibold ${amount * 100 === chip ? "bg-[#3b82f6] text-white" : "bg-[#f3f6fa]"}`}>
              {chip >= 100000 ? `₹${chip / 100000}k` : `₹${chip / 100}`}
            </button>
          ))}
        </div>
        {gate.qr_image ? <img src={gate.qr_image} alt="Pay QR" className="mx-auto mt-4 h-48 w-48 rounded-2xl border object-contain" /> : <p className="mt-3 text-center text-[12px] text-[#94a3b8]">Is method pe QR nahi hai. Account details use karo.</p>}
        <label className="mt-3 block text-[12px] font-semibold text-[#64748b]">
          UTR / reference
          <input value={reference} onChange={(event) => setReference(event.target.value)} className="mt-1 h-11 w-full rounded-xl border px-3 text-[14px] font-normal outline-none" />
        </label>
        <label className="mt-3 flex h-11 cursor-pointer items-center justify-center rounded-xl border text-[13px] font-semibold">
          {shot ? "Screenshot ready" : "Upload payment screenshot"}
          <input type="file" accept="image/*" className="hidden" onChange={(event) => {
            const file = event.target.files?.[0];
            if (!file) return;
            const image = new Image();
            image.onload = () => {
              const canvas = document.createElement("canvas");
              const scale = Math.min(1, 900 / image.width);
              canvas.width = Math.max(1, image.width * scale);
              canvas.height = Math.max(1, image.height * scale);
              canvas.getContext("2d")?.drawImage(image, 0, 0, canvas.width, canvas.height);
              setShot(canvas.toDataURL("image/jpeg", 0.72));
            };
            image.src = URL.createObjectURL(file);
          }} />
        </label>
        <button type="button" disabled={pending || !gatewayId} onClick={pay} className="mt-3 h-12 w-full rounded-2xl bg-gradient-to-r from-[#2563eb] to-[#60a5fa] font-semibold text-white disabled:opacity-60">
          {pending ? "Sending…" : `I paid ${inr(amount * 100)}`}
        </button>
        <p className="mt-2 text-center text-[11px] text-[#94a3b8]">Aapka fund 10 minute mein update ho jayega.</p>
        {note && <p className="mt-2 text-center text-[12px] text-[#2458c5]">{note}</p>}
        {claims.length > 0 && (
          <ul className="mt-3 space-y-1 text-[12px]">
            {claims.map((claim) => (
              <li key={claim.id} className="flex justify-between rounded-lg bg-[#f8fafc] px-2 py-1">
                <span>{claim.id}</span>
                <span>{inr(claim.amount_paise)} · {claim.status}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
        );
      })()}
      <section className="rounded-3xl border border-[#e7eef6] bg-white p-4">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-semibold">Transaction History</h2>
          <span className="text-[12px] text-[#94a3b8]">{shown.length} total</span>
        </div>
        <div className="mb-3 flex gap-2">
          {["All", "Deposits", "Orders", "Refunds"].map((item) => (
            <button key={item} type="button" onClick={() => setFilter(item)} className={`rounded-full px-3 py-1 text-[12px] font-semibold ${filter === item ? "bg-[#e8eef8]" : "text-[#94a3b8]"}`}>{item}</button>
          ))}
        </div>
        {shown.length === 0 ? (
          <p className="py-8 text-center text-[13px] text-[#94a3b8]">No transactions yet<br />Your deposits and spending will appear here</p>
        ) : (
          <ul className="space-y-2 text-[13px]">
            {shown.map((row) => (
              <li key={row.id} className="flex justify-between rounded-xl bg-[#f8fafc] px-3 py-2">
                <span>{row.note}</span>
                <span className={row.amount_paise < 0 ? "text-rose-500" : "text-emerald-600"}>{inr(row.amount_paise)}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
