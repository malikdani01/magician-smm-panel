import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Authed } from "@/components/gate";
import { adminPaymentClaims, adminReviewPayment, adminSaveGateway } from "@/lib/admin.functions";
import { inr } from "@/lib/money";

export const Route = createFileRoute("/admin/payments")({
  component: () => (
    <Authed>
      <Payments />
    </Authed>
  ),
});

type Claim = {
  id: string;
  email: string;
  name: string;
  amount_paise: number;
  screenshot: string;
  reference: string;
  status: string;
  created_at: string;
  gateway_name?: string;
  reject_reason?: string;
};

type Gate = { id: string; name: string; account_title: string; account_number: string; ifsc: string; instructions: string; qr_image: string; min_paise: number; max_paise: number; enabled: boolean; archived: boolean };

const EMPTY: Gate = { id: "", name: "", account_title: "", account_number: "", ifsc: "", instructions: "", qr_image: "", min_paise: 10000, max_paise: 10000000, enabled: true, archived: false };

function shrink(file: File) {
  return new Promise<string>((resolve, reject) => {
    const image = new Image();
    image.onload = () => {
      const canvas = document.createElement("canvas");
      const scale = Math.min(1, 900 / image.width);
      canvas.width = Math.max(1, image.width * scale);
      canvas.height = Math.max(1, image.height * scale);
      canvas.getContext("2d")?.drawImage(image, 0, 0, canvas.width, canvas.height);
      resolve(canvas.toDataURL("image/jpeg", 0.72));
    };
    image.onerror = () => reject(new Error("Could not read that image."));
    image.src = URL.createObjectURL(file);
  });
}

function Payments() {
  const [gates, setGates] = useState<Gate[]>([]);
  const [form, setForm] = useState<Gate>(EMPTY);
  const [claims, setClaims] = useState<Claim[]>([]);
  const [message, setMessage] = useState("");
  const [reason, setReason] = useState("");
  const [filter, setFilter] = useState("pending");
  const [openShot, setOpenShot] = useState("");

  function load() {
    adminPaymentClaims().then((result) => {
      setGates(result.gateways);
      setClaims(result.claims);
    }).catch((err: unknown) => setMessage(err instanceof Error ? err.message : "Could not load payments."));
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <header>
        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#2563eb]">Admin</p>
        <h1 className="text-[28px] font-bold">Payments</h1>
        <p className="text-[13px] text-[#64748b]">UPI, JazzCash ya bank add karo. Account number aur IFSC save karo. Customer screenshot bhejega. Approve sirf ek baar wallet credit karta hai. Pehle apne account mein payment verify karo.</p>
      </header>
      <section className="rounded-[24px] border border-[#e7eef6] bg-white p-4">
        <h2 className="font-semibold">{form.id ? "Edit gateway" : "Add payment gateway"}</h2>
        <div className="mt-3 grid gap-2">
          <input value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} placeholder="Name, e.g. UPI, JazzCash, Bank" className="h-11 rounded-xl border px-3 text-[13px]" />
          <input value={form.account_title} onChange={(event) => setForm({ ...form, account_title: event.target.value })} placeholder="Account title" className="h-11 rounded-xl border px-3 text-[13px]" />
          <input value={form.account_number} onChange={(event) => setForm({ ...form, account_number: event.target.value })} placeholder="Account / wallet number" className="h-11 rounded-xl border px-3 text-[13px]" />
          <input value={form.ifsc} onChange={(event) => setForm({ ...form, ifsc: event.target.value })} placeholder="IFSC, bank ke liye" className="h-11 rounded-xl border px-3 text-[13px]" />
          <input value={form.instructions} onChange={(event) => setForm({ ...form, instructions: event.target.value })} placeholder="Instructions" className="h-11 rounded-xl border px-3 text-[13px]" />
          <div className="grid grid-cols-2 gap-2">
            <input value={form.min_paise / 100} onChange={(event) => setForm({ ...form, min_paise: Math.floor(Number(event.target.value) || 0) * 100 })} placeholder="Min ₹" className="h-11 rounded-xl border px-3 text-[13px]" />
            <input value={form.max_paise / 100} onChange={(event) => setForm({ ...form, max_paise: Math.floor(Number(event.target.value) || 0) * 100 })} placeholder="Max ₹" className="h-11 rounded-xl border px-3 text-[13px]" />
          </div>
          <label className="flex items-center gap-2 text-[13px]"><input type="checkbox" checked={form.enabled} onChange={(event) => setForm({ ...form, enabled: event.target.checked })} /> Enabled</label>
          <label className="flex h-11 cursor-pointer items-center rounded-xl border px-3 text-[13px] font-semibold">
            Upload QR
            <input type="file" accept="image/*" className="hidden" onChange={async (event) => {
              const file = event.target.files?.[0];
              if (!file) return;
              setForm({ ...form, qr_image: await shrink(file) });
            }} />
          </label>
          {form.qr_image && <img src={form.qr_image} alt="" className="h-32 w-32 rounded-xl border object-contain" />}
        </div>
        <button type="button" onClick={async () => {
          await adminSaveGateway({ data: { ...form, min_rupees: form.min_paise / 100, max_rupees: form.max_paise / 100, archived: form.archived } });
          setForm(EMPTY);
          setMessage("Gateway saved.");
          load();
        }} className="mt-3 h-11 w-full rounded-xl bg-[#2563eb] text-[13px] font-bold text-white">Save gateway</button>
        <button type="button" onClick={() => setForm(EMPTY)} className="mt-2 h-10 w-full rounded-xl border text-[12px] font-semibold">Add another</button>
        <ul className="mt-3 space-y-2 text-[13px]">
          {gates.map((gate) => (
            <li key={gate.id} className="flex items-center justify-between rounded-xl bg-[#f8fafc] px-3 py-2">
              <span>{gate.name} · {gate.enabled ? "on" : "off"} {gate.archived ? "· archived" : ""}</span>
              <span className="flex gap-2">
                <button type="button" onClick={() => setForm(gate)} className="font-semibold text-[#2563eb]">Edit</button>
                <button type="button" onClick={async () => { await adminSaveGateway({ data: { ...gate, min_rupees: gate.min_paise / 100, max_rupees: gate.max_paise / 100, archived: true, enabled: false, qr_image: "" } }); load(); }} className="font-semibold text-rose-600">Archive</button>
              </span>
            </li>
          ))}
        </ul>
      </section>
      {message && <p className="rounded-xl bg-[#eff6ff] px-3 py-2 text-[13px]">{message}</p>}
      <div className="flex gap-2">
        {["pending", "approved", "declined", "all"].map((item) => (
          <button key={item} type="button" onClick={() => setFilter(item)} className={`rounded-full px-3 py-1 text-[12px] font-semibold ${filter === item ? "bg-[#2563eb] text-white" : "bg-white"}`}>{item}</button>
        ))}
      </div>
      <ul className="space-y-3">
        {claims.filter((claim) => filter === "all" || claim.status === filter).map((claim) => (
          <li key={claim.id} className="rounded-2xl border border-[#e7eef6] bg-white p-4">
            <div className="flex gap-3">
              <button type="button" onClick={() => setOpenShot(claim.screenshot)}><img src={claim.screenshot} alt="" className="h-28 w-24 rounded-xl object-cover" /></button>
              <div className="min-w-0 flex-1">
                <p className="font-semibold">{claim.name}</p>
                <p className="truncate text-[12px] text-[#64748b]">{claim.email} · {claim.gateway_name || "Gateway"}</p>
                <p className="mt-1 text-[14px] font-bold">{inr(claim.amount_paise)} · {claim.id}</p>
                <p className="text-[12px] text-[#64748b]">{claim.reference || "No UTR"} · {claim.status} · {new Date(claim.created_at).toLocaleString("en-IN", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}</p>
                {claim.reject_reason && <p className="text-[12px] text-rose-600">{claim.reject_reason}</p>}
                {claim.status === "pending" && (
                  <div className="mt-2 space-y-2">
                    <input value={reason} onChange={(event) => setReason(event.target.value)} placeholder="Reject reason" className="h-9 w-full rounded-lg border px-2 text-[12px]" />
                    <div className="flex gap-2">
                      <button type="button" onClick={async () => { await adminReviewPayment({ data: { id: claim.id, approve: true } }); load(); }} className="h-9 rounded-lg bg-emerald-600 px-3 text-[12px] font-bold text-white">Approve</button>
                      <button type="button" onClick={async () => { await adminReviewPayment({ data: { id: claim.id, approve: false, reason } }); load(); }} className="h-9 rounded-lg border border-rose-200 px-3 text-[12px] font-bold text-rose-600">Decline</button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </li>
        ))}
        {claims.length === 0 && <p className="text-center text-[13px] text-[#94a3b8]">No payment screenshots yet.</p>}
      </ul>
      {openShot && <button type="button" onClick={() => setOpenShot("")} className="fixed inset-0 z-40 grid place-items-center bg-black/70 p-6"><img src={openShot} alt="Payment proof" className="max-h-[80vh] rounded-2xl" /></button>}
    </div>
  );
}
