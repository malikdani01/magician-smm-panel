import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Activity,
  ArrowRight,
  ChartColumn,
  Layers,
  ShieldCheck,
  Sparkles,
  Timer,
  Wallet,
  Zap,
} from "lucide-react";
import { SignedIn, SignedOut } from "@/lib/auth/gates";
import { Mark } from "@/components/shell";

export const Route = createFileRoute("/")({ component: Home });

const FEATURES = [
  {
    icon: Timer,
    title: "Staged drip",
    body: "Spread a cue across hours with a little jitter, instead of dumping the whole quantity at once.",
  },
  {
    icon: Layers,
    title: "Source slots",
    body: "The desk can rotate sources later. Nothing is plugged in, so every cue stays on your ledger.",
  },
  {
    icon: Wallet,
    title: "Wallet first",
    body: "Add studio credit, then spend it. No plan gate, and no payment gateway is connected.",
  },
  {
    icon: Activity,
    title: "Live desk",
    body: "Balance, queued cues, and recent rows sit on one screen the moment you sign in.",
  },
  {
    icon: ShieldCheck,
    title: "No plan gate",
    body: "Create an account and order when the wallet has credit. There is no subscription wall.",
  },
  {
    icon: Sparkles,
    title: "Bundle cues",
    body: "Views stay the base. Likes, saves, and shares can ride along at a fixed ratio.",
  },
];

const PLATFORMS = ["Instagram", "TikTok", "YouTube", "Telegram", "Facebook"];

const ROWS = [
  ["Instagram", "Reel views", "12,500", "Running"],
  ["TikTok", "Hearts", "4,200", "Queued"],
  ["YouTube", "Subscribers", "850", "Complete"],
  ["Instagram", "Followers", "2,000", "Running"],
];

function Home() {
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 border-b border-[#bae6fd] bg-[rgba(224,242,254,0.75)] backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5 sm:px-8">
          <Mark />
          <nav className="hidden items-center gap-8 text-sm text-slate-500 md:flex">
            <a href="#features" className="hover:text-slate-800">Features</a>
            <a href="#platforms" className="hover:text-slate-800">Platforms</a>
            <Link to="/support" className="hover:text-slate-800">Support</Link>
          </nav>
          <div className="flex items-center gap-2.5">
            <SignedOut>
              <Link to="/login" className="hidden min-h-10 items-center rounded-lg px-3 text-sm text-slate-500 hover:text-slate-800 sm:inline-flex">
                Sign in
              </Link>
              <Link to="/login" className="btn-gradient inline-flex min-h-10 items-center gap-1.5 rounded-lg px-4 text-sm font-semibold">
                Get started <ArrowRight className="size-3.5" />
              </Link>
            </SignedOut>
            <SignedIn>
              <Link to="/dashboard" className="btn-gradient inline-flex min-h-10 items-center gap-1.5 rounded-lg px-4 text-sm font-semibold">
                Open desk <ArrowRight className="size-3.5" />
              </Link>
            </SignedIn>
          </div>
        </div>
      </header>

      <main>
        <section className="relative">
          <div className="mx-auto max-w-5xl px-5 pt-16 text-center sm:px-8 sm:pt-24 pb-16 sm:pb-24">
            <p className="mb-8 inline-flex items-center gap-2 rounded-full border border-[#93c5fd] bg-[#eff6ff] px-3 py-1">
              <span className="relative flex size-2">
                <span className="absolute inline-flex size-full animate-ping rounded-full bg-[#3b82f6] opacity-75" />
                <span className="relative inline-flex size-2 rounded-full bg-[#2563eb]" />
              </span>
              <span className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#2563eb]">
                Magiciansmm · Desk v1
              </span>
            </p>
            <h1 className="mx-auto mb-6 max-w-4xl text-5xl tracking-tight text-slate-900 sm:text-7xl">
              The growth desk
              <br />
              for <span className="serif-em">social work.</span>
            </h1>
            <p className="mx-auto mb-10 max-w-2xl text-base leading-relaxed text-slate-600 sm:text-xl">
              Paste a link, pick a bundle, and hold the cue on your own ledger. Instagram, TikTok, and YouTube are priced in. No provider is connected.
            </p>
            <div className="flex flex-col items-center justify-center gap-3 sm:flex-row sm:gap-4">
              <Link to="/login" className="btn-gradient inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-xl px-7 text-sm font-semibold sm:w-auto">
                Open the desk <ArrowRight className="size-4" />
              </Link>
              <Link
                to="/login"
                className="inline-flex min-h-12 w-full items-center justify-center rounded-xl border border-[#93c5fd] bg-white/70 px-7 text-sm font-semibold text-slate-700 sm:w-auto"
              >
                Add credit
              </Link>
            </div>
            <div className="mt-16 border-t border-[#bae6fd] pt-8">
              <p className="mb-5 text-[10px] uppercase tracking-[0.24em] text-slate-400">
                Built for the platforms that matter
              </p>
              <div className="flex flex-wrap items-center justify-center gap-x-10 gap-y-4 text-slate-400">
                {PLATFORMS.map((name) => (
                  <span key={name} className="text-xs font-semibold uppercase tracking-[0.18em]">
                    {name}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section id="features" className="border-t border-[#bae6fd] py-20 sm:py-28">
          <div className="mx-auto max-w-6xl px-5 sm:px-8">
            <div className="mb-14 max-w-2xl">
              <p className="mb-4 text-[11px] font-semibold uppercase tracking-[0.22em] text-[#2563eb]">The software</p>
              <h2 className="text-3xl text-slate-900 sm:text-5xl">
                Built like infrastructure,
                <br />
                <span className="serif-em">used like a product.</span>
              </h2>
            </div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 sm:gap-5 lg:grid-cols-3">
              {FEATURES.map((feature) => (
                <article key={feature.title} className="rounded-2xl border border-[#bae6fd] bg-white/75 p-6 backdrop-blur">
                  <div className="mb-5 grid size-10 place-items-center rounded-lg border border-[#bfdbfe] bg-[#eff6ff] text-[#2563eb]">
                    <feature.icon className="size-5" />
                  </div>
                  <h3 className="mb-2 text-base font-semibold text-slate-800">{feature.title}</h3>
                  <p className="text-sm leading-relaxed text-slate-500">{feature.body}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="platforms" className="border-t border-[#bae6fd] py-20">
          <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 sm:px-8 lg:grid-cols-2">
            <div>
              <p className="mb-4 text-[11px] font-semibold uppercase tracking-[0.22em] text-[#2563eb]">Cross-platform</p>
              <h2 className="mb-5 text-3xl text-slate-900 sm:text-5xl">
                One desk for
                <br />
                <span className="serif-em">every channel.</span>
              </h2>
              <p className="mb-8 max-w-lg leading-relaxed text-slate-600">
                Drop in a URL, choose a bundle, and launch. Magiciansmm stores the cue, the price, and the pace. Upstream delivery waits until you connect a source.
              </p>
              <ul className="space-y-3">
                {[
                  "Instagram views, likes, and follows",
                  "TikTok views, hearts, and follows",
                  "YouTube views and subscribers",
                  "Telegram and Facebook lines, priced later",
                ].map((line) => (
                  <li key={line} className="flex items-center gap-3 text-sm text-slate-700">
                    <span className="grid size-5 place-items-center rounded-full border border-[#bfdbfe] bg-[#eff6ff] text-[#2563eb]">
                      <ChartColumn className="size-3" />
                    </span>
                    {line}
                  </li>
                ))}
              </ul>
            </div>
            <div className="relative">
              <div className="absolute -inset-4 rounded-full bg-[#2563eb]/10 blur-2xl" />
              <div className="relative rounded-2xl border border-[#bae6fd] bg-white/85 p-6 shadow-md backdrop-blur">
                <div className="mb-5 flex items-center gap-1.5">
                  <span className="size-2.5 rounded-full bg-red-300" />
                  <span className="size-2.5 rounded-full bg-amber-200" />
                  <span className="size-2.5 rounded-full bg-emerald-300" />
                  <span className="ml-auto text-[10px] uppercase tracking-[0.18em] text-slate-400">magiciansmm</span>
                </div>
                <div className="space-y-3">
                  {ROWS.map(([platform, kind, qty, status]) => (
                    <div key={platform + kind} className="flex items-center justify-between rounded-lg border border-[#bae6fd] bg-[#f0f9ff] px-3.5 py-3">
                      <div>
                        <p className="mb-0.5 text-[10px] uppercase tracking-widest text-slate-400">{platform}</p>
                        <p className="text-sm font-medium text-slate-700">{kind}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-semibold text-slate-800">{qty}</p>
                        <p className={
                          "text-[10px] font-semibold uppercase tracking-wider " +
                          (status === "Complete" ? "text-emerald-500" : status === "Queued" ? "text-amber-500" : "text-blue-500")
                        }>
                          {status}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="border-t border-[#bae6fd] py-20">
          <div className="mx-auto max-w-4xl px-5 text-center sm:px-8">
            <h2 className="mb-5 text-3xl text-slate-900 sm:text-5xl">
              Ready to open <span className="serif-em">the desk?</span>
            </h2>
            <p className="mx-auto mb-8 max-w-xl text-slate-600">
              Skip the template panels. Run the ledger like software, then connect a source when you choose.
            </p>
            <Link to="/login" className="btn-gradient inline-flex min-h-12 items-center justify-center gap-2 rounded-xl px-7 text-sm font-semibold">
              Open the desk <Zap className="size-4" />
            </Link>
          </div>
        </section>
      </main>

      <footer className="border-t border-[#bae6fd] py-10">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-5 text-sm text-slate-500 sm:flex-row sm:px-8">
          <div className="flex items-center gap-2.5">
            <Mark compact />
            <span>© {new Date().getFullYear()} Magiciansmm · v1</span>
          </div>
          <div className="flex items-center gap-6">
            <Link to="/support" className="hover:text-slate-800">Support</Link>
            <Link to="/catalog" className="hover:text-slate-800">Services</Link>
            <Link to="/login" className="hover:text-slate-800">Sign in</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
