import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Instagram } from "lucide-react";
import { Authed } from "@/components/gate";
import { linkInstagram, listInstagram } from "@/lib/panel.functions";

export const Route = createFileRoute("/instagram")({
  component: () => (
    <Authed>
      <Page />
    </Authed>
  ),
});

function Page() {
  const [username, setUsername] = useState("");
  const [rows, setRows] = useState<{ id: string; username: string }[]>([]);
  const [note, setNote] = useState("");

  function load() {
    listInstagram().then(setRows).catch(() => setRows([]));
  }
  useEffect(load, []);

  async function link() {
    setNote("");
    try {
      await linkInstagram({ data: username });
      setUsername("");
      setNote("Linked on your desk. Public posts are not fetched until a source is connected.");
      load();
    } catch (err: unknown) {
      setNote(err instanceof Error ? err.message : "Could not link.");
    }
  }

  return (
    <div className="mx-auto max-w-xl space-y-4">
      <section className="rounded-3xl bg-gradient-to-r from-[#eef4ff] to-white p-4">
        <h1 className="flex items-center gap-2 text-[22px] font-bold"><span className="grid size-9 place-items-center rounded-xl bg-[#3b82f6] text-white"><Instagram className="size-4" /></span> Instagram Accounts</h1>
        <p className="text-[13px] text-[#64748b]">Link your IG account to import posts and boost engagement.</p>
      </section>
      <section className="rounded-3xl border border-[#e7eef6] bg-white p-4">
        <p className="text-[11px] font-semibold tracking-widest text-[#94a3b8]">ADD INSTAGRAM USERNAME</p>
        <div className="mt-2 flex gap-2">
          <input value={username} onChange={(event) => setUsername(event.target.value)} placeholder="@ your_username" className="h-11 flex-1 rounded-xl bg-[#f8fafc] px-3 outline-none" />
          <button type="button" onClick={link} className="rounded-xl bg-[#60a5fa] px-4 font-semibold text-white">+ Link</button>
        </div>
        <p className="mt-2 text-[12px] text-[#94a3b8]">Read-only. We only keep the username. Profile import waits for a source.</p>
        <p className="mt-2 rounded-xl bg-emerald-50 px-3 py-2 text-[12px] text-emerald-700">{rows.length}/5 links used · {Math.max(0, 5 - rows.length)} more accounts can be linked in this 30-day window.</p>
        {note && <p className="mt-2 text-[12px]">{note}</p>}
      </section>
      <section className="rounded-3xl border border-[#e7eef6] bg-white p-8 text-center text-[13px] text-[#64748b]">
        {rows.length === 0 ? "No Instagram accounts linked yet." : (
          <ul className="space-y-2 text-left">
            {rows.map((row) => <li key={row.id} className="rounded-xl bg-[#f8fafc] px-3 py-2 font-semibold">@{row.username}</li>)}
          </ul>
        )}
      </section>
    </div>
  );
}
