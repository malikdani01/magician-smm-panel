import { useEffect, useState, type ChangeEvent, type ReactNode } from "react";
import { createFileRoute } from "@tanstack/react-router";
import {
  Bookmark,
  Camera,
  Eye,
  EyeOff,
  Heart,
  KeyRound,
  LogOut,
  MessageCircle,
  Repeat2,
  Save,
  Settings as SettingsIcon,
  Share2,
  Shield,
  Sparkles,
  User,
  Users,
} from "lucide-react";
import { signOut } from "@/lib/auth/client";
import { Authed } from "@/components/gate";
import { changeDeskPassword, getPrefs, savePrefs } from "@/lib/panel.functions";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/settings")({
  component: () => (
    <Authed>
      <Settings />
    </Authed>
  ),
});

const DEFAULTS: Record<string, number> = {
  views: 100,
  likes: 5,
  comments: 2,
  saves: 1,
  shares: 1,
  reposts: 0.5,
  followers: 2,
  subscribers: 3,
  watch_hours: 5,
  retweets: 4,
};

function Settings() {
  const { user } = useCurrentUserState();
  const [name, setName] = useState("");
  const [photo, setPhoto] = useState("");
  const [organic, setOrganic] = useState(false);
  const [ratios, setRatios] = useState<Record<string, number>>(DEFAULTS);
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [key, setKey] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState("");

  useEffect(() => {
    getPrefs()
      .then((prefs) => {
        setName(prefs.full_name || user?.displayName || "");
        setPhoto(prefs.avatar_url || "");
        setOrganic(Boolean(prefs.organic_enabled));
        setKey(prefs.api_key || "");
        try {
          setRatios({ ...DEFAULTS, ...JSON.parse(prefs.ratios_json || "{}") });
        } catch {
          setRatios(DEFAULTS);
        }
      })
      .catch(() => setNote("Settings could not load."));
  }, [user?.displayName]);

  function setRatio(id: string, value: number) {
    setRatios((current) => ({ ...current, [id]: value }));
  }

  async function onPhoto(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (file.size > 120_000) {
      setNote("Photo is too large. Use an image under 120 KB.");
      return;
    }
    const data = await fileToData(file);
    setPhoto(data);
    await savePrefs({ data: { avatar_url: data } });
    setNote("Photo saved.");
  }

  async function saveName() {
    setBusy("profile");
    try {
      await savePrefs({ data: { full_name: name } });
      setNote("Profile saved.");
    } catch (err: unknown) {
      setNote(err instanceof Error ? err.message : "Could not save profile.");
    } finally {
      setBusy("");
    }
  }

  async function toggleOrganic() {
    const next = !organic;
    setOrganic(next);
    await savePrefs({ data: { organic_enabled: next } });
    setNote(next ? "AI Organic Automation enabled." : "AI Organic Automation disabled.");
  }

  async function saveRatios() {
    setBusy("ratios");
    try {
      await savePrefs({ data: { organic_enabled: organic, ratios_json: JSON.stringify(ratios) } });
      setNote("AI configuration saved on this desk. No outside model is connected.");
    } catch (err: unknown) {
      setNote(err instanceof Error ? err.message : "Could not save configuration.");
    } finally {
      setBusy("");
    }
  }

  async function changePassword() {
    if (password.length < 8) {
      setNote("Use at least 8 characters.");
      return;
    }
    if (password !== confirm) {
      setNote("New password and confirm password do not match.");
      return;
    }
    setBusy("password");
    try {
      await changeDeskPassword({ data: password });
      setPassword("");
      setConfirm("");
      setNote("Password updated. Use it the next time you sign in.");
    } catch (err: unknown) {
      setNote(err instanceof Error ? err.message : "Could not change password.");
    } finally {
      setBusy("");
    }
  }

  return (
    <div className="mx-auto max-w-3xl space-y-4 pb-16">
      <section className="flex items-center gap-3 rounded-3xl border border-[#e7eef6] bg-white px-5 py-4">
        <span className="grid size-11 place-items-center rounded-2xl bg-[#2563eb] text-white">
          <SettingsIcon className="size-5" />
        </span>
        <div>
          <h1 className="text-[22px] font-bold text-[#0f172a]">Settings</h1>
          <p className="text-[13px] text-[#64748b]">Manage your account and preferences</p>
        </div>
      </section>

      <section className="rounded-3xl border border-[#e7eef6] bg-white p-5">
        <p className="flex items-center gap-2 font-semibold"><User className="size-4 text-[#64748b]" /> Profile Information</p>
        <p className="text-[12px] text-[#94a3b8]">Update your personal details</p>
        <div className="mt-4 flex items-center gap-3">
          <span className="relative grid size-14 place-items-center overflow-hidden rounded-2xl bg-[#e8f1ff] text-[#64748b]">
            {photo ? <img src={photo} alt="" className="size-full object-cover" /> : <User className="size-6" />}
            <label className="absolute -bottom-1 -right-1 grid size-6 cursor-pointer place-items-center rounded-full bg-[#2563eb] text-white">
              <Camera className="size-3" />
              <input type="file" accept="image/*" className="hidden" onChange={onPhoto} />
            </label>
          </span>
          <div>
            <p className="font-semibold">{name || "Member"}</p>
            <p className="text-[12px] text-[#64748b]">{user?.primaryEmail}</p>
            <label className="cursor-pointer text-[12px] font-semibold text-[#2563eb]">
              Upload photo
              <input type="file" accept="image/*" className="hidden" onChange={onPhoto} />
            </label>
          </div>
        </div>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <label className="text-[13px] font-medium text-[#334155]">
            Full Name
            <input value={name} onChange={(event) => setName(event.target.value)} className="mt-1 h-11 w-full rounded-xl bg-[#e7f0f8] px-3 outline-none" />
          </label>
          <label className="text-[13px] font-medium text-[#334155]">
            Email Address
            <input value={user?.primaryEmail || ""} disabled className="mt-1 h-11 w-full rounded-xl bg-[#e7f0f8] px-3 text-[#64748b] outline-none" />
            <span className="mt-1 block text-[11px] font-normal text-[#94a3b8]">Email cannot be changed</span>
          </label>
        </div>
        <button type="button" disabled={busy === "profile"} onClick={saveName} className="mt-4 inline-flex h-10 items-center gap-2 rounded-xl bg-[#2563eb] px-4 text-[13px] font-semibold text-white disabled:opacity-60">
          <Save className="size-4" /> Save Changes
        </button>
      </section>

      <section className="rounded-3xl border border-[#e7eef6] bg-white p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="flex items-center gap-2 font-semibold">
              <Sparkles className="size-4 text-[#2563eb]" /> AI Organic Automation
              <span className="rounded-full bg-[#efe7ff] px-2 py-0.5 text-[10px] font-bold text-[#7c3aed]">PREMIUM</span>
            </p>
            <p className="text-[12px] text-[#94a3b8]">Configure your default organic settings</p>
          </div>
          <button type="button" onClick={toggleOrganic} className="inline-flex items-center gap-2 text-[11px] font-bold tracking-wide text-[#64748b]">
            {organic ? "ENABLED" : "DISABLED"}
            <span className={`relative h-7 w-12 rounded-full ${organic ? "bg-[#2563eb]" : "bg-[#dbe4ee]"}`}>
              <span className={`absolute top-0.5 size-6 rounded-full bg-white shadow ${organic ? "left-5" : "left-0.5"}`} />
            </span>
          </button>
        </div>
        <div className="mt-4 rounded-2xl border border-[#dbeafe] bg-[#f8fbff] p-3 text-[13px] text-[#334155]">
          <p className="font-semibold"><Sparkles className="mr-1 inline size-3.5 text-[#2563eb]" /> What is Organic Mode?</p>
          <p className="mt-1 text-[12px] leading-relaxed text-[#64748b]">When enabled, all your new orders will automatically use AI-generated delivery patterns. This creates unique growth curves for every order to look 100% natural to social algorithms.</p>
        </div>

        <div className="mt-4 flex items-center gap-2 text-[13px] font-semibold">
          <span className="text-[#64748b]">%</span> AI Organic Ratios — Universal
          <span className="rounded-full bg-[#e0e7ff] px-2 py-0.5 text-[10px] font-bold text-[#3730a3]">ALL PLATFORMS</span>
        </div>
        <div className="mt-3 grid gap-3 sm:grid-cols-3">
          <Ratio icon={<Eye className="size-3.5" />} label="VIEWS RATIO" value={ratios.views} tone="text-[#2563eb]" onChange={(value) => setRatio("views", value)} />
          <Ratio icon={<Heart className="size-3.5 text-rose-500" />} label="LIKES RATIO" value={ratios.likes} tone="text-rose-500" onChange={(value) => setRatio("likes", value)} />
          <Ratio icon={<MessageCircle className="size-3.5 text-[#94a3b8]" />} label="COMMENTS RATIO" value={ratios.comments} tone="text-[#64748b]" onChange={(value) => setRatio("comments", value)} />
        </div>

        <p className="mb-2 mt-4 flex items-center gap-2 text-[13px] font-semibold">
          Instagram & TikTok <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-600">IG + TT</span>
        </p>
        <div className="grid gap-3 sm:grid-cols-3">
          <Ratio icon={<Bookmark className="size-3.5 text-sky-500" />} label="SAVES" value={ratios.saves} tone="text-emerald-500" onChange={(value) => setRatio("saves", value)} />
          <Ratio icon={<Share2 className="size-3.5 text-sky-500" />} label="SHARES" value={ratios.shares} tone="text-[#2563eb]" onChange={(value) => setRatio("shares", value)} />
          <Ratio icon={<Repeat2 className="size-3.5 text-sky-500" />} label="REPOSTS" value={ratios.reposts} tone="text-[#2563eb]" onChange={(value) => setRatio("reposts", value)} />
        </div>
        <div className="mt-3 max-w-sm">
          <Ratio icon={<Users className="size-3.5 text-violet-500" />} label="FOLLOWERS" value={ratios.followers} tone="text-violet-500" onChange={(value) => setRatio("followers", value)} />
        </div>

        <p className="mb-2 mt-4 text-[13px] font-semibold">YouTube <span className="rounded-full bg-rose-50 px-2 py-0.5 text-[10px] font-bold text-rose-500">YT</span></p>
        <div className="grid gap-3 sm:grid-cols-2">
          <Ratio icon={<span className="text-[12px]">▶</span>} label="SUBSCRIBERS" value={ratios.subscribers} tone="text-rose-500" onChange={(value) => setRatio("subscribers", value)} />
          <Ratio icon={<span className="text-[12px]">◷</span>} label="WATCH HOURS" value={ratios.watch_hours} tone="text-rose-500" onChange={(value) => setRatio("watch_hours", value)} />
        </div>

        <p className="mb-2 mt-4 text-[13px] font-semibold">Twitter / X <span className="rounded-full bg-sky-50 px-2 py-0.5 text-[10px] font-bold text-sky-600">X</span></p>
        <div className="max-w-sm">
          <Ratio icon={<Repeat2 className="size-3.5 text-sky-500" />} label="RETWEETS" value={ratios.retweets} tone="text-[#2563eb]" onChange={(value) => setRatio("retweets", value)} />
        </div>

        <p className="mt-4 rounded-2xl bg-[#f8fbff] p-3 text-[12px] leading-relaxed text-[#64748b]">
          <Shield className="mr-1 inline size-3.5" /> Ratios are calculated relative to your "Base Quantity". For example, if Views are 100% and Likes are 5%, an order of 10,000 Views will auto-generate 500 Likes. These apply to ALL your orders across all platforms.
        </p>
        <button type="button" disabled={busy === "ratios"} onClick={saveRatios} className="mt-4 inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-[#2563eb] text-[14px] font-semibold text-white disabled:opacity-60">
          <Save className="size-4" /> {busy === "ratios" ? "Saving…" : "Save AI Configuration"}
        </button>
      </section>

      <section className="rounded-3xl border border-[#e7eef6] bg-white p-5">
        <p className="flex items-center gap-2 font-semibold"><KeyRound className="size-4 text-amber-500" /> Change Password</p>
        <p className="text-[12px] text-[#94a3b8]">Update your account password</p>
        <label className="mt-3 block text-[13px] font-medium">
          New Password
          <span className="relative mt-1 block">
            <input type={showPassword ? "text" : "password"} value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Enter new password" className="h-11 w-full rounded-xl bg-[#e7f0f8] px-3 pr-10 outline-none" />
            <button type="button" onClick={() => setShowPassword((value) => !value)} className="absolute right-3 top-3 text-[#94a3b8]" aria-label="Show password">
              {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
            </button>
          </span>
        </label>
        <label className="mt-3 block text-[13px] font-medium">
          Confirm New Password
          <input type={showPassword ? "text" : "password"} value={confirm} onChange={(event) => setConfirm(event.target.value)} placeholder="Confirm new password" className="mt-1 h-11 w-full rounded-xl bg-[#e7f0f8] px-3 outline-none" />
        </label>
        <button type="button" disabled={busy === "password"} onClick={changePassword} className="mt-4 inline-flex h-10 items-center gap-2 rounded-xl border border-[#e7eef6] px-4 text-[13px] font-semibold disabled:opacity-60">
          <KeyRound className="size-3.5" /> {busy === "password" ? "Updating…" : "Change Password"}
        </button>
      </section>

      <section className="rounded-3xl border border-[#e7eef6] bg-white p-5">
        <p className="flex items-center gap-2 font-semibold"><KeyRound className="size-4 text-emerald-500" /> API Key</p>
        <p className="text-[12px] text-[#94a3b8]">Manage your API access key for integrations</p>
        <p className="mt-3 text-[13px] font-medium">Your API Key</p>
        <input readOnly value={key || "••••••••••••••••••••"} className="mt-1 h-11 w-full rounded-xl bg-[#f8fafc] px-3 font-mono text-[13px] outline-none" />
        <p className="mt-1 text-[11px] text-[#94a3b8]">Keep your API key secret. Do not share it publicly.</p>
        <button
          type="button"
          onClick={async () => {
            const next = await savePrefs({ data: { rotateKey: true } });
            setKey(next?.api_key || "");
            setNote("New API key generated. It does not call a provider yet.");
          }}
          className="mt-3 inline-flex h-10 items-center gap-2 rounded-xl border border-[#e7eef6] px-4 text-[13px] font-semibold"
        >
          <KeyRound className="size-3.5" /> Generate API Key
        </button>
      </section>

      <section className="flex items-center justify-between rounded-3xl border border-[#e7eef6] bg-white p-5">
        <div>
          <p className="font-semibold">Sign Out</p>
          <p className="text-[12px] text-[#94a3b8]">Sign out from your account on this device</p>
        </div>
        <button type="button" onClick={() => signOut("/login")} className="inline-flex items-center gap-2 rounded-xl bg-[#ef4444] px-4 py-2 text-[13px] font-semibold text-white">
          <LogOut className="size-4" /> Sign Out
        </button>
      </section>
      {note && <p className="text-center text-[13px] text-[#334155]">{note}</p>}
    </div>
  );
}

function Ratio({ icon, label, value, tone, onChange }: { icon: ReactNode; label: string; value: number; tone: string; onChange: (value: number) => void }) {
  const shown = Number.isInteger(value) ? `${value}%` : `${value}%`;
  return (
    <label className="block rounded-2xl border border-[#eef2f6] bg-white p-3">
      <span className="flex items-center justify-between text-[11px] font-semibold tracking-wide text-[#64748b]">
        <span className="inline-flex items-center gap-1">{icon} {label}</span>
        <b className={tone}>{shown}</b>
      </span>
      <input type="range" min={0} max={100} step={0.5} value={value} onChange={(event) => onChange(Number(event.target.value))} className="mt-3 w-full accent-[#111827]" />
      <span className="mt-1 flex justify-between text-[10px] text-[#94a3b8]"><span>0%</span><span>50%</span><span>100%</span></span>
    </label>
  );
}

function fileToData(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Could not read that photo."));
    reader.readAsDataURL(file);
  });
}
