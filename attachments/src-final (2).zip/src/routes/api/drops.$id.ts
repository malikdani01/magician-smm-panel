import { createFileRoute } from "@tanstack/react-router";
import { getSql } from "@/lib/db";
import { listOrderDrops } from "@/lib/drip.server";
import { requireUserId } from "@/lib/auth/verify.server";

export const Route = createFileRoute("/api/drops/$id")({
  server: {
    handlers: {
      GET: async ({ request, params }) => {
        const url = new URL(request.url);
        const bearer = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "") || url.searchParams.get("token") || undefined;
        let userId: string;
        try {
          userId = await requireUserId(bearer);
        } catch {
          return Response.json({ error: "Unauthorized" }, { status: 401 });
        }
        const id = String(params.id || "");
        if (id.length < 8) return Response.json({ error: "Missing order" }, { status: 400 });
        const drops = await listOrderDrops(userId, id);
        const sql = await getSql();
        const orders = await sql<{ status: string }>`select status from engagement_orders where id = ${id} and user_id = ${userId}`;
        const placed = drops.filter((d) => d.status === "placed").length;
        console.log(`[drops] poll order ${id.slice(0, 8)} → ${drops.length} runs, ${placed} placed`);
        return Response.json(
          { drops, status: orders[0]?.status ?? "processing", at: Date.now() },
          { headers: { "cache-control": "no-store, max-age=0" } },
        );
      },
    },
  },
});
