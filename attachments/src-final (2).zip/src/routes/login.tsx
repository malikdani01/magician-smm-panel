import { useState, type FormEvent } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { GROK_PROVIDERS, authClient, authEnabled, rememberSessionToken, signIn } from "@/lib/auth/client";
import { Mark, inputClass } from "@/components/shell";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const [mode, setMode] = useState<"in" | "up">("in");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setError("");
    setPending(true);
    try {
      if (mode === "up") {
        const result = await authClient.signUp.email({
          email,
          password,
          name: name || email.split("@")[0] || "Member",
          callbackURL: "/dashboard",
        });
        if (result.error) throw new Error(result.error.message || "Could not create the account.");
        const token = (result.data as { token?: string } | null)?.token;
        if (token) rememberSessionToken(token);
      } else {
        const result = await authClient.signIn.email({
          email,
          password,
          callbackURL: "/dashboard",
        });
        if (result.error) throw new Error(result.error.message || "Those details were not accepted.");
        const token = (result.data as { token?: string } | null)?.token;
        if (token) rememberSessionToken(token);
      }
      window.location.assign("/dashboard");
      return;
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign-in failed.");
    } finally {
      setPending(false);
    }
  }

  return (
    <main className="relative min-h-screen px-4 py-8">
      <Link to="/" className="inline-flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-slate-800">
        <ArrowLeft className="size-4" /> Back to home
      </Link>
      <div className="mx-auto mt-8 w-full max-w-md">
        <div className="mb-6 flex justify-center">
          <Mark />
        </div>
        <div className="rounded-2xl border border-[#bae6fd] bg-white p-6 shadow-[0_14px_40px_rgba(20,50,110,0.08)] md:p-8">
          <h1 className="text-3xl text-slate-900">{mode === "in" ? "Welcome back" : "Create your desk"}</h1>
          <p className="mt-1 text-sm text-slate-500">
            {mode === "in" ? "Sign in to your dashboard." : "Free account. Add credit when you are ready."}
          </p>
          {authEnabled ? (
            <form onSubmit={submit} className="mt-6 space-y-4">
              {mode === "up" && (
                <label className="block space-y-1.5">
                  <span className="text-xs font-semibold text-mute">Name</span>
                  <input className={inputClass} value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" />
                </label>
              )}
              <label className="block space-y-1.5">
                <span className="text-xs font-semibold text-mute">Email</span>
                <input
                  className={inputClass}
                  type="email"
                  required
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                />
              </label>
              <label className="block space-y-1.5">
                <span className="flex items-center justify-between text-xs font-semibold text-mute">
                  Password
                  {mode === "in" && <span className="font-medium text-primary">8+ characters</span>}
                </span>
                <input
                  className={inputClass}
                  type="password"
                  required
                  minLength={8}
                  autoComplete={mode === "up" ? "new-password" : "current-password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                />
              </label>
              {error && <p className="text-sm text-destructive">{error}</p>}
              <button
                type="submit"
                disabled={pending}
                className="btn-gradient inline-flex min-h-12 w-full items-center justify-center rounded-xl text-sm font-semibold disabled:opacity-50"
              >
                {pending ? "Please wait…" : mode === "in" ? "Sign in" : "Create account"}
              </button>
              <button
                type="button"
                className="w-full text-center text-sm text-slate-500"
                onClick={() => {
                  setMode(mode === "in" ? "up" : "in");
                  setError("");
                }}
              >
                {mode === "in" ? (
                  <>Don't have an account? <span className="font-semibold text-primary">Sign up</span></>
                ) : (
                  <>Already have a desk? <span className="font-semibold text-primary">Sign in</span></>
                )}
              </button>
              <div className="space-y-2 border-t border-line pt-4">
                {GROK_PROVIDERS.map((provider) => (
                  <button
                    key={provider.providerId}
                    type="button"
                    onClick={() => signIn(provider.providerId, { callbackURL: "/dashboard" })}
                    className="inline-flex min-h-11 w-full items-center justify-center rounded-xl border border-line bg-card text-sm font-semibold"
                  >
                    Continue with {provider.label}
                  </button>
                ))}
              </div>
            </form>
          ) : (
            <p className="mt-4 text-sm text-mute">Sign-in is disabled.</p>
          )}
        </div>
      </div>
    </main>
  );
}
