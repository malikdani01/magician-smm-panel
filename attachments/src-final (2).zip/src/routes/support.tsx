import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Authed } from "@/components/gate";
import { listTickets, openTicket } from "@/lib/panel.functions";

export const Route = createFileRoute("/support")({
  component: () => (
    <Authed>
      <Support />
    </Authed>
  ),
});

const FAQ = [
  ["How fast is delivery?", "Orders stay on your ledger and drip by the schedule you set. A provider is not connected yet, so nothing is sent upstream."],
  ["Why is Place Order disabled?", "The wallet has to cover the total. Add funds on the wallet page. That credit is local until a gateway is connected."],
  ["Can I change ratios?", "Yes. Settings stores your organic ratios, and the order page has a per-type Settings panel."],
];

function Support() {
  const [rows, setRows] = useState<{ id: string; subject: string; body: string }[]>([]);
  const [open, setOpen] = useState(false);
  const [faq, setFaq] = useState(false);
  const [chat, setChat] = useState(false);
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [note, setNote] = useState("");

  function load() {
    listTickets().then(setRows).catch(() => setRows([]));
  }
  useEffect(load, []);

  async function send() {
    try {
      await openTicket({ data: { subject, body } });
      setSubject("");
      setBody("");
      setOpen(false);
      setChat(false);
      setNote("Ticket saved.");
      load();
    } catch (err: unknown) {
      setNote(err instanceof Error ? err.message : "Could not open the ticket.");
    }
  }

  return (
    <div className="mx-auto max-w-xl space-y-4">
      <section className="flex items-center justify-between rounded-3xl border border-[#e7eef6] bg-white p-4">
        <div>
          <h1 className="text-[22px] font-bold">Support Center</h1>
          <p className="text-[13px] text-[#64748b]">Get help with your orders and account</p>
        </div>
        <button type="button" onClick={() => setOpen(true)} className="rounded-xl bg-[#3b82f6] px-3 py-2 text-[13px] font-semibold text-white">+ New Ticket</button>
      </section>
      <div className="grid grid-cols-4 gap-2 text-center">
        {[["Total Tickets", rows.length], ["Open", rows.length], ["Resolved", 0], ["Avg Response", "~2h"]].map(([label, value]) => (
          <article key={String(label)} className="rounded-2xl border border-[#e7eef6] bg-white p-3">
            <p className="text-[18px] font-bold">{value}</p>
            <p className="text-[11px] text-[#94a3b8]">{label}</p>
          </article>
        ))}
      </div>
      <section className="rounded-3xl border border-[#e7eef6] bg-white p-6 text-center">
        <p className="font-semibold">Your Tickets</p>
        {rows.length === 0 ? (
          <>
            <p className="mt-6 text-[13px] text-[#94a3b8]">No tickets yet<br />Need help? Create a support ticket and we'll assist you.</p>
            <button type="button" onClick={() => setOpen(true)} className="mt-3 h-10 rounded-xl bg-[#3b82f6] px-4 text-[13px] font-semibold text-white">+ Create Your First Ticket</button>
          </>
        ) : (
          <ul className="mt-3 space-y-2 text-left text-[13px]">
            {rows.map((row) => <li key={row.id} className="rounded-xl bg-[#f8fafc] p-3"><b>{row.subject}</b><p>{row.body}</p></li>)}
          </ul>
        )}
      </section>
      <section className="flex items-center justify-between rounded-3xl border border-[#e7eef6] bg-white p-4">
        <div>
          <p className="font-semibold">Need Quick Help?</p>
          <p className="text-[12px] text-[#94a3b8]">Check our FAQ or contact us directly for urgent issues</p>
        </div>
        <div className="flex gap-2">
          <button type="button" onClick={() => setFaq((value) => !value)} className="rounded-xl border px-3 py-2 text-[12px] font-semibold">View FAQ</button>
          <button type="button" onClick={() => setChat(true)} className="rounded-xl border px-3 py-2 text-[12px] font-semibold">Live Chat</button>
        </div>
      </section>
      {faq && (
        <div className="space-y-2">
          {FAQ.map(([q, a]) => <article key={q} className="rounded-2xl bg-white p-3 text-[13px]"><b>{q}</b><p className="text-[#64748b]">{a}</p></article>)}
        </div>
      )}
      {(open || chat) && (
        <section className="rounded-3xl border border-[#e7eef6] bg-white p-4">
          <p className="font-semibold">{chat ? "Live chat desk" : "New ticket"}</p>
          <p className="text-[12px] text-[#94a3b8]">Saved on your ledger. No outside agent is connected.</p>
          <input value={subject} onChange={(event) => setSubject(event.target.value)} placeholder="Subject" className="mt-2 h-11 w-full rounded-xl bg-[#f8fafc] px-3" />
          <textarea value={body} onChange={(event) => setBody(event.target.value)} placeholder="What do you need?" className="mt-2 h-24 w-full rounded-xl bg-[#f8fafc] p-3" />
          <button type="button" onClick={send} className="mt-2 h-10 rounded-xl bg-[#3b82f6] px-4 text-[13px] font-semibold text-white">Send</button>
        </section>
      )}
      {note && <p className="text-center text-[13px]">{note}</p>}
    </div>
  );
}
