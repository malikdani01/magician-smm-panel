import { readFileSync } from "node:fs";

const API = "https://yoyomedia.in/api/v2";
const FREE_MODELS = [
  "google/gemma-4-26b-a4b-it:free",
  "nvidia/nemotron-3-super-120b-a12b:free",
  "thinkingmachines/inkling-small:free",
];

type Secrets = { openrouter: string; yoyomedia: string };

export type LiveService = {
  id: number;
  platform: string;
  category: string;
  name: string;
  min: number;
  max: number;
  rateUsd: number;
  note: string;
  dripAllowed: boolean;
};

type RawService = {
  service: number | string;
  name: string;
  type?: string;
  category: string;
  rate: string | number;
  min: string | number;
  max: string | number;
  refill?: boolean;
  dripfeed?: boolean;
  description?: string;
};

type ProviderLine = {
  engagement_type: string;
  quantity: number;
  runs?: number;
  intervalMinutes?: number;
  serviceId?: string;
  apiUrl?: string;
  apiKey?: string;
};
export type PlacedLine = { engagement_type: string; providerOrderId: string; label: string };

let catalogCache: { at: number; rows: RawService[] } | null = null;
let balanceCache: { at: number; balanceUsd: number; currency: string } | null = null;

function secrets(): Secrets {
  const fromEnv = {
    openrouter: process.env.OPENROUTER_API_KEY || "",
    yoyomedia: process.env.YOYOMEDIA_API_KEY || "",
  };
  if (fromEnv.openrouter && fromEnv.yoyomedia) return fromEnv;
  const candidates = [
    process.env.PROVIDERS_FILE || "",
    `${process.cwd()}/.secrets/providers.json`,
    "/workspace/.secrets/providers.json",
  ].filter(Boolean);
  let file: Secrets = { openrouter: "", yoyomedia: "" };
  for (const path of candidates) {
    try {
      file = JSON.parse(readFileSync(path, "utf8")) as Secrets;
      break;
    } catch {
      /* try the next location */
    }
  }
  return {
    openrouter: fromEnv.openrouter || file.openrouter,
    yoyomedia: fromEnv.yoyomedia || file.yoyomedia,
  };
}

async function yoyo(fields: Record<string, string>, apiUrl?: string, apiKey?: string) {
  const key = apiKey || secrets().yoyomedia;
  if (!key) throw new Error("No provider API key is saved.");
  const body = new URLSearchParams({ key, ...fields });
  const response = await fetch(apiUrl || API, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body,
  });
  const json = (await response.json()) as { error?: string; order?: number | string };
  if (!response.ok || json?.error) throw new Error(json?.error || `Provider returned ${response.status}.`);
  return json as Record<string, unknown>;
}

export async function providerOrderStatus(orderId: string, apiUrl?: string, apiKey?: string) {
  const json = await yoyo({ action: "status", order: orderId }, apiUrl, apiKey);
  return {
    status: String(json.status || "unknown"),
    remains: String(json.remains ?? ""),
    startCount: String(json.start_count ?? ""),
  };
}

export async function fetchProviderCatalog(apiUrl?: string, apiKey?: string) {
  const rows = (await yoyo({ action: "services" }, apiUrl, apiKey)) as unknown as RawService[];
  if (!Array.isArray(rows)) throw new Error("Provider did not return a service list.");
  return rows;
}

export function detectPlatform(category: string, name: string) {
  const text = `${category} ${name}`.toLowerCase();
  if (/instagram|\bigtv\b/.test(text)) return "instagram";
  if (/tik\s?tok/.test(text)) return "tiktok";
  if (/you\s?tube/.test(text)) return "youtube";
  if (/facebook/.test(text)) return "facebook";
  if (/twitter|retweet/.test(text)) return "twitter";
  if (/telegram/.test(text)) return "telegram";
  if (/whats\s?app/.test(text)) return "whatsapp";
  if (/spotify/.test(text)) return "spotify";
  if (/linkedin/.test(text)) return "linkedin";
  if (/discord/.test(text)) return "discord";
  if (/twitch/.test(text)) return "twitch";
  if (/snapchat/.test(text)) return "snapchat";
  if (/kwai/.test(text)) return "kwai";
  return "other";
}

async function rawServices() {
  if (catalogCache && Date.now() - catalogCache.at < 10 * 60 * 1000) return catalogCache.rows;
  const rows = (await yoyo({ action: "services" })) as unknown as RawService[];
  if (!Array.isArray(rows)) throw new Error("YoYoMedia did not return a service list.");
  catalogCache = { at: Date.now(), rows };
  return rows;
}

function toLive(row: RawService): LiveService {
  const note = String(row.description || row.type || "").split("\n").map((line) => line.trim()).filter(Boolean)[0] || "";
  return {
    id: Number(row.service),
    platform: detectPlatform(row.category, row.name),
    category: row.category,
    name: row.name,
    min: Number(row.min) || 1,
    max: Number(row.max) || 1,
    rateUsd: Number(row.rate) || 0,
    note: note.slice(0, 180),
    dripAllowed: Boolean(row.dripfeed),
  };
}

export async function providerBalance() {
  if (balanceCache && Date.now() - balanceCache.at < 60 * 1000) return balanceCache;
  const json = await yoyo({ action: "balance" });
  balanceCache = { at: Date.now(), balanceUsd: Number(json.balance) || 0, currency: String(json.currency || "USD") };
  return balanceCache;
}

export async function browseProvider(input: { platform: string; category: string; query: string }) {
  const rows = (await rawServices()).map(toLive).filter((row) => input.platform === "all" || row.platform === input.platform);
  const names = Array.from(new Set(rows.map((row) => row.category))).sort((a, b) => a.localeCompare(b));
  const categories = input.platform === "all" ? ["All categories", ...names] : names;
  const category = categories.includes(input.category) ? input.category : categories[0] || "";
  const query = input.query.trim().toLowerCase();
  let services = category === "All categories" ? rows : rows.filter((row) => row.category === category);
  if (query) {
    services = rows.filter((row) => `${row.id} ${row.name} ${row.category}`.toLowerCase().includes(query));
  }
  const cap = category === "All categories" && !query ? rows.length : 200;
  return { categories, category, services: services.slice(0, cap) };
}

export async function findLiveService(id: number) {
  const row = (await rawServices()).find((item) => Number(item.service) === id);
  return row ? toLive(row) : null;
}

const TYPE_RULE: Record<string, { yes: RegExp; no: RegExp }> = {
  views: { yes: /\bviews?\b/, no: /\b(likes?|shares?|saves?|favourites?|favorites?|comments?|followers?|reposts?|subscribers?)\b/ },
  likes: { yes: /\blikes?\b/, no: /\b(views?|shares?|saves?|favourites?|favorites?|comments?|followers?|reposts?|subscribers?|live)\b/ },
  comments: { yes: /\bcomments?\b/, no: /\b(views?|likes?|shares?|saves?|favourites?|favorites?|followers?|reposts?|live)\b/ },
  shares: { yes: /\bshares?\b/, no: /\b(views?|likes?|saves?|favourites?|favorites?|comments?|followers?|reposts?|live)\b/ },
  saves: { yes: /\b(saves?|favourites?|favorites?)\b/, no: /\b(views?|likes?|shares?|comments?|followers?|reposts?|live)\b/ },
  reposts: { yes: /\breposts?\b/, no: /\b(views?|likes?|shares?|saves?|favourites?|favorites?|comments?|followers?|live)\b/ },
  followers: { yes: /\bfollowers?\b/, no: /\b(views?|likes?|shares?|saves?|favourites?|favorites?|comments?|reposts?)\b/ },
};

export async function pickRandomService(platform: string, type: string, quantity: number, apiUrl?: string, apiKey?: string) {
  const rows = await fetchProviderCatalog(apiUrl, apiKey);
  const rule = TYPE_RULE[type] || { yes: new RegExp(`\\b${type}\\b`, "i"), no: /$^/ };
  const candidates = rows.filter((row) => {
    if (detectPlatform(row.category, row.name) !== platform) return false;
    if (row.type && row.type !== "Default") return false;
    const name = String(row.name || "").toLowerCase();
    if (!rule.yes.test(name) || rule.no.test(name)) return false;
    if (/combo|package|\+|free /.test(name)) return false;
    const min = Number(row.min);
    const max = Number(row.max);
    return quantity >= min && quantity <= max;
  });
  if (candidates.length === 0) return null;
  candidates.sort((a, b) => Number(a.rate) - Number(b.rate));
  const pool = candidates.slice(0, 12);
  const choice = pool[Math.floor(Math.random() * pool.length)];
  return { serviceId: String(choice.service), name: String(choice.name) };
}

function matchService(rows: RawService[], platform: string, type: string, quantity: number, preferDrip = false) {
  const rule = TYPE_RULE[type] || { yes: new RegExp(`\\b${type}\\b`, "i"), no: /$^/ };
  const candidates = rows.filter((row) => {
    if (detectPlatform(row.category, row.name) !== platform) return false;
    if (row.type && row.type !== "Default") return false;
    const name = String(row.name || "").toLowerCase();
    if (!rule.yes.test(name) || rule.no.test(name)) return false;
    if (/combo|package|\+|free /.test(name)) return false;
    const min = Number(row.min);
    const max = Number(row.max);
    return quantity >= min && quantity <= max;
  });
  candidates.sort((a, b) => Number(a.rate) - Number(b.rate));
  const pool = preferDrip && candidates.some((row) => row.dripfeed) ? candidates.filter((row) => row.dripfeed) : candidates;
  return pool[0] || null;
}

async function cancelOrders(ids: string[]) {
  await Promise.all(ids.map(async (id) => {
    try {
      await yoyo({ action: "cancel", order: id });
    } catch {
      /* provider may reject cancel; the caller still surfaces the original error */
    }
  }));
}

export async function placeProviderLines(platform: string, link: string, lines: ProviderLine[]): Promise<PlacedLine[]> {
  const rows = await rawServices();
  const placed: PlacedLine[] = [];
  try {
    for (const line of lines) {
      const spread = Boolean(line.runs && line.runs > 1 && line.intervalMinutes);
      const service = line.serviceId ? null : matchService(rows, platform, line.engagement_type, line.quantity, spread);
      if (!line.serviceId && !service) {
        throw new Error(`YoYoMedia has no ${platform} ${line.engagement_type} service for quantity ${line.quantity.toLocaleString("en-IN")}.`);
      }
      const fields: Record<string, string> = {
        action: "add",
        service: String(line.serviceId || service?.service),
        link,
        quantity: String(line.quantity),
      };
      if (!line.serviceId && spread && service?.dripfeed && line.runs && line.intervalMinutes) {
        fields.runs = String(line.runs);
        fields.interval = String(line.intervalMinutes);
      }
      const result = line.serviceId
        ? await yoyo(fields, line.apiUrl, line.apiKey)
        : await yoyo(fields);
      if (!result.order) throw new Error(`Provider rejected ${line.engagement_type}.`);
      placed.push({
        engagement_type: line.engagement_type,
        providerOrderId: String(result.order),
        label: String(service?.name || `Service ${line.serviceId}`),
      });
    }
    return placed;
  } catch (error) {
    await cancelOrders(placed.map((line) => line.providerOrderId));
    throw error;
  }
}

export async function placeExactService(serviceId: number, link: string, quantity: number) {
  const result = await yoyo({
    action: "add",
    service: String(serviceId),
    link,
    quantity: String(quantity),
  });
  if (!result.order) throw new Error("YoYoMedia rejected this order.");
  return String(result.order);
}

export async function cancelProviderOrder(id: string) {
  await cancelOrders([id]);
}

export async function askFreeModel(system: string, prompt: string) {
  const key = secrets().openrouter;
  if (!key) throw new Error("OpenRouter key is missing.");
  let last = "The free model did not answer.";
  for (const model of FREE_MODELS) {
    try {
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${key}`,
          "Content-Type": "application/json",
          "HTTP-Referer": "http://127.0.0.1:8080",
          "X-Title": "Magiciansmm",
        },
        body: JSON.stringify({
          model,
          messages: [
            { role: "system", content: system },
            { role: "user", content: prompt },
          ],
          max_tokens: 400,
          temperature: 0.2,
        }),
      });
      const json = (await response.json()) as {
        error?: { message?: string };
        choices?: { message?: { content?: string | null; reasoning?: string | null } }[];
      };
      if (!response.ok) throw new Error(json.error?.message || `${model} failed.`);
      const message = json.choices?.[0]?.message;
      const text = (message?.content || message?.reasoning || "").trim();
      if (!text) throw new Error(`${model} returned an empty reply.`);
      return text;
    } catch (error) {
      last = error instanceof Error ? error.message : last;
    }
  }
  throw new Error(last);
}
