/** Provider rates are USD per 1,000. The desk shows INR. */
export const USD_TO_INR = 84;

export function usdQtyToPaise(ratePerThousandUsd: number, quantity: number) {
  if (!Number.isFinite(ratePerThousandUsd) || !Number.isFinite(quantity) || quantity <= 0) return 0;
  return Math.max(1, Math.round((quantity / 1000) * ratePerThousandUsd * USD_TO_INR * 100));
}
