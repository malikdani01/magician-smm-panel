import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Library, Sparkles, Wallet } from "lucide-react";
import { Authed } from "@/components/gate";
import { getDashboard, getPrefs, type DashboardData } from "@/lib/panel.functions";
import { inr } from "@/lib/money";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/dashboard")({
  component: () => (
    <Authed>
      <Dashboard />
    </Authed>
  ),
});

function greeting() {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning,";
  if (hour < 18) return "Good afternoon,";
  return "Good evening,";
}

function Dashboard() {
  const { user } = useCurrentUserState();
  const [data, setData] = useState<DashboardData | null>(null);
  const [name, setName] = useState("");

  useEffect(() => {
    getDashboard().then(setData).catch(() => setData(null));
    getPrefs().then((prefs) => setName(prefs.full_name || "")).catch(() => setName(""));
  }, []);

  const display = name || user?.displayName || "Member";
  const cards = [
    ["BALANCE", data ? inr(data.balance_paise) : "—", "Available funds"],
    ["TOTAL ORDERS", String(data?.order_count ?? 0), `${data?.order_count ?? 0} completed`],
    ["ACTIVE", String(data?.queued_count ?? 0), "In progress"],
    ["TOTAL SPENT", data ? inr(data.spend_paise) : "—", "All time"],
  ];

  return (
    <div className="mx-auto max-w-xl space-y-4">
      <div className="flex items-end justify-between">
        <div>
          <p className="text-[13px] text-[#64748b]">{greeting()}</p>
          <h1 className="text-[28px] font-bold">{display}</h1>
        </div>
        <div className="flex gap-2">
          <Link to="/engagement-order" className="rounded-full bg-[#eef4ff] px-3 py-2 text-[12px] font-semibold text-[#2458c5]">Engagement</Link>
          <Link to="/mass" className="rounded-full bg-[#3b82f6] px-3 py-2 text-[12px] font-semibold text-white">Mass Order</Link>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {cards.map(([label, value, hint]) => (
          <article key={label} className="rounded-2xl border border-[#e7eef6] bg-white p-4">
            <p className="text-[10px] font-semibold tracking-wide text-[#94a3b8]">{label}</p>
            <p className="text-[22px] font-bold">{value}</p>
            <p className="text-[12px] text-[#94a3b8]">{hint}</p>
          </article>
        ))}
      </div>
      <section className="rounded-2xl border border-[#e7eef6] bg-white p-6 text-center">
        <p className="font-semibold">All Orders</p>
        <p className="mt-6 text-[13px] text-[#94a3b8]">{data?.recent.length ? `${data.recent.length} recent` : "No engagement orders yet"}</p>
        <Link to="/engagement-order" className="mt-3 inline-flex h-10 items-center rounded-full bg-[#3b82f6] px-4 text-[13px] font-semibold text-white">Create First Order</Link>
      </section>
      <section className="rounded-2xl border border-[#e7eef6] bg-white p-6 text-center">
        <p className="font-semibold">Single Orders</p>
        <p className="mt-6 text-[13px] text-[#94a3b8]">No orders yet</p>
        <Link to="/catalog" className="mt-3 inline-flex h-10 items-center rounded-full bg-[#3b82f6] px-4 text-[13px] font-semibold text-white">Place Order</Link>
      </section>
      <div className="grid grid-cols-3 gap-2">
        <Link to="/engagement-order" className="rounded-2xl border border-[#e7eef6] bg-white p-3 text-[12px]"><Sparkles className="mb-1 size-4 text-[#3b82f6]" /><b>Full Engagement</b><p className="text-[#94a3b8]">Views + Likes + Comments</p></Link>
        <Link to="/wallet" className="rounded-2xl border border-[#e7eef6] bg-white p-3 text-[12px]"><Wallet className="mb-1 size-4 text-emerald-500" /><b>Add Funds</b><p className="text-[#94a3b8]">Deposit to wallet</p></Link>
        <Link to="/catalog" className="rounded-2xl border border-[#e7eef6] bg-white p-3 text-[12px]"><Library className="mb-1 size-4 text-sky-500" /><b>All Services</b><p className="text-[#94a3b8]">Browse catalog</p></Link>
      </div>
    </div>
  );
}
