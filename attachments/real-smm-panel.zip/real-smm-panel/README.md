# OrganicSMM Pro — Real Engagement Panel

Modern dark-themed SMM Panel inspired by organicsmm.pro & extipspanel.com, focused on **real-looking organic engagement**.

## Features

- **No Balance / No Top-up / No Payment** — Orders go straight to YoYo Media API
- **Real Engagement (Auto Boost)** section with:
  - Platform selector (Instagram / TikTok)
  - Base Views quantity
  - Delivery time window
  - Graph curves (S-Curve, Linear, Spike, Viral, Slow Build)
  - AI-calculated organic ratios for Likes / Comments / Shares / Saves / Reposts
  - Toggle each engagement type
  - One-click multi-order placement
- **New Order** — Full service catalog (4000+ services) with search + category filter
- **Orders** tracking (stored locally + status check via API)
- Dark modern UI matching the screenshots you provided

## How to Run

1. Open `index.html` in any modern browser (Chrome / Edge / Firefox)
2. Or serve it locally:

```bash
cd real-smm-panel
python3 -m http.server 8080
# then open http://localhost:8080
```

## API

- Provider: https://yoyomedia.in
- Endpoint: `https://yoyomedia.in/api/v2`
- Your API key is already configured in `app.js`

## Notes

- Services are loaded live from the API on page load.
- Real Engagement automatically finds the cheapest matching views/likes/comments services.
- For production you should move the API key to a backend proxy so it is not visible in the browser.
- AI key is present for future “Ask AI” enhancements (currently ratios are smart defaults that adapt to the selected graph).

## Structure

```
real-smm-panel/
├── index.html   ← UI
├── app.js       ← All logic + API calls
└── README.md
```
