#!/usr/bin/env python3
"""
OrganicSMM Pro Server
- YoYo Media API proxy
- OpenRouter AI proxy
- Background scheduler for curve-based manual order placement
"""

from http.server import HTTPServer, SimpleHTTPRequestHandler
import urllib.request
import urllib.parse
import json
import ssl
import threading
import time
import uuid

API_URL = "https://yoyomedia.in/api/v2"
API_KEY = "59fcf26c648e111617dafa5d77683f1d1523ea87f58776c88b35d69c5ffdbc99"
AI_URL = "https://openrouter.ai/api/v1/chat/completions"
AI_KEY = "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"

campaigns = {}
pending_jobs = []
jobs_lock = threading.Lock()


def place_smm_order(service_id, link, quantity):
    try:
        data = urllib.parse.urlencode({
            "key": API_KEY,
            "action": "add",
            "service": service_id,
            "link": link,
            "quantity": quantity
        }).encode("utf-8")
        req = urllib.request.Request(API_URL, data=data, method="POST")
        req.add_header("Content-Type", "application/x-www-form-urlencoded")
        ctx = ssl.create_default_context()
        with urllib.request.urlopen(req, context=ctx, timeout=30) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"error": str(e)}


def scheduler_loop():
    print("[Scheduler] Started - will place orders at calculated times")
    while True:
        now = time.time()
        to_run = []
        with jobs_lock:
            still = []
            for job in pending_jobs:
                if job["execute_at"] <= now and job["status"] == "scheduled":
                    to_run.append(job)
                else:
                    still.append(job)
            pending_jobs[:] = still

        for job in to_run:
            print(f"[Scheduler] Placing {job['type']} x{job['quantity']} (campaign {job['campaign_id']})")
            result = place_smm_order(job["service"], job["link"], job["quantity"])
            job["status"] = "placed" if result.get("order") else "failed"
            job["order_id"] = result.get("order")
            job["result"] = result
            job["placed_at"] = time.time()

            cid = job["campaign_id"]
            if cid in campaigns:
                campaigns[cid]["placed_count"] = campaigns[cid].get("placed_count", 0) + 1
                if job["status"] == "placed":
                    campaigns[cid]["orders"].append({
                        "order_id": result.get("order"),
                        "type": job["type"],
                        "qty": job["quantity"],
                        "placed_at": job["placed_at"]
                    })
                if campaigns[cid]["placed_count"] >= campaigns[cid]["total_jobs"]:
                    campaigns[cid]["status"] = "completed"
            print(f"[Scheduler] -> {result}")

        time.sleep(10)


scheduler_thread = threading.Thread(target=scheduler_loop, daemon=True)
scheduler_thread.start()


class ProxyHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def do_GET(self):
        if self.path.startswith("/campaign/"):
            cid = self.path.split("/")[-1]
            data = campaigns.get(cid, {"error": "not found"})
            with jobs_lock:
                jobs = [j for j in pending_jobs if j["campaign_id"] == cid]
            out = dict(data)
            out["pending_jobs"] = [{
                "type": j["type"], "quantity": j["quantity"],
                "execute_at": j["execute_at"], "status": j["status"],
                "order_id": j.get("order_id"),
                "in_seconds": max(0, int(j["execute_at"] - time.time()))
            } for j in jobs]
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(out).encode())
        elif self.path == "/campaigns":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(list(campaigns.values())).encode())
        else:
            super().do_GET()

    def do_POST(self):
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length)

        if self.path == "/api":
            try:
                params = urllib.parse.parse_qs(body.decode("utf-8"))
                params["key"] = [API_KEY]
                data = urllib.parse.urlencode({k: v[0] for k, v in params.items()}).encode("utf-8")
                req = urllib.request.Request(API_URL, data=data, method="POST")
                req.add_header("Content-Type", "application/x-www-form-urlencoded")
                ctx = ssl.create_default_context()
                with urllib.request.urlopen(req, context=ctx, timeout=45) as resp:
                    result = resp.read()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(result)
            except Exception as e:
                self.send_response(500)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"error": str(e)}).encode())

        elif self.path == "/ai":
            try:
                payload = json.loads(body.decode("utf-8"))
                data = json.dumps(payload).encode("utf-8")
                req = urllib.request.Request(AI_URL, data=data, method="POST")
                req.add_header("Content-Type", "application/json")
                req.add_header("Authorization", f"Bearer {AI_KEY}")
                req.add_header("HTTP-Referer", "http://localhost:8080")
                req.add_header("X-Title", "OrganicSMM Pro")
                ctx = ssl.create_default_context()
                with urllib.request.urlopen(req, context=ctx, timeout=60) as resp:
                    result = resp.read()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(result)
            except Exception as e:
                self.send_response(500)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"error": str(e)}).encode())

        elif self.path == "/schedule":
            try:
                data = json.loads(body.decode("utf-8"))
                campaign_id = str(uuid.uuid4())[:8]
                jobs = data.get("jobs", [])
                now = time.time()

                campaign = {
                    "id": campaign_id,
                    "link": data.get("link"),
                    "platform": data.get("platform"),
                    "graph": data.get("graph"),
                    "hours": data.get("hours"),
                    "views": data.get("views"),
                    "created_at": now,
                    "status": "running",
                    "total_jobs": len(jobs),
                    "placed_count": 0,
                    "orders": [],
                    "ai_reason": data.get("ai_reason", "")
                }
                campaigns[campaign_id] = campaign

                with jobs_lock:
                    for j in jobs:
                        pending_jobs.append({
                            "campaign_id": campaign_id,
                            "type": j["type"],
                            "service": j["service"],
                            "link": data["link"],
                            "quantity": int(j["quantity"]),
                            "execute_at": now + float(j["delay_seconds"]),
                            "status": "scheduled",
                            "order_id": None
                        })

                print(f"[Campaign] {campaign_id} scheduled {len(jobs)} jobs over {data.get('hours')}h")
                for j in jobs:
                    mins = int(j['delay_seconds']) // 60
                    print(f"  -> {j['type']:12} qty={j['quantity']:6} in {mins} min")

                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({
                    "ok": True,
                    "campaign_id": campaign_id,
                    "total_jobs": len(jobs),
                    "message": f"Scheduled {len(jobs)} orders over {data.get('hours')} hours"
                }).encode())
            except Exception as e:
                self.send_response(500)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"error": str(e)}).encode())
        else:
            self.send_error(404)

    def log_message(self, format, *args):
        print(f"[{self.log_date_time_string()}] {args[0]}")


if __name__ == "__main__":
    port = 8080
    print("=" * 55)
    print("  OrganicSMM Pro Server")
    print("  Live AI + Curve-based Manual Scheduling")
    print("=" * 55)
    print(f"  Open: http://localhost:{port}")
    print("  KEEP THIS WINDOW OPEN while campaigns run!")
    print("  Press Ctrl+C to stop")
    print("=" * 55)
    server = HTTPServer(("0.0.0.0", port), ProxyHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
