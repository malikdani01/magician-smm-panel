import { useEffect, useState, type ButtonHTMLAttributes, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  Activity,
  LayoutDashboard,
  Library,
  LifeBuoy,
  ListPlus,
  Menu,
  MessageCircle,
  PlusSquare,
  Receipt,
  Settings,
  Sparkles,
  Wallet,
  Wand2,
  Users,
  Boxes,
  KeyRound,
  QrCode,
  X,
} from "lucide-react";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getWallet } from "@/lib/panel.functions";
import { getDeskRole } from "@/lib/admin.functions";
import { applyTheme, savedTheme } from "@/lib/theme";
import { inr } from "@/lib/money";

const walletCache = { at: 0, value: null as number | null };

const LINKS = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard, hot: false },
  { to: "/engagement-order", label: "Full Engagement", icon: Wand2, hot: false },
  { to: "/single-order", label: "Single Order", icon: PlusSquare, hot: false },
  { to: "/mass", label: "Mass Order", icon: ListPlus, hot: true },
  { to: "/engagement-orders", label: "All Orders", icon: Receipt, hot: false },
  { to: "/instagram", label: "Instagram Accounts", icon: Library, hot: false },
  { to: "/tiktok", label: "TikTok Accounts", icon: Library, hot: false },
  { to: "/detect", label: "Bot Detection", icon: Activity, hot: false },
  { to: "/wallet", label: "Wallet", icon: Wallet, hot: false },
  { to: "/telegram-bot", label: "Telegram Bot", icon: MessageCircle, hot: false },
  { to: "/support", label: "Support", icon: LifeBuoy, hot: false },
  { to: "/settings", label: "Settings", icon: Settings, hot: false },
] as const;

const ADMIN_LINKS = [
  { to: "/admin/services", label: "Services", icon: Boxes, hot: false },
  { to: "/admin/engagement", label: "Engagement APIs", icon: KeyRound, hot: false },
  { to: "/admin/payments", label: "Payments", icon: QrCode, hot: false },
  { to: "/admin/customers", label: "Customers", icon: Users, hot: false },
] as const;

export function Mark({ compact = false }: { compact?: boolean }) {
  return (
    <Link to="/" className="flex items-center gap-2.5">
      <span className="grid size-9 place-items-center rounded-2xl bg-gradient-to-br from-indigo-500 to-cyan-400 text-white shadow-lg shadow-indigo-500/30">
        <Sparkles className="size-4" />
      </span>
      {!compact && (
        <span className="flex flex-col leading-tight">
          <span className="text-[15px] font-bold tracking-tight text-foreground">Magiciansmm</span>
          <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-indigo-500/80">Premium desk</span>
        </span>
      )}
    </Link>
  );
}

export function Wordmark() {
  return <Mark />;
}

export function Shell({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (state) => state.location.pathname });
  const { user, isPending } = useCurrentUserState();
  const [balance, setBalance] = useState<number | null>(null);
  const [admin, setAdmin] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    applyTheme(savedTheme());
  }, []);

  useEffect(() => {
    setOpen(false);
    getDeskRole().then((role) => setAdmin(role === "admin")).catch(() => setAdmin(false));
    if (walletCache.value != null && Date.now() - walletCache.at < 20000) {
      setBalance(walletCache.value);
      return;
    }
    getWallet()
      .then((wallet) => {
        walletCache.at = Date.now();
        walletCache.value = wallet.balance_paise;
        setBalance(wallet.balance_paise);
      })
      .catch(() => setBalance(null));
  }, [path]);

  const links = admin ? [...LINKS, ...ADMIN_LINKS] : LINKS;
  const initial = (user?.displayName || user?.primaryEmail || "M").slice(0, 1).toUpperCase();
  const activeOf = (to: string) => path === to || (to !== "/dashboard" && path.startsWith(`${to}/`));

  const menu = (
    <>
      <div className="mx-4 mb-3 flex items-center gap-2.5 rounded-2xl border border-white/60 bg-white/70 px-3 py-2.5 shadow-sm">
        <div className="grid size-9 shrink-0 place-items-center rounded-full bg-gradient-to-br from-indigo-500 to-cyan-400 text-[12px] font-bold text-white">
          {initial}
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[13px] font-semibold">{user?.displayName || "Member"}</p>
          <p className="truncate text-[10px] text-mute">{user?.primaryEmail || "Signed in"}</p>
        </div>
        <span className="pulse-dot" />
      </div>
      <div className="wallet-card mx-4 mb-4 rounded-2xl p-4">
        <p className="mb-1 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider">
          <Wallet className="size-3" /> Wallet balance
        </p>
        <p className="mb-3 text-[26px] font-extrabold tracking-tight">{balance == null ? "—" : inr(balance)}</p>
        <Link to="/wallet" className="flex h-9 w-full items-center justify-center gap-1.5 rounded-xl text-[12px] font-semibold">
          <Wallet className="size-3.5" /> Add credit
        </Link>
      </div>
      <nav className="flex-1 overflow-y-auto px-3 pb-6">
        <p className="mb-2 px-3 text-[10px] font-semibold uppercase tracking-[0.22em] text-mute">Menu</p>
        {links.map((link) => {
          const active = activeOf(link.to);
          const Icon = link.icon;
          return (
            <Link
              key={link.to}
              to={link.to}
              className={
                "nav-item mb-1 flex min-h-11 items-center gap-2.5 rounded-2xl px-3 py-2 text-[13px] " +
                (active ? "bg-indigo-50 font-semibold text-indigo-600 shadow-sm" : "text-slate-600 hover:bg-white/80")
              }
            >
              <Icon className="size-4" />
              <span className="flex-1">{link.label}</span>
              {link.hot && !active && (
                <span className="rounded-full bg-gradient-to-r from-rose-500 to-orange-400 px-1.5 py-0.5 text-[8px] font-bold text-white">HOT</span>
              )}
            </Link>
          );
        })}
      </nav>
    </>
  );

  return (
    <div className="min-h-screen md:grid md:grid-cols-[272px_minmax(0,1fr)]">
      <aside className="sticky top-0 hidden h-screen flex-col border-r md:flex" style={{ background: "var(--desk-sidebar)", borderColor: "var(--desk-line)" }}>
        <div className="flex items-center justify-between px-5 pb-3 pt-5">
          <Mark />
        </div>
        {menu}
      </aside>

      {open && (
        <div className="fixed inset-0 z-40 md:hidden">
          <button type="button" aria-label="Close menu" className="absolute inset-0 bg-slate-900/40" onClick={() => setOpen(false)} />
          <aside className="drawer relative flex h-full w-[min(86vw,320px)] flex-col pt-4 shadow-2xl" style={{ background: "var(--desk-sidebar)" }}>
            <div className="mb-3 flex items-center justify-between px-5">
              <Mark />
              <button type="button" onClick={() => setOpen(false)} className="grid size-9 place-items-center rounded-full bg-white text-slate-600 shadow-sm" aria-label="Close">
                <X className="size-4" />
              </button>
            </div>
            {menu}
          </aside>
        </div>
      )}

      <div className="min-w-0 pb-24 md:pb-0">
        <header className="sticky top-0 z-20 flex items-center justify-between border-b px-4 py-3 backdrop-blur-xl" style={{ background: "color-mix(in oklab, var(--desk-header) 88%, transparent)", borderColor: "var(--desk-line)" }}>
          <button type="button" onClick={() => setOpen(true)} className="grid size-10 place-items-center rounded-2xl bg-white text-slate-700 shadow-sm md:hidden" aria-label="Open menu">
            <Menu className="size-5" />
          </button>
          <p className="text-[14px] font-semibold tracking-tight text-slate-800">Magiciansmm</p>
          <div>{isPending ? <div className="size-8" /> : <UserButton />}</div>
        </header>
        <main className="page-rise mx-auto max-w-6xl px-4 py-5 md:px-8 md:py-8">{children}</main>
      </div>

      <Link
        to="/support"
        className="fixed bottom-24 right-4 z-30 grid size-14 place-items-center rounded-full bg-gradient-to-br from-indigo-500 to-cyan-400 text-white shadow-2xl shadow-indigo-500/30 md:bottom-6"
        aria-label="Support"
      >
        <MessageCircle className="size-6" />
      </Link>

      <nav className="fixed inset-x-0 bottom-0 z-20 grid grid-cols-5 border-t backdrop-blur-xl md:hidden" style={{ background: "color-mix(in oklab, var(--desk-sidebar) 92%, transparent)", borderColor: "var(--desk-line)" }}>
        {LINKS.slice(0, 4).map((link) => {
          const active = activeOf(link.to);
          const Icon = link.icon;
          return (
            <Link key={link.to} to={link.to} className={"flex min-h-16 flex-col items-center justify-center gap-1 text-[10px] font-medium " + (active ? "text-indigo-600" : "text-slate-500")}>
              <Icon className="size-4" />
              {link.label.split(" ")[0]}
            </Link>
          );
        })}
        <button type="button" onClick={() => setOpen(true)} className="flex min-h-16 flex-col items-center justify-center gap-1 text-[10px] font-medium text-slate-500">
          <Menu className="size-4" />
          More
        </button>
      </nav>
    </div>
  );
}

export function Panel({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <section className={`glass-card p-5 ${className}`}>{children}</section>;
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block space-y-2">
      <span className="text-xs font-semibold tracking-wide text-mute">{label}</span>
      {children}
    </label>
  );
}

export const inputClass =
  "w-full rounded-xl border border-line bg-white/90 px-4 py-3 text-sm text-foreground outline-none focus:border-indigo-400";

export function PrimaryButton({ children, className = "", ...props }: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button {...props} className={"btn-gradient inline-flex min-h-11 items-center justify-center rounded-xl px-5 text-sm font-semibold disabled:opacity-50 " + className}>
      {children}
    </button>
  );
}

export function GhostButton({ children, className = "", ...props }: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button {...props} className={"inline-flex min-h-11 items-center justify-center rounded-xl border border-line bg-white px-5 text-sm font-semibold text-foreground " + className}>
      {children}
    </button>
  );
}
