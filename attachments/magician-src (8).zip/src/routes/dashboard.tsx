import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Library, RefreshCw, Wallet, Wand2, PlusSquare } from "lucide-react";
import { Authed } from "@/components/gate";
import { getDeskRole } from "@/lib/admin.functions";
import { apiBalances, getDashboard, getPrefs, type DashboardData } from "@/lib/panel.functions";
import { inr } from "@/lib/money";
import wizard from "@/assets/wizard.jpg";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/dashboard")({
  component: () => (
    <Authed>
      <Dashboard />
    </Authed>
  ),
});

function greeting() {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning,";
  if (hour < 18) return "Good afternoon,";
  return "Good evening,";
}

const TONES = [
  "from-violet-600 to-fuchsia-500",
  "from-emerald-500 to-teal-400",
  "from-amber-500 to-orange-400",
  "from-sky-500 to-indigo-500",
];

function Dashboard() {
  const { user } = useCurrentUserState();
  const [data, setData] = useState<DashboardData | null>(null);
  const [name, setName] = useState("");
  const [admin, setAdmin] = useState(false);
  const [balances, setBalances] = useState<Awaited<ReturnType<typeof apiBalances>>>([]);
  const [checking, setChecking] = useState(false);
  const [checkedAt, setCheckedAt] = useState("");

  function loadBalances() {
    setChecking(true);
    apiBalances()
      .then((rows) => {
        setBalances(rows);
        setCheckedAt(new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }));
      })
      .catch(() => setBalances([]))
      .finally(() => setChecking(false));
  }

  useEffect(() => {
    getDashboard().then(setData).catch(() => setData(null));
    getPrefs().then((prefs) => setName(prefs.full_name || "")).catch(() => setName(""));
    getDeskRole()
      .then((role) => {
        if (role !== "admin") return;
        setAdmin(true);
        loadBalances();
      })
      .catch(() => setAdmin(false));
  }, []);

  const display = name || user?.displayName || "Member";
  const cards = [
    ["BALANCE", data ? inr(data.balance_paise) : "—", "Available funds"],
    ["TOTAL ORDERS", String(data?.order_count ?? 0), `${data?.order_count ?? 0} completed`],
    ["ACTIVE", String(data?.queued_count ?? 0), "In progress"],
    ["TOTAL SPENT", data ? inr(data.spend_paise) : "—", "All time"],
  ];

  return (
    <div className="mx-auto max-w-xl space-y-4">
      <section className="hero-glow relative overflow-hidden rounded-[28px] border p-5" style={{ background: "linear-gradient(120deg, color-mix(in oklab, var(--desk-primary) 70%, #1e1b4b), color-mix(in oklab, var(--desk-accent) 35%, #0f172a))" }}>
        <div className="relative z-10 max-w-md">
          <p className="text-[13px] text-white/80">{greeting()}</p>
          <h1 className="text-[32px] font-extrabold text-white">Welcome back, {display}</h1>
          <p className="mt-1 text-[13px] text-white/75">Your SMM panel is ready. Place a drip, check APIs, add credit.</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Link to="/engagement-order" className="inline-flex h-10 items-center gap-1 rounded-full bg-white px-4 text-[13px] font-semibold text-violet-700">Create New Order</Link>
            <Link to="/mass" className="inline-flex h-10 items-center gap-1 rounded-full border border-white/30 px-4 text-[13px] font-semibold text-white">Mass Order</Link>
          </div>
        </div>
        <img src={wizard} alt="" className="pointer-events-none absolute -right-6 -top-4 hidden h-48 w-auto md:block" />
      </section>

      {admin && (
        <section className="rounded-2xl border p-4">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="font-semibold">API balance</p>
              <p className="text-[12px] text-[#94a3b8]">{checkedAt ? `Checked ${checkedAt}` : "Engagement aur service APIs"}</p>
            </div>
            <button type="button" onClick={loadBalances} disabled={checking} className="inline-flex h-9 items-center gap-1 rounded-full border px-3 text-[12px] font-semibold disabled:opacity-60">
              <RefreshCw className={`size-3.5 ${checking ? "animate-spin" : ""}`} /> {checking ? "Checking" : "Refresh"}
            </button>
          </div>
          {balances.length === 0 ? (
            <p className="mt-4 text-[13px] text-[#94a3b8]">{checking ? "Balances la rahe hain…" : "Koi API save nahi. Full engagement APIs mein URL + key daalo."}</p>
          ) : (
            <ul className="mt-3 space-y-2">
              {balances.map((row) => (
                <li key={`${row.host}-${row.keyTail}-${row.label}`} className="flex items-center justify-between gap-3 rounded-2xl px-3 py-2" style={{ background: "color-mix(in oklab, var(--desk-card) 70%, white 8%)" }}>
                  <div className="min-w-0">
                    <p className="truncate text-[13px] font-semibold capitalize">{row.label.replaceAll(":", " · ")}</p>
                    <p className="truncate text-[11px] text-[#94a3b8]">{row.host} · key ••••{row.keyTail}</p>
                    {row.error && <p className="text-[11px] text-rose-400">{row.error}</p>}
                  </div>
                  <div className="text-right">
                    <p className={`text-[16px] font-bold ${row.low ? "text-rose-400" : ""}`}>{row.error ? "—" : `${row.balance.toLocaleString("en-IN")} ${row.currency}`}</p>
                    {row.low && !row.error && <p className="text-[10px] font-bold uppercase text-rose-400">Low · refill</p>}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      )}

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {cards.map(([label, value, hint], index) => (
          <article key={label} className={`stat-pop rounded-2xl bg-gradient-to-br p-4 text-white ${TONES[index % TONES.length]}`} style={{ animationDelay: `${index * 60}ms` }}>
            <p className="text-[10px] font-semibold tracking-wide text-white/80">{label}</p>
            <p className="text-[22px] font-extrabold">{value}</p>
            <p className="text-[12px] text-white/75">{hint}</p>
          </article>
        ))}
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        <section className="rounded-2xl border p-5">
          <p className="font-semibold">All Orders</p>
          <p className="mt-2 text-[13px] text-[#94a3b8]">{data?.recent.length ? `${data.recent.length} recent` : "No engagement orders yet"}</p>
          <Link to="/engagement-order" className="mt-4 inline-flex h-10 items-center rounded-full bg-[#3b82f6] px-4 text-[13px] font-semibold text-white">Create First Order</Link>
        </section>
        <section className="rounded-2xl border p-5">
          <p className="font-semibold">Single Orders</p>
          <p className="mt-2 text-[13px] text-[#94a3b8]">Browse a service and place one order</p>
          <Link to="/catalog" className="mt-4 inline-flex h-10 items-center rounded-full bg-[#3b82f6] px-4 text-[13px] font-semibold text-white">Place Order</Link>
        </section>
      </div>

      <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
        <Link to="/engagement-order" className="rounded-2xl border p-3 text-[12px]"><Wand2 className="mb-1 size-4 text-violet-300" /><b>Full Engagement</b><p className="text-[#94a3b8]">Views + Likes + Saves</p></Link>
        <Link to="/wallet" className="rounded-2xl border p-3 text-[12px]"><Wallet className="mb-1 size-4 text-emerald-300" /><b>Add Funds</b><p className="text-[#94a3b8]">{data ? inr(data.balance_paise) : "Deposit to wallet"}</p></Link>
        <Link to="/single-order" className="rounded-2xl border p-3 text-[12px]"><PlusSquare className="mb-1 size-4 text-sky-300" /><b>Single Order</b><p className="text-[#94a3b8]">One service, one link</p></Link>
        <Link to="/catalog" className="rounded-2xl border p-3 text-[12px] sm:col-span-3"><Library className="mb-1 size-4 text-cyan-300" /><b>All Services</b><p className="text-[#94a3b8]">Browse catalog</p></Link>
      </div>
    </div>
  );
}
