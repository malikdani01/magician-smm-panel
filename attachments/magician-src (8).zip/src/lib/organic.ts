export type Pace = {
  window: "auto" | "6h" | "12h" | "24h" | "48h" | "custom";
  customHours: number;
  runsMode: "auto" | "manual";
  runs: number;
  variance: number;
  peak: boolean;
};

export const DEFAULT_PACE: Pace = {
  window: "auto",
  customHours: 24,
  runsMode: "auto",
  runs: 0,
  variance: 25,
  peak: false,
};

const CHUNK: Record<string, number> = {
  views: 100,
  likes: 10,
  comments: 10,
  shares: 10,
  reposts: 10,
  saves: 50,
  followers: 10,
};

function mix(seed: number) {
  const x = Math.sin(seed * 12.9898) * 43758.5453;
  return x - Math.floor(x);
}

export function autoRuns(quantity: number, type: string) {
  const chunk = CHUNK[type] ?? 10;
  const max = Math.max(1, Math.floor(quantity / chunk));
  const base = Math.max(1, Math.round(Math.sqrt(Math.max(quantity, 1)) * 0.52));
  const jitter = Math.round((mix(quantity + type.length * 17) - 0.45) * 6);
  return Math.min(max, Math.max(1, base + jitter));
}

export function windowHours(pace: Pace, runs: number) {
  if (pace.window === "6h") return 6;
  if (pace.window === "12h") return 12;
  if (pace.window === "24h") return 24;
  if (pace.window === "48h") return 48;
  if (pace.window === "custom") return Math.max(1, pace.customHours);
  return Math.max(2, runs * 2);
}

export function formatDuration(hours: number) {
  const totalMin = Math.max(1, Math.round(hours * 60));
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  if (h <= 0) return `~${m}m`;
  return `~${h}h ${m}m`;
}

export function riskLabel(variance: number) {
  if (variance < 18) return { label: "High", hint: "High detection risk — increase variance", tone: "rose" as const };
  if (variance < 35) return { label: "Medium", hint: "Moderate risk — consider increasing", tone: "amber" as const };
  return { label: "Low", hint: "Looks closer to organic pacing", tone: "emerald" as const };
}

export type RunRow = { at: Date; amount: number; total: number; peak: boolean };

function istHour(date: Date) {
  const hour = new Intl.DateTimeFormat("en-US", {
    timeZone: "Asia/Kolkata",
    hour: "2-digit",
    hourCycle: "h23",
  }).format(date);
  return Number(hour);
}

export function isPeakHour(date: Date) {
  const hour = istHour(date);
  return hour >= 18 && hour < 23;
}

function nextPeakStart(from: Date) {
  for (let step = 0; step < 30; step += 1) {
    const probe = new Date(from.getTime() + step * 60 * 60 * 1000);
    if (istHour(probe) !== 18) continue;
    const minute = Number(
      new Intl.DateTimeFormat("en-US", { timeZone: "Asia/Kolkata", minute: "2-digit" }).format(probe),
    );
    return new Date(probe.getTime() - minute * 60 * 1000);
  }
  return new Date(from.getTime() + 6 * 60 * 60 * 1000);
}

export function buildRuns(quantity: number, runs: number, variance: number, start = new Date(), totalHours = 24, seed = 1, peak = false): RunRow[] {
  const count = Math.max(1, Math.min(runs, Math.max(quantity, 1)));
  let slots: Date[];
  if (peak) {
    const peakCount = Math.max(1, Math.round(count * 0.65));
    const offCount = Math.max(0, count - peakCount);
    const peakStart = nextPeakStart(start);
    const peakGap = (5 * 60 * 60 * 1000) / peakCount;
    const offGap = (Math.max(totalHours, 5) * 60 * 60 * 1000) / Math.max(1, offCount);
    slots = [
      ...Array.from({ length: peakCount }, (_, index) => new Date(peakStart.getTime() + peakGap * index)),
      ...Array.from({ length: offCount }, (_, index) => new Date(start.getTime() + offGap * index)),
    ].sort((a, b) => a.getTime() - b.getTime());
  } else {
    const gap = (totalHours * 3600 * 1000) / count;
    slots = Array.from({ length: count }, (_, index) => new Date(start.getTime() + gap * index));
  }
  const weights = slots.map((at, index) => {
    const swing = (mix(seed + index * 3.1) * 2 - 1) * (variance / 100);
    let weight = Math.max(0.25, 1 + swing);
    if (peak) weight *= isPeakHour(at) ? 2.8 : 0.4;
    return weight;
  });
  const sum = weights.reduce((a, b) => a + b, 0);
  let used = 0;
  return weights.map((weight, index) => {
    const amount = index === count - 1 ? Math.max(0, quantity - used) : Math.max(1, Math.round((quantity * weight) / sum));
    used += amount;
    const at = slots[index] ?? start;
    return { at, amount, total: Math.min(quantity, used), peak: peak && isPeakHour(at) };
  }).filter((row) => row.amount > 0);
}

export const PROVIDER_MIN: Record<string, number> = {
  views: 100,
  likes: 10,
  comments: 10,
  shares: 10,
  reposts: 10,
  saves: 50,
  followers: 10,
};

function sampleCurve(curve: number[], t: number) {
  if (curve.length === 0) return 1;
  if (curve.length === 1) return Math.max(0.05, curve[0]);
  const x = Math.min(1, Math.max(0, t)) * (curve.length - 1);
  const index = Math.floor(x);
  const next = Math.min(curve.length - 1, index + 1);
  const mixAt = x - index;
  return Math.max(0.05, curve[index] + (curve[next] - curve[index]) * mixAt);
}

/** Split one line into provider-sized drops across the delivery window. */
export function planDrops(input: {
  quantity: number;
  type: string;
  runs: number;
  hours: number;
  curve?: number[];
  variance?: number;
  peak?: boolean;
  min?: number;
  start?: Date;
}) {
  const quantity = Math.max(0, Math.floor(input.quantity));
  if (quantity <= 0) return [] as { at: Date; amount: number }[];
  const min = Math.max(1, Math.floor(input.min ?? PROVIDER_MIN[input.type] ?? 10));
  const start = input.start ?? new Date();
  const hours = Math.max(1 / 60, Number(input.hours) || 1);
  const safeQty = Math.max(quantity, min);
  const pieces = Math.max(1, Math.min(Math.floor(safeQty / min), Math.floor(input.runs) || 1));
  const curve = (input.curve ?? []).filter((point) => Number.isFinite(point) && point > 0);
  const weights = Array.from({ length: pieces }, (_, index) => {
    const t = pieces === 1 ? 1 : index / (pieces - 1);
    const at = new Date(start.getTime() + t * hours * 3600 * 1000);
    let weight = sampleCurve(curve, t);
    if (input.peak) weight *= isPeakHour(at) ? 2.4 : 0.45;
    const swing = 1 + ((mix(index * 9.1 + quantity) * 2 - 1) * ((input.variance ?? 0) / 100));
    return Math.max(0.05, weight * swing);
  });
  const weightSum = weights.reduce((sum, weight) => sum + weight, 0);
  let leftover = safeQty - pieces * min;
  return weights.map((weight, index) => {
    const t = pieces === 1 ? 0 : index / (pieces - 1);
    const extra = index === pieces - 1 ? leftover : Math.min(leftover, Math.round((leftover * weight) / weightSum));
    leftover -= extra;
    return { at: new Date(start.getTime() + t * hours * 3600 * 1000), amount: min + Math.max(0, extra) };
  });
}

const MIX_GAP_MIN: Record<string, number> = {
  likes: 5,
  shares: 9,
  saves: 13,
  reposts: 17,
  comments: 21,
  followers: 25,
};

export type MixLine = {
  type: string;
  quantity: number;
  runs: number;
  hours: number;
  curve?: number[];
  variance?: number;
  peak?: boolean;
  min?: number;
};

export type MixDrop = { type: string; at: Date; amount: number; total: number };

/** Views are the spine. Likes, saves, shares and reposts land in the gaps, not after every view run is done. */
export function mixDrops(lines: MixLine[], start = new Date()): MixDrop[] {
  const planned = lines
    .filter((line) => Math.floor(line.quantity) > 0)
    .map((line) => ({
      type: line.type,
      drops: planDrops({
        quantity: line.quantity,
        type: line.type,
        runs: line.runs,
        hours: line.hours,
        curve: line.curve,
        variance: line.variance,
        peak: line.peak,
        min: line.min,
        start,
      }),
    }))
    .filter((line) => line.drops.length > 0);
  if (planned.length === 0) return [];
  const spine = planned.find((line) => line.type === "views") ?? planned.reduce((best, line) => (line.drops.length > best.drops.length ? line : best));
  const spineTimes = spine.drops.map((drop) => drop.at.getTime());
  const last = spineTimes[spineTimes.length - 1] ?? start.getTime();
  const used = new Set<number>();
  const mixed: { type: string; at: Date; amount: number }[] = [];

  const takeTime = (at: number) => {
    let next = at;
    while (used.has(next)) next += 15_000;
    used.add(next);
    return new Date(next);
  };

  spine.drops.forEach((drop) => {
    mixed.push({ type: spine.type, at: takeTime(drop.at.getTime()), amount: drop.amount });
  });

  for (const line of planned) {
    if (line.type === spine.type) continue;
    const count = line.drops.length;
    const gapMin = MIX_GAP_MIN[line.type] ?? 8;
    line.drops.forEach((drop, index) => {
      const slot = count === 1
        ? Math.min(spineTimes.length - 1, Math.max(0, Math.floor(spineTimes.length * 0.4)))
        : Math.min(spineTimes.length - 1, Math.round(((index + 1) * (spineTimes.length - 1)) / (count + 1)));
      const jitter = Math.round((mix(index * 17 + line.type.length * 3) - 0.5) * 4 * 60 * 1000);
      const at = Math.min(last + 8 * 60 * 1000, (spineTimes[slot] ?? start.getTime()) + gapMin * 60 * 1000 + jitter);
      mixed.push({ type: line.type, at: takeTime(at), amount: drop.amount });
    });
  }

  mixed.sort((a, b) => a.at.getTime() - b.at.getTime());
  const totals: Record<string, number> = {};
  return mixed.map((row) => {
    totals[row.type] = (totals[row.type] || 0) + row.amount;
    return { ...row, total: totals[row.type] };
  });
}

export function perRunSpread(quantity: number, runs: number, variance: number) {
  const each = quantity / Math.max(1, runs);
  const delta = Math.max(1, Math.round(each * (variance / 100)));
  return delta;
}

const BANDS: Record<string, { lowOk: number; highOk: number; lowDanger: number; highDanger: number; label: string }> = {
  likes: { lowOk: 4, highOk: 10, lowDanger: 1, highDanger: 20, label: "Likes / Views" },
  comments: { lowOk: 0.3, highOk: 1.5, lowDanger: 0.05, highDanger: 4, label: "Comments / Views" },
  shares: { lowOk: 0.3, highOk: 2, lowDanger: 0.02, highDanger: 5, label: "Shares / Views" },
  saves: { lowOk: 0.3, highOk: 3, lowDanger: 0.02, highDanger: 6, label: "Saves / Views" },
};

export function ratioReport(qty: Record<string, number>) {
  const views = qty.views ?? 0;
  const shares = (qty.shares ?? 0) + (qty.reposts ?? 0);
  const measured = {
    likes: qty.likes ?? 0,
    comments: qty.comments ?? 0,
    shares,
    saves: qty.saves ?? 0,
  };
  const checks = Object.entries(BANDS).map(([key, band]) => {
    const value = measured[key as keyof typeof measured];
    const pct = views > 0 ? (value / views) * 100 : 0;
    let status: "ok" | "low" | "high" | "danger_low" | "danger_high" | "none" = "none";
    if (views <= 0) status = "none";
    else if (pct <= band.lowDanger) status = "danger_low";
    else if (pct < band.lowOk) status = "low";
    else if (pct >= band.highDanger) status = "danger_high";
    else if (pct > band.highOk) status = "high";
    else status = "ok";
    const score = status === "ok" || status === "none" ? 100 : status === "low" || status === "high" ? 55 : 20;
    const mid = (band.lowOk + band.highOk) / 2;
    const aim = Math.round((views * mid) / 100);
    return { key, label: band.label, value, pct, status, score, aim, mid };
  });
  const scored = checks.filter((check) => check.status !== "none");
  const health = scored.length ? Math.round(scored.reduce((sum, check) => sum + check.score, 0) / scored.length) : 100;
  const suggestions = checks
    .filter((check) => check.status !== "ok" && check.status !== "none")
    .map((check) =>
      check.status === "high" || check.status === "danger_high"
        ? `Reduce ${check.key} or add more views: currently ${check.value.toLocaleString("en-IN")} (${check.pct.toFixed(2)}%). Aim ~${check.aim.toLocaleString("en-IN")} (${Math.round(check.mid)}%).`
        : `Add more ${check.key}: currently ${check.value.toLocaleString("en-IN")} (${check.pct.toFixed(2)}%). Try ~${check.aim.toLocaleString("en-IN")} (${Math.round(check.mid)}%).`,
    );
  return { checks, health, botting: 100 - health, suggestions, off: health < 100 };
}

export function curvePoints(kind: "s" | "steady" | "viral" | "double") {
  if (kind === "steady") return [0.08, 0.26, 0.46, 0.66, 0.84, 1];
  if (kind === "viral") return [0.02, 0.05, 0.12, 0.7, 0.92, 1];
  if (kind === "double") return [0.04, 0.42, 0.48, 0.55, 0.9, 1];
  return [0.04, 0.1, 0.22, 0.48, 0.78, 1];
}

export const GROWTH_FAMILIES = [
  "random-walk",
  "s-curve",
  "viral-spike",
  "steady-climb",
  "double-peak",
  "burst-pause",
  "slow-burn",
  "late-surge",
  "staircase",
  "front-load",
  "night-drip",
  "morning-ramp",
] as const;

export const TEMPLATE_COUNT = 552;

export type GrowthTemplate = { id: number; name: (typeof GROWTH_FAMILIES)[number]; organic: number; seed: number };

export function growthTemplate(id: number): GrowthTemplate {
  const n = ((Math.floor(id) - 1) % TEMPLATE_COUNT + TEMPLATE_COUNT) % TEMPLATE_COUNT;
  return {
    id: n + 1,
    name: GROWTH_FAMILIES[n % GROWTH_FAMILIES.length],
    organic: 96 + (n % 4),
    seed: 17 + n * 13,
  };
}

export function listGrowthCatalog() {
  return Array.from({ length: TEMPLATE_COUNT }, (_, index) => {
    const template = growthTemplate(index + 1);
    return { id: template.id, name: template.name, organic: template.organic };
  });
}

function shape(name: string, t: number) {
  if (name === "s-curve") return 1 / (1 + Math.exp(-12 * (t - 0.5)));
  if (name === "viral-spike") return t < 0.18 ? t * 0.2 : Math.min(1, 0.08 + Math.pow(t, 0.72));
  if (name === "steady-climb") return t;
  if (name === "double-peak") return t < 0.42 ? t * 1.05 : t < 0.58 ? 0.44 : Math.min(1, 0.44 + (t - 0.58) * 1.35);
  if (name === "burst-pause") return Math.min(1, Math.floor(t * 5) / 4.2 + (t % 0.2) * 0.15);
  if (name === "slow-burn") return Math.pow(t, 1.7);
  if (name === "late-surge") return Math.pow(t, 2.6);
  if (name === "staircase") return Math.min(1, Math.floor(t * 7) / 6);
  if (name === "front-load") return Math.pow(t, 0.42);
  if (name === "night-drip") return t < 0.62 ? t * 0.45 : Math.min(1, 0.28 + (t - 0.62) * 1.9);
  if (name === "morning-ramp") return t < 0.3 ? Math.min(1, t * 2.1) : Math.min(1, 0.63 + (t - 0.3) * 0.53);
  return t;
}

export function growthSeries(id: number, steps = 84) {
  const template = growthTemplate(id);
  const points: number[] = [];
  for (let index = 0; index < steps; index += 1) {
    const t = index / (steps - 1);
    if (template.name === "random-walk") {
      const prev = points[index - 1] ?? 0;
      const step = 0.004 + mix(template.seed + index * 1.3) * 0.022;
      points.push(index === steps - 1 ? 1 : Math.min(0.992, prev + step));
      continue;
    }
    const noise = (mix(template.seed + index * 1.7) - 0.5) * 0.028;
    const value = Math.max(0, Math.min(1, shape(template.name, t) + noise));
    points.push(index === 0 ? 0 : Math.max(points[index - 1] ?? 0, value));
  }
  points[0] = 0;
  points[points.length - 1] = 1;
  return { ...template, points };
}

export function bestOrganicMix(views: number, floors?: Record<string, number>) {
  return mixFromRatios(views, { likes: 3.1, shares: 1.3, saves: 1.1, reposts: 0.8 }, floors);
}

export const SETTINGS_RATIO_DEFAULTS: Record<string, number> = {
  views: 100,
  likes: 5,
  comments: 2,
  saves: 1,
  shares: 1,
  reposts: 0.5,
  followers: 2,
  subscribers: 3,
  watch_hours: 5,
  retweets: 4,
};

const FULL_ENGAGEMENT_TYPES = ["likes", "shares", "reposts", "saves"];

/** Percents are the Settings sliders: likes 5 means 5% of views. */
export function mixFromRatios(
  views: number,
  ratios: Record<string, number>,
  floors?: Record<string, number>,
  types: string[] = FULL_ENGAGEMENT_TYPES,
) {
  const base = Math.max(0, Math.floor(views));
  const out: Record<string, number> = {};
  for (const type of types) {
    const pct = Number(ratios[type]);
    if (!Number.isFinite(pct) || pct <= 0) continue;
    const min = Math.max(1, Math.floor(floors?.[type] ?? PROVIDER_MIN[type] ?? 1));
    const value = Math.round((base * pct) / 100);
    if (value <= 0) continue;
    out[type] = Math.max(min, value);
  }
  return out;
}

export function organicOpening(input: { linkReady: boolean; quantities: Record<string, number>; botting: number }) {
  const views = input.quantities.views ?? 0;
  const likes = input.quantities.likes ?? 0;
  const shares = input.quantities.shares ?? 0;
  const saves = input.quantities.saves ?? 0;
  const tone = input.botting <= 20 ? "looks quite natural" : input.botting <= 45 ? "is moderate — you can still place it" : "is high — spread the mix out";
  const lead = input.linkReady
    ? "Link is on the page. I am reading the mix you selected, not the live post."
    : "Please paste your post link first so I can analyze it.";
  return `${lead}
You've selected ${likes.toLocaleString("en-IN")} likes, ${shares.toLocaleString("en-IN")} shares, ${saves.toLocaleString("en-IN")} saves, ${views.toLocaleString("en-IN")} views.
Botting risk is ${input.botting}% — ${tone}. You can ask —
'How many likes should I add?', 'Is this safe?', 'How long will delivery take?'`;
}

export function answerOrganic(question: string, input: {
  quantities: Record<string, number>;
  health: number;
  botting: number;
  hours: number;
  runs: number;
  peak: boolean;
  finish: string;
  ratios?: Record<string, number>;
}) {
  const q = question.toLowerCase();
  const views = input.quantities.views ?? 0;
  const likes = input.quantities.likes ?? 0;
  const ratios = { ...SETTINGS_RATIO_DEFAULTS, ...(input.ratios ?? {}) };
  const mix = mixFromRatios(views, ratios);
  const likePct = views > 0 ? (likes / views) * 100 : 0;
  if (q.includes("safe") || q.includes("risk") || q.includes("bot")) {
    return `Health is ${input.health}/100 and botting risk is ${input.botting}%. ${input.botting <= 20 ? "This mix is in a natural band." : input.botting <= 45 ? "Moderate risk. Raise variance above 35% or move likes toward about 7% of views." : "High risk. Cut the extras or add more views before you place it."} No outside AI is connected — this is the local check.`;
  }
  if (q.includes("long") || q.includes("time") || q.includes("deliver")) {
    return `Views are set for ${input.runs} runs over about ${input.hours < 1 ? `${Math.round(input.hours * 60)} minutes` : `${input.hours.toFixed(1)} hours`}. Finish lands around ${input.finish}. Peak hours boost is ${input.peak ? "on, so most of the quantity is pulled into 6–11 PM IST." : "off. Turn it on if you want the bigger drops between 6 and 11 PM IST."}`;
  }
  if (q.includes("like")) {
    const aim = mix.likes ?? 0;
    const delta = aim - likes;
    return `You have ${likes.toLocaleString("en-IN")} likes on ${views.toLocaleString("en-IN")} views (${likePct.toFixed(2)}%). Settings is ${ratios.likes}% likes. Aim for about ${aim.toLocaleString("en-IN")} likes (${delta >= 0 ? `add ${delta.toLocaleString("en-IN")}` : `remove ${Math.abs(delta).toLocaleString("en-IN")}`}).`;
  }
  if (q.includes("ratio") || q.includes("suggest") || q.includes("best") || q.includes("mix")) {
    return `Settings mix for ${views.toLocaleString("en-IN")} views: ${(mix.likes ?? 0).toLocaleString("en-IN")} likes (${ratios.likes}%), ${(mix.shares ?? 0).toLocaleString("en-IN")} shares (${ratios.shares}%), ${(mix.saves ?? 0).toLocaleString("en-IN")} saves (${ratios.saves}%), ${(mix.reposts ?? 0).toLocaleString("en-IN")} reposts (${ratios.reposts}%).`;
  }
  return "I can only read this order. Ask: Is this safe? How long will delivery take? How many more likes should I add? Suggest the best ratio. An outside AI API is not connected yet.";
}

