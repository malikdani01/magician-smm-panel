import { useEffect, useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Authed } from "@/components/gate";
import { checkDropStatus, editScheduledDrop, getOrder, listOrderDrops, refillEngagement, setRunState, type OrderRow } from "@/lib/panel.functions";
import { inr } from "@/lib/money";

export const Route = createFileRoute("/orders/$id")({ component: DetailPage });

type Drop = { id: string; engagement_type: string; quantity: number; place_at: string; status: string; provider_order_id: string | null; service_label: string | null; error: string | null };

const TONE: Record<string, string> = {
  views: "text-sky-600 bg-sky-50",
  likes: "text-emerald-600 bg-emerald-50",
  saves: "text-amber-600 bg-amber-50",
  shares: "text-blue-600 bg-blue-50",
  reposts: "text-violet-600 bg-violet-50",
};

function DetailPage() {
  const { id } = Route.useParams();
  return <Authed><Detail id={id} /></Authed>;
}

function Detail({ id }: { id: string }) {
  const [order, setOrder] = useState<OrderRow | null | undefined>(undefined);
  const [drops, setDrops] = useState<Drop[]>([]);
  const [error, setError] = useState("");
  const [statusNote, setStatusNote] = useState("");
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const [edit, setEdit] = useState<Drop | null>(null);
  const [qty, setQty] = useState("");
  const [when, setWhen] = useState("");
  const [checked, setChecked] = useState("");

  function load() {
    getOrder({ data: id }).then(setOrder).catch((err: unknown) => setError(err instanceof Error ? err.message : "Missing order."));
    listOrderDrops({ data: id }).then(setDrops).catch((err: unknown) => {
      setDrops([]);
      setError(err instanceof Error ? err.message : "Could not load runs.");
    });
    setChecked(new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", second: "2-digit" }));
  }

  useEffect(() => {
    load();
    const timer = window.setInterval(load, 4000);
    return () => window.clearInterval(timer);
  }, [id]);

  const sorted = useMemo(() => [...drops].sort((a, b) => a.place_at.localeCompare(b.place_at)), [drops]);
  if (order === undefined) return <p className="text-[#64748b]">Loading order…</p>;
  if (!order) return <p className="text-rose-600">{error || "Order not found."}</p>;

  const delivered = drops.filter((drop) => drop.status === "placed").reduce((sum, drop) => sum + drop.quantity, 0);
  const total = order.items.reduce((sum, item) => sum + item.quantity, 0);
  const placed = drops.filter((drop) => drop.status === "placed").length;
  const pending = drops.filter((drop) => drop.status === "waiting" || drop.status === "paused").length;
  const active = drops.filter((drop) => drop.status === "placing").length;
  const next = sorted.find((drop) => drop.status === "waiting" || drop.status === "placing");
  const pct = total ? Math.round((delivered / total) * 100) : 0;
  const running = new Map<string, number>();
  const editIndex = edit ? sorted.findIndex((drop) => drop.id === edit.id) + 1 : 0;

  function openEdit(drop: Drop) {
    setEdit(drop);
    setQty(String(drop.quantity));
    setWhen(toLocal(drop.place_at));
    setError("");
  }

  return (
    <div className="mx-auto max-w-3xl space-y-4 pb-16">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <Link to="/engagement-orders" className="text-[18px] text-[#64748b]">←</Link>
            <h1 className="text-[22px] font-bold">Order #{order.order_number.replace("MAG-", "")}</h1>
            <span className="rounded-full bg-[#111827] px-2 py-0.5 text-[10px] font-bold text-white">{order.status}</span>
            {order.organic && <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-700">Organic</span>}
            <span className="rounded-full bg-[#eef4ff] px-2 py-0.5 text-[10px] font-bold text-[#2563eb]">LIVE TRACKING</span>
          </div>
          <a href={order.link} target="_blank" rel="noreferrer" className="mt-1 block max-w-lg truncate text-[12px] text-[#64748b]">{order.link}</a>
        </div>
        <div className="text-right">
          <p className="text-[11px] text-[#94a3b8]">Auto-updating</p>
          <p className="text-[11px] text-[#94a3b8]">Last: {checked}</p>
          <button type="button" onClick={load} className="mt-1 rounded-full border bg-white px-3 py-1.5 text-[12px] font-semibold">Refresh</button>
        </div>
      </div>

      <section className="rounded-[24px] border border-[#e7eef6] bg-white p-4 shadow-sm">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-semibold">Live order menu</h2>
          <span className="rounded-full bg-emerald-50 px-2 py-1 text-[11px] font-semibold text-emerald-700">Auto-updating</span>
        </div>
        <div className="space-y-3">
          {order.items.map((item) => {
            const mine = drops.filter((drop) => drop.engagement_type === item.engagement_type).sort((a, b) => a.place_at.localeCompare(b.place_at));
            const sent = mine.filter((drop) => drop.status === "placed").reduce((sum, drop) => sum + drop.quantity, 0);
            const doneRuns = mine.filter((drop) => drop.status === "placed").length;
            const leftRuns = mine.filter((drop) => drop.status === "waiting" || drop.status === "paused" || drop.status === "placing").length;
            const nextRun = mine.find((drop) => drop.status === "waiting" || drop.status === "placing");
            const last = mine[mine.length - 1];
            return (
              <article key={item.id} className={`rounded-2xl p-3 ${TONE[item.engagement_type] || "bg-[#f8fafc]"}`}>
                <div className="flex items-center justify-between">
                  <b className="capitalize">{item.engagement_type}</b>
                  <span className="text-[12px] font-semibold">{sent.toLocaleString("en-IN")} / {item.quantity.toLocaleString("en-IN")} gaye</span>
                </div>
                <p className="mt-1 text-[12px] text-[#334155]">
                  {doneRuns} run lag chuke · {leftRuns} run bache · {Math.max(0, item.quantity - sent).toLocaleString("en-IN")} quantity bachi
                </p>
                <p className="text-[12px] text-[#334155]">
                  {nextRun ? `Next ${clock(nextRun.place_at)} (${fromNow(nextRun.place_at)})` : "Koi pending run nahi"}
                  {last ? ` · last ${clock(last.place_at)}` : ""}
                </p>
              </article>
            );
          })}
        </div>
      </section>

      <section className="rounded-[24px] border border-[#e7eef6] bg-white p-4 shadow-sm">
        <div className="mb-3 flex items-center justify-between">
          <p className="text-[12px] font-bold tracking-widest text-[#334155]">LIVE TRACKING</p>
          <p className="rounded-full bg-emerald-50 px-3 py-1 text-[12px] font-semibold text-emerald-700">{next ? `Next: ${fromNow(next.place_at)}` : "No pending run"}</p>
        </div>
        <div className="grid grid-cols-5 text-center">
          <Count n={drops.length} label="Total runs" />
          <Count n={placed} label="Completed" />
          <Count n={active} label="In progress" />
          <Count n={pending} label="Pending" />
          <Count n={delivered} label="Delivered" />
        </div>
        <div className="mt-4 flex justify-between text-[13px]"><span>Overall progress</span><b>{delivered.toLocaleString("en-IN")} / {total.toLocaleString("en-IN")}</b></div>
        <div className="mt-1 h-2 overflow-hidden rounded-full bg-[#eef3f8]"><div className="h-full bg-[#93c5fd]" style={{ width: `${pct}%` }} /></div>
        <div className="mt-1 flex justify-between text-[12px] text-[#94a3b8]"><span>{placed} of {drops.length} runs sent</span><span>{pct}% done</span></div>
      </section>

      <section className="rounded-[24px] border border-[#e7eef6] bg-white p-4">
        <h2 className="mb-3 text-[15px] font-semibold">Delivery counters</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          {order.items.map((item) => {
            const done = drops.filter((drop) => drop.engagement_type === item.engagement_type && drop.status === "placed").reduce((sum, drop) => sum + drop.quantity, 0);
            return (
              <div key={item.id} className="rounded-2xl border border-[#eef2f6] p-3">
                <div className="flex justify-between"><b className="capitalize">{item.engagement_type}</b><span className="text-[12px] text-[#64748b]">{item.quantity ? Math.round((done / item.quantity) * 100) : 0}%</span></div>
                <Line k="Target" v={item.quantity} />
                <Line k="Delivered" v={done} />
                <Line k="Remaining" v={Math.max(0, item.quantity - done)} />
              </div>
            );
          })}
        </div>
      </section>

      <section className="rounded-[24px] border border-[#e7eef6] bg-white p-4">
        <h2 className="mb-3 font-semibold">Live engagement stats</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          {order.items.map((item) => {
            const mine = drops.filter((drop) => drop.engagement_type === item.engagement_type);
            const done = mine.filter((drop) => drop.status === "placed").reduce((sum, drop) => sum + drop.quantity, 0);
            const paused = mine.some((drop) => drop.status === "paused");
            return (
              <article key={item.id} className={`rounded-2xl p-3 ${TONE[item.engagement_type] || "bg-[#f8fafc]"}`}>
                <p className="text-[11px] font-bold uppercase">{item.engagement_type}</p>
                <p className="text-[22px] font-bold text-[#0f172a]">{done.toLocaleString("en-IN")} <span className="text-[13px] font-medium text-[#64748b]">/ {item.quantity.toLocaleString("en-IN")}</span></p>
                <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/80"><div className="h-full bg-[#60a5fa]" style={{ width: `${item.quantity ? Math.min(100, (done / item.quantity) * 100) : 0}%` }} /></div>
                <div className="mt-3 flex gap-2">
                  <button type="button" onClick={() => setRunState({ data: { orderId: order.id, type: item.engagement_type, status: paused ? "waiting" : "paused" } }).then(load)} className="h-8 flex-1 rounded-lg bg-white text-[12px] font-semibold">{paused ? "Resume" : "Pause"}</button>
                  <button type="button" onClick={() => refillEngagement({ data: { orderId: order.id, type: item.engagement_type } }).then(load).catch((err: unknown) => setError(err instanceof Error ? err.message : "Refill failed."))} className="h-8 flex-1 rounded-lg bg-[#2563eb] text-[12px] font-semibold text-white">Refill</button>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      <section className="rounded-[24px] border border-[#e7eef6] bg-white p-4">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <h2 className="font-semibold">Run schedule <span className="rounded-full bg-[#f1f5f9] px-2 py-0.5 text-[11px] font-medium text-[#64748b]">{drops.length} total runs</span></h2>
          <span className="rounded-full bg-emerald-50 px-2 py-1 text-[12px] text-emerald-700">{placed} sent</span>
        </div>
        <p className="mb-3 text-[13px] font-semibold">Organic delivery timeline</p>
        <div className="mb-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
          {order.items.map((item) => {
            const done = drops.filter((drop) => drop.engagement_type === item.engagement_type && drop.status === "placed").reduce((sum, drop) => sum + drop.quantity, 0);
            return <div key={item.id} className="rounded-2xl bg-[#fff8eb] px-2 py-3 text-center text-[12px]"><b>{done.toLocaleString("en-IN")}/{item.quantity.toLocaleString("en-IN")}</b><p className="uppercase text-[#94a3b8]">{item.engagement_type}</p></div>;
          })}
        </div>
        <div className="space-y-3">
          {sorted.map((drop, index) => {
            running.set(drop.engagement_type, (running.get(drop.engagement_type) ?? 0) + (drop.status === "cancelled" ? 0 : drop.quantity));
            const hot = drop.status === "placing" || drop.status === "placed";
            return (
              <article key={drop.id} className={`rounded-2xl border p-3 ${hot ? "border-amber-200 bg-amber-50/50" : "border-[#eef2f6] bg-[#f8fbff]"}`}>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className={`grid size-8 place-items-center rounded-full text-[12px] font-bold text-white ${hot ? "bg-amber-500" : "bg-[#1d4ed8]"}`}>#{index + 1}</span>
                      <span className="rounded-full bg-white px-2 py-0.5 text-[11px] font-semibold">{label(drop.status)}</span>
                      <span className="text-[13px] font-bold text-amber-600">+{drop.quantity.toLocaleString("en-IN")} {drop.engagement_type}</span>
                    </div>
                    <p className="mt-1 truncate text-[12px] text-[#2563eb]">via {drop.service_label || "provider service"}</p>
                    <p className="text-[12px] text-[#64748b]">{clock(drop.place_at)} {drop.status === "waiting" ? `· Next in ${fromNow(drop.place_at)}` : ""}</p>
                    {drop.provider_order_id && <p className="text-[12px]">Order #{drop.provider_order_id}</p>}
                    {drop.error && <p className="text-[12px] text-rose-600">{drop.error}</p>}
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-semibold tracking-wide text-[#94a3b8]">PROVIDER</p>
                    <p className="max-w-40 truncate text-[12px] font-semibold text-[#2563eb]">{drop.service_label || "Pending"}</p>
                    {(drop.status === "waiting" || drop.status === "paused") && <button type="button" onClick={() => openEdit(drop)} className="mt-2 text-[12px] font-semibold text-[#2563eb]">Edit</button>}
                    {drop.provider_order_id && <button type="button" onClick={() => checkDropStatus({ data: drop.id }).then((row) => setStatusNote(`#${drop.provider_order_id}: ${row.status}${row.remains ? `, remains ${row.remains}` : ""}`)).catch((err: unknown) => setError(err instanceof Error ? err.message : "Status failed."))} className="mt-1 block text-[12px] font-semibold text-[#0f766e]">Check now</button>}
                  </div>
                </div>
                <p className="mt-3 text-[11px] font-semibold text-[#64748b]">TOTAL AT {clock(drop.place_at).toUpperCase()}</p>
                <div className="mt-1 grid grid-cols-2 gap-2 sm:grid-cols-4">
                  {order.items.map((item) => (
                    <div key={item.id} className="rounded-xl bg-[#fff8eb] px-2 py-2 text-center text-[11px]">
                      <b>{Math.min(item.quantity, running.get(item.engagement_type) ?? 0).toLocaleString("en-IN")}/{item.quantity.toLocaleString("en-IN")}</b>
                      <p className="uppercase text-[#94a3b8]">{item.engagement_type}</p>
                    </div>
                  ))}
                </div>
              </article>
            );
          })}
        </div>
      </section>

      <h2 className="text-[16px] font-semibold">Per-service history</h2>
      {order.items.map((item) => {
        const mine = drops.filter((drop) => drop.engagement_type === item.engagement_type).sort((a, b) => a.place_at.localeCompare(b.place_at));
        const done = mine.filter((drop) => drop.status === "placed").reduce((sum, drop) => sum + drop.quantity, 0);
        const waiting = mine.filter((drop) => drop.status === "waiting" || drop.status === "paused");
        const shown = open[item.engagement_type] !== false;
        const nextRun = waiting[0];
        return (
          <section key={item.id} className="rounded-[24px] border border-[#e7eef6] bg-white p-4 shadow-sm">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="truncate font-semibold capitalize">{item.service_name || item.engagement_type}</p>
                <p className="truncate text-[12px] text-[#64748b]">{order.link}</p>
              </div>
              <div className="flex items-center gap-2">
                <b>{item.quantity.toLocaleString("en-IN")}</b>
                <button type="button" onClick={() => setRunState({ data: { orderId: order.id, type: item.engagement_type, status: waiting.some((drop) => drop.status === "paused") ? "waiting" : "paused" } }).then(load)} className="rounded-full border px-3 py-1 text-[12px] font-semibold">Pause</button>
                <button type="button" onClick={() => setRunState({ data: { orderId: order.id, type: item.engagement_type, status: "cancelled" } }).then(load)} className="grid size-8 place-items-center rounded-full border text-rose-500">×</button>
                <span className="rounded-full bg-[#eef4ff] px-2 py-1 text-[10px] font-bold text-[#2563eb]">{mine.length === 0 ? "NO RUNS" : waiting.length ? "PENDING" : "DONE"}</span>
              </div>
            </div>
            <div className="mt-4 flex items-center justify-between">
              <p className="text-[12px] font-bold tracking-wide text-emerald-600">LIVE DELIVERY TRACKING</p>
              <p className="text-[12px] text-emerald-700">{nextRun ? `Next: ${fromNow(nextRun.place_at)}` : "No pending run"}</p>
            </div>
            <div className="mt-2 grid grid-cols-5 border-y border-[#eef2f6] py-3 text-center">
              <Count n={mine.length} label="Total runs" />
              <Count n={mine.filter((drop) => drop.status === "placed").length} label="Completed" />
              <Count n={mine.filter((drop) => drop.status === "placing").length} label="Processing" />
              <Count n={waiting.length} label="Pending" />
              <Count n={done} label="Delivered" />
            </div>
            {shown && (
              <ul className="divide-y divide-[#eef2f6]">
                {mine.map((drop, index) => {
                  const sum = mine.slice(0, index + 1).filter((row) => row.status !== "cancelled").reduce((totalQty, row) => totalQty + row.quantity, 0);
                  return (
                    <li key={drop.id} className="flex items-center justify-between gap-3 py-3">
                      <div className="flex items-start gap-3">
                        <span className="grid size-8 place-items-center rounded-full bg-[#1d4ed8] text-[12px] font-bold text-white">#{index + 1}</span>
                        <div>
                          <p className="text-[13px]"><span className="rounded-full bg-[#eef4ff] px-2 py-0.5 text-[11px] font-semibold text-[#2563eb]">{label(drop.status)}</span> <b className="text-emerald-600">+{drop.quantity} {item.engagement_type}</b> <span className="text-[#64748b]">Scheduled: {Math.min(item.quantity, sum)} / {item.quantity}</span></p>
                          <p className="text-[12px] text-[#64748b]">{clock(drop.place_at)} {drop.status === "waiting" ? `(in ${fromNow(drop.place_at)})` : ""}</p>
                        </div>
                      </div>
                      {(drop.status === "waiting" || drop.status === "paused") && <button type="button" onClick={() => openEdit(drop)} className="rounded-full border px-3 py-1 text-[12px] font-semibold">Edit</button>}
                    </li>
                  );
                })}
              </ul>
            )}
            <button type="button" onClick={() => setOpen((current) => ({ ...current, [item.engagement_type]: !shown }))} className="mt-2 w-full text-center text-[12px] font-semibold text-[#64748b]">{shown ? "Hide schedule" : "Show schedule"}</button>
          </section>
        );
      })}

      <section className="rounded-[24px] border border-[#e7eef6] bg-white p-4">
        <h2 className="mb-3 font-semibold">Order details</h2>
        <div className="grid grid-cols-2 gap-3 text-[13px] sm:grid-cols-4">
          <div><p className="text-[#94a3b8]">Created</p><b>{new Date(order.created_at).toLocaleString("en-IN", { month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit" })}</b></div>
          <div><p className="text-[#94a3b8]">Total price</p><b>{inr(order.total_paise)}</b></div>
          <div><p className="text-[#94a3b8]">Variance</p><b>±{order.variance_percent}%</b></div>
          <div><p className="text-[#94a3b8]">Peak hours</p><b>{order.organic ? "Enabled" : "Off"}</b></div>
        </div>
      </section>
      {statusNote && <p className="rounded-xl bg-[#ecfeff] px-3 py-2 text-[13px]">{statusNote}</p>}
      {error && <p className="text-[13px] text-rose-600">{error}</p>}

      {edit && (
        <div className="fixed inset-0 z-40 grid place-items-center bg-black/30 p-4">
          <form
            className="w-full max-w-md rounded-3xl bg-white p-5 shadow-2xl"
            onSubmit={async (event) => {
              event.preventDefault();
              try {
                await editScheduledDrop({ data: { id: edit.id, quantity: Number(qty), placeAt: new Date(when).toISOString() } });
                setEdit(null);
                load();
              } catch (err: unknown) {
                setError(err instanceof Error ? err.message : "Could not save this run.");
              }
            }}
          >
            <div className="flex items-start justify-between">
              <div>
                <h2 className="text-[18px] font-bold">Edit scheduled run</h2>
                <p className="text-[12px] text-[#64748b]">Modify the quantity or scheduled time for this pending run</p>
              </div>
              <button type="button" onClick={() => setEdit(null)} className="text-[#94a3b8]">×</button>
            </div>
            <p className="mt-3 inline-flex gap-2 rounded-full bg-[#f8fafc] px-3 py-1 text-[12px] capitalize"><span>{edit.engagement_type}</span><span>Run #{editIndex}</span></p>
            <label className="mt-3 block text-[13px] font-semibold">Quantity to deliver
              <input value={qty} onChange={(event) => setQty(event.target.value.replace(/[^\d]/g, ""))} className="mt-1 h-11 w-full rounded-xl border border-[#bfdbfe] bg-[#f8fbff] px-3" />
            </label>
            <p className="mt-1 text-[12px] text-[#94a3b8]">Original: {edit.quantity}</p>
            <p className="mt-3 text-[13px] font-semibold">Scheduled time</p>
            <div className="mt-2 flex flex-wrap gap-2">
              {[1, 3, 6, 12, 24].map((hours) => (
                <button key={hours} type="button" onClick={() => setWhen(toLocal(new Date(Date.now() + hours * 3600_000).toISOString()))} className="rounded-full border px-3 py-1 text-[12px] font-semibold">+{hours}h</button>
              ))}
            </div>
            <input type="datetime-local" value={when} onChange={(event) => setWhen(event.target.value)} className="mt-3 h-11 w-full rounded-xl border px-3" />
            <p className="mt-1 text-[12px] text-[#94a3b8]">Original: {clock(edit.place_at)}</p>
            <div className="mt-4 flex justify-end gap-2">
              <button type="button" onClick={() => setEdit(null)} className="h-10 rounded-xl border px-4 text-[13px]">Cancel</button>
              <button className="h-10 rounded-xl bg-[#2563eb] px-4 text-[13px] font-bold text-white">Save changes</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

function Count({ n, label }: { n: number; label: string }) {
  return <div><p className="text-[20px] font-bold">{n.toLocaleString("en-IN")}</p><p className="text-[10px] uppercase tracking-wide text-[#94a3b8]">{label}</p></div>;
}

function Line({ k, v }: { k: string; v: number }) {
  return <p className="mt-1 flex justify-between text-[13px]"><span className="text-[#64748b]">{k}</span><b>{v.toLocaleString("en-IN")}</b></p>;
}

function label(status: string) {
  if (status === "placed" || status === "placing") return "in progress";
  if (status === "paused") return "Paused";
  if (status === "cancelled") return "Cancelled";
  if (status === "failed") return "Failed";
  return "Scheduled";
}

function fromNow(iso: string) {
  const min = Math.round((new Date(iso).getTime() - Date.now()) / 60000);
  if (min <= 1) return "less than a minute";
  if (min < 60) return `${min} minutes`;
  const hours = Math.round(min / 60);
  return hours === 1 ? "about 1 hour" : `about ${hours} hours`;
}

function clock(iso: string) {
  return new Date(iso).toLocaleString("en-IN", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
}

function toLocal(iso: string) {
  const date = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}
