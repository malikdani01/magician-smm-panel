// New-host template only; exactly one process may own this PGlite directory.
const path = require('node:path');
module.exports = { apps: [{name: 'magiciansmm', cwd: __dirname,
 script: '.output/server/index.mjs', interpreter: 'node',
 node_args: '--env-file=.env.production', instances: 1, exec_mode: 'fork',
 autorestart: true, env: {NODE_ENV:'production', HOST:'127.0.0.1', PORT:'8080',
 PGLITE_DATA_DIR: path.join(__dirname, 'data')}}] };
