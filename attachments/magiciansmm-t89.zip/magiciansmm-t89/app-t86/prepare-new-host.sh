#!/usr/bin/env bash
# NEW HOST ONLY. Builds code; does not restore data or start background jobs.
set -euo pipefail
cd "$(dirname "$0")"
[[ "$(node -p 'process.versions.node.split(`.`)[0]')" == 22 ]] || { echo 'Install Node 22 first'; exit 1; }
npm ci
NITRO_PRESET=node-server VITE_AUTH_ENABLED=true npm run build
mkdir -p .output/server/_libs
cp node_modules/@electric-sql/pglite/dist/{pglite.wasm,pglite.data,initdb.wasm} .output/server/_libs/
echo 'Build prepared. Read RESTORE-HINGLISH.md; restore DB/config BEFORE starting PM2.'
