import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Library, RefreshCw, Wallet, Wand2, ShoppingBag, Activity, Receipt, Code2, Server, Database, Globe, Cable, Clock } from "lucide-react";
import { Authed } from "@/components/gate";
import { getDeskRole } from "@/lib/admin.functions";
import { apiBalances, getDashboard, getPrefs, type DashboardData } from "@/lib/panel.functions";
import { inr } from "@/lib/money";
import banner from "@/assets/welcome-banner.jpg";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/dashboard")({
  component: () => (
    <Authed>
      <Dashboard />
    </Authed>
  ),
});

function greeting() {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning,";
  if (hour < 18) return "Good afternoon,";
  return "Good evening,";
}

const API_ICONS = [Code2, Server, Database, Globe, Cable];
const TONES = [
  { wash: "from-violet-600 to-fuchsia-500", Icon: Wallet },
  { wash: "from-sky-500 to-indigo-500", Icon: ShoppingBag },
  { wash: "from-emerald-500 to-teal-400", Icon: Activity },
  { wash: "from-amber-500 to-orange-400", Icon: Receipt },
];

function Dashboard() {
  const { user } = useCurrentUserState();
  const [data, setData] = useState<DashboardData | null>(null);
  const [name, setName] = useState("");
  const [admin, setAdmin] = useState(false);
  const [balances, setBalances] = useState<Awaited<ReturnType<typeof apiBalances>>>([]);
  const [checking, setChecking] = useState(false);
  const [checkedAt, setCheckedAt] = useState("");

  function loadBalances() {
    setChecking(true);
    apiBalances()
      .then((rows) => {
        setBalances(rows);
        setCheckedAt(new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }));
      })
      .catch(() => setBalances([]))
      .finally(() => setChecking(false));
  }

  useEffect(() => {
    getDashboard().then(setData).catch(() => setData(null));
    getPrefs().then((prefs) => setName(prefs.full_name || "")).catch(() => setName(""));
    getDeskRole()
      .then((role) => {
        if (role !== "admin") return;
        setAdmin(true);
        loadBalances();
      })
      .catch(() => setAdmin(false));
  }, []);

  const display = name || user?.displayName || "Member";
  const cards = [
    ["BALANCE", data ? inr(data.balance_paise) : "—", "Available funds"],
    ["TOTAL ORDERS", String(data?.order_count ?? 0), `${data?.order_count ?? 0} completed`],
    ["ACTIVE", String(data?.queued_count ?? 0), "In progress"],
    ["TOTAL SPENT", data ? inr(data.spend_paise) : "—", "All time"],
  ];

  return (
    <div className="mx-auto max-w-6xl space-y-4">
      <section className="welcome-banner relative aspect-[1874/839] overflow-hidden rounded-[28px]">
        <img src={banner} alt="" className="absolute inset-0 h-full w-full object-cover object-center" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/25 to-transparent" />
        <div className="welcome-shine" />
        <div className="relative z-10 max-w-lg p-6 md:p-8">
          <p className="rise-in text-[13px] text-white/85">{greeting()}</p>
          <h1 className="rise-in rise-d1 text-[34px] font-extrabold leading-none text-white md:text-[42px]">Welcome back, <span className="name-glow text-amber-300">{display}</span></h1>
          <p className="rise-in rise-d2 mt-2 max-w-sm text-[13px] text-white/85">Your SMM panel is ready. Place a drip, check APIs, add credit.</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Link to="/engagement-order" className="btn-live inline-flex h-11 items-center rounded-full bg-amber-300 px-5 text-[13px] font-semibold text-slate-950">Create New Order</Link>
            <Link to="/mass" className="btn-pop rise-d4 inline-flex h-11 items-center rounded-full border border-white/50 bg-black/30 px-5 text-[13px] font-semibold text-white backdrop-blur">Mass Order</Link>
          </div>
        </div>
      </section>

      {admin && (
        <section className="api-balance">
          <div className="api-balance-head">
            <span className="api-balance-mark"><Code2 className="size-4" /></span>
            <div className="min-w-0">
              <h2>API balance</h2>
              <p><Clock className="size-3.5" /> {checkedAt ? `Checked ${checkedAt}` : "Not checked yet"} · Full engagement APIs only</p>
            </div>
            <button type="button" onClick={loadBalances} disabled={checking}>
              <RefreshCw className={`size-3.5 ${checking ? "animate-spin" : ""}`} /> {checking ? "Checking" : "Refresh"}
            </button>
          </div>
          {balances.length === 0 ? (
            <p className="api-balance-empty">{checking ? "Balances la rahe hain…" : "Koi API save nahi. Full engagement APIs mein URL + key daalo."}</p>
          ) : (
            <ul>
              {balances.map((row, index) => {
                const Icon = API_ICONS[index % API_ICONS.length];
                const code = row.currency.toUpperCase();
                const tone = code === "INR" ? "cyan" : code === "USD" || row.low ? "pink" : "";
                return (
                  <li key={`${row.host}-${row.keyTail}-${row.label}`} style={{ animationDelay: `${index * 50}ms` }}>
                    <span className="api-balance-icon"><Icon className="size-4" /></span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate capitalize">{row.label.replaceAll(":", " · ")}</p>
                      <small className="block truncate">{row.host} · key ***{row.keyTail}</small>
                      {row.error && <small className="api-balance-error">{row.error}</small>}
                    </div>
                    <div className="api-balance-amt">
                      <b className={tone}>{row.error ? "—" : <>{row.balance.toLocaleString("en-IN")} <span>{row.currency}</span></>}</b>
                      {row.low && !row.error && <em>Low · refill</em>}
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </section>
      )}

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {cards.map(([label, value, hint], index) => {
          const tone = TONES[index % TONES.length];
          const Icon = tone.Icon;
          return (
            <article key={label} className={`stat-pop relative overflow-hidden rounded-2xl bg-gradient-to-br p-4 text-white ${tone.wash}`} style={{ animationDelay: `${index * 60}ms` }}>
              <span className="mb-2 grid size-8 place-items-center rounded-xl bg-white/20"><Icon className="size-4" /></span>
              <p className="text-[10px] font-semibold tracking-wide text-white/80">{label}</p>
              <p className="text-[22px] font-extrabold">{value}</p>
              <p className="text-[12px] text-white/75">{hint}</p>
              <svg viewBox="0 0 120 36" className="mt-2 h-8 w-full opacity-80" aria-hidden>
                <path d="M0 28 C 18 26, 24 18, 40 20 S 62 8, 78 14 100 6 120 10" fill="none" stroke="white" strokeWidth="2" />
              </svg>
            </article>
          );
        })}
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        <section className="rounded-2xl border p-5">
          <p className="font-semibold">All Orders</p>
          <p className="mt-2 text-[13px] text-[#94a3b8]">{data?.recent.length ? `${data.recent.length} recent` : "No engagement orders yet"}</p>
          <Link to="/engagement-order" className="mt-4 inline-flex h-10 items-center rounded-full bg-[#3b82f6] px-4 text-[13px] font-semibold text-white">Create First Order</Link>
        </section>
        <section className="rounded-2xl border p-5">
          <p className="font-semibold">Single Orders</p>
          <p className="mt-2 text-[13px] text-[#94a3b8]">Browse a service and place one order</p>
          <Link to="/catalog" className="mt-4 inline-flex h-10 items-center rounded-full bg-[#3b82f6] px-4 text-[13px] font-semibold text-white">Place Order</Link>
        </section>
      </div>

      <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
        <Link to="/engagement-order" className="flex items-center justify-between rounded-2xl border p-3 text-[12px]"><span><Wand2 className="mb-1 size-4 text-violet-300" /><b className="block">Full Engagement</b><span className="text-[#94a3b8]">Views + Likes + Saves</span></span><span>→</span></Link>
        <Link to="/wallet" className="flex items-center justify-between rounded-2xl border p-3 text-[12px]"><span><Wallet className="mb-1 size-4 text-emerald-300" /><b className="block">Add Funds</b><span className="text-[#94a3b8]">{data ? inr(data.balance_paise) : "Deposit to wallet"}</span></span><span>→</span></Link>
        <Link to="/catalog" className="flex items-center justify-between rounded-2xl border p-3 text-[12px]"><span><Library className="mb-1 size-4 text-cyan-300" /><b className="block">All Services</b><span className="text-[#94a3b8]">Browse catalog</span></span><span>→</span></Link>
      </div>
    </div>
  );
}
