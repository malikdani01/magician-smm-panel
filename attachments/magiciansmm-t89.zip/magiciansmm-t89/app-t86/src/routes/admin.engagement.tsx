import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Authed } from "@/components/gate";
import { adminBindings, adminSaveBindings, adminSaveServiceLimit, adminServiceLimit } from "@/lib/admin.functions";

export const Route = createFileRoute("/admin/engagement")({
  component: () => (
    <Authed>
      <EngagementApis />
    </Authed>
  ),
});

const TYPES = ["views", "likes", "saves", "shares", "reposts", "comments"] as const;

type ProviderKey = { api_url: string; api_key: string };
type Row = {
  slot: string;
  api_url: string;
  api_key: string;
  service_id: string;
  pick_mode: string;
  min_quantity: number;
  price_per_1k_paise: number;
  section_enabled: boolean;
  providers: ProviderKey[];
};

function EngagementApis() {
  const [rows, setRows] = useState<Row[]>([]);
  const [platform, setPlatform] = useState<"instagram" | "tiktok">("instagram");
  const [note, setNote] = useState("");
  const [rateText, setRateText] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [activeLimit, setActiveLimit] = useState("1");

  useEffect(() => {
    adminBindings()
      .then((list) => setRows(list.filter((row) => row.slot !== "single") as Row[]))
      .catch((err: unknown) => setNote(err instanceof Error ? err.message : "Could not load."));
    adminServiceLimit().then((row) => setActiveLimit(String(row.limit))).catch(() => setActiveLimit("1"));
  }, []);

  function patch(slot: string, next: Partial<Row>) {
    setRows((current) => current.map((row) => (row.slot === slot ? { ...row, ...next } : row)));
  }

  function setProvider(slot: string, index: number, next: Partial<ProviderKey>) {
    setRows((current) => current.map((row) => {
      if (row.slot !== slot) return row;
      const providers = row.providers.length ? [...row.providers] : [{ api_url: "", api_key: "" }];
      providers[index] = { ...providers[index], ...next };
      const first = providers.find((item) => item.api_key.trim()) || providers[0];
      return { ...row, providers, api_url: first?.api_url || "", api_key: first?.api_key || "" };
    }));
  }

  return (
    <div className="mx-auto max-w-xl space-y-4">
      <header>
        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#2563eb]">Admin</p>
        <h1 className="text-[28px] font-bold">Full engagement APIs</h1>
        <p className="text-[13px] text-[#64748b]">Har type ka provider yahan. Panel ka rate bhi yahin set karo — per 1,000. Service provider se aayegi, price tumhari.</p>
      </header>
      <div className="grid grid-cols-2 gap-2">
        {(["instagram", "tiktok"] as const).map((item) => (
          <button key={item} type="button" onClick={() => setPlatform(item)} className={`h-11 rounded-xl text-[13px] font-bold uppercase ${platform === item ? "bg-[#2563eb] text-white" : "bg-white text-[#334155]"}`}>
            {item}
          </button>
        ))}
      </div>
      {TYPES.map((type) => {
        const slot = `${platform}:${type}`;
        const row = rows.find((item) => item.slot === slot);
        if (!row) return null;
        const providers = row.providers.length ? row.providers : [{ api_url: row.api_url || "", api_key: row.api_key || "" }];
        return (
          <section key={slot} className="rounded-[24px] border border-[#e7eef6] bg-white p-4 shadow-sm">
            <div className="flex items-center justify-between gap-3">
              <h2 className="font-semibold capitalize">{type}</h2>
              <button type="button" role="switch" aria-checked={row.section_enabled !== false} onClick={() => patch(slot, { section_enabled: row.section_enabled === false })} className={`relative h-7 w-12 rounded-full ${row.section_enabled === false ? "bg-[#3a335f]" : "bg-violet-500"}`}>
                <span className={`absolute top-0.5 size-6 rounded-full bg-white shadow ${row.section_enabled === false ? "left-0.5" : "left-5"}`} />
              </button>
            </div>
            <p className={`mt-1 text-[11px] font-bold uppercase ${row.section_enabled === false ? "text-rose-400" : "text-emerald-400"}`}>{row.section_enabled === false ? "Hidden on Full Engagement" : "Showing on Full Engagement"}</p>
            <div className="mt-3 grid gap-3">
              {providers.map((provider, index) => (
                <div key={`${slot}-${index}`} className="grid gap-2 rounded-2xl bg-[#f8fafc] p-3">
                  <div className="flex items-center justify-between">
                    <p className="text-[12px] font-semibold text-[#334155]">API provider {index + 1}</p>
                    {providers.length > 1 && (
                      <button
                        type="button"
                        onClick={() => patch(slot, { providers: providers.filter((_, item) => item !== index) })}
                        className="text-[12px] font-semibold text-[#b91c1c]"
                      >
                        Remove
                      </button>
                    )}
                  </div>
                  <input value={provider.api_url} onChange={(event) => setProvider(slot, index, { api_url: event.target.value })} placeholder="Provider API URL" className="h-11 rounded-xl border border-[#e7eef6] bg-white px-3 text-[13px] outline-none" />
                  <input value={provider.api_key} onChange={(event) => setProvider(slot, index, { api_key: event.target.value })} placeholder="API key" className="h-11 rounded-xl border border-[#e7eef6] bg-white px-3 text-[13px] outline-none" />
                </div>
              ))}
              <button
                type="button"
                onClick={() => patch(slot, { providers: [...providers, { api_url: "", api_key: "" }] })}
                className="h-10 rounded-xl bg-[#f3f6fa] text-[12px] font-bold text-[#1d4ed8]"
              >
                Add another API
              </button>
              <label className="block text-[12px] font-semibold text-[#334155]">
                Panel rate per 1,000 (₹)
                <input
                  inputMode="decimal"
                  value={rateText[slot] ?? (row.price_per_1k_paise ? String(row.price_per_1k_paise / 100) : "")}
                  onChange={(event) => {
                    const raw = event.target.value.replace(/[^\d.]/g, "").replace(/(\..*)\./g, "$1");
                    setRateText((current) => ({ ...current, [slot]: raw }));
                    const rupees = Number(raw);
                    patch(slot, { price_per_1k_paise: raw === "" || !Number.isFinite(rupees) ? 0 : Math.round(rupees * 100) });
                  }}
                  placeholder="e.g. 5"
                  className="mt-1 h-11 w-full rounded-xl border border-[#e7eef6] px-3 text-[13px] outline-none"
                />
              </label>
              <p className="text-[11px] text-[#64748b]">1000 {type} ka panel charge. Jo yahan save karoge wahi price chalegi. Khali chhodo to purana bundle rate chalega.</p>
              <label className="block text-[12px] font-semibold text-[#334155]">
                Minimum quantity
                <input
                  inputMode="numeric"
                  value={row.min_quantity ? String(row.min_quantity) : ""}
                  onChange={(event) => {
                    const raw = event.target.value.replace(/[^\d]/g, "");
                    patch(slot, { min_quantity: raw === "" ? 0 : Number(raw) });
                  }}
                  className="mt-1 h-11 w-full rounded-xl border border-[#e7eef6] px-3 text-[13px] outline-none"
                />
              </label>
              <p className="text-[11px] text-[#94a3b8]">Har run ek hi provider pe. Views, likes, shares, saves, reposts alag-alag rotate hote hain. Pehle Non Drop / No Drop / Stable / Guaranteed / Refill. Drop 15% se zyada, Unknown, ya no-refill reject. Sab busy hon to sabse kam remains wale pe, aur uski doosri no-drop service ID pe.</p>
              <p className="text-[11px] text-[#94a3b8]">Keywords: Non Drop, No Drop, ND, Zero Drop, Guaranteed, 100% Guaranteed, Permanent, Stable, Instant, Instant Start, Fast Start, 0-5 Minutes Start, Immediate Start, Instant Delivery, High Quality, No Loss, Lifetime Guarantee. Sirf Refill likha ho to Non Drop nahi maana jayega. Reject: Drop %, High Drop, Refill Only, Slow Start, Delayed Start, Gradual Delivery, Drip Feed, Unknown, Unstable, Low Quality, Start 12 Hours, Start 24 Hours. Keyword na mile to same category ki suitable service pe order lagta hai. Pending ya In Progress Service ID skip hoti hai.</p>
            </div>
          </section>
        );
      })}
      <label className="block rounded-2xl border border-[#e7eef6] bg-white p-4 text-[13px] font-semibold text-[#334155]">
        Max active orders per Service ID
        <input inputMode="numeric" value={activeLimit} onChange={(event) => setActiveLimit(event.target.value.replace(/[^\d]/g, ""))} className="mt-2 h-11 w-full rounded-xl border border-[#e7eef6] px-3 text-[13px] outline-none" />
        <p className="mt-1 text-[11px] font-normal text-[#94a3b8]">Default 1. Pending ya In Progress wali Service ID skip hoti hai. Sab busy hon to sabse kam load wali pe order lagta hai. Complete hone ke baad wahi ID dubara chalti hai.</p>
      </label>
      <button
        type="button"
        disabled={busy}
        onClick={async () => {
          setBusy(true);
          setNote("");
          try {
            const current = await adminBindings();
            const single = current.find((row) => row.slot === "single");
            await adminSaveBindings({ data: single ? [...rows, single as Row] : rows });
            await adminSaveServiceLimit({ data: { limit: Math.max(1, Number(activeLimit) || 1) } });
            setNote(`${platform} configuration saved.`);
          } catch (err: unknown) {
            setNote(err instanceof Error ? err.message : "Save failed.");
          } finally {
            setBusy(false);
          }
        }}
        className="h-12 w-full rounded-xl bg-[#2563eb] text-[14px] font-bold text-white disabled:opacity-60"
      >
        {busy ? "Saving…" : `Save ${platform} configuration`}
      </button>
      {note && <p className="text-center text-[13px] text-[#1e3a8a]">{note}</p>}
    </div>
  );
}
