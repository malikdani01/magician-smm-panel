//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BJmdvLcd.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/panel-new/src/routes/__root.tsx",
		children: [
			"/",
			"/api-access",
			"/catalog",
			"/dashboard",
			"/detect",
			"/engagement-order",
			"/engagement-orders",
			"/instagram",
			"/login",
			"/mass",
			"/order",
			"/orders",
			"/settings",
			"/single-order",
			"/support",
			"/telegram-bot",
			"/tiktok",
			"/wallet",
			"/admin/customers",
			"/admin/engagement",
			"/admin/payments",
			"/admin/services",
			"/api/auth/$",
			"/api/drops/$id",
			"/api/meta/callback",
			"/api/meta/start",
			"/api/tiktok/callback",
			"/api/tiktok/start"
		],
		preloads: [
			"/assets/index-Bo_VbNsp.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/preload-helper-CATKbdXS.js",
			"/assets/useMatch-N-D_55-w.js",
			"/assets/useNavigate-BVBKrbSk.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bo_VbNsp.js"
		} }]
	},
	"/": {
		filePath: "/workspace/panel-new/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-uuDTTqD2.js",
			"/assets/shell-CiMfhoGp.js",
			"/assets/house-BqdR93jz.js",
			"/assets/shield-check-hehnHewU.js",
			"/assets/zap-BpSN09qK.js"
		]
	},
	"/api-access": {
		filePath: "/workspace/panel-new/src/routes/api-access.tsx",
		children: void 0,
		preloads: [
			"/assets/api-access-CAdEGonP.js",
			"/assets/shell-CiMfhoGp.js",
			"/assets/gate-UHr7HYfe.js"
		]
	},
	"/catalog": {
		filePath: "/workspace/panel-new/src/routes/catalog.tsx",
		children: void 0,
		preloads: [
			"/assets/catalog-D9aeP4Ci.js",
			"/assets/shell-CiMfhoGp.js",
			"/assets/gate-UHr7HYfe.js"
		]
	},
	"/dashboard": {
		filePath: "/workspace/panel-new/src/routes/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-BnKx7PrJ.js",
			"/assets/shell-CiMfhoGp.js",
			"/assets/clock-BRnYyNYc.js",
			"/assets/refresh-cw-CSBWg1Q7.js",
			"/assets/gate-UHr7HYfe.js"
		]
	},
	"/detect": {
		filePath: "/workspace/panel-new/src/routes/detect.tsx",
		children: void 0,
		preloads: [
			"/assets/detect-CKcjqyE9.js",
			"/assets/shell-CiMfhoGp.js",
			"/assets/gate-UHr7HYfe.js",
			"/assets/tiktok.functions-B8e8Bnc7.js"
		]
	},
	"/engagement-order": {
		filePath: "/workspace/panel-new/src/routes/engagement-order.tsx",
		children: void 0,
		preloads: [
			"/assets/engagement-order-x9dNMIEi.js",
			"/assets/shell-CiMfhoGp.js",
			"/assets/share-2-Cr3jPnrQ.js",
			"/assets/calendar-O0jsdoeU.js",
			"/assets/clock-BRnYyNYc.js",
			"/assets/eye-pLOrbtl9.js",
			"/assets/instagram-D1yj0jFI.js",
			"/assets/link-2-BQSb8Lh7.js",
			"/assets/settings-2-CAHoYGKK.js",
			"/assets/refresh-cw-CSBWg1Q7.js",
			"/assets/shield-check-hehnHewU.js",
			"/assets/sparkles-DOrksW0c.js",
			"/assets/zap-BpSN09qK.js",
			"/assets/gate-UHr7HYfe.js",
			"/assets/organic-CDYRcV-V.js"
		]
	},
	"/engagement-orders": {
		filePath: "/workspace/panel-new/src/routes/engagement-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/engagement-orders-C6gpXWwA.js",
			"/assets/shell-CiMfhoGp.js",
			"/assets/share-2-Cr3jPnrQ.js",
			"/assets/eye-pLOrbtl9.js",
			"/assets/gate-UHr7HYfe.js"
		]
	},
	"/instagram": {
		filePath: "/workspace/panel-new/src/routes/instagram.tsx",
		children: void 0,
		preloads: [
			"/assets/instagram-BOa5mewR.js",
			"/assets/shell-CiMfhoGp.js",
			"/assets/instagram-D1yj0jFI.js",
			"/assets/gate-UHr7HYfe.js"
		]
	},
	"/login": {
		filePath: "/workspace/panel-new/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-S2z2Li1X.js", "/assets/shell-CiMfhoGp.js"]
	},
	"/mass": {
		filePath: "/workspace/panel-new/src/routes/mass.tsx",
		children: void 0,
		preloads: [
			"/assets/mass-bkb1kEQd.js",
			"/assets/shell-CiMfhoGp.js",
			"/assets/share-2-Cr3jPnrQ.js",
			"/assets/calendar-O0jsdoeU.js",
			"/assets/clock-BRnYyNYc.js",
			"/assets/link-2-BQSb8Lh7.js",
			"/assets/settings-2-CAHoYGKK.js",
			"/assets/refresh-cw-CSBWg1Q7.js",
			"/assets/search-C2-ej2_p.js",
			"/assets/zap-BpSN09qK.js",
			"/assets/gate-UHr7HYfe.js",
			"/assets/organic-CDYRcV-V.js"
		]
	},
	"/order": {
		filePath: "/workspace/panel-new/src/routes/order.tsx",
		children: void 0,
		preloads: ["/assets/order-_f-yhHlA.js"]
	},
	"/orders": {
		filePath: "/workspace/panel-new/src/routes/orders.tsx",
		children: ["/orders/$id"],
		preloads: ["/assets/orders-GKtxpC5N.js", "/assets/useRouterState-D-c_iaEa.js"]
	},
	"/settings": {
		filePath: "/workspace/panel-new/src/routes/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-DYbpQ1Ds.js",
			"/assets/shell-CiMfhoGp.js",
			"/assets/share-2-Cr3jPnrQ.js",
			"/assets/eye-pLOrbtl9.js",
			"/assets/shield-DL8JZzcw.js",
			"/assets/sparkles-DOrksW0c.js",
			"/assets/gate-UHr7HYfe.js"
		]
	},
	"/single-order": {
		filePath: "/workspace/panel-new/src/routes/single-order.tsx",
		children: void 0,
		preloads: [
			"/assets/single-order-DBxHWD98.js",
			"/assets/shell-CiMfhoGp.js",
			"/assets/clock-BRnYyNYc.js",
			"/assets/house-BqdR93jz.js",
			"/assets/link-2-BQSb8Lh7.js",
			"/assets/search-C2-ej2_p.js",
			"/assets/zap-BpSN09qK.js",
			"/assets/gate-UHr7HYfe.js"
		]
	},
	"/support": {
		filePath: "/workspace/panel-new/src/routes/support.tsx",
		children: void 0,
		preloads: [
			"/assets/support-vo6C89za.js",
			"/assets/shell-CiMfhoGp.js",
			"/assets/gate-UHr7HYfe.js"
		]
	},
	"/telegram-bot": {
		filePath: "/workspace/panel-new/src/routes/telegram-bot.tsx",
		children: void 0,
		preloads: [
			"/assets/telegram-bot-Bx_3s7Dx.js",
			"/assets/shell-CiMfhoGp.js",
			"/assets/shield-DL8JZzcw.js",
			"/assets/sparkles-DOrksW0c.js",
			"/assets/gate-UHr7HYfe.js"
		]
	},
	"/tiktok": {
		filePath: "/workspace/panel-new/src/routes/tiktok.tsx",
		children: void 0,
		preloads: [
			"/assets/tiktok-CgQQ-woh.js",
			"/assets/gate-UHr7HYfe.js",
			"/assets/tiktok.functions-B8e8Bnc7.js"
		]
	},
	"/wallet": {
		filePath: "/workspace/panel-new/src/routes/wallet.tsx",
		children: void 0,
		preloads: [
			"/assets/wallet-BwscLo5M.js",
			"/assets/shell-CiMfhoGp.js",
			"/assets/calendar-O0jsdoeU.js",
			"/assets/gate-UHr7HYfe.js"
		]
	},
	"/admin/customers": {
		filePath: "/workspace/panel-new/src/routes/admin.customers.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.customers-BY9Fdv_Z.js",
			"/assets/shell-CiMfhoGp.js",
			"/assets/gate-UHr7HYfe.js"
		]
	},
	"/admin/engagement": {
		filePath: "/workspace/panel-new/src/routes/admin.engagement.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.engagement-BB5o21XB.js",
			"/assets/shell-CiMfhoGp.js",
			"/assets/gate-UHr7HYfe.js"
		]
	},
	"/admin/payments": {
		filePath: "/workspace/panel-new/src/routes/admin.payments.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.payments-DMtY7MHk.js",
			"/assets/shell-CiMfhoGp.js",
			"/assets/gate-UHr7HYfe.js"
		]
	},
	"/admin/services": {
		filePath: "/workspace/panel-new/src/routes/admin.services.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.services-Bp8L5ZRd.js",
			"/assets/shell-CiMfhoGp.js",
			"/assets/gate-UHr7HYfe.js"
		]
	},
	"/orders/$id": {
		filePath: "/workspace/panel-new/src/routes/orders.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/orders._id-DvNV_9vm.js",
			"/assets/shell-CiMfhoGp.js",
			"/assets/gate-UHr7HYfe.js",
			"/assets/organic-CDYRcV-V.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
