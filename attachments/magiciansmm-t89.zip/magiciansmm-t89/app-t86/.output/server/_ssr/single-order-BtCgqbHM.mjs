import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { B as House, J as Clock, P as Link2, t as Zap, x as Search } from "../_libs/lucide-react.mjs";
import { E as adminSingleBalances, J as getDeskRole, N as browseLiveServices, Q as getWallet, _ as adminProviders, et as inr, h as adminFetchProvider, m as adminDeleteProvider, mt as placeSingleOrder, x as adminSaveProvider } from "./shell-CfBlaVSk.mjs";
import { t as Authed } from "./gate-DNi4gEUE.mjs";
import { t as usdQtyToPaise } from "./fx-Ci4OJEB9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/single-order-BtCgqbHM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PLATFORMS = [
	"instagram",
	"tiktok",
	"youtube",
	"facebook",
	"twitter",
	"telegram",
	"whatsapp",
	"spotify",
	"linkedin",
	"discord",
	"twitch",
	"snapchat",
	"kwai"
];
var ICONS = {
	instagram: InstagramMark,
	tiktok: TikTokMark,
	youtube: YoutubeMark,
	facebook: FacebookMark,
	twitter: XMark,
	telegram: TelegramMark,
	whatsapp: WhatsAppMark,
	spotify: SpotifyMark,
	linkedin: LinkedInMark,
	discord: DiscordMark,
	twitch: TwitchMark,
	snapchat: SnapchatMark,
	kwai: KwaiMark
};
function SingleOrder() {
	const [platform, setPlatform] = (0, import_react.useState)("all");
	const [query, setQuery] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("");
	const [categories, setCategories] = (0, import_react.useState)([]);
	const [services, setServices] = (0, import_react.useState)([]);
	const [serviceId, setServiceId] = (0, import_react.useState)("");
	const [balanceUsd, setBalanceUsd] = (0, import_react.useState)(null);
	const [link, setLink] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [drip, setDrip] = (0, import_react.useState)(false);
	const [runs, setRuns] = (0, import_react.useState)("");
	const [intervalMinutes, setIntervalMinutes] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [pending, setPending] = (0, import_react.useState)(false);
	const [admin, setAdmin] = (0, import_react.useState)(false);
	const [keys, setKeys] = (0, import_react.useState)([{
		name: "Provider 1",
		api_url: "https://yoyomedia.in/api/v2",
		api_key: ""
	}]);
	const [savedApis, setSavedApis] = (0, import_react.useState)([]);
	const [apiBalances, setApiBalances] = (0, import_react.useState)({});
	const [keyNote, setKeyNote] = (0, import_react.useState)("");
	const [keyBusy, setKeyBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		getDeskRole().then((role) => setAdmin(role === "admin")).catch(() => setAdmin(false));
		adminProviders().then((rows) => setSavedApis(rows.map((row) => ({
			id: row.id,
			name: row.name,
			api_url: row.api_url,
			enabled: row.enabled
		})))).catch(() => setSavedApis([]));
	}, []);
	(0, import_react.useEffect)(() => {
		if (!admin) return;
		let stop = false;
		const tick = () => {
			adminSingleBalances().then((rows) => {
				if (stop) return;
				setApiBalances(Object.fromEntries(rows.map((row) => [row.id, row])));
			}).catch(() => void 0);
		};
		tick();
		const timer = window.setInterval(tick, 12e3);
		return () => {
			stop = true;
			window.clearInterval(timer);
		};
	}, [admin, savedApis.length]);
	(0, import_react.useEffect)(() => {
		let cancel = false;
		const timer = window.setTimeout(() => {
			setLoading(true);
			browseLiveServices({ data: {
				platform,
				category,
				query
			} }).then((result) => {
				if (cancel) return;
				setCategories(result.categories);
				setServices(result.services);
				setBalanceUsd(result.balanceUsd);
				if (result.category !== category) setCategory(result.category);
				setServiceId((current) => result.services.some((service) => service.managedId === current) ? current : result.services[0]?.managedId ?? "");
				setNote("");
			}).catch((err) => {
				if (!cancel) setNote(err instanceof Error ? err.message : "Could not load YoYoMedia services.");
			}).finally(() => {
				if (!cancel) setLoading(false);
			});
		}, query ? 250 : 0);
		return () => {
			cancel = true;
			window.clearTimeout(timer);
		};
	}, [
		platform,
		category,
		query
	]);
	const service = services.find((item) => item.managedId === serviceId) ?? services[0] ?? null;
	const dripAllowed = Boolean(service?.dripAllowed);
	const dripOn = drip && dripAllowed;
	const runCount = Math.max(1, Math.floor(Number(runs) || 0));
	const qty = Math.floor(Number(amount));
	const totalQty = dripOn && runCount > 0 ? qty * runCount : qty;
	const charge = service && Number.isFinite(qty) && qty > 0 ? usdQtyToPaise(service.rateUsd, totalQty) : 0;
	const inRange = Boolean(service) && Number.isFinite(qty) && qty >= (service?.min ?? 0) && qty <= (service?.max ?? 0);
	function pickPlatform(next) {
		setPlatform(next);
		setCategory("");
		setQuery("");
		setServiceId("");
	}
	async function submit() {
		if (!service) return;
		if (!inRange) {
			setNote(`Amount must be between ${service.min.toLocaleString("en-IN")} and ${service.max.toLocaleString("en-IN")}.`);
			return;
		}
		setPending(true);
		setNote("");
		try {
			if ((await getWallet()).balance_paise < charge) {
				setNote("Panel wallet does not cover this order. Add credit first.");
				return;
			}
			const result = await placeSingleOrder({ data: {
				serviceId: service.id,
				managedId: service.managedId,
				link,
				amount: qty,
				drip: dripOn,
				runs: dripOn ? runCount : 1,
				intervalMinutes: Math.max(1, Math.floor(Number(intervalMinutes) || 1))
			} });
			setNote(dripOn ? `${result.order_number} drip started. First run is placing now, next runs follow the interval.` : `${result.order_number} place ho chuka hai #${result.provider_order_id} · ${inr(result.total_paise)}. Delivery abhi live track hogi.`);
			setLink("");
			setAmount("");
		} catch (err) {
			setNote(err instanceof Error ? err.message : "Order failed.");
		} finally {
			setPending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl pb-16",
		children: [admin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mb-4 rounded-[28px] border border-[#dbeafe] bg-white p-4 shadow-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-[16px] font-bold",
					children: "Single order APIs"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-[12px] text-[#64748b]",
					children: "URL aur API key yahan daalo. Har API ka balance live update hota rahega. Remove dabao to balance bhi hat jayega."
				}),
				savedApis.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: savedApis.map((row) => {
						const live = apiBalances[row.id];
						const money = live && !live.error ? `${live.currency || "USD"} ${live.balance.toLocaleString("en-IN", {
							minimumFractionDigits: 2,
							maximumFractionDigits: 2
						})}` : "";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-2 rounded-xl bg-[#f8fafc] px-3 py-2 text-[12px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block truncate",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: row.name }),
										" · ",
										row.api_url
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `mt-0.5 block font-semibold ${live?.error ? "text-rose-500" : live?.low ? "text-amber-600" : "text-emerald-600"}`,
									children: live ? live.error || `Balance ${money}` : "Balance check ho raha hai…"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: keyBusy,
								onClick: async () => {
									setKeyBusy(true);
									try {
										await adminDeleteProvider({ data: row.id });
										setSavedApis((current) => current.filter((item) => item.id !== row.id));
										setKeyNote(`${row.name} hata diya. Dashboard API balance se bhi nikal gaya.`);
									} catch (err) {
										setKeyNote(err instanceof Error ? err.message : "Could not remove.");
									} finally {
										setKeyBusy(false);
									}
								},
								className: "shrink-0 font-semibold text-rose-600",
								children: "Remove"
							})]
						}, row.id);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid gap-3",
					children: [
						keys.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2 rounded-2xl bg-[#f8fafc] p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[12px] font-semibold",
										children: ["API ", index + 1]
									}), keys.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setKeys(keys.filter((_, itemIndex) => itemIndex !== index)),
										className: "text-[12px] font-semibold text-[#b91c1c]",
										children: "Remove"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: item.api_url,
									onChange: (event) => setKeys(keys.map((row, itemIndex) => itemIndex === index ? {
										...row,
										api_url: event.target.value
									} : row)),
									placeholder: "API URL",
									className: "h-11 rounded-xl border border-[#e7eef6] bg-white px-3 text-[13px] outline-none"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: item.api_key,
									onChange: (event) => setKeys(keys.map((row, itemIndex) => itemIndex === index ? {
										...row,
										api_key: event.target.value
									} : row)),
									placeholder: "API key",
									className: "h-11 rounded-xl border border-[#e7eef6] bg-white px-3 text-[13px] outline-none"
								})
							]
						}, index)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setKeys([...keys, {
								name: `Provider ${keys.length + 1}`,
								api_url: "https://yoyomedia.in/api/v2",
								api_key: ""
							}]),
							className: "h-10 rounded-xl bg-[#f3f6fa] text-[12px] font-bold text-[#1d4ed8]",
							children: "Add another API"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: keyBusy,
							onClick: async () => {
								const filled = keys.filter((item) => item.api_key.trim());
								if (!filled.length) {
									setKeyNote("API key daalo.");
									return;
								}
								setKeyBusy(true);
								setKeyNote("");
								const notes = [];
								for (const item of filled) try {
									const saved = await adminSaveProvider({ data: {
										name: item.name || "Provider",
										api_url: item.api_url,
										api_key: item.api_key,
										enabled: true
									} });
									const result = await adminFetchProvider({ data: saved.id });
									notes.push(`${result.total.toLocaleString("en-IN")} services`);
								} catch (err) {
									notes.push(err instanceof Error ? err.message : "Save failed");
								}
								setKeyNote(notes.join(" · ") + " · API balance mein aa gayi.");
								setSavedApis(await adminProviders().then((rows) => rows.map((row) => ({
									id: row.id,
									name: row.name,
									api_url: row.api_url,
									enabled: row.enabled
								}))).catch(() => savedApis));
								setKeyBusy(false);
							},
							className: "h-11 rounded-xl bg-[#2563eb] text-[13px] font-bold text-white disabled:opacity-60",
							children: keyBusy ? "Saving…" : "Save APIs and load services"
						}),
						keyNote && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[12px] text-[#1e3a8a]",
							children: keyNote
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-[28px] border border-[#e7eef6] bg-white p-4 shadow-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "All platforms",
						onClick: () => pickPlatform("all"),
						className: `grid size-11 place-items-center rounded-2xl border ${platform === "all" ? "border-[#2563eb] bg-[#2563eb] text-white ring-2 ring-[#2563eb]" : "border-[#e7eef6] bg-[#eef3f8] text-[#334155]"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: "size-5" })
					}), PLATFORMS.map((id) => {
						const Icon = ICONS[id];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": id,
							onClick: () => pickPlatform(id),
							className: `grid size-11 place-items-center rounded-2xl border ${platform === id ? "border-[#2563eb] bg-white ring-2 ring-[#2563eb]" : "border-[#e7eef6] bg-white"}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {})
						}, id);
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-[12px] text-[#64748b]",
					children: loading ? "Loading live YoYoMedia services…" : `YoYoMedia balance $${balanceUsd?.toFixed(2) ?? "—"} · charge uses ₹84 per $1`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 block text-[13px] font-semibold text-[#334155]",
					children: ["Search for a service...", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-1 flex h-11 items-center gap-2 rounded-xl bg-[#e7f0f8] px-3 text-[#94a3b8]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: query,
							onChange: (event) => setQuery(event.target.value),
							placeholder: "Search...",
							className: "w-full bg-transparent text-[14px] text-[#0f172a] outline-none"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 block text-[13px] font-semibold text-[#334155]",
					children: ["Category", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: category,
						onChange: (event) => {
							setCategory(event.target.value);
							setServiceId("");
						},
						className: "mt-1 h-11 w-full rounded-xl border border-[#e7eef6] bg-white px-3 text-[14px]",
						children: [categories.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item)), categories.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "No category"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 block text-[13px] font-semibold text-[#334155]",
					children: ["Service", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: service?.managedId ?? "",
						onChange: (event) => setServiceId(event.target.value),
						className: "mt-1 h-11 w-full rounded-xl border border-[#e7eef6] bg-white px-3 text-[13px]",
						children: services.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: item.managedId || String(item.id),
							children: [
								item.id,
								" · ",
								platform === "all" ? `${item.platform || item.category} · ` : "",
								item.name,
								item.providerName ? ` · ${item.providerName}` : ""
							]
						}, item.managedId || item.id))
					})]
				}),
				service && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceChip, { service }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[13px] font-semibold text-[#334155]",
						children: "Provider note"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1 flex items-center gap-3 rounded-xl bg-[#f8fbff] px-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-9 place-items-center rounded-full bg-[#e8f1ff] text-[#2563eb]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[14px] font-semibold",
							children: service?.note || (loading ? "Loading…" : "No extra note from the provider")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[12px] text-[#94a3b8]",
							children: service ? `${inr(Math.round(service.rateUsd * 84 * 100))} per 1,000` : "Pick a service"
						})] })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 block text-[13px] font-semibold text-[#334155]",
					children: ["Enter Link", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-1 flex h-11 items-center gap-2 rounded-xl border border-[#e7eef6] px-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "size-4 text-[#94a3b8]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: link,
							onChange: (event) => setLink(event.target.value),
							placeholder: "Paste your link here",
							className: "w-full bg-transparent text-[14px] outline-none"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 block text-[13px] font-semibold text-[#334155]",
					children: [
						"Amount",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: amount,
							inputMode: "numeric",
							onChange: (event) => setAmount(event.target.value.replace(/[^\d]/g, "")),
							placeholder: "Enter amount",
							className: "mt-1 h-11 w-full rounded-xl border border-[#e7eef6] px-3 text-[14px] outline-none"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-1 block text-[12px] font-normal text-[#94a3b8]",
							children: [
								"Min: ",
								service?.min.toLocaleString("en-IN") ?? "—",
								" · Max: ",
								service?.max.toLocaleString("en-IN") ?? "—"
							]
						}),
						amount !== "" && service && qty < service.min && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-[12px] font-semibold text-rose-600",
							children: [
								"Below ",
								service.min.toLocaleString("en-IN"),
								" not allowed"
							]
						}),
						amount !== "" && service && qty > service.max && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-[12px] font-semibold text-rose-600",
							children: [
								"Above ",
								service.max.toLocaleString("en-IN"),
								" not allowed"
							]
						})
					]
				}),
				dripAllowed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 rounded-2xl border border-violet-400/40 bg-[#241c48] p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center justify-between gap-3 text-[14px] font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Drip-feed" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								role: "switch",
								"aria-checked": drip,
								onClick: () => setDrip((value) => !value),
								className: `relative h-7 w-12 rounded-full ${drip ? "bg-violet-500" : "bg-[#3a335f]"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-0.5 size-6 rounded-full bg-white shadow ${drip ? "left-5" : "left-0.5"}` })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-[12px] text-[#c4b5fd]",
							children: "Is service pe provider drip support karta hai. Runs alag-alag interval pe place honge."
						}),
						dripOn && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-[13px] font-semibold",
									children: [
										"Runs",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: runs,
											inputMode: "numeric",
											onChange: (event) => setRuns(event.target.value.replace(/[^\d]/g, "")),
											placeholder: "How many orders",
											className: "mt-1 h-11 w-full rounded-xl px-3 text-[14px] outline-none"
										}),
										runs !== "" && Number(runs) < 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-[12px] font-semibold text-rose-300",
											children: "Below 1 not allowed"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-[13px] font-semibold",
									children: [
										"Intervals (in minutes)",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: intervalMinutes,
											inputMode: "numeric",
											onChange: (event) => setIntervalMinutes(event.target.value.replace(/[^\d]/g, "")),
											placeholder: "Minutes between runs",
											className: "mt-1 h-11 w-full rounded-xl px-3 text-[14px] outline-none"
										}),
										intervalMinutes !== "" && Number(intervalMinutes) < 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-[12px] font-semibold text-rose-300",
											children: "Below 1 not allowed"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-[13px] font-semibold",
									children: ["Total quantity", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										readOnly: true,
										value: Number.isFinite(totalQty) ? totalQty : 0,
										className: "mt-1 h-11 w-full rounded-xl px-3 text-[14px] outline-none"
									})]
								})
							]
						})
					]
				}) : service && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-[12px] text-[#a5b4fc]",
					children: "Is service pe drip-feed available nahi hai."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-center justify-between text-[14px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold",
						children: "Charge"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-bold text-[#2563eb]",
						children: inr(charge)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					disabled: pending || !service,
					onClick: submit,
					className: "mt-4 inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#2563eb] text-[14px] font-bold tracking-wide text-white disabled:opacity-60",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-4" }),
						" ",
						pending ? "SUBMITTING…" : "SUBMIT ORDER"
					]
				}),
				note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-center text-[13px] text-[#334155]",
					children: note
				})
			]
		})]
	});
}
function ServiceChip({ service }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "mt-2 flex items-start gap-2 text-[12px] leading-snug text-[#475569]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "rounded-md bg-[#2563eb] px-1.5 py-0.5 text-[10px] font-bold text-white",
			children: service.id
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: service.name })]
	});
}
function InstagramMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: "size-7",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("radialGradient", {
				id: "ig",
				cx: "30%",
				cy: "110%",
				r: "120%",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
						offset: "0%",
						stopColor: "#f9ce34"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
						offset: "40%",
						stopColor: "#ee2a7b"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
						offset: "100%",
						stopColor: "#6228d7"
					})
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "32",
				height: "32",
				rx: "8",
				fill: "url(#ig)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "8",
				y: "8",
				width: "16",
				height: "16",
				rx: "5",
				fill: "none",
				stroke: "#fff",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16",
				cy: "16",
				r: "4",
				fill: "none",
				stroke: "#fff",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "21.5",
				cy: "10.5",
				r: "1.2",
				fill: "#fff"
			})
		]
	});
}
function TikTokMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: "size-7",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "32",
				height: "32",
				rx: "8",
				fill: "#111"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M18 8c.6 2.4 2.2 4 4.6 4.4v2.4c-1.6 0-3.1-.5-4.4-1.4v6.4a5.8 5.8 0 1 1-5-5.7v2.6a3.3 3.3 0 1 0 2.4 3.1V8H18z",
				fill: "#25f4ee",
				transform: "translate(-.6 .4)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M18 8c.6 2.4 2.2 4 4.6 4.4v2.4c-1.6 0-3.1-.5-4.4-1.4v6.4a5.8 5.8 0 1 1-5-5.7v2.6a3.3 3.3 0 1 0 2.4 3.1V8H18z",
				fill: "#fe2c55",
				transform: "translate(.6 -.2)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M18 8c.6 2.4 2.2 4 4.6 4.4v2.4c-1.6 0-3.1-.5-4.4-1.4v6.4a5.8 5.8 0 1 1-5-5.7v2.6a3.3 3.3 0 1 0 2.4 3.1V8H18z",
				fill: "#fff"
			})
		]
	});
}
function YoutubeMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: "size-7",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "32",
			height: "32",
			rx: "8",
			fill: "#ff0033"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M13 11.5v9l8-4.5-8-4.5z",
			fill: "#fff"
		})]
	});
}
function FacebookMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: "size-7",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "32",
			height: "32",
			rx: "8",
			fill: "#1877f2"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M18.2 16.8H16v8h-3.2v-8H11v-2.7h1.8v-1.8c0-2.2 1-3.5 3.6-3.5h2.2v2.7h-1.4c-.8 0-1 .3-1 .9v1.7h2.5l-.5 2.7z",
			fill: "#fff"
		})]
	});
}
function XMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: "size-7",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "32",
			height: "32",
			rx: "8",
			fill: "#111"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M9 9.5h3.2l3.2 4.3 3.6-4.3H22l-5 5.8L22.4 22h-3.1l-3.5-4.6L12 22H9.2l5.3-6.2L9 9.5z",
			fill: "#fff"
		})]
	});
}
function TelegramMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: "size-7",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "16",
			cy: "16",
			r: "14",
			fill: "#2aa3e0"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M8 15.6 22.2 10l-2.2 12.2-4.6-3.4-2.4 2.3.2-3.6 8.2-7.4-10.2 6.1L8 15.6z",
			fill: "#fff"
		})]
	});
}
function WhatsAppMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: "size-7",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "16",
			cy: "16",
			r: "14",
			fill: "#25d366"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 8.2a7.6 7.6 0 0 0-6.5 11.5L8.6 23l3.4-.9A7.6 7.6 0 1 0 16 8.2zm4.3 10.7c-.2.5-1 .9-1.4 1-.4 0-.8.2-2.7-.6-2.3-.9-3.7-3.2-3.8-3.4-.1-.2-1-1.3-1-2.5s.6-1.8.9-2c.2-.2.5-.3.7-.3h.5c.2 0 .4 0 .5.4.2.5.7 1.8.7 1.9.1.1 0 .3-.1.5l-.3.4c-.1.1-.2.3-.1.5.2.3.7 1.2 1.5 1.9 1 .9 1.8 1.1 2.1 1.3.2.1.4.1.5-.1l.6-.7c.2-.2.3-.2.5-.1l1.6.8c.2.1.4.2.4.3 0 .2-.1.8-.4 1.1z",
			fill: "#fff"
		})]
	});
}
function SpotifyMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: "size-7",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16",
				cy: "16",
				r: "14",
				fill: "#1db954"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M10 13.2c3.6-1.1 8-.8 11.2 1.1",
				fill: "none",
				stroke: "#fff",
				strokeWidth: "1.7",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M11 16.4c2.8-.8 6.2-.6 8.6.8",
				fill: "none",
				stroke: "#fff",
				strokeWidth: "1.5",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M12 19.4c2.1-.5 4.4-.3 6 .6",
				fill: "none",
				stroke: "#fff",
				strokeWidth: "1.4",
				strokeLinecap: "round"
			})
		]
	});
}
function LinkedInMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: "size-7",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "32",
			height: "32",
			rx: "6",
			fill: "#0a66c2"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M9 13h3v10H9zM10.5 8.2a1.7 1.7 0 1 1 0 3.4 1.7 1.7 0 0 1 0-3.4zM15 13h2.9v1.4h.1c.4-.8 1.4-1.6 2.9-1.6 3.1 0 3.6 2 3.6 4.6V23H21v-4.8c0-1.1 0-2.6-1.6-2.6s-1.8 1.2-1.8 2.5V23H15v-10z",
			fill: "#fff"
		})]
	});
}
function DiscordMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: "size-7",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "32",
			height: "32",
			rx: "8",
			fill: "#5865f2"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M21.6 11.2a10 10 0 0 0-2.5-1l-.2.5a8 8 0 0 1 2.2.8 11 11 0 0 0-8.2 0 8 8 0 0 1 2.2-.8l-.2-.5a10 10 0 0 0-2.5 1C9.4 13.6 8.8 16 8.6 18.3c1.3 1 2.6 1.6 3.9 2l.8-1.2a6 6 0 0 1-1.2-.6l.3-.2c2.4 1.1 5 1.1 7.3 0l.3.2c-.4.2-.8.4-1.2.6l.8 1.2c1.3-.4 2.6-1 3.9-2-.3-2.4-1-4.8-2.9-7.1zM13.6 17.2c-.6 0-1.1-.6-1.1-1.3s.5-1.3 1.1-1.3 1.1.6 1.1 1.3-.5 1.3-1.1 1.3zm4.8 0c-.6 0-1.1-.6-1.1-1.3s.5-1.3 1.1-1.3 1.1.6 1.1 1.3-.5 1.3-1.1 1.3z",
			fill: "#fff"
		})]
	});
}
function TwitchMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: "size-7",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "32",
			height: "32",
			rx: "8",
			fill: "#9146ff"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M10 8h12v10l-3 3h-3l-2 2h-2v-2H10V8zm3 2v6h1.5V10H13zm4 0v6H18.5V10H17z",
			fill: "#fff"
		})]
	});
}
function KwaiMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: "size-7",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "32",
			height: "32",
			rx: "8",
			fill: "#ff4906"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M9 22V10h3.2l3.3 6.2L18.8 10H22v12h-2.6v-6.8L16.4 22h-1.7l-3.1-6.8V22H9z",
			fill: "#fff"
		})]
	});
}
function SnapchatMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: "size-7",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "32",
			height: "32",
			rx: "8",
			fill: "#fffc00"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 7.5c2.2 0 3.6 1.6 3.6 3.8 0 1.2-.2 2.2 0 2.8.3.6 1.4.7 2 .9.4.1.3.6-.2.7-.8.1-1.3.5-1.4 1.1 0 .3.4.5 1.1.7.5.2.7.5.4.8-.6.5-1.6.6-2.2 1.2-.3.3-.2.7.4 1 .8.4 1.6 1 1.2 1.6-.5.7-2 .4-3.1.2-.4 0-.7.3-.8.7-.2.8-1 1.3-1.9 1.3s-1.7-.5-1.9-1.3c-.1-.4-.4-.7-.8-.7-1.1.2-2.6.5-3.1-.2-.4-.6.4-1.2 1.2-1.6.6-.3.7-.7.4-1-.6-.6-1.6-.7-2.2-1.2-.3-.3-.1-.6.4-.8.7-.2 1.1-.4 1.1-.7-.1-.6-.6-1-1.4-1.1-.5-.1-.6-.6-.2-.7.6-.2 1.7-.3 2-.9.2-.6 0-1.6 0-2.8 0-2.2 1.4-3.8 3.6-3.8z",
			fill: "#111"
		})]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Authed, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SingleOrder, {}) });
//#endregion
export { SplitComponent as component };
