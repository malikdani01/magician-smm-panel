import { r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-DY5Pyta6.mjs";
import { u as getSql } from "./organic-DU6S6wDh.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
import { g as requireAdmin } from "./admin.server-B6p1lYbS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/instagram.functions-Ca18p79M.js
var listInstagramConnections_createServerFn_handler = createServerRpc({
	id: "1c9e8571cff3c98c4935177f1a4e48ce8017be201a866fd51db1a4081d83fa7e",
	name: "listInstagramConnections",
	filename: "src/lib/instagram.functions.ts"
}, (opts) => listInstagramConnections.__executeServer(opts));
var listInstagramConnections = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listInstagramConnections_createServerFn_handler, async ({ context }) => {
	await requireAdmin(context.userId);
	const rows = await (await getSql())`
      select id, username, ig_user_id, expires_at::text as expires_at
      from instagram_oauth
      where user_id = ${context.userId}
      order by created_at desc
    `;
	return {
		ready: Boolean(process.env.INSTAGRAM_APP_ID?.trim() && process.env.INSTAGRAM_APP_SECRET?.trim()),
		accounts: rows
	};
});
//#endregion
export { listInstagramConnections_createServerFn_handler };
