import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-DY5Pyta6.mjs";
import { z as Instagram } from "../_libs/lucide-react.mjs";
import { nt as listInstagram, tt as linkInstagram, z as createSsrRpc } from "./shell-CfBlaVSk.mjs";
import { n as StaffOnly, t as Authed } from "./gate-DNi4gEUE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/instagram-B136YR8c.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var listInstagramConnections = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("1c9e8571cff3c98c4935177f1a4e48ce8017be201a866fd51db1a4081d83fa7e"));
function Page() {
	const [username, setUsername] = (0, import_react.useState)("");
	const [rows, setRows] = (0, import_react.useState)([]);
	const [connected, setConnected] = (0, import_react.useState)([]);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [note, setNote] = (0, import_react.useState)("");
	function load() {
		listInstagram().then(setRows).catch(() => setRows([]));
		listInstagramConnections().then((result) => {
			setReady(result.ready);
			setConnected(result.accounts);
		}).catch(() => setConnected([]));
	}
	(0, import_react.useEffect)(load, []);
	(0, import_react.useEffect)(() => {
		const params = new URLSearchParams(window.location.search);
		if (params.get("ig") === "connected") setNote("Instagram connect ho gaya. Ab is account ke counts padhe ja sakte hain.");
		if (params.get("ig") === "error") setNote(params.get("reason") || "Connect fail.");
	}, []);
	async function link() {
		setNote("");
		try {
			await linkInstagram({ data: username });
			setUsername("");
			setNote("Username save ho gaya. Counts ke liye neeche Connect Instagram use karo.");
			load();
		} catch (err) {
			setNote(err instanceof Error ? err.message : "Could not link.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl bg-gradient-to-r from-[#eef4ff] to-white p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "flex items-center gap-2 text-[22px] font-bold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-9 place-items-center rounded-xl bg-[#3b82f6] text-white",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Instagram, { className: "size-4" })
					}), " Instagram Accounts"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[13px] text-[#64748b]",
					children: "Professional account Allow karega, tab views, likes, saves aur shares usi account se aayenge."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border border-[#e7eef6] bg-white p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-semibold tracking-widest text-[#94a3b8]",
						children: "CONNECT INSTAGRAM"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-[12px] text-[#64748b]",
						children: "Abhi sirf tester account connect hoga. `sannaraj` se Instagram pe Allow dabana."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/api/meta/start",
						className: "mt-3 inline-flex h-11 items-center rounded-xl bg-[#2563eb] px-4 text-[13px] font-bold text-white",
						children: "Connect Instagram"
					}),
					!ready && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-[12px] text-rose-600",
						children: "Server ko INSTAGRAM_APP_ID aur INSTAGRAM_APP_SECRET .env mein nahi mile. Dev server restart karo."
					}),
					connected.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-2",
						children: connected.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-xl bg-emerald-50 px-3 py-2 text-[13px] font-semibold text-emerald-800",
							children: ["Connected @", row.username || row.ig_user_id]
						}, row.id))
					}),
					note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-[12px]",
						children: note
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border border-[#e7eef6] bg-white p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-semibold tracking-widest text-[#94a3b8]",
						children: "ADD INSTAGRAM USERNAME"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: username,
							onChange: (event) => setUsername(event.target.value),
							placeholder: "@ your_username",
							className: "h-11 flex-1 rounded-xl bg-[#f8fafc] px-3 outline-none"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: link,
							className: "rounded-xl bg-[#60a5fa] px-4 font-semibold text-white",
							children: "+ Link"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-[12px] text-[#94a3b8]",
						children: "Yeh sirf naam save karta hai. Counts Connect wale account se aate hain."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 rounded-xl bg-emerald-50 px-3 py-2 text-[12px] text-emerald-700",
						children: [
							rows.length,
							"/5 links used · ",
							Math.max(0, 5 - rows.length),
							" more accounts can be linked in this 30-day window."
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "rounded-3xl border border-[#e7eef6] bg-white p-8 text-center text-[13px] text-[#64748b]",
				children: rows.length === 0 ? "No username saved yet." : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2 text-left",
					children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-xl bg-[#f8fafc] px-3 py-2 font-semibold",
						children: ["@", row.username]
					}, row.id))
				})
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Authed, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StaffOnly, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {}) }) });
//#endregion
export { SplitComponent as component };
