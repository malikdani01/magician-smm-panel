import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-DY5Pyta6.mjs";
import { Z as Calendar, i as Wallet, it as ArrowUpRight, st as ArrowDownRight } from "../_libs/lucide-react.mjs";
import { At as useCurrentUserState, Dt as submitPaymentClaim, G as fromMinor, Ot as subscribeCurrency, Q as getWallet, R as convertMajor, W as formatMajor, ct as moneyCode, et as inr, kt as toBaseMinor, lt as moneyState, ot as listPaymentGateways, ut as myPaymentClaims, z as createSsrRpc } from "./shell-CfBlaVSk.mjs";
import { t as Authed } from "./gate-DNi4gEUE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/wallet-DhxTeVW4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var getDepositDesk = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("b1ae4c1a0b5eff32155b74736bdcf465f5eb0af21e51f2b8da9fe9c653920585"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const inr = Math.round(Number(input?.inr));
	if (!Number.isFinite(inr) || inr < 1) throw new Error("Enter a valid amount.");
	return { inr };
}).handler(createSsrRpc("5b07ee47958fc2c01e82993fafeee2544ec66907245d64d4d2e96230408d3eb1"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input?.id) throw new Error("Missing deposit.");
	return { id: String(input.id) };
}).handler(createSsrRpc("53a1f822c70843fcbf43cb5342882aaca528b7b58f8724b34754783b0ea201cd"));
var checkWalletDeposit = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	id: String(input?.id || ""),
	txid: String(input?.txid || "").trim()
})).handler(createSsrRpc("9d9811be9e2c367b8d5828ac29403a1e2270d71f4dfa3e6b07b82855f56322d2"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input?.id) throw new Error("Missing deposit.");
	return {
		id: String(input.id),
		screenshot: String(input.screenshot || "")
	};
}).handler(createSsrRpc("c339e900427b4fe3a45195a7a48c5a81e45af9e0634f40109dab1f3a7064103a"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const inr = Math.round(Number(input?.inr));
	if (!Number.isFinite(inr) || inr < 1) throw new Error("Enter a valid amount.");
	return { inr };
}).handler(createSsrRpc("491e96f1d6c6d8608f925cbac01db32da2f26a5bdce86bc02ed036b9a75e9333"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	id: String(input?.id || ""),
	orderId: String(input?.orderId || ""),
	paymentId: String(input?.paymentId || ""),
	signature: String(input?.signature || "")
})).handler(createSsrRpc("5de11bed71183fba67b2af4462a4f13f10799e54a416af658b9baccae3e739b3"));
var SLOTS = [
	{
		id: "upi",
		title: "Instant UPI",
		sub: "GPay · PhonePe · Paytm",
		badge: "UPI",
		hint: "Proof submit karo · wallet admin approve ke baad update hoga",
		chips: [
			100,
			500,
			1e3,
			2e3,
			5e3
		]
	},
	{
		id: "crypto",
		title: "Pay with Crypto",
		sub: "USDT · BTC · TRX · LTC · ETH",
		badge: "CRYPTO",
		hint: "Hash submit karo · wallet admin approve ke baad update hoga",
		chips: [
			90,
			500,
			1e3,
			2e3,
			5e3,
			1e4
		]
	},
	{
		id: "talk",
		title: "Talk to Admin",
		sub: "Custom / bulk top-ups on Telegram",
		badge: "MANUAL",
		hint: "Message pre-filled · replies in minutes",
		chips: [
			100,
			500,
			1e3,
			2e3,
			5e3,
			1e4
		]
	},
	{
		id: "jazzcash",
		title: "JazzCash",
		sub: "Account · QR · screenshot",
		badge: "PK",
		hint: "Transaction id aur screenshot · admin approve ke baad credit",
		chips: [
			100,
			500,
			1e3,
			2e3,
			5e3,
			1e4
		]
	}
];
var PERIODS = [
	{
		id: "today",
		label: "Today"
	},
	{
		id: "yesterday",
		label: "Yesterday"
	},
	{
		id: "7",
		label: "Last 7 Days"
	},
	{
		id: "30",
		label: "Last 30 Days"
	},
	{
		id: "lifetime",
		label: "Lifetime"
	},
	{
		id: "custom",
		label: "Custom Range..."
	}
];
function slotCoinsOf(gate) {
	const parsed = (gate.network || "").split("\n").map((line) => line.trim()).filter(Boolean).map((line) => {
		const [label, network, address] = line.split("|").map((part) => part.trim());
		return {
			label: label || "USDT",
			network: network || "",
			address: address || ""
		};
	}).filter((row) => row.address);
	if (parsed.length) return parsed;
	if (gate.account_number) return [{
		label: gate.pay_currency || "USDT",
		network: "",
		address: gate.account_number
	}];
	return [];
}
function dayStart(date) {
	return new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
}
function WalletPage() {
	const { user } = useCurrentUserState();
	const [balance, setBalance] = (0, import_react.useState)(0);
	const [rows, setRows] = (0, import_react.useState)([]);
	const [amount, setAmount] = (0, import_react.useState)(100);
	const [gateways, setGateways] = (0, import_react.useState)([]);
	const [slot, setSlot] = (0, import_react.useState)("upi");
	const [filter, setFilter] = (0, import_react.useState)("All");
	const [period, setPeriod] = (0, import_react.useState)("lifetime");
	const [periodOpen, setPeriodOpen] = (0, import_react.useState)(false);
	const [from, setFrom] = (0, import_react.useState)("");
	const [to, setTo] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	const [shot, setShot] = (0, import_react.useState)("");
	const [reference, setReference] = (0, import_react.useState)("");
	const [claims, setClaims] = (0, import_react.useState)([]);
	const [checkout, setCheckout] = (0, import_react.useState)(false);
	const [left, setLeft] = (0, import_react.useState)(600);
	const [coin, setCoin] = (0, import_react.useState)(0);
	const [copied, setCopied] = (0, import_react.useState)("");
	const [method, setMethod] = (0, import_react.useState)("razorpay");
	const [payNet, setPayNet] = (0, import_react.useState)(0);
	const [desk, setDesk] = (0, import_react.useState)({
		razorpay: false,
		razorMin: 200,
		razorMax: 1e5,
		usdtAddress: "",
		usdtRate: 90,
		usdtMin: 10,
		usdtMaxInr: 5e5
	});
	const [ledger, setLedger] = (0, import_react.useState)([]);
	const [banner, setBanner] = (0, import_react.useState)("");
	const [txid, setTxid] = (0, import_react.useState)("");
	const [shotName, setShotName] = (0, import_react.useState)("");
	const [payOpen, setPayOpen] = (0, import_react.useState)(false);
	const [moneyTick, setMoneyTick] = (0, import_react.useState)(0);
	function load() {
		getWallet().then((wallet) => {
			setBalance(wallet.balance_paise);
			setRows(wallet.transactions);
		});
		listPaymentGateways().then((next) => setGateways(next)).catch(() => setGateways([]));
		myPaymentClaims().then(setClaims).catch(() => setClaims([]));
		getDepositDesk().then((result) => {
			setDesk(result.config);
			setLedger(result.deposits);
		}).catch(() => void 0);
	}
	(0, import_react.useEffect)(load, []);
	(0, import_react.useEffect)(() => {
		const stop = subscribeCurrency(() => setMoneyTick((value) => value + 1));
		return () => {
			stop();
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!checkout) return;
		setLeft(600);
		const timer = window.setInterval(() => setLeft((value) => value > 0 ? value - 1 : 0), 1e3);
		return () => window.clearInterval(timer);
	}, [checkout, slot]);
	const gate = (0, import_react.useMemo)(() => {
		const match = (kind) => gateways.find((item) => item.pay_kind === kind || kind === "jazzcash" && /jazz/i.test(item.name));
		return match(slot);
	}, [gateways, slot]);
	SLOTS.filter((item) => item.id !== "jazzcash" || gateways.some((row) => row.pay_kind === "jazzcash" || /jazz/i.test(row.name)));
	SLOTS.find((item) => item.id === slot) ?? SLOTS[0];
	gate?.pay_kind;
	const slotCoins = gate ? slotCoinsOf(gate) : [];
	slotCoins[coin] || slotCoins[0];
	toBaseMinor(amount);
	moneyState().display.symbol;
	gate && gate.min_paise / 100;
	gate && gate.max_paise / 100;
	const ranged = (0, import_react.useMemo)(() => {
		const today = dayStart(/* @__PURE__ */ new Date());
		return rows.filter((row) => {
			const at = new Date(row.created_at).getTime();
			if (!Number.isFinite(at)) return period === "lifetime";
			if (period === "today") return at >= today;
			if (period === "yesterday") return at >= today - 864e5 && at < today;
			if (period === "7") return at >= today - 5184e5;
			if (period === "30") return at >= today - 25056e5;
			if (period === "custom") {
				const start = from ? dayStart(new Date(from)) : 0;
				const end = to ? dayStart(new Date(to)) + 864e5 : Number.POSITIVE_INFINITY;
				return at >= start && at < end;
			}
			return true;
		});
	}, [
		rows,
		period,
		from,
		to
	]);
	const deposits = ranged.filter((row) => row.amount_paise > 0 && row.kind !== "refund").reduce((sum, row) => sum + row.amount_paise, 0);
	const spent = Math.abs(ranged.filter((row) => row.amount_paise < 0).reduce((sum, row) => sum + row.amount_paise, 0));
	const shown = ranged.filter((row) => {
		if (filter === "Deposit") return row.amount_paise > 0 && row.kind !== "refund";
		if (filter === "Order") return row.amount_paise < 0;
		if (filter === "Refund") return row.kind === "refund" || /^refund/i.test(row.note);
		return true;
	});
	const periodLabel = PERIODS.find((item) => item.id === period)?.label ?? "Lifetime";
	const openUsdt = ledger.find((row) => row.gateway === "USDT" && row.status === "open");
	(0, import_react.useEffect)(() => {
		if (!openUsdt) return;
		const timer = window.setInterval(() => {
			checkWalletDeposit({ data: { id: openUsdt.id } }).then((result) => {
				if (result.status === "paid") {
					setBanner("USDT payment confirmed. Wallet credited.");
					load();
				}
			}).catch(() => void 0);
		}, 15e3);
		return () => window.clearInterval(timer);
	}, [openUsdt?.id]);
	function copyText(value) {
		navigator.clipboard?.writeText(value).then(() => {
			setCopied(value);
			window.setTimeout(() => setCopied(""), 1400);
		}).catch(() => setNote("Copy nahi hua. Number select karke copy karo."));
	}
	const code = moneyCode();
	const razorGate = gateways.find((item) => item.pay_kind === "razorpay" || item.pay_kind === "upi");
	const jazzGate = gateways.find((item) => item.pay_kind === "jazzcash" || /jazz/i.test(item.name));
	const cryptoGate = gateways.find((item) => item.pay_kind === "crypto" || item.pay_kind === "usdt");
	const payGate = method === "jazzcash" ? jazzGate : method === "crypto" ? cryptoGate : razorGate;
	const limits = method === "crypto" ? {
		min: cryptoGate?.pay_currency === "USD" ? cryptoGate.min_paise / 100 : 5,
		max: cryptoGate?.pay_currency === "USD" ? cryptoGate.max_paise / 100 : 5e3,
		cur: "USD"
	} : method === "jazzcash" ? {
		min: jazzGate?.pay_currency === "PKR" ? jazzGate.min_paise / 100 : 100,
		max: jazzGate?.pay_currency === "PKR" ? jazzGate.max_paise / 100 : 5e5,
		cur: "PKR"
	} : {
		min: razorGate?.pay_currency === "INR" || !razorGate ? razorGate && razorGate.min_paise !== 2e4 ? razorGate.min_paise / 100 : 100 : razorGate.min_paise / 100,
		max: razorGate ? razorGate.max_paise / 100 : 1e5,
		cur: razorGate?.pay_currency || "INR"
	};
	const minShown = convertMajor(limits.min, limits.cur, code);
	const maxShown = convertMajor(limits.max, limits.cur, code);
	const payCoins = (cryptoGate?.network || "").split("\n").map((line) => {
		const [network, address] = line.split("|").map((part) => part.trim());
		return address ? {
			network,
			address
		} : null;
	}).filter((row) => Boolean(row));
	if (payCoins.length === 0 && cryptoGate?.account_number) payCoins.push({
		network: "TRC20",
		address: cryptoGate.account_number
	});
	const picked = payCoins[Math.min(payNet, Math.max(payCoins.length - 1, 0))];
	const rateInr = Number(cryptoGate?.ifsc) || desk.usdtRate || 90;
	const usdtEach = fromMinor(Math.round(rateInr * 100));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl space-y-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[28px] border bg-[#12182b]/80 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-16 shrink-0 place-items-center rounded-2xl bg-violet-500/15 text-violet-200",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-7" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[12px] font-semibold tracking-[0.16em] text-violet-200",
						children: "WALLET BALANCE"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[34px] font-bold leading-tight",
						children: inr(balance)
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 flex items-center gap-2 text-[13px] text-cyan-300",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-cyan-400" }), " Updates in real-time"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[28px] border bg-[#12182b]/80 p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-[22px] font-bold",
							children: "Add Balance"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[13px] text-[#a5b4fc]",
							children: "Select payment method and specify deposit amount."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full border border-emerald-400/30 bg-emerald-400/10 px-3 py-1 text-[11px] font-bold text-emerald-300",
							children: "0% Processing Fees"
						})]
					}),
					banner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 rounded-2xl border border-cyan-400/30 bg-cyan-400/10 px-3 py-2 text-[13px] text-cyan-100",
						children: banner
					}),
					payOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setPayOpen(false),
								className: "text-[13px] font-semibold text-cyan-300",
								children: "Back"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 text-[18px] font-bold",
								children: [
									method === "jazzcash" ? "JazzCash" : method === "crypto" ? "Crypto" : "UPI",
									" · ",
									formatMajor(amount)
								]
							}),
							!payGate && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-[13px] text-amber-300",
								children: "Admin ne is method ki payment details save nahi ki. Payments mein gateway on karo."
							}),
							payGate && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 space-y-3 rounded-2xl border bg-black/20 p-3 text-[13px]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[12px] font-semibold tracking-wide text-[#a5b4fc]",
										children: "PAYMENT INFORMATION"
									}),
									payGate.account_title && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[16px] font-semibold",
										children: payGate.account_title
									}),
									method === "crypto" ? payCoins.length === 0 || !picked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-amber-200",
										children: "Admin ne koi crypto address save nahi kiya."
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
												className: "block text-[12px] font-semibold",
												children: ["Network", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
													value: Math.min(payNet, payCoins.length - 1),
													onChange: (event) => setPayNet(Number(event.target.value)),
													className: "mt-1 h-11 w-full rounded-xl border bg-[#0f172a] px-3 text-[14px] text-white",
													children: payCoins.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: index,
														children: row.network
													}, `${row.network}-${index}`))
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "min-w-0 flex-1 break-all",
													children: picked.address
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => copyText(picked.address),
													className: "h-8 shrink-0 rounded-full border border-violet-400/40 px-3 text-[12px] font-semibold text-violet-200",
													children: copied === picked.address ? "Copied" : "Copy"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[12px] text-[#c4b5fd]",
												children: [
													"Sirf ",
													picked.network,
													" network pe payment bhejo."
												]
											})
										]
									}) : payGate.account_number && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "break-all",
											children: [
												method === "jazzcash" ? "JazzCash" : "UPI",
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: payGate.account_number })
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => copyText(payGate.account_number),
											className: "h-8 shrink-0 rounded-full border border-violet-400/40 px-3 text-[12px] font-semibold text-violet-200",
											children: copied === payGate.account_number ? "Copied" : "Copy"
										})]
									}),
									method === "jazzcash" && payGate.ifsc && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
										"IBAN ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: payGate.ifsc }),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => copyText(payGate.ifsc),
											className: "ml-2 font-semibold text-cyan-300",
											children: copied === payGate.ifsc ? "Copied" : "Copy"
										})
									] }),
									payGate.instructions && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[#c4b5fd]",
										children: payGate.instructions
									}),
									method === "crypto" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-semibold text-cyan-200",
										children: [
											"About $",
											usdtEach > 0 ? (amount / usdtEach).toFixed(2) : "0",
											" USDT. Rate: 1 USDT = ",
											rateInr,
											" INR = ",
											formatMajor(usdtEach),
											" (",
											code,
											"). Sirf likhe hue network pe bhejo."
										]
									}),
									payGate.qr_image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: payGate.qr_image,
										alt: "Payment QR",
										className: "mx-auto h-[280px] w-full max-w-[320px] rounded-2xl bg-white object-contain p-3"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[12px] text-amber-200",
										children: "QR nahi laga. Upar wala account use karo."
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-3 block text-[12px] font-semibold",
								children: ["Transaction ID", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: reference,
									onChange: (event) => setReference(event.target.value),
									placeholder: "UTR / JazzCash TID / TXID",
									className: "mt-1 h-11 w-full rounded-xl border bg-black/20 px-3 text-[14px] outline-none"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-3 flex h-11 cursor-pointer items-center justify-center rounded-xl border text-[13px] font-semibold",
								children: [shot ? "Screenshot ready" : "Upload payment screenshot", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									accept: "image/*",
									className: "hidden",
									onChange: (event) => {
										const file = event.target.files?.[0];
										if (!file || file.size > 8e6) return;
										const image = new Image();
										image.onload = () => {
											const canvas = document.createElement("canvas");
											const scale = Math.min(1, 900 / image.width);
											canvas.width = Math.max(1, image.width * scale);
											canvas.height = Math.max(1, image.height * scale);
											canvas.getContext("2d")?.drawImage(image, 0, 0, canvas.width, canvas.height);
											setShot(canvas.toDataURL("image/jpeg", .72));
										};
										image.src = URL.createObjectURL(file);
									}
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: pending || !payGate,
								onClick: async () => {
									if (!payGate) return;
									setPending(true);
									setBanner("");
									try {
										const result = await submitPaymentClaim({ data: {
											amountPaise: toBaseMinor(amount),
											displayMajor: amount,
											screenshot: shot,
											reference,
											gatewayId: payGate.id
										} });
										setBanner(`${result.id} pending. Admin approve karega to amount wallet mein add ho jayegi.`);
										setShot("");
										setReference("");
										setPayOpen(false);
										load();
									} catch (err) {
										setBanner(err instanceof Error ? err.message : "Could not submit the payment.");
									} finally {
										setPending(false);
									}
								},
								className: "mt-3 h-12 w-full rounded-2xl bg-gradient-to-r from-violet-600 to-cyan-500 text-[15px] font-semibold text-white disabled:opacity-60",
								children: pending ? "Sending…" : "Submit for approval"
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-[14px] font-semibold",
							children: "1. Select Payment Method"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 grid gap-3 sm:grid-cols-3",
							children: [
								[
									"razorpay",
									"UPI",
									"INDIA",
									""
								],
								[
									"crypto",
									"Crypto",
									"GLOBAL",
									`1 USDT = ${formatMajor(usdtEach)}`
								],
								[
									"jazzcash",
									"JazzCash",
									"PAKISTAN",
									"Account · IBAN · QR"
								]
							].map(([id, title, badge, sub]) => {
								const row = id === "crypto" ? {
									min: cryptoGate?.pay_currency === "USD" ? cryptoGate.min_paise / 100 : 5,
									cur: "USD"
								} : id === "jazzcash" ? {
									min: jazzGate?.pay_currency === "PKR" ? jazzGate.min_paise / 100 : 100,
									cur: "PKR"
								} : {
									min: razorGate && razorGate.min_paise !== 2e4 ? razorGate.min_paise / 100 : 100,
									cur: "INR"
								};
								const shown = convertMajor(row.min, row.cur, code);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										setMethod(id);
										setPayOpen(false);
									},
									className: `rounded-2xl border p-3 text-left ${method === id ? "border-cyan-300 bg-gradient-to-br from-violet-600/50 to-cyan-500/30" : "bg-black/20"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: title }),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full bg-white/10 px-1.5 text-[10px] font-bold text-cyan-200",
											children: badge
										}),
										sub ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-1 block text-[12px] text-[#c4b5fd]",
											children: sub
										}) : null,
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "mt-1 block text-[12px] font-semibold text-cyan-200",
											children: [
												"Min ",
												row.min,
												" ",
												row.cur,
												shown != null ? ` · ${formatMajor(shown)}` : ""
											]
										})
									]
								}, id);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[14px] font-semibold",
								children: "2. Choose Deposit Amount"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-[12px] font-semibold text-cyan-300",
								children: [
									"Min ",
									limits.min,
									" ",
									limits.cur,
									minShown != null ? ` · ${formatMajor(minShown)}` : "",
									" · Max ",
									maxShown != null ? formatMajor(maxShown) : limits.max
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 grid grid-cols-3 gap-2 sm:grid-cols-6",
							children: (method === "crypto" ? [
								5,
								10,
								25,
								50,
								100,
								250
							] : [
								100,
								250,
								500,
								1e3,
								2500,
								5e3
							]).map((chip) => {
								const value = convertMajor(chip, limits.cur, code) ?? chip;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setAmount(value),
									className: `h-10 rounded-xl border text-[12px] font-semibold ${amount === value ? "border-cyan-300 bg-violet-600/40" : "bg-black/20"}`,
									children: method === "crypto" ? `$${chip}` : formatMajor(value)
								}, chip);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-[13px] font-semibold",
							children: ["Amount in ", code]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex items-center gap-2 rounded-xl border bg-black/20 px-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[18px] text-[#c4b5fd]",
								children: moneyState().display.symbol
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: amount || "",
								inputMode: "decimal",
								onChange: (event) => setAmount(Number(event.target.value.replace(/[^\d.]/g, "")) || 0),
								className: "h-12 w-full bg-transparent text-[22px] font-bold outline-none"
							})]
						}),
						method === "crypto" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-[13px] font-semibold text-cyan-200",
							children: [
								"= ",
								usdtEach > 0 ? (amount / usdtEach).toFixed(2) : "0",
								" USDT · 1 USDT = ",
								formatMajor(usdtEach)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								setBanner("");
								if (amount <= 0) {
									setBanner("Amount likho.");
									return;
								}
								const native = convertMajor(amount, code, limits.cur);
								if (native != null && (native < limits.min - .02 || native > limits.max + .02)) {
									setBanner(`Amount ${limits.min} se ${limits.max} ${limits.cur} ke beech honi chahiye.`);
									return;
								}
								setPayOpen(true);
							},
							className: "mt-4 h-12 w-full rounded-2xl bg-gradient-to-r from-violet-600 to-cyan-500 text-[16px] font-semibold text-white",
							children: ["Pay ", formatMajor(amount)]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-center text-[12px] text-[#94a3b8]",
							children: "Pay ke baad payment details, transaction ID aur screenshot isi next page pe aayenge."
						})
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[28px] border bg-[#12182b]/80 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-[22px] font-bold",
						children: "Wallet Analytics"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[13px] text-[#94a3b8]",
						children: "Deposits & spending for the selected period"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative mt-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setPeriodOpen((open) => !open),
							className: "inline-flex h-10 items-center gap-2 rounded-full border px-4 text-[13px] font-semibold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-4 text-violet-300" }),
								" ",
								periodLabel
							]
						}), periodOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute z-20 mt-2 w-48 overflow-hidden rounded-2xl border bg-[#0f172a] py-1 shadow-2xl",
							children: PERIODS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setPeriod(item.id);
									setPeriodOpen(false);
								},
								className: `block w-full px-4 py-2 text-left text-[14px] ${period === item.id ? "font-semibold text-cyan-300" : "text-white"}`,
								children: item.label
							}, item.id))
						})]
					}),
					period === "custom" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							value: from,
							onChange: (event) => setFrom(event.target.value),
							className: "h-10 rounded-xl border bg-black/20 px-3 text-[13px]"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							value: to,
							onChange: (event) => setTo(event.target.value),
							className: "h-10 rounded-xl border bg-black/20 px-3 text-[13px]"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid grid-cols-2 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "TOTAL DEPOSIT",
								value: inr(deposits),
								foot: periodLabel,
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4" }),
								tone: "text-emerald-300"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "TOTAL SPENT",
								value: inr(spent),
								foot: periodLabel,
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownRight, { className: "size-4" }),
								tone: "text-rose-300"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "CURRENT BALANCE",
								value: inr(balance),
								foot: "Live · not filtered",
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-4" }),
								tone: "text-violet-200"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "TRANSACTIONS",
								value: String(ranged.length),
								foot: periodLabel,
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[14px]",
									children: "∿"
								}),
								tone: "text-cyan-200"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[28px] border bg-[#12182b]/80 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-[22px] font-bold",
							children: "Transactions"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[12px] text-[#94a3b8]",
							children: "Filtered by selected period"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [
							"All",
							"Deposit",
							"Order",
							"Refund"
						].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setFilter(item),
							className: `h-9 rounded-full px-4 text-[13px] font-semibold ${filter === item ? "bg-[#111827] text-white" : "bg-white/10 text-[#e2e8f0]"}`,
							children: item
						}, item))
					}),
					claims.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-2 text-[13px]",
						children: claims.map((claim) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex justify-between gap-2 rounded-2xl border px-3 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate",
								children: claim.id
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "shrink-0",
								children: [
									inr(claim.amount_paise),
									" · ",
									claim.status === "declined" ? "rejected" : claim.status
								]
							})]
						}, claim.id))
					}),
					shown.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-4 py-14 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mx-auto grid size-16 place-items-center rounded-full bg-violet-500/15 text-violet-200",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-7" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-[18px] font-semibold",
								children: "No wallet activity found"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-[13px] text-[#94a3b8]",
								children: "Nothing here for the selected date range."
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-2 text-[13px]",
						children: shown.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3 rounded-2xl border px-3 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.note }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `shrink-0 font-semibold ${row.amount_paise < 0 ? "text-rose-300" : "text-emerald-300"}`,
								children: inr(row.amount_paise)
							})]
						}, row.id))
					})
				]
			})
		]
	});
}
function Stat({ label, value, foot, icon, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border bg-black/20 p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-semibold tracking-wide text-[#94a3b8]",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `grid size-7 place-items-center rounded-full bg-white/10 ${tone}`,
					children: icon
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-[20px] font-bold",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-[12px] text-[#64748b]",
				children: foot
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Authed, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WalletPage, {}) });
//#endregion
export { SplitComponent as component };
