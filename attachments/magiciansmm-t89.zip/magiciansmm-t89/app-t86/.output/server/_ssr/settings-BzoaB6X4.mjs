import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as signOut } from "./client-DKNO_Bt1.mjs";
import { G as EyeOff, R as KeyRound, S as Save, V as Heart, W as Eye, X as Camera, _ as Settings, a as Users, d as Sparkles, g as Share2, j as LogOut, k as MessageCircle, nt as Bookmark, o as User, p as Shield, w as Repeat2 } from "../_libs/lucide-react.mjs";
import { A as applyFx, At as useCurrentUserState, Ct as savedTheme, F as changeDeskPassword, J as getDeskRole, O as applyBase, P as changeAdminLogin, St as savedMotion, U as findCurrency, Y as getMoneyConfig, Z as getPrefs, _t as saveDeskLook, bt as savePrefs, c as THEMES, gt as saveBaseCurrency, ht as refreshFx, k as applyDisplay, lt as moneyState, n as MOTIONS, t as CURRENCIES, vt as saveDisplayCurrency, xt as saveTheme, yt as saveMotion } from "./shell-CfBlaVSk.mjs";
import { t as Authed } from "./gate-DNi4gEUE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-BzoaB6X4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DEFAULTS = {
	views: 100,
	likes: 5,
	comments: 2,
	saves: 1,
	shares: 1,
	reposts: .5,
	followers: 2,
	subscribers: 3,
	watch_hours: 5,
	retweets: 4
};
function Settings$1() {
	const { user } = useCurrentUserState();
	const [name, setName] = (0, import_react.useState)("");
	const [photo, setPhoto] = (0, import_react.useState)("");
	const [organic, setOrganic] = (0, import_react.useState)(false);
	const [ratios, setRatios] = (0, import_react.useState)(DEFAULTS);
	const [password, setPassword] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)("");
	const [adminEmail, setAdminEmail] = (0, import_react.useState)("");
	const [adminPassword, setAdminPassword] = (0, import_react.useState)("");
	const [adminConfirm, setAdminConfirm] = (0, import_react.useState)("");
	const [showPassword, setShowPassword] = (0, import_react.useState)(false);
	const [key, setKey] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)("");
	const [theme, setTheme] = (0, import_react.useState)(THEMES[0]);
	const [motion, setMotion] = (0, import_react.useState)("rise");
	const [admin, setAdmin] = (0, import_react.useState)(false);
	const [currency, setCurrency] = (0, import_react.useState)(CURRENCIES[0]);
	const [baseCode, setBaseCode] = (0, import_react.useState)("INR");
	const [fxNote, setFxNote] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		setTheme(savedTheme());
		setMotion(savedMotion());
	}, []);
	(0, import_react.useEffect)(() => {
		getPrefs().then((prefs) => {
			setName(prefs.full_name || user?.displayName || "");
			setPhoto(prefs.avatar_url || "");
			setOrganic(Boolean(prefs.organic_enabled));
			setKey(prefs.api_key || "");
			try {
				setRatios({
					...DEFAULTS,
					...JSON.parse(prefs.ratios_json || "{}")
				});
			} catch {
				setRatios(DEFAULTS);
			}
		}).catch(() => setNote("Settings could not load."));
		getDeskRole().then((role) => setAdmin(role === "admin")).catch(() => setAdmin(false));
		getMoneyConfig().then((config) => {
			applyBase(findCurrency(config.base));
			applyFx(config);
			setBaseCode(config.base);
			const shown = findCurrency(config.display || config.base);
			setCurrency(shown);
			applyDisplay(shown);
			const when = config.updatedAt ? new Date(config.updatedAt).toLocaleString() : "not loaded";
			setFxNote(config.stale ? `Last saved rates ${when}. Live feed did not answer.` : `Rates updated ${when}.`);
		}).catch(() => void 0);
	}, [user?.displayName]);
	function setRatio(id, value) {
		setRatios((current) => ({
			...current,
			[id]: value
		}));
	}
	async function onPhoto(event) {
		const file = event.target.files?.[0];
		event.target.value = "";
		if (!file) return;
		if (!file.type.startsWith("image/")) {
			setNote("Sirf photo choose karo.");
			return;
		}
		try {
			const data = await compressPhoto(file);
			setPhoto(data);
			setNote("Photo ready. Save Changes dabao, tab yeh permanent lagegi.");
		} catch (err) {
			setNote(err instanceof Error ? err.message : "Photo nahi khuli.");
		}
	}
	async function saveName() {
		setBusy("profile");
		try {
			await savePrefs({ data: {
				full_name: name,
				...photo.startsWith("data:image/") ? { avatar_url: photo } : {}
			} });
			setNote("Profile save ho gaya. Name aur photo ab permanent hain.");
		} catch (err) {
			setNote(err instanceof Error ? err.message : "Could not save profile.");
		} finally {
			setBusy("");
		}
	}
	async function saveCurrency(next) {
		setCurrency(next);
		applyDisplay(next);
		setBusy("currency");
		try {
			await saveDisplayCurrency({ data: next.code });
			setNote(`${next.code} ab aapke panel pe dikhega. Wallet ka stored balance nahi badla.`);
		} catch (err) {
			setNote(err instanceof Error ? err.message : "Currency save nahi hui.");
		} finally {
			setBusy("");
		}
	}
	async function saveBase(code) {
		setBusy("base");
		try {
			const saved = await saveBaseCurrency({ data: code });
			applyBase(findCurrency(saved.base));
			applyFx(saved);
			setBaseCode(saved.base);
			setFxNote(`Base ${saved.base}. Rates refreshed. Purane wallet numbers rewrite nahi hue.`);
		} catch (err) {
			setNote(err instanceof Error ? err.message : "Base currency save nahi hui.");
		} finally {
			setBusy("");
		}
	}
	async function reloadRates() {
		setBusy("fx");
		try {
			const saved = await refreshFx();
			applyFx(saved);
			const when = saved.updatedAt ? new Date(saved.updatedAt).toLocaleString() : "now";
			setFxNote(saved.stale ? `Feed fail. Last rates ${when}.` : `Rates refreshed ${when}.`);
		} catch (err) {
			setNote(err instanceof Error ? err.message : "Rates refresh nahi hui.");
		} finally {
			setBusy("");
		}
	}
	async function toggleOrganic() {
		const next = !organic;
		setOrganic(next);
		await savePrefs({ data: { organic_enabled: next } });
		setNote(next ? "AI Organic Automation enabled." : "AI Organic Automation disabled.");
	}
	async function saveRatios() {
		setBusy("ratios");
		try {
			await savePrefs({ data: {
				organic_enabled: organic,
				ratios_json: JSON.stringify(ratios)
			} });
			setNote("AI configuration saved on this desk. No outside model is connected.");
		} catch (err) {
			setNote(err instanceof Error ? err.message : "Could not save configuration.");
		} finally {
			setBusy("");
		}
	}
	(0, import_react.useEffect)(() => {
		if (user?.primaryEmail) setAdminEmail(user.primaryEmail);
	}, [user?.primaryEmail]);
	async function saveAdminLogin() {
		const email = adminEmail.trim().toLowerCase();
		const nextPassword = adminPassword.trim();
		if (nextPassword && nextPassword.length < 8) {
			setNote("Password kam se kam 8 characters ka ho.");
			return;
		}
		if (nextPassword !== adminConfirm.trim()) {
			setNote("Password aur confirm password same hone chahiye.");
			return;
		}
		if (!email) {
			setNote("Admin email likho.");
			return;
		}
		setBusy("admin-login");
		try {
			const saved = await changeAdminLogin({ data: {
				email,
				password: nextPassword
			} });
			setAdminEmail(saved.email);
			setAdminPassword("");
			setAdminConfirm("");
			setNote("Admin login update ho gaya. Agli dafa isi email aur password se login karo.");
		} catch (err) {
			setNote(err instanceof Error ? err.message : "Admin login update nahi hua.");
		} finally {
			setBusy("");
		}
	}
	async function changePassword() {
		if (password.length < 8) {
			setNote("Use at least 8 characters.");
			return;
		}
		if (password !== confirm) {
			setNote("New password and confirm password do not match.");
			return;
		}
		setBusy("password");
		try {
			await changeDeskPassword({ data: password });
			setPassword("");
			setConfirm("");
			setNote("Password updated. Use it the next time you sign in.");
		} catch (err) {
			setNote(err instanceof Error ? err.message : "Could not change password.");
		} finally {
			setBusy("");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl space-y-4 pb-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex items-center gap-3 rounded-3xl border border-[#e7eef6] bg-white px-5 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-11 place-items-center rounded-2xl bg-[#2563eb] text-white",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-[22px] font-bold text-[#0f172a]",
					children: "Settings"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[13px] text-[#64748b]",
					children: "Manage your account and preferences"
				})] })]
			}),
			admin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border border-[#e7eef6] bg-white p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-center gap-2 font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-4 text-violet-500" }), " Admin login"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[12px] text-[#94a3b8]",
						children: "Yahan se admin email aur password change karo. Agli login isi se hogi."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-3 block text-[13px] font-medium",
						children: ["Admin email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "email",
							value: adminEmail,
							onChange: (event) => setAdminEmail(event.target.value),
							placeholder: "admin@email.com",
							className: "mt-1 h-11 w-full rounded-xl bg-[#e7f0f8] px-3 outline-none"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-3 block text-[13px] font-medium",
						children: ["Naya password", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: showPassword ? "text" : "password",
							value: adminPassword,
							onChange: (event) => setAdminPassword(event.target.value),
							placeholder: "Khali chhoro agar sirf email change karni ho",
							className: "mt-1 h-11 w-full rounded-xl bg-[#e7f0f8] px-3 outline-none"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-3 block text-[13px] font-medium",
						children: ["Confirm password", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: showPassword ? "text" : "password",
							value: adminConfirm,
							onChange: (event) => setAdminConfirm(event.target.value),
							placeholder: "Password dobara likho",
							className: "mt-1 h-11 w-full rounded-xl bg-[#e7f0f8] px-3 outline-none"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: busy === "admin-login",
						onClick: saveAdminLogin,
						className: "mt-4 inline-flex h-10 items-center gap-2 rounded-xl bg-[#2563eb] px-4 text-[13px] font-semibold text-white disabled:opacity-60",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-3.5" }),
							" ",
							busy === "admin-login" ? "Saving…" : "Save admin login"
						]
					})
				]
			}),
			admin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: "Theme"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[12px] text-[#94a3b8]",
						children: "Preset ya custom colour. Save ke baad poora panel change hota hai, refresh ke baad bhi."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4",
						children: THEMES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								setTheme(item);
								saveTheme(item);
							},
							className: `rounded-2xl border p-3 text-left text-[12px] font-semibold ${theme.id === item.id ? "ring-2 ring-violet-400" : ""}`,
							style: {
								background: item.card,
								color: item.text
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-2 block h-2 rounded-full",
								style: { background: `linear-gradient(90deg, ${item.primary}, ${item.accent})` }
							}), item.name]
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3",
						children: [
							["primary", "Primary"],
							["accent", "Accent"],
							["bg", "Background"],
							["card", "Card"],
							["sidebar", "Sidebar"],
							["text", "Text"]
						].map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-[12px] font-semibold",
							children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "color",
								value: theme[key].startsWith("#") ? theme[key] : "#7c3aed",
								onChange: (event) => setTheme((current) => ({
									...current,
									id: "custom",
									name: "Custom",
									[key]: event.target.value
								})),
								className: "mt-1 h-10 w-full rounded-lg bg-transparent"
							})]
						}, key))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							const next = {
								...theme,
								id: theme.id || "custom",
								name: theme.name || "Custom"
							};
							saveTheme(next);
							saveDeskLook({ data: {
								theme: JSON.stringify(next),
								motion
							} }).catch(() => setNote("Theme is saved on this browser. Server save failed."));
						},
						className: "mt-4 h-10 rounded-xl bg-[#2563eb] px-4 text-[13px] font-semibold text-white",
						children: "Save theme"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: "Your currency"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[12px] text-[#94a3b8]",
						children: "Prices poore panel pe is currency mein dikhengi. Wallet aur orders database mein base currency mein hi rehte hain."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3",
						children: CURRENCIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: busy === "currency",
							onClick: () => saveCurrency(item),
							className: `h-14 rounded-xl border px-3 text-left text-[12px] font-semibold ${currency.code === item.code ? "ring-2 ring-violet-400" : ""}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block",
								children: [
									item.flag,
									" ",
									item.code
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-[10px] font-medium opacity-70",
								children: item.name
							})]
						}, item.code))
					}),
					fxNote && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-[12px] text-[#a5b4fc]",
						children: [
							fxNote,
							" ",
							moneyState().fxStale ? "Using last good rates." : ""
						]
					})
				]
			}),
			admin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: "Base currency"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[12px] text-[#94a3b8]",
						children: "Yahi currency stored prices ki hai. Change karne se purane wallet, orders ya payments rewrite nahi hote. Sirf tab badlo jab prices isi currency mein dale gaye hon."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: CURRENCIES.slice(0, 12).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: busy === "base",
							onClick: () => saveBase(item.code),
							className: `h-10 rounded-xl border px-3 text-[12px] font-bold ${baseCode === item.code ? "ring-2 ring-violet-400" : ""}`,
							children: [
								item.flag,
								" ",
								item.code
							]
						}, item.code))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: busy === "fx",
						onClick: reloadRates,
						className: "mt-3 h-10 rounded-xl bg-[#2563eb] px-4 text-[13px] font-semibold text-white disabled:opacity-50",
						children: "Refresh exchange rates"
					})
				]
			}),
			admin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: "Page animation"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[12px] text-[#94a3b8]",
						children: "Jo select karoge, dashboard, engagement, settings, login — har page switch pe wahi animation chalega."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3",
						children: MOTIONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								setMotion(item.id);
								saveMotion(item.id);
								saveDeskLook({ data: {
									theme: JSON.stringify(theme),
									motion: item.id
								} }).catch(() => setNote("Animation is saved on this browser. Server save failed."));
							},
							className: `page-motion rounded-2xl border px-3 py-3 text-left text-[13px] font-semibold ${motion === item.id ? "ring-2 ring-violet-400" : ""}`,
							children: item.name
						}, item.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border border-[#e7eef6] bg-white p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-center gap-2 font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-4 text-[#64748b]" }), " Profile Information"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[12px] text-[#94a3b8]",
						children: "Update your personal details"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "relative grid size-14 place-items-center overflow-hidden rounded-2xl bg-[#e8f1ff] text-[#64748b]",
							children: [photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: photo,
								alt: "",
								className: "size-full object-cover"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-6" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "absolute -bottom-1 -right-1 grid size-6 cursor-pointer place-items-center rounded-full bg-[#2563eb] text-white",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									accept: "image/*",
									className: "hidden",
									onChange: onPhoto
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: name || "Member"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[12px] text-[#64748b]",
								children: user?.primaryEmail
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "cursor-pointer text-[12px] font-semibold text-[#2563eb]",
								children: ["Upload photo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									accept: "image/*",
									className: "hidden",
									onChange: onPhoto
								})]
							})
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-[13px] font-medium text-[#334155]",
							children: ["Full Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: name,
								onChange: (event) => setName(event.target.value),
								className: "mt-1 h-11 w-full rounded-xl bg-[#e7f0f8] px-3 outline-none"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-[13px] font-medium text-[#334155]",
							children: [
								"Email Address",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: user?.primaryEmail || "",
									disabled: true,
									className: "mt-1 h-11 w-full rounded-xl bg-[#e7f0f8] px-3 text-[#64748b] outline-none"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-[11px] font-normal text-[#94a3b8]",
									children: "Email cannot be changed"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: busy === "profile",
						onClick: saveName,
						className: "mt-4 inline-flex h-10 items-center gap-2 rounded-xl bg-[#2563eb] px-4 text-[13px] font-semibold text-white disabled:opacity-60",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), " Save Changes"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border border-[#e7eef6] bg-white p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center gap-2 font-semibold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4 text-[#2563eb]" }),
								" AI Organic Automation",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-[#efe7ff] px-2 py-0.5 text-[10px] font-bold text-[#7c3aed]",
									children: "PREMIUM"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[12px] text-[#94a3b8]",
							children: "Configure your default organic settings"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: toggleOrganic,
							className: "inline-flex items-center gap-2 text-[11px] font-bold tracking-wide text-[#64748b]",
							children: [organic ? "ENABLED" : "DISABLED", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `relative h-7 w-12 rounded-full ${organic ? "bg-[#2563eb]" : "bg-[#dbe4ee]"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-0.5 size-6 rounded-full bg-white shadow ${organic ? "left-5" : "left-0.5"}` })
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 rounded-2xl border border-[#dbeafe] bg-[#f8fbff] p-3 text-[13px] text-[#334155]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "mr-1 inline size-3.5 text-[#2563eb]" }), " What is Organic Mode?"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-[12px] leading-relaxed text-[#64748b]",
							children: "When enabled, all your new orders will automatically use AI-generated delivery patterns. This creates unique growth curves for every order to look 100% natural to social algorithms."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-center gap-2 text-[13px] font-semibold",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[#64748b]",
								children: "%"
							}),
							" AI Organic Ratios — Universal",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-[#e0e7ff] px-2 py-0.5 text-[10px] font-bold text-[#3730a3]",
								children: "ALL PLATFORMS"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ratio, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5" }),
								label: "VIEWS RATIO",
								value: ratios.views,
								tone: "text-[#2563eb]",
								onChange: (value) => setRatio("views", value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ratio, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "size-3.5 text-rose-500" }),
								label: "LIKES RATIO",
								value: ratios.likes,
								tone: "text-rose-500",
								onChange: (value) => setRatio("likes", value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ratio, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-3.5 text-[#94a3b8]" }),
								label: "COMMENTS RATIO",
								value: ratios.comments,
								tone: "text-[#64748b]",
								onChange: (value) => setRatio("comments", value)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mb-2 mt-4 flex items-center gap-2 text-[13px] font-semibold",
						children: ["Instagram & TikTok ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-600",
							children: "IG + TT"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ratio, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-3.5 text-sky-500" }),
								label: "SAVES",
								value: ratios.saves,
								tone: "text-emerald-500",
								onChange: (value) => setRatio("saves", value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ratio, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-3.5 text-sky-500" }),
								label: "SHARES",
								value: ratios.shares,
								tone: "text-[#2563eb]",
								onChange: (value) => setRatio("shares", value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ratio, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat2, { className: "size-3.5 text-sky-500" }),
								label: "REPOSTS",
								value: ratios.reposts,
								tone: "text-[#2563eb]",
								onChange: (value) => setRatio("reposts", value)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 max-w-sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ratio, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-3.5 text-violet-500" }),
							label: "FOLLOWERS",
							value: ratios.followers,
							tone: "text-violet-500",
							onChange: (value) => setRatio("followers", value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mb-2 mt-4 text-[13px] font-semibold",
						children: ["YouTube ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-rose-50 px-2 py-0.5 text-[10px] font-bold text-rose-500",
							children: "YT"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ratio, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[12px]",
								children: "▶"
							}),
							label: "SUBSCRIBERS",
							value: ratios.subscribers,
							tone: "text-rose-500",
							onChange: (value) => setRatio("subscribers", value)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ratio, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[12px]",
								children: "◷"
							}),
							label: "WATCH HOURS",
							value: ratios.watch_hours,
							tone: "text-rose-500",
							onChange: (value) => setRatio("watch_hours", value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mb-2 mt-4 text-[13px] font-semibold",
						children: ["Twitter / X ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-sky-50 px-2 py-0.5 text-[10px] font-bold text-sky-600",
							children: "X"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "max-w-sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ratio, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat2, { className: "size-3.5 text-sky-500" }),
							label: "RETWEETS",
							value: ratios.retweets,
							tone: "text-[#2563eb]",
							onChange: (value) => setRatio("retweets", value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 rounded-2xl bg-[#f8fbff] p-3 text-[12px] leading-relaxed text-[#64748b]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "mr-1 inline size-3.5" }), " Ratios are calculated relative to your \"Base Quantity\". For example, if Views are 100% and Likes are 5%, an order of 10,000 Views will auto-generate 500 Likes. These apply to ALL your orders across all platforms."]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: busy === "ratios",
						onClick: saveRatios,
						className: "mt-4 inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-[#2563eb] text-[14px] font-semibold text-white disabled:opacity-60",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }),
							" ",
							busy === "ratios" ? "Saving…" : "Save AI Configuration"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border border-[#e7eef6] bg-white p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-center gap-2 font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-4 text-amber-500" }), " Change Password"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[12px] text-[#94a3b8]",
						children: "Update your account password"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-3 block text-[13px] font-medium",
						children: ["New Password", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "relative mt-1 block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: showPassword ? "text" : "password",
								value: password,
								onChange: (event) => setPassword(event.target.value),
								placeholder: "Enter new password",
								className: "h-11 w-full rounded-xl bg-[#e7f0f8] px-3 pr-10 outline-none"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setShowPassword((value) => !value),
								className: "absolute right-3 top-3 text-[#94a3b8]",
								"aria-label": "Show password",
								children: showPassword ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-3 block text-[13px] font-medium",
						children: ["Confirm New Password", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: showPassword ? "text" : "password",
							value: confirm,
							onChange: (event) => setConfirm(event.target.value),
							placeholder: "Confirm new password",
							className: "mt-1 h-11 w-full rounded-xl bg-[#e7f0f8] px-3 outline-none"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: busy === "password",
						onClick: changePassword,
						className: "mt-4 inline-flex h-10 items-center gap-2 rounded-xl border border-[#e7eef6] px-4 text-[13px] font-semibold disabled:opacity-60",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-3.5" }),
							" ",
							busy === "password" ? "Updating…" : "Change Password"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border border-[#e7eef6] bg-white p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-center gap-2 font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-4 text-emerald-500" }), " API Key"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[12px] text-[#94a3b8]",
						children: "Manage your API access key for integrations"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-[13px] font-medium",
						children: "Your API Key"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						readOnly: true,
						value: key || "••••••••••••••••••••",
						className: "mt-1 h-11 w-full rounded-xl bg-[#f8fafc] px-3 font-mono text-[13px] outline-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-[11px] text-[#94a3b8]",
						children: "Keep your API key secret. Do not share it publicly."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: async () => {
							const next = await savePrefs({ data: { rotateKey: true } });
							setKey(next?.api_key || "");
							setNote("New API key generated. It does not call a provider yet.");
						},
						className: "mt-3 inline-flex h-10 items-center gap-2 rounded-xl border border-[#e7eef6] px-4 text-[13px] font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-3.5" }), " Generate API Key"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex items-center justify-between rounded-3xl border border-[#e7eef6] bg-white p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: "Sign Out"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[12px] text-[#94a3b8]",
					children: "Sign out from your account on this device"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => signOut("/login"),
					className: "inline-flex items-center gap-2 rounded-xl bg-[#ef4444] px-4 py-2 text-[13px] font-semibold text-white",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), " Sign Out"]
				})]
			}),
			note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-[13px] text-[#334155]",
				children: note
			})
		]
	});
}
function Ratio({ icon, label, value, tone, onChange }) {
	const [text, setText] = (0, import_react.useState)(() => String(value));
	const editing = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (!editing.current) setText(value === 0 ? "" : String(value));
	}, [value]);
	function apply(raw) {
		const cleaned = raw.replace(/[^\d.]/g, "");
		const parts = cleaned.split(".");
		const next = parts.length > 2 ? `${parts[0]}.${parts.slice(1).join("")}` : cleaned;
		setText(next);
		if (next === "" || next === ".") {
			onChange(0);
			return;
		}
		const num = Number(next);
		if (Number.isFinite(num)) onChange(Math.min(100, Math.max(0, num)));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "block rounded-2xl border border-[#eef2f6] bg-white p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex items-center justify-between gap-2 text-[11px] font-semibold tracking-wide text-[#64748b]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1",
					children: [
						icon,
						" ",
						label
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						inputMode: "decimal",
						value: text,
						placeholder: "0",
						onFocus: () => {
							editing.current = true;
						},
						onBlur: () => {
							editing.current = false;
							if (text.trim() === "" || text === ".") {
								onChange(0);
								setText("");
								return;
							}
							const num = Math.min(100, Math.max(0, Number(text)));
							if (!Number.isFinite(num)) {
								setText(String(value));
								return;
							}
							onChange(num);
							setText(String(num));
						},
						onChange: (event) => apply(event.target.value),
						className: `h-8 w-16 rounded-lg border border-[#e7eef6] bg-[#f8fafc] text-center text-[13px] font-bold outline-none focus:border-[#93c5fd] ${tone}`
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: tone,
						children: "%"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "range",
				min: 0,
				max: 100,
				step: .5,
				value,
				onChange: (event) => onChange(Number(event.target.value)),
				className: "mt-3 w-full accent-[#111827]"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "mt-1 flex justify-between text-[10px] text-[#94a3b8]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "0%" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "50%" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "100%" })
				]
			})
		]
	});
}
function compressPhoto(file) {
	return new Promise((resolve, reject) => {
		const url = URL.createObjectURL(file);
		const img = new Image();
		img.onload = () => {
			const size = 256;
			const canvas = document.createElement("canvas");
			canvas.width = size;
			canvas.height = size;
			const ctx = canvas.getContext("2d");
			if (!ctx) {
				URL.revokeObjectURL(url);
				reject(/* @__PURE__ */ new Error("Could not read that photo."));
				return;
			}
			const scale = Math.max(size / img.width, size / img.height);
			const w = img.width * scale;
			const h = img.height * scale;
			ctx.drawImage(img, (size - w) / 2, (size - h) / 2, w, h);
			URL.revokeObjectURL(url);
			resolve(canvas.toDataURL("image/jpeg", .72));
		};
		img.onerror = () => {
			URL.revokeObjectURL(url);
			reject(/* @__PURE__ */ new Error("Could not read that photo."));
		};
		img.src = url;
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Authed, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings$1, {}) });
//#endregion
export { SplitComponent as component };
