import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as Sparkles, i as Wallet, p as Shield, rt as Bell, tt as Bot } from "../_libs/lucide-react.mjs";
import { t as Authed } from "./gate-DNi4gEUE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/telegram-bot-CkzH2eur.js
var import_jsx_runtime = require_jsx_runtime();
var CARDS = [
	[
		Sparkles,
		"Place Orders",
		"Instagram links par views, likes aur comments ke orders Telegram se place karein."
	],
	[
		Wallet,
		"Wallet Balance",
		"Apna live wallet balance aur recent transactions turant check karein."
	],
	[
		Bell,
		"Live Order Updates",
		"Processing, completed aur failed orders ki instant notifications paayein."
	],
	[
		Bot,
		"Manage Instagram Posts",
		"Recent posts dekhein aur Telegram ke andar se quick boost apply karein."
	],
	[
		Sparkles,
		"Auto Order Presets",
		"Default quantity aur auto/manual mode ko simple commands se control karein."
	],
	[
		Shield,
		"Secure Account Linking",
		"One-time verification ke saath apna Magiciansmm account safely connect karein."
	]
];
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between text-[13px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Telegram Bot" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/dashboard",
					children: "Home"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border border-[#e7eef6] bg-white px-6 py-10 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mx-auto grid size-14 place-items-center rounded-full bg-[#eef4ff] text-[#3b82f6]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bot, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-[12px] text-[#3b82f6]",
						children: "In Development"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-['Playfair_Display',Georgia,serif] text-[34px] leading-none",
						children: "Telegram Bot Coming Soon"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-3 max-w-md text-[13px] text-[#64748b]",
						children: "Magiciansmm panel ko Telegram se manage karna aur bhi fast hone wala hai. Hamari team ek secure aur powerful bot experience tayyar kar rahi hai."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 inline-flex rounded-full bg-[#eef4ff] px-3 py-1 text-[12px] text-[#2458c5]",
						children: "Launch update aapko dashboard par mil jayega"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-['Playfair_Display',Georgia,serif] text-[28px]",
					children: "What's Coming"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[13px] text-[#64748b]",
					children: "Telegram par milne wale powerful features"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: CARDS.map(([Icon, title, body]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-[#e7eef6] bg-white p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 text-[#3b82f6]" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-semibold",
							children: String(title)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[12px] text-[#64748b]",
							children: String(body)
						})
					]
				}, String(title)))
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Authed, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {}) });
//#endregion
export { SplitComponent as component };
