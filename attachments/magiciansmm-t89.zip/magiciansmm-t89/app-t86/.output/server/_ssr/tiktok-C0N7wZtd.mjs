import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as StaffOnly, t as Authed } from "./gate-DNi4gEUE.mjs";
import { t as listTikTokVideos } from "./tiktok.functions-nU2h4tOs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tiktok-C0N7wZtd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const [username, setUsername] = (0, import_react.useState)("");
	const [connected, setConnected] = (0, import_react.useState)(false);
	const [note, setNote] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const params = new URLSearchParams(window.location.search);
		if (params.get("tt") === "connected") setNote("TikTok connect ho gaya.");
		if (params.get("tt") === "error") setNote(params.get("reason") || "Connect fail.");
		listTikTokVideos().then((result) => {
			setConnected(result.connected);
			setUsername(result.username);
		}).catch((err) => setNote(err instanceof Error ? err.message : "Check fail."));
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-3xl bg-gradient-to-r from-[#f3f4f6] to-white p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "flex items-center gap-2 text-[22px] font-bold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-9 place-items-center rounded-xl bg-[#111827] text-white text-[16px]",
					children: "♪"
				}), "TikTok Accounts"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[13px] text-[#64748b]",
				children: "Sandbox target user se Allow karo. Uske public videos Bot Detection mein aayengi."
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-3xl border border-[#e7eef6] bg-white p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-semibold tracking-widest text-[#94a3b8]",
					children: "CONNECT TIKTOK"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-[12px] text-[#64748b]",
					children: "Cloudflare tunnel chalu hona chahiye, aur .env mein TIKTOK_CLIENT_KEY, SECRET aur REDIRECT_URI hona chahiye."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "/api/tiktok/start",
					className: "mt-3 inline-flex h-11 items-center rounded-xl bg-[#111827] px-4 text-[13px] font-bold text-white",
					children: "Connect TikTok"
				}),
				connected && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 rounded-xl bg-emerald-50 px-3 py-2 text-[13px] font-semibold text-emerald-800",
					children: ["Connected ", username || "TikTok account"]
				}),
				note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-[12px]",
					children: note
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/detect",
					className: "mt-3 block text-[12px] font-semibold text-[#2563eb]",
					children: "Bot Detection pe jaao →"
				})
			]
		})]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Authed, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StaffOnly, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {}) }) });
//#endregion
export { SplitComponent as component };
