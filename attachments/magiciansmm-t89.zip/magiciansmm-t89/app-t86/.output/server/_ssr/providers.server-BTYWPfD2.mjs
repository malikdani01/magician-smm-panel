import { r as __exportAll } from "../_runtime.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
import { readFileSync } from "node:fs";
//#region node_modules/.nitro/vite/services/ssr/assets/providers.server-BTYWPfD2.js
var providers_server_BTYWPfD2_exports = /* @__PURE__ */ __exportAll({
	i: () => dripEnabled,
	n: () => fetchProviderCatalog,
	r: () => providers_server_exports,
	t: () => detectPlatform
});
/** True only when the provider explicitly says this service supports drip-feed. */
function dripEnabled(value) {
	if (value === true || value === 1) return true;
	if (typeof value === "string") {
		const flag = value.trim().toLowerCase();
		return flag === "1" || flag === "true" || flag === "yes" || flag === "on";
	}
	return false;
}
var providers_server_exports = /* @__PURE__ */ __exportAll$1({
	NO_PROVIDER: () => NO_PROVIDER,
	askFreeModel: () => askFreeModel,
	browseProvider: () => browseProvider,
	cancelProviderOrder: () => cancelProviderOrder,
	detectPlatform: () => detectPlatform,
	fetchProviderCatalog: () => fetchProviderCatalog,
	listApiBalances: () => listApiBalances,
	listSingleOrderBalances: () => listSingleOrderBalances,
	placeChunk: () => placeChunk,
	placeExactOnProvider: () => placeExactOnProvider,
	providerBalance: () => providerBalance,
	providerOrderStatus: () => providerOrderStatus,
	providerPhase: () => providerPhase,
	readRemains: () => readRemains,
	savedProviderKeys: () => savedProviderKeys,
	serviceTier: () => serviceTier
});
var FREE_MODELS = [
	"google/gemma-4-26b-a4b-it:free",
	"nvidia/nemotron-3-super-120b-a12b:free",
	"thinkingmachines/inkling-small:free"
];
var catalogCache = null;
var balanceCache = null;
function secrets() {
	const fromEnv = {
		openrouter: process.env.OPENROUTER_API_KEY || "",
		yoyomedia: process.env.YOYOMEDIA_API_KEY || ""
	};
	if (fromEnv.openrouter && fromEnv.yoyomedia) return fromEnv;
	const candidates = [
		process.env.PROVIDERS_FILE || "",
		`${process.cwd()}/.secrets/providers.json`,
		"/workspace/.secrets/providers.json"
	].filter(Boolean);
	let file = {
		openrouter: "",
		yoyomedia: ""
	};
	for (const path of candidates) try {
		file = JSON.parse(readFileSync(path, "utf8"));
		break;
	} catch {}
	return {
		openrouter: fromEnv.openrouter || file.openrouter,
		yoyomedia: fromEnv.yoyomedia || file.yoyomedia
	};
}
async function yoyo(fields, apiUrl, apiKey) {
	const sent = await yoyoRaw(fields, apiUrl, apiKey);
	if (fields.action === "add") {
		if (!sent.order) throw new Error(sent.error || "Provider rejected the order.");
		return { order: sent.order };
	}
	if (sent.error && !sent.raw.trim().startsWith("[") && !sent.raw.trim().startsWith("{")) throw new Error(sent.error);
	try {
		return JSON.parse(sent.raw);
	} catch {
		throw new Error(sent.error || "Provider returned an unreadable response.");
	}
}
var NO_PROVIDER = "No Provider Available";
var catalogMemo = /* @__PURE__ */ new Map();
async function yoyoRaw(fields, apiUrl, apiKey) {
	const key = String(apiKey || "").trim();
	const url = String(apiUrl || "").trim();
	if (!key || !url) return {
		order: "",
		error: NO_PROVIDER,
		raw: ""
	};
	const body = new URLSearchParams({
		key,
		...fields
	});
	try {
		const response = await fetch(url, {
			method: "POST",
			headers: { "content-type": "application/x-www-form-urlencoded" },
			body
		});
		const raw = await response.text();
		let json = {};
		try {
			json = JSON.parse(raw);
		} catch {
			return {
				order: "",
				error: raw.slice(0, 180) || `HTTP ${response.status}`,
				raw
			};
		}
		return {
			order: json.order != null && String(json.order) !== "" && String(json.order) !== "0" ? String(json.order) : "",
			error: typeof json.error === "string" && json.error ? json.error : "",
			raw
		};
	} catch (error) {
		return {
			order: "",
			error: error instanceof Error ? error.message : "Network error",
			raw: ""
		};
	}
}
function readRemains(status, remains) {
	const text = String(status || "").toLowerCase();
	if (text.includes("complete") && !text.includes("progress")) return 0;
	const raw = String(remains ?? "").trim();
	if (!raw) return null;
	const value = Number(raw);
	if (!Number.isFinite(value)) return null;
	return Math.max(0, value);
}
function providerPhase(status) {
	const live = String(status || "").toLowerCase();
	if (/cancel|fail|refund/.test(live)) return "closed";
	if (live.includes("partial")) return "partial";
	if (live.includes("complete")) return "complete";
	return "open";
}
async function providerOrderStatus(orderId, apiUrl, apiKey) {
	const json = await yoyo({
		action: "status",
		order: orderId
	}, apiUrl, apiKey);
	return {
		status: String(json.status || "unknown"),
		remains: String(json.remains ?? ""),
		startCount: String(json.start_count ?? "")
	};
}
async function fetchProviderCatalog(apiUrl, apiKey) {
	const url = String(apiUrl || "").trim();
	const key = String(apiKey || "").trim();
	const cacheKey = `${url}|${key}`;
	const hit = catalogMemo.get(cacheKey);
	if (hit && Date.now() - hit.at < 6e4) return hit.rows;
	const rows = await yoyo({ action: "services" }, url, key);
	if (!Array.isArray(rows)) throw new Error("Provider did not return a service list.");
	catalogMemo.set(cacheKey, {
		at: Date.now(),
		rows
	});
	return rows;
}
function detectPlatform(category, name) {
	const text = `${category} ${name}`.toLowerCase();
	if (/instagram|\bigtv\b/.test(text)) return "instagram";
	if (/tik\s?tok/.test(text)) return "tiktok";
	if (/you\s?tube/.test(text)) return "youtube";
	if (/facebook/.test(text)) return "facebook";
	if (/twitter|retweet/.test(text)) return "twitter";
	if (/telegram/.test(text)) return "telegram";
	if (/whats\s?app/.test(text)) return "whatsapp";
	if (/spotify/.test(text)) return "spotify";
	if (/linkedin/.test(text)) return "linkedin";
	if (/discord/.test(text)) return "discord";
	if (/twitch/.test(text)) return "twitch";
	if (/snapchat/.test(text)) return "snapchat";
	if (/kwai/.test(text)) return "kwai";
	return "other";
}
async function savedProviderKeys() {
	const { bindingMap } = await import("./admin.server-B6p1lYbS.mjs").then((n) => n.r);
	const map = await bindingMap();
	const found = [];
	for (const slot of Object.values(map)) for (const item of slot.providers || []) {
		const apiKey = String(item.api_key || "").trim();
		const apiUrl = String(item.api_url || "").trim();
		if (!apiKey || !apiUrl) continue;
		if (found.some((row) => row.apiKey === apiKey && row.apiUrl === apiUrl)) continue;
		found.push({
			apiUrl,
			apiKey
		});
	}
	return found;
}
async function rawServices() {
	if (catalogCache && Date.now() - catalogCache.at < 6e4) return catalogCache.rows;
	const keys = await savedProviderKeys();
	if (keys.length === 0) return [];
	const merged = [];
	for (const key of keys) try {
		const rows = await fetchProviderCatalog(key.apiUrl, key.apiKey);
		for (const row of rows) merged.push(row);
	} catch {}
	catalogCache = {
		at: Date.now(),
		rows: merged
	};
	return merged;
}
function toLive(row) {
	const note = String(row.description || row.type || "").split("\n").map((line) => line.trim()).filter(Boolean)[0] || "";
	return {
		id: Number(row.service),
		platform: detectPlatform(row.category, row.name),
		category: row.category,
		name: row.name,
		min: Number(row.min) || 1,
		max: Number(row.max) || 1,
		rateUsd: Number(row.rate) || 0,
		note: note.slice(0, 180),
		dripAllowed: dripEnabled(row.dripfeed ?? row.drip_feed)
	};
}
async function providerBalance() {
	if (balanceCache && Date.now() - balanceCache.at < 6e4) return balanceCache;
	const first = (await savedProviderKeys())[0];
	if (!first) return {
		at: Date.now(),
		balanceUsd: 0,
		currency: "USD"
	};
	const json = await yoyo({ action: "balance" }, first.apiUrl, first.apiKey);
	balanceCache = {
		at: Date.now(),
		balanceUsd: Number(json.balance) || 0,
		currency: String(json.currency || "USD")
	};
	return balanceCache;
}
function shortBalanceError(message) {
	const text = message.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
	const named = text.match(/40[0-9] [^<\s][^.]{0,40}|50[0-9] [^<\s][^.]{0,40}|not allowed|unauthorized|forbidden|not found/i);
	return (named ? named[0] : text).slice(0, 80) || "Balance failed";
}
function hostOf(url) {
	try {
		return new URL(url).host;
	} catch {
		return url.slice(0, 42);
	}
}
async function listApiBalances() {
	const found = [];
	const push = (label, apiUrl, apiKey) => {
		const url = String(apiUrl || "").trim();
		const key = String(apiKey || "").trim();
		if (!url || !key) return;
		const existing = found.find((item) => item.apiUrl === url && item.apiKey === key);
		if (existing) {
			if (!existing.label.includes(label)) existing.label = `${existing.label} · ${label}`;
			return;
		}
		found.push({
			label,
			apiUrl: url,
			apiKey: key
		});
	};
	const allowed = /^(instagram|tiktok):(views|likes|saves|shares|reposts|comments)$/;
	try {
		const { listBindings } = await import("./admin.server-B6p1lYbS.mjs").then((n) => n.r);
		const rows = await listBindings();
		for (const row of rows) {
			if (!allowed.test(row.slot)) continue;
			const providers = (row.providers || []).filter((item) => item.api_url.trim() && item.api_key.trim());
			providers.forEach((item, index) => push(providers.length > 1 ? `${row.slot} #${index + 1}` : row.slot, item.api_url, item.api_key));
		}
	} catch {}
	return (await Promise.all(found.map(async (item) => {
		try {
			const json = await yoyo({ action: "balance" }, item.apiUrl, item.apiKey);
			const balance = Number(json.balance);
			const amount = Number.isFinite(balance) ? balance : 0;
			return {
				label: item.label,
				host: hostOf(item.apiUrl),
				keyTail: item.apiKey.slice(-4),
				balance: amount,
				currency: String(json.currency || "USD"),
				low: amount < 5,
				error: ""
			};
		} catch (error) {
			return {
				label: item.label,
				host: hostOf(item.apiUrl),
				keyTail: item.apiKey.slice(-4),
				balance: 0,
				currency: "",
				low: true,
				error: shortBalanceError(error instanceof Error ? error.message : "Balance failed")
			};
		}
	}))).sort((a, b) => Number(a.error !== "") - Number(b.error !== "") || a.balance - b.balance);
}
async function listSingleOrderBalances() {
	const { listProviders } = await import("./admin.server-B6p1lYbS.mjs").then((n) => n.r);
	const providers = (await listProviders()).filter((item) => item.enabled && item.api_url.trim() && item.api_key.trim());
	return Promise.all(providers.map(async (item) => {
		try {
			const json = await yoyo({ action: "balance" }, item.api_url, item.api_key);
			const balance = Number(json.balance);
			const amount = Number.isFinite(balance) ? balance : 0;
			return {
				id: item.id,
				name: item.name,
				host: hostOf(item.api_url),
				balance: amount,
				currency: String(json.currency || "USD"),
				low: amount < 5,
				error: ""
			};
		} catch (error) {
			return {
				id: item.id,
				name: item.name,
				host: hostOf(item.api_url),
				balance: 0,
				currency: "",
				low: true,
				error: shortBalanceError(error instanceof Error ? error.message : "Balance failed")
			};
		}
	}));
}
async function browseProvider(input) {
	const rows = (await rawServices()).map(toLive).filter((row) => input.platform === "all" || row.platform === input.platform);
	const names = Array.from(new Set(rows.map((row) => row.category))).sort((a, b) => a.localeCompare(b));
	const categories = input.platform === "all" ? ["All categories", ...names] : names;
	const category = categories.includes(input.category) ? input.category : categories[0] || "";
	const query = input.query.trim().toLowerCase();
	let services = category === "All categories" ? rows : rows.filter((row) => row.category === category);
	if (query) services = rows.filter((row) => `${row.id} ${row.name} ${row.category}`.toLowerCase().includes(query));
	const cap = category === "All categories" && !query ? rows.length : 200;
	return {
		categories,
		category,
		services: services.slice(0, cap)
	};
}
var TYPE_RULE = {
	views: {
		yes: /\bviews?\b/,
		no: /\b(likes?|shares?|saves?|favourites?|favorites?|comments?|followers?|reposts?|subscribers?)\b/
	},
	likes: {
		yes: /\blikes?\b/,
		no: /\b(views?|shares?|saves?|favourites?|favorites?|comments?|followers?|reposts?|subscribers?|live)\b/
	},
	comments: {
		yes: /\bcomments?\b/,
		no: /\b(views?|likes?|shares?|saves?|favourites?|favorites?|followers?|reposts?|live)\b/
	},
	shares: {
		yes: /\bshares?\b/,
		no: /\b(views?|likes?|saves?|favourites?|favorites?|comments?|followers?|live)\b/
	},
	saves: {
		yes: /\b(saves?|favourites?|favorites?)\b/,
		no: /\b(views?|likes?|shares?|comments?|followers?|reposts?|live)\b/
	},
	reposts: {
		yes: /\breposts?\b/,
		no: /\b(views?|likes?|shares?|saves?|favourites?|favorites?|comments?|followers?|live)\b/
	},
	followers: {
		yes: /\bfollowers?\b/,
		no: /\b(views?|likes?|shares?|saves?|favourites?|favorites?|comments?|reposts?)\b/
	}
};
function readDrop(text) {
	const nonDrop = /non[-\s]?drop|no[-\s]?drop|nondrop|drop\s*:\s*non\s*drop/.test(text);
	const unknown = /drop\s*:\s*unknown/.test(text);
	const noRefill = /no[-\s]?refill|without refill|non[-\s]?refill/.test(text);
	let maxPct = null;
	for (const match of text.matchAll(/drop\s*:\s*(\d+(?:\.\d+)?)\s*(?:-|–|to)?\s*(\d+(?:\.\d+)?)?\s*%/gi)) {
		const low = Number(match[1]);
		const high = match[2] ? Number(match[2]) : low;
		const top = Math.max(low, high);
		if (Number.isFinite(top)) maxPct = maxPct == null ? top : Math.max(maxPct, top);
	}
	return {
		nonDrop,
		unknown,
		maxPct,
		noRefill
	};
}
function flags(text) {
	return {
		nonDrop: /non[-\s]?drop|no[-\s]?drop|nondrop|\bnd\b|zero[-\s]?drop|no\s*loss/.test(text),
		guaranteed: /100\s*%\s*guaranteed|lifetime\s*guarantee|\bguaranteed\b|\bguarantee\b|\bpermanent\b/.test(text),
		stable: /\bstable\b|high\s*quality|high\s*retention/.test(text),
		instantStart: /instant\s*start|immediate\s*start|0\s*[-–to]{1,3}\s*5\s*min/.test(text),
		fast: /fast\s*start|instant\s*delivery|\binstant\b/.test(text)
	};
}
function rejectedService(text, nonDrop) {
	if (/high\s*drop/.test(text)) return true;
	if (/refill\s*only/.test(text) && !nonDrop) return true;
	if (/slow\s*start|delayed\s*start|gradual\s*delivery|drip\s*feed/.test(text)) return true;
	if (/\bunknown\b|\bunstable\b|low\s*quality/.test(text)) return true;
	if (/start\s*:?\s*(12|24)\s*(h|hr|hrs|hour|hours)\b/.test(text)) return true;
	if (/drop\s*:\s*(\d+(?:\.\d+)?)(?:\s*(?:-|–|to)\s*(\d+(?:\.\d+)?))?\s*%?/.test(text)) {
		const low = Number(RegExp.$1);
		const high = RegExp.$2 ? Number(RegExp.$2) : low;
		if (Math.max(low, high) > 0) return true;
	}
	const plain = text.replace(/drop\s*:\s*non\s*drop/g, " ").replace(/non[-\s]?drop|no[-\s]?drop|nondrop|zero[-\s]?drop/g, " ");
	if (/\bdrop\b/.test(plain)) return true;
	return false;
}
function qualifiedScore(text) {
	const mark = flags(text);
	if (rejectedService(text, mark.nonDrop)) return 0;
	const fastStart = mark.instantStart || mark.fast || /0\s*[-–]\s*5\s*min/.test(text);
	if (mark.nonDrop && mark.instantStart && mark.guaranteed) return 1e3;
	if (mark.nonDrop && mark.instantStart) return 800;
	if (mark.nonDrop && /fast\s*start/.test(text)) return 700;
	if (mark.nonDrop && mark.guaranteed && fastStart) return 650;
	let score = 0;
	if (mark.nonDrop) score += 220;
	if (mark.guaranteed) score += 160;
	if (mark.instantStart) score += 150;
	if (mark.fast) score += 120;
	if (mark.stable) score += 90;
	return score;
}
function qualityScore(text, refillFlag, type) {
	if (type && [
		"views",
		"likes",
		"shares",
		"saves",
		"comments",
		"reposts"
	].includes(type)) return qualifiedScore(text);
	let score = 0;
	if (/non[-\s]?drop|no[-\s]?drop|nondrop|drop\s*:\s*non\s*drop/.test(text)) score += 100;
	if (/\bstable\b/.test(text)) score += 80;
	if (/guaranteed|guarantee/.test(text)) score += 70;
	if (/\brefill\b/.test(text) || refillFlag) score += 40;
	return score;
}
/** Views, likes, shares, saves, comments, reposts: only explicit non-drop / guaranteed / stable / instant keywords. Refill alone is not non-drop. */
function serviceTier(row, type) {
	const text = `${row.name || ""} ${row.category || ""} ${row.description || ""}`.toLowerCase();
	if (Boolean(type && [
		"views",
		"likes",
		"shares",
		"saves",
		"comments",
		"reposts"
	].includes(type))) {
		const mark = flags(text);
		if (/no[-\s]?refill|without refill|non[-\s]?refill/.test(text)) return "reject";
		if (rejectedService(text, mark.nonDrop)) return "reject";
		if (qualifiedScore(text) > 0) return "good";
		return "soft";
	}
	const info = readDrop(text);
	if (info.noRefill || info.unknown) return "reject";
	if (info.maxPct != null && info.maxPct > 15) return "reject";
	if (qualityScore(text, Boolean(row.refill), type) > 0) return "good";
	if (info.maxPct != null && info.maxPct >= 10 && info.maxPct <= 15) return "soft";
	return "reject";
}
function stableScore(row, type) {
	if (serviceTier(row, type) === "reject") return 0;
	return qualityScore(`${row.name || ""} ${row.category || ""} ${row.description || ""}`.toLowerCase(), Boolean(row.refill), type) || (serviceTier(row, type) === "soft" ? 1 : 0);
}
async function placeChunk(input) {
	let qty = Math.max(1, Math.floor(input.quantity));
	const providers = (input.providers?.length ? input.providers : [{
		apiUrl: input.apiUrl,
		apiKey: input.apiKey
	}]).map((item) => ({
		apiUrl: String(item.apiUrl || "").trim(),
		apiKey: String(item.apiKey || "").trim()
	})).filter((item) => item.apiKey && item.apiUrl);
	if (providers.length === 0) throw new Error(NO_PROVIDER);
	const rule = TYPE_RULE[input.type] || {
		yes: new RegExp(`\\b${input.type}\\b`, "i"),
		no: /$^/
	};
	const used = new Set((input.usedKeys || []).map((key) => key.trim()).filter(Boolean));
	const pendingByKey = input.pendingByKey || {};
	const usedServices = input.usedServiceIds || {};
	const activeByService = input.activeByService || {};
	const limit = Math.max(1, Math.floor(input.serviceLimit || 1));
	const scans = await Promise.all(providers.map(async (provider) => {
		const started = Date.now();
		try {
			return {
				provider,
				rows: await fetchProviderCatalog(provider.apiUrl, provider.apiKey),
				ms: Date.now() - started
			};
		} catch (error) {
			const message = error instanceof Error ? error.message : "catalog failed";
			console.log(`[drops] catalog skip ${provider.apiUrl}: ${message}`);
			return {
				provider,
				rows: [],
				ms: Date.now() - started
			};
		}
	}));
	const choices = [];
	for (const scan of scans) {
		const fresh = !used.has(scan.provider.apiKey);
		const pending = pendingByKey[scan.provider.apiKey] ?? 0;
		const seen = new Set(usedServices[scan.provider.apiKey] || []);
		for (const row of scan.rows) {
			if (detectPlatform(row.category, row.name) !== input.platform) continue;
			if (row.type && String(row.type).toLowerCase() !== "default") continue;
			const label = String(row.name || "").toLowerCase();
			const blob = `${row.name || ""} ${row.category || ""}`.toLowerCase();
			if (!rule.yes.test(blob) || rule.no.test(label)) continue;
			if (/combo|package|\+|free /.test(label)) continue;
			const tier = serviceTier(row, input.type);
			const min = Number(row.min) || 0;
			const max = Number(row.max) || 0;
			if (qty < min || max > 0 && qty > max) continue;
			if (tier === "reject") continue;
			const id = String(row.service);
			const active = activeByService[`${scan.provider.apiKey}::${id}`] || 0;
			choices.push({
				id,
				name: String(row.name || `Service ${row.service}`),
				score: stableScore(row, input.type),
				tier,
				rate: Number(row.rate) || 0,
				apiUrl: scan.provider.apiUrl,
				apiKey: scan.provider.apiKey,
				ms: scan.ms,
				fresh,
				pending,
				reusedService: seen.has(id),
				active
			});
		}
	}
	const noise = new Map(choices.map((choice) => [choice, Math.random()]));
	const ranked = [...choices].sort((a, b) => {
		const aFree = a.active < limit ? 0 : 1;
		const bFree = b.active < limit ? 0 : 1;
		if (aFree !== bFree) return aFree - bFree;
		if (a.tier !== b.tier) return a.tier === "good" ? -1 : 1;
		if (b.score !== a.score) return b.score - a.score;
		if (a.active !== b.active) return a.active - b.active;
		if (a.reusedService !== b.reusedService) return a.reusedService ? 1 : -1;
		return (noise.get(a) || 0) - (noise.get(b) || 0);
	});
	const unique = [];
	for (const choice of ranked) {
		if (unique.some((item) => item.apiKey === choice.apiKey && item.id === choice.id)) continue;
		unique.push(choice);
		if (unique.length === 12) break;
	}
	if (unique.length === 0) for (const scan of scans) {
		const fresh = !used.has(scan.provider.apiKey);
		const pending = pendingByKey[scan.provider.apiKey] ?? 0;
		const seen = new Set(usedServices[scan.provider.apiKey] || []);
		for (const row of scan.rows) {
			if (detectPlatform(row.category, row.name) !== input.platform) continue;
			const label = String(row.name || "").toLowerCase();
			const blob = `${row.name || ""} ${row.category || ""}`.toLowerCase();
			if (!rule.yes.test(blob) || rule.no.test(label)) continue;
			if (/combo|package|\+|free /.test(label)) continue;
			const min = Number(row.min) || 0;
			const max = Number(row.max) || 0;
			if (qty < min || max > 0 && qty > max) continue;
			const id = String(row.service);
			const active = activeByService[`${scan.provider.apiKey}::${id}`] || 0;
			choices.push({
				id,
				name: String(row.name || `Service ${row.service}`),
				score: 1,
				tier: "soft",
				rate: Number(row.rate) || 0,
				apiUrl: scan.provider.apiUrl,
				apiKey: scan.provider.apiKey,
				ms: scan.ms,
				fresh,
				pending,
				reusedService: seen.has(id),
				active
			});
		}
	}
	if (choices.length > ranked.length) {
		ranked.length = 0;
		ranked.push(...[...choices].sort((a, b) => {
			const aFree = a.active < limit ? 0 : 1;
			const bFree = b.active < limit ? 0 : 1;
			if (aFree !== bFree) return aFree - bFree;
			if (a.active !== b.active) return a.active - b.active;
			return (noise.get(a) || Math.random()) - (noise.get(b) || 0);
		}));
		unique.length = 0;
		for (const choice of ranked) {
			if (unique.some((item) => item.apiKey === choice.apiKey && item.id === choice.id)) continue;
			unique.push(choice);
			if (unique.length === 12) break;
		}
	}
	if (unique.length === 0) {
		let lowest = 0;
		for (const scan of scans) for (const row of scan.rows) {
			if (detectPlatform(row.category, row.name) !== input.platform) continue;
			const blob = `${row.name || ""} ${row.category || ""}`.toLowerCase();
			const label = String(row.name || "").toLowerCase();
			if (!rule.yes.test(blob) || rule.no.test(label)) continue;
			const min = Number(row.min) || 0;
			if (min > lowest) lowest = min;
		}
		const hint = lowest > qty ? ` Lowest ${input.type} minimum on the connected API is ${lowest}.` : "";
		throw new Error(`No suitable ${input.platform} ${input.type} service accepts quantity ${qty}.${hint}`);
	}
	const open = unique.filter((item) => item.active < limit);
	const queue = (open.length ? open : unique).slice(0, 4);
	console.log(`[drops] ${input.type} x${qty} queue: ${queue.slice(0, 3).map((item) => `#${item.id} ${item.fresh ? "fresh" : "return"} ${item.tier} ${item.name}`).join(" | ")}`);
	let last = "Provider rejected the order.";
	const tryChoice = async (choice) => {
		const sent = await yoyoRaw({
			action: "add",
			service: choice.id,
			link: input.link.trim(),
			quantity: String(qty)
		}, choice.apiUrl, choice.apiKey);
		if (sent.order) {
			console.log(`[drops] placed once on #${choice.id} via ${choice.apiUrl}. Other APIs were not used.`);
			return {
				orderId: sent.order,
				serviceId: choice.id,
				label: choice.name,
				apiUrl: choice.apiUrl,
				apiKey: choice.apiKey,
				quantity: qty
			};
		}
		last = sent.error || last;
		console.log(`[drops] #${choice.id} refused, trying next eligible only: ${last}`);
		return null;
	};
	for (const choice of queue) {
		const placed = await tryChoice(choice);
		if (placed) return placed;
	}
	throw new Error(last);
}
async function cancelOrders(ids) {
	await Promise.all(ids.map(async (id) => {
		try {
			await yoyo({
				action: "cancel",
				order: id
			});
		} catch {}
	}));
}
async function placeExactOnProvider(input) {
	const sent = await yoyoRaw({
		action: "add",
		service: String(input.serviceId),
		link: input.link.trim(),
		quantity: String(Math.max(1, Math.floor(input.quantity)))
	}, input.apiUrl, input.apiKey);
	if (!sent.order) throw new Error(sent.error || "Provider rejected this order.");
	return {
		orderId: sent.order,
		serviceId: String(input.serviceId)
	};
}
async function cancelProviderOrder(id, apiUrl, apiKey) {
	if (apiUrl && apiKey) {
		await yoyoRaw({
			action: "cancel",
			order: id
		}, apiUrl, apiKey);
		return;
	}
	await cancelOrders([id]);
}
async function askFreeModel(system, prompt) {
	const key = secrets().openrouter;
	if (!key) throw new Error("OpenRouter key is missing.");
	let last = "The free model did not answer.";
	for (const model of FREE_MODELS) try {
		const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
			method: "POST",
			headers: {
				Authorization: `Bearer ${key}`,
				"Content-Type": "application/json",
				"HTTP-Referer": "http://127.0.0.1:8080",
				"X-Title": "Magiciansmm"
			},
			body: JSON.stringify({
				model,
				messages: [{
					role: "system",
					content: system
				}, {
					role: "user",
					content: prompt
				}],
				max_tokens: 400,
				temperature: .2
			})
		});
		const json = await response.json();
		if (!response.ok) throw new Error(json.error?.message || `${model} failed.`);
		const message = json.choices?.[0]?.message;
		const text = (message?.content || message?.reasoning || "").trim();
		if (!text) throw new Error(`${model} returned an empty reply.`);
		return text;
	} catch (error) {
		last = error instanceof Error ? error.message : last;
	}
	throw new Error(last);
}
//#endregion
export { providers_server_BTYWPfD2_exports as i, dripEnabled as n, fetchProviderCatalog as r, detectPlatform as t };
