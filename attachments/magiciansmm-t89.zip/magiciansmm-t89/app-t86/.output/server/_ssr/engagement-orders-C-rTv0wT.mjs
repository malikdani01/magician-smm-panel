import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { V as Heart, W as Eye, g as Share2, nt as Bookmark } from "../_libs/lucide-react.mjs";
import { at as listOrders, et as inr } from "./shell-CfBlaVSk.mjs";
import { t as Authed } from "./gate-DNi4gEUE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/engagement-orders-C-rTv0wT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Orders() {
	const [rows, setRows] = (0, import_react.useState)([]);
	const [drops, setDrops] = (0, import_react.useState)({});
	const [q, setQ] = (0, import_react.useState)("");
	function load() {
		const stamp = Date.now();
		listOrders({ data: { t: stamp } }).then(async (orders) => {
			setRows(orders);
			const pairs = await Promise.all(orders.slice(0, 20).map(async (order) => {
				const res = await fetch(`/api/drops/${order.id}?t=${stamp}`, { cache: "no-store" }).catch(() => null);
				const data = res?.ok ? await res.json().catch(() => ({ drops: [] })) : { drops: [] };
				return [order.id, data.drops || []];
			}));
			setDrops(Object.fromEntries(pairs));
		}).catch(() => setRows([]));
	}
	(0, import_react.useEffect)(() => {
		load();
		const timer = window.setInterval(load, 8e3);
		return () => window.clearInterval(timer);
	}, []);
	const shown = rows.filter((row) => `${row.order_number} ${row.link}`.toLowerCase().includes(q.toLowerCase()));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-[22px] font-bold",
					children: "All Orders"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[13px] text-[#64748b]",
					children: "Single, drip and full engagement orders, with live tracking"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: load,
						className: "rounded-full border bg-white px-3 py-2 text-[12px] font-semibold",
						children: "Refresh"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/engagement-order",
						className: "rounded-xl bg-[#2563eb] px-3 py-2 text-[12px] font-semibold text-white",
						children: "+ New Order"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: q,
				onChange: (event) => setQ(event.target.value),
				placeholder: "Search by order number or video link...",
				className: "h-12 w-full rounded-2xl bg-[#e7f0fa] px-4 outline-none"
			}),
			shown.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border border-[#e7eef6] bg-white py-16 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "No orders yet" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/engagement-order",
					className: "mt-3 inline-flex h-10 items-center rounded-xl bg-[#2563eb] px-4 text-[13px] font-semibold text-white",
					children: "Place Your First Order"
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-3",
				children: shown.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderCard, {
					order: row,
					drops: drops[row.id] ?? []
				}, row.id))
			})
		]
	});
}
function OrderCard({ order, drops }) {
	const placed = drops.filter((drop) => drop.status === "placed").length;
	const pending = drops.filter((drop) => drop.status === "waiting" || drop.status === "paused").length;
	const active = drops.filter((drop) => drop.status === "placing").length;
	const delivered = drops.reduce((sum, drop) => sum + (drop.status === "placed" && typeof drop.sent === "number" ? drop.sent : 0), 0);
	const total = order.items.reduce((sum, item) => sum + item.quantity, 0);
	const next = drops.filter((drop) => drop.status === "waiting").sort((a, b) => a.place_at.localeCompare(b.place_at))[0];
	const pct = total ? Math.round(delivered / total * 100) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/orders/$id",
		params: { id: order.id },
		className: "block rounded-[24px] border border-[#e7eef6] bg-white p-4 shadow-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-semibold",
					children: [
						"Order #",
						order.order_number.replace("MAG-", ""),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-1 rounded-full bg-[#111827] px-2 py-0.5 text-[10px] font-bold text-white",
							children: order.status
						}),
						" ",
						order.organic && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-700",
							children: "Organic"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-md truncate text-[12px] text-[#64748b]",
					children: order.link
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-bold",
							children: inr(order.total_paise)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-semibold text-[#2563eb]",
							children: "Open live tracking ›"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-[#94a3b8]",
							children: ago(order.created_at)
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-4 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Delivered",
						value: delivered
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Placed",
						value: placed
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Pending",
						value: pending
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Active",
						value: active
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex justify-between text-[12px] text-[#64748b]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					placed,
					" / ",
					drops.length || order.items.length,
					" runs"
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					delivered.toLocaleString("en-IN"),
					" / ",
					total.toLocaleString("en-IN"),
					" (",
					pct,
					"%)"
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 h-1.5 overflow-hidden rounded-full bg-[#e7eef6]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full bg-[#93c5fd]",
					style: { width: `${pct}%` }
				})
			}),
			next && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 rounded-xl bg-[#f4f8fc] px-3 py-2 text-[13px] text-[#334155]",
				children: [
					"Next run: ",
					clock(next.place_at),
					" (in ",
					fromNow(next.place_at),
					")"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-wrap gap-2 text-[12px]",
				children: order.items.map((item) => {
					const sent = drops.filter((drop) => drop.engagement_type === item.engagement_type).reduce((sum, drop) => sum + (drop.status === "placed" && typeof drop.sent === "number" ? drop.sent : 0), 0);
					const placedQty = drops.filter((drop) => drop.engagement_type === item.engagement_type && drop.status === "placed").reduce((sum, drop) => sum + drop.quantity, 0);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1 rounded-full bg-[#f8fafc] px-2 py-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypeIcon, { type: item.engagement_type }),
							" ",
							item.engagement_type,
							": ",
							sent,
							"/",
							item.quantity,
							" deliver · ",
							placedQty,
							" placed"
						]
					}, item.id);
				})
			})
		]
	}) });
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl bg-[#f4f8fc] px-2 py-3 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[18px] font-bold",
			children: value.toLocaleString("en-IN")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] text-[#64748b]",
			children: label
		})]
	});
}
function TypeIcon({ type }) {
	if (type === "likes") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "size-3 text-rose-500" });
	if (type === "shares" || type === "reposts") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-3 text-sky-500" });
	if (type === "saves") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-3 text-amber-500" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3 text-emerald-500" });
}
function clock(iso) {
	return new Date(iso).toLocaleTimeString("en-IN", {
		hour: "2-digit",
		minute: "2-digit"
	});
}
function ago(iso) {
	const min = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 6e4));
	if (min < 1) return "less than a minute ago";
	if (min < 60) return `${min} min ago`;
	return `${Math.round(min / 60)}h ago`;
}
function fromNow(iso) {
	const min = Math.round((new Date(iso).getTime() - Date.now()) / 6e4);
	if (min <= 0) return "less than a minute";
	if (min < 60) return `${min} minute${min === 1 ? "" : "s"}`;
	const hours = Math.round(min / 60);
	return hours === 1 ? "about 1 hour" : `about ${hours} hours`;
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Authed, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Orders, {}) });
//#endregion
export { SplitComponent as component };
