import { r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-DY5Pyta6.mjs";
import { u as getSql } from "./organic-DU6S6wDh.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
import { g as requireAdmin } from "./admin.server-B6p1lYbS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tiktok.functions-Vxw9dSwU.js
var listTikTokVideos_createServerFn_handler = createServerRpc({
	id: "47df4f76b2a619a11a9900bd3da647ea0d37ab5d21171cec377d5166f7648f24",
	name: "listTikTokVideos",
	filename: "src/lib/tiktok.functions.ts"
}, (opts) => listTikTokVideos.__executeServer(opts));
var listTikTokVideos = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listTikTokVideos_createServerFn_handler, async ({ context }) => {
	await requireAdmin(context.userId);
	const row = (await (await getSql())`
      select access_token, username from tiktok_oauth
      where user_id = ${context.userId}
      order by created_at desc
      limit 1
    `)[0];
	if (!row?.access_token) return {
		connected: false,
		username: "",
		videos: []
	};
	const res = await fetch("https://open.tiktokapis.com/v2/video/list/?fields=id,title,video_description,share_url,like_count,comment_count,share_count,view_count", {
		method: "POST",
		headers: {
			authorization: `Bearer ${row.access_token}`,
			"content-type": "application/json"
		},
		body: JSON.stringify({ max_count: 20 })
	});
	const body = await res.json().catch(() => ({}));
	if (!res.ok || body.error?.code && body.error.code !== "ok") throw new Error(body.error?.message || "TikTok videos nahi mili.");
	const videos = (body.data?.videos ?? []).map((video) => ({
		id: video.id,
		caption: video.video_description || video.title || "",
		permalink: video.share_url,
		like_count: video.like_count ?? 0,
		comments_count: video.comment_count ?? 0,
		view_count: video.view_count ?? 0,
		share_count: video.share_count ?? 0
	}));
	return {
		connected: true,
		username: row.username,
		videos
	};
});
//#endregion
export { listTikTokVideos_createServerFn_handler };
