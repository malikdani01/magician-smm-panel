import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as graphBotScore, f as growthPreview } from "./organic-DU6S6wDh.mjs";
import { B as editScheduledDrop, I as checkDropStatus, Tt as setRunState, X as getOrder, et as inr, it as listOrderDrops, wt as setOrderFlow } from "./shell-CfBlaVSk.mjs";
import { t as Authed } from "./gate-DNi4gEUE.mjs";
import { n as Route$6 } from "./router-BUBrNJ6H.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/orders._id-BJXgw0p7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function sentOf(drop) {
	if (drop.status !== "placed" || typeof drop.sent !== "number") return 0;
	return drop.sent;
}
function OrganicBoard({ order, drops }) {
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	const [mode, setMode] = (0, import_react.useState)("total");
	const [schedule, setSchedule] = (0, import_react.useState)("batch");
	const [shown, setShown] = (0, import_react.useState)(6);
	(0, import_react.useEffect)(() => {
		const timer = window.setInterval(() => setNow(Date.now()), 1e3);
		return () => window.clearInterval(timer);
	}, []);
	const sorted = [...drops].sort((a, b) => a.place_at.localeCompare(b.place_at));
	let saved = null;
	try {
		saved = order.preview_json ? JSON.parse(order.preview_json) : null;
	} catch {
		saved = null;
	}
	const qty = (type) => order.items.find((item) => item.engagement_type === type)?.quantity ?? 0;
	const typed = (type) => {
		const value = saved?.quantities?.[type];
		return typeof value === "number" && value > 0 ? value : qty(type);
	};
	const done = (type) => drops.filter((drop) => drop.engagement_type === type).reduce((sum, drop) => sum + sentOf(drop), 0);
	const views = typed("views");
	const likes = typed("likes");
	const shares = typed("shares");
	const saves = typed("saves");
	const gotViews = done("views");
	const gotLikes = done("likes");
	const gotShares = done("shares");
	const gotSaves = done("saves");
	const deliveredEngagement = gotLikes + gotShares + gotSaves;
	const actualRate = gotViews > 0 ? deliveredEngagement / gotViews * 100 : 0;
	const fallbackDelivery = Object.fromEntries([
		"views",
		"likes",
		"shares",
		"saves"
	].map((type) => {
		const rows = sorted.filter((drop) => drop.engagement_type === type);
		if (rows.length === 0) return [type, {
			hours: 1,
			runs: 1,
			variance: order.variance_percent
		}];
		const span = (new Date(rows[rows.length - 1].place_at).getTime() - new Date(rows[0].place_at).getTime()) / 36e5;
		return [type, {
			hours: Math.max(.25, span || .25),
			runs: rows.length,
			variance: order.variance_percent
		}];
	}));
	const preview = growthPreview({
		quantities: {
			views,
			likes,
			shares,
			saves
		},
		delivery: saved?.delivery ?? fallbackDelivery,
		origin: new Date(order.created_at).getTime() || Date.now()
	});
	const planned = preview.engagement;
	const plannedRate = preview.rate;
	const live = order.status === "processing" || order.status === "pending";
	const upcoming = sorted.filter((drop) => drop.status === "waiting" || drop.status === "placing" || drop.status === "paused");
	const next = upcoming[0];
	const after = next ? upcoming.find((drop) => drop.engagement_type !== next.engagement_type) : void 0;
	const due = next ? new Date(next.place_at).getTime() - now : 0;
	const clockLeft = !next ? "" : next.status === "placing" ? "Placing" : due <= 0 ? "Due now" : `${Math.floor(due / 36e5)}h ${Math.floor(due % 36e5 / 6e4)}m`;
	const rateOf = (part, base) => base > 0 ? part / base * 100 : 0;
	const cards = [
		{
			label: "Views",
			icon: "◎",
			got: gotViews,
			target: views,
			note: `${views ? Math.round(gotViews / views * 100) : 0}%`,
			tone: "text-violet-300"
		},
		{
			label: "Likes",
			icon: "♡",
			got: gotLikes,
			target: likes,
			note: `${rateOf(gotLikes, gotViews).toFixed(1)}% of views`,
			tone: "text-pink-300"
		},
		{
			label: "Shares",
			icon: "➤",
			got: gotShares,
			target: shares,
			note: `${rateOf(gotShares, gotViews).toFixed(1)}% of views`,
			tone: "text-emerald-300"
		},
		{
			label: "Saves",
			icon: "▣",
			got: gotSaves,
			target: saves,
			note: `${rateOf(gotSaves, gotViews).toFixed(1)}% of views`,
			tone: "text-amber-300"
		}
	];
	const chartKeys = [
		"views",
		"likes",
		"shares",
		"saves"
	];
	const chartColor = {
		views: "#c084fc",
		likes: "#60a5fa",
		shares: "#22d3ee",
		saves: "#f472b6"
	};
	const ceiling = Math.max(views, likes, shares, saves, gotViews, gotLikes, gotShares, gotSaves, 1);
	const origin = new Date(order.created_at).getTime() || (sorted[0] ? new Date(sorted[0].place_at).getTime() : now);
	const horizon = Math.max(now, ...sorted.map((drop) => new Date(drop.place_at).getTime()), origin + 9e5);
	const spanMs = Math.max(1, horizon - origin);
	const steps = 48;
	const liveLines = Object.fromEntries(chartKeys.map((key) => {
		const mine = sorted.filter((drop) => drop.engagement_type === key && drop.status === "placed");
		const points = [];
		const batches = [];
		for (let index = 0; index < steps; index += 1) {
			const at = origin + index / 47 * spanMs;
			if (at > now + 1500) {
				points.push(NaN);
				batches.push(NaN);
				continue;
			}
			const prevAt = index === 0 ? origin - 1 : origin + (index - 1) / 47 * spanMs;
			let total = 0;
			let step = 0;
			for (const drop of mine) {
				const when = new Date(drop.place_at).getTime();
				if (when > at) continue;
				const sent = sentOf(drop);
				total += sent;
				if (when > prevAt) step += sent;
			}
			points.push(Math.sqrt(Math.min(1, total / ceiling)));
			batches.push(Math.sqrt(Math.min(1, step / ceiling)));
		}
		return [key, {
			points,
			batches
		}];
	}));
	const shownLine = Object.fromEntries(chartKeys.map((key) => [key, mode === "total" ? liveLines[key].points : liveLines[key].batches]));
	const width = 640;
	const height = 230;
	const pad = {
		l: 36,
		r: 8,
		t: 12,
		b: 28
	};
	const innerW = width - pad.l - pad.r;
	const innerH = height - pad.t - pad.b;
	const linePath = (points) => {
		let drawing = false;
		return points.map((point, index) => {
			if (!Number.isFinite(point)) {
				drawing = false;
				return "";
			}
			const x = pad.l + index / Math.max(1, points.length - 1) * innerW;
			const y = pad.t + (1 - point) * innerH;
			const cmd = drawing ? "L" : "M";
			drawing = true;
			return `${cmd}${x.toFixed(1)},${y.toFixed(1)}`;
		}).filter(Boolean).join(" ");
	};
	const area = `${linePath(shownLine.views ?? [])} L${pad.l + innerW},${pad.t + innerH} L${pad.l},${pad.t + innerH} Z`;
	const spanH = Math.max(.25, spanMs / 36e5);
	const xTicks = [
		0,
		.5,
		1
	].map((part) => ({
		x: pad.l + part * innerW,
		label: part === 0 ? "Start" : spanH * part < 48 ? `${Math.round(spanH * part)}h` : `${(spanH * part / 24).toFixed(1)}d`
	}));
	const yTicks = [
		0,
		.5,
		1
	].map((frac) => ({
		y: pad.t + (1 - Math.sqrt(frac)) * innerH,
		label: Math.round(frac * ceiling).toLocaleString("en-IN")
	}));
	const elapsedH = Math.max(.25, (now - origin) / 36e5);
	const floors = {
		views: 100,
		likes: 10,
		shares: 10,
		saves: 50
	};
	const liveServices = chartKeys.filter((key) => (key === "views" ? gotViews : key === "likes" ? gotLikes : key === "shares" ? gotShares : gotSaves) > 0).map((key) => ({
		key,
		label: key[0].toUpperCase() + key.slice(1),
		qty: key === "views" ? gotViews : key === "likes" ? gotLikes : key === "shares" ? gotShares : gotSaves,
		runs: Math.max(1, drops.filter((drop) => drop.engagement_type === key && sentOf(drop) > 0).length),
		hours: elapsedH,
		floor: floors[key]
	}));
	const bot = liveServices.length === 0 ? {
		score: 0,
		band: "0-20",
		name: "Waiting",
		action: "Abhi koi quantity deliver nahi hui. Graph tab banega jab pehla run video pe aayega."
	} : graphBotScore({
		views: gotViews,
		likes: gotLikes,
		shares: gotShares,
		saves: gotSaves,
		hours: elapsedH,
		runs: liveServices.find((item) => item.key === "views")?.runs || liveServices[0].runs,
		services: liveServices
	});
	const botBar = bot.score <= 20 ? "#22c55e" : bot.score <= 40 ? "#14b8a6" : bot.score <= 60 ? "#f59e0b" : bot.score <= 80 ? "#f97316" : "#ef4444";
	const mix = [
		{
			label: "Likes",
			value: gotLikes,
			color: "#f472b6"
		},
		{
			label: "Shares",
			value: gotShares,
			color: "#34d399"
		},
		{
			label: "Saves",
			value: gotSaves,
			color: "#fbbf24"
		}
	];
	const mixTotal = mix.reduce((sum, item) => sum + item.value, 0);
	const ring = 2 * Math.PI * 28;
	let ringAt = 0;
	const days = /* @__PURE__ */ new Map();
	for (const drop of sorted) {
		const day = new Date(drop.place_at).toLocaleDateString("en-IN", {
			day: "2-digit",
			month: "short"
		});
		const row = days.get(day) || {
			views: 0,
			likes: 0,
			shares: 0,
			saves: 0,
			got: 0
		};
		if (drop.engagement_type === "views") row.views += drop.quantity;
		if (drop.engagement_type === "likes") row.likes += drop.quantity;
		if (drop.engagement_type === "shares") row.shares += drop.quantity;
		if (drop.engagement_type === "saves") row.saves += drop.quantity;
		row.got += sentOf(drop);
		days.set(day, row);
	}
	const dayRows = [...days.entries()];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3 rounded-[24px] border border-violet-500/30 bg-[#0c1020] p-3 text-white shadow-sm sm:p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[18px] font-bold",
					children: ["Organic Delivery ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `ml-1 rounded-full px-2 py-0.5 align-middle text-[10px] font-bold ${live ? "bg-rose-500 text-white" : "bg-white/10 text-white/70"}`,
						children: live ? "LIVE" : order.status
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[12px] text-white/55",
					children: [
						"Live graph · delivered quantity se banta hai · ",
						sorted.length,
						" batches"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full rounded-2xl bg-gradient-to-r from-violet-600 to-pink-500 px-4 py-3 sm:w-64",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[10px] font-bold tracking-wide text-white/80",
							children: ["NEXT BATCH", next ? ` · ${new Date(next.place_at).toLocaleString("en-IN", {
								day: "2-digit",
								month: "short",
								hour: "numeric",
								minute: "2-digit"
							}).toUpperCase()}` : ""]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[13px] font-bold",
							children: clockLeft || "—"
						})]
					}), next ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[22px] font-bold leading-tight",
						children: [
							next.quantity.toLocaleString("en-IN"),
							" ",
							next.engagement_type
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[12px] text-white/80",
						children: after ? `then ${after.quantity.toLocaleString("en-IN")} ${after.engagement_type}` : next.status
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-[13px]",
						children: "No delivery batches waiting."
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2 lg:grid-cols-5",
				children: [cards.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-white/10 bg-[#14182b] p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: `text-[12px] font-semibold ${card.tone}`,
							children: [
								card.icon,
								" ",
								card.label
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[26px] font-bold leading-none",
							children: card.got.toLocaleString("en-IN")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex items-center justify-between text-[11px] text-white/50",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["of ", card.target.toLocaleString("en-IN")] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: card.tone,
								children: card.note
							})]
						})
					]
				}, card.label)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-white/10 bg-[#14182b] p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[12px] font-semibold text-violet-300",
							children: "↗ Engagement rate"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[26px] font-bold leading-none",
							children: [(gotViews > 0 ? actualRate : 0).toFixed(2), "%"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-[11px] text-white/50",
							children: [deliveredEngagement.toLocaleString("en-IN"), " delivered now"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] text-white/40",
							children: [
								"Planned ",
								plannedRate.toFixed(2),
								"% · ",
								planned.toLocaleString("en-IN"),
								" actions"
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 lg:grid-cols-[1.45fr_0.7fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-white/10 bg-[#101426] p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex flex-wrap items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[14px] font-bold",
								children: "Views & engagement over time"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex rounded-full bg-[#0c1020] p-0.5 text-[11px] font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setMode("batch"),
									className: `rounded-full px-3 py-1 ${mode === "batch" ? "bg-violet-600 text-white" : "text-white/60"}`,
									children: "Per batch"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setMode("total"),
									className: `rounded-full px-3 py-1 ${mode === "total" ? "bg-violet-600 text-white" : "text-white/60"}`,
									children: "Running total"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-1 flex gap-3 text-[11px] text-white/60",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-violet-300",
									children: "● Views"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sky-300",
									children: "● Likes"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-cyan-300",
									children: "● Shares"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-pink-300",
									children: "● Saves"
								})
							]
						}),
						sorted.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "py-16 text-center text-[12px] text-white/50",
							children: "No delivery batches available yet."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
							viewBox: `0 0 ${width} ${height}`,
							className: "h-64 w-full",
							children: [
								yTicks.map((tick) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
									x1: pad.l,
									x2: width - pad.r,
									y1: tick.y,
									y2: tick.y,
									stroke: "#1e293b"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
									x: 2,
									y: tick.y + 3,
									fill: "#94a3b8",
									fontSize: "10",
									children: tick.label
								})] }, tick.label)),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
									d: area,
									fill: "#c084fc",
									opacity: "0.16"
								}),
								chartKeys.filter((key) => (key === "views" ? views : key === "likes" ? likes : key === "shares" ? shares : saves) > 0).map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
									d: linePath(shownLine[key] ?? []),
									fill: "none",
									stroke: chartColor[key],
									strokeWidth: key === "views" ? 2.8 : 2.2,
									strokeLinejoin: "round",
									strokeLinecap: "round"
								}, key)),
								xTicks.map((tick) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
									x: tick.x,
									y: 222,
									textAnchor: "middle",
									fill: "#94a3b8",
									fontSize: "10",
									children: tick.label
								}, tick.label))
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 rounded-2xl border border-white/10 p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[14px] font-bold",
										children: [
											"Bot score ",
											bot.score,
											"/100"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "rounded-full border border-white/20 px-2 py-0.5 text-[11px]",
										children: [
											bot.band,
											" · ",
											bot.name
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 h-2 overflow-hidden rounded-full bg-white/10",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-2 rounded-full",
										style: {
											width: `${bot.score}%`,
											background: botBar
										}
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-[12px] font-semibold",
									children: bot.action
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-white/10 bg-[#14182b] p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[13px] font-bold",
							children: "Engagement mix"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
								viewBox: "0 0 100 100",
								className: "size-24",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
										cx: "50",
										cy: "50",
										r: "28",
										fill: "none",
										stroke: "rgba(255,255,255,0.08)",
										strokeWidth: "12"
									}),
									mixTotal > 0 && mix.map((item) => {
										const len = item.value / mixTotal * ring;
										const node = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
											cx: "50",
											cy: "50",
											r: "28",
											fill: "none",
											stroke: item.color,
											strokeWidth: "12",
											strokeDasharray: `${len} ${ring - len}`,
											strokeDashoffset: -ringAt,
											transform: "rotate(-90 50 50)"
										}, item.label);
										ringAt += len;
										return node;
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("text", {
										x: "50",
										y: "48",
										textAnchor: "middle",
										fill: "white",
										fontSize: "12",
										fontWeight: "700",
										children: [(gotViews > 0 ? actualRate : 0).toFixed(2), "%"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
										x: "50",
										y: "60",
										textAnchor: "middle",
										fill: "rgba(255,255,255,0.55)",
										fontSize: "7",
										children: "OF VIEWS"
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[12px]",
								children: mix.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "flex justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										style: { color: item.color },
										children: item.label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: item.value.toLocaleString("en-IN") })]
								}, item.label))
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-white/10 bg-[#14182b] p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[13px] font-bold",
							children: "Daily breakdown"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 space-y-2",
							children: [dayRows.slice(0, 4).map(([day, row], index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-[12px]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"Day ",
									index + 1,
									" · ",
									day
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.views.toLocaleString("en-IN") })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 h-2 overflow-hidden rounded-full bg-white/10",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-gradient-to-r from-violet-500 to-pink-400",
									style: { width: `${views ? Math.min(100, row.views / views * 100) : 0}%` }
								})
							})] }, day)), dayRows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[12px] text-white/50",
								children: "No delivery batches available yet."
							})]
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-white/10 bg-[#101426] p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[14px] font-bold",
						children: "Batch schedule"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex rounded-full bg-[#0c1020] p-0.5 text-[11px] font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setSchedule("batch"),
							className: `rounded-full px-3 py-1 ${schedule === "batch" ? "bg-violet-600" : "text-white/60"}`,
							children: "By batch"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setSchedule("day"),
							className: `rounded-full px-3 py-1 ${schedule === "day" ? "bg-violet-600" : "text-white/60"}`,
							children: "Daily summary"
						})]
					})]
				}), schedule === "day" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-2 sm:grid-cols-2",
					children: dayRows.map(([day, row], index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-violet-600/80 px-3 py-2 text-[12px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: ["Day ", index + 1] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							day,
							" · ",
							row.views.toLocaleString("en-IN"),
							" views · likes ",
							row.likes.toLocaleString("en-IN"),
							" · shares ",
							row.shares.toLocaleString("en-IN"),
							" · saves ",
							row.saves.toLocaleString("en-IN")
						] })]
					}, day))
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [sorted.slice(0, shown).map((drop, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2 rounded-xl border border-white/10 px-3 py-1.5 text-[12px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", {
								className: "text-violet-300",
								children: ["#", index + 1]
							}),
							" ",
							drop.status,
							" · ",
							new Date(drop.place_at).toLocaleString("en-IN", {
								day: "2-digit",
								month: "short",
								hour: "2-digit",
								minute: "2-digit"
							}),
							" · +",
							drop.quantity.toLocaleString("en-IN"),
							" ",
							drop.engagement_type
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate text-white/50",
							children: drop.service_label || "scheduled"
						})]
					}, drop.id)), shown < sorted.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setShown((count) => count + 12),
						className: "text-[12px] font-semibold text-violet-300",
						children: "Load more"
					})]
				})]
			})
		]
	});
}
var TONE = {
	views: "text-sky-600 bg-sky-50",
	likes: "text-emerald-600 bg-emerald-50",
	saves: "text-amber-600 bg-amber-50",
	shares: "text-blue-600 bg-blue-50",
	reposts: "text-violet-600 bg-violet-50"
};
function DetailPage() {
	const { id } = Route$6.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Authed, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, { id }) });
}
function Detail({ id }) {
	const [order, setOrder] = (0, import_react.useState)(void 0);
	const [drops, setDrops] = (0, import_react.useState)([]);
	const [error, setError] = (0, import_react.useState)("");
	const [statusNote, setStatusNote] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)({});
	const [edit, setEdit] = (0, import_react.useState)(null);
	const [qty, setQty] = (0, import_react.useState)("");
	const [when, setWhen] = (0, import_react.useState)("");
	const [checked, setChecked] = (0, import_react.useState)("");
	function load() {
		const stamp = Date.now();
		fetch(`/api/drops/${id}?t=${stamp}`, {
			cache: "no-store",
			headers: { "cache-control": "no-cache" }
		}).then((res) => {
			if (!res.ok) throw new Error(`drops ${res.status}`);
			return res.json();
		}).then((data) => {
			setDrops(data.drops || []);
			if (data.status) setOrder((current) => current ? {
				...current,
				status: data.status
			} : current);
			setError("");
		}).catch(() => {
			listOrderDrops({ data: {
				id,
				t: stamp
			} }).then(setDrops).catch((err) => setError(err instanceof Error ? err.message : "Could not load runs."));
		});
		getOrder({ data: {
			id,
			t: stamp
		} }).then(setOrder).catch(() => void 0);
		setChecked((/* @__PURE__ */ new Date()).toLocaleTimeString("en-IN", {
			hour: "2-digit",
			minute: "2-digit",
			second: "2-digit"
		}));
	}
	(0, import_react.useEffect)(() => {
		load();
		const timer = window.setInterval(load, 4e3);
		return () => window.clearInterval(timer);
	}, [id]);
	const sorted = (0, import_react.useMemo)(() => [...drops].sort((a, b) => a.place_at.localeCompare(b.place_at)), [drops]);
	if (order === void 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-[#64748b]",
		children: "Loading order…"
	});
	if (!order) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-rose-600",
		children: error || "Order not found."
	});
	const delivered = drops.reduce((sum, drop) => sum + sentOf(drop), 0);
	const total = order.items.reduce((sum, item) => sum + item.quantity, 0);
	const placed = drops.filter((drop) => drop.status === "placed").length;
	const pending = drops.filter((drop) => drop.status === "waiting" || drop.status === "paused").length;
	const active = drops.filter((drop) => drop.status === "placing").length;
	const next = sorted.find((drop) => drop.status === "waiting" || drop.status === "placing");
	const pct = total ? Math.round(delivered / total * 100) : 0;
	const running = /* @__PURE__ */ new Map();
	const editIndex = edit ? sorted.findIndex((drop) => drop.id === edit.id) + 1 : 0;
	function openEdit(drop) {
		setEdit(drop);
		setQty(String(drop.quantity));
		setWhen(toLocal(drop.place_at));
		setError("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl space-y-4 pb-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/engagement-orders",
								className: "text-[18px] text-[#64748b]",
								children: "←"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "text-[22px] font-bold",
								children: ["Order #", order.order_number.replace("MAG-", "")]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-[#111827] px-2 py-0.5 text-[10px] font-bold text-white",
								children: order.status
							}),
							order.organic && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-700",
								children: "Organic"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-[#eef4ff] px-2 py-0.5 text-[10px] font-bold text-[#2563eb]",
								children: "LIVE TRACKING"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: order.link,
						target: "_blank",
						rel: "noreferrer",
						className: "mt-1 block max-w-lg truncate text-[12px] text-[#64748b]",
						children: order.link
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-[#94a3b8]",
							children: "Auto-updating"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] text-[#94a3b8]",
							children: ["Last: ", checked]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: load,
							className: "mt-1 rounded-full border bg-white px-3 py-1.5 text-[12px] font-semibold",
							children: "Refresh"
						}),
						order.status !== "cancelled" && order.status !== "complete" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setOrderFlow({ data: {
									orderId: order.id,
									status: order.status === "paused" ? "waiting" : "paused"
								} }).then(load),
								className: "rounded-full bg-[#5b4dff] px-3 py-1.5 text-[12px] font-semibold text-white",
								children: order.status === "paused" ? "Resume" : "Pause"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setOrderFlow({ data: {
									orderId: order.id,
									status: "cancelled"
								} }).then(load),
								className: "rounded-full bg-rose-500 px-3 py-1.5 text-[12px] font-semibold text-white",
								children: "Cancel"
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrganicBoard, {
				order,
				drops
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[24px] border border-[#e7eef6] bg-white p-4 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "Live order menu"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-emerald-50 px-2 py-1 text-[11px] font-semibold text-emerald-700",
						children: "Auto-updating"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-3",
					children: order.items.map((item) => {
						const mine = drops.filter((drop) => drop.engagement_type === item.engagement_type).sort((a, b) => a.place_at.localeCompare(b.place_at));
						const sent = mine.reduce((sum, drop) => sum + sentOf(drop), 0);
						const placedQty = mine.filter((drop) => drop.status === "placed").reduce((sum, drop) => sum + drop.quantity, 0);
						const doneRuns = mine.filter((drop) => drop.status === "placed").length;
						const leftRuns = mine.filter((drop) => drop.status === "waiting" || drop.status === "paused" || drop.status === "placing").length;
						const nextRun = mine.find((drop) => drop.status === "waiting" || drop.status === "placing");
						const last = mine[mine.length - 1];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: `rounded-2xl p-3 ${TONE[item.engagement_type] || "bg-[#f8fafc]"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
										className: "capitalize",
										children: item.engagement_type
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[12px] font-semibold",
										children: [
											sent.toLocaleString("en-IN"),
											" deliver / ",
											item.quantity.toLocaleString("en-IN"),
											" · ",
											placedQty.toLocaleString("en-IN"),
											" place ho chuke"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-[12px] text-[#334155]",
									children: [
										doneRuns,
										" run place ho chuke · ",
										leftRuns,
										" run bache · ",
										Math.max(0, item.quantity - sent).toLocaleString("en-IN"),
										" deliver bacha"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[12px] text-[#334155]",
									children: [nextRun ? `Next ${clock(nextRun.place_at)} (${fromNow(nextRun.place_at)})` : "Koi pending run nahi", last ? ` · last ${clock(last.place_at)}` : ""]
								})
							]
						}, item.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[24px] border border-[#e7eef6] bg-white p-4 shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[12px] font-bold tracking-widest text-[#334155]",
							children: "LIVE TRACKING"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rounded-full bg-emerald-50 px-3 py-1 text-[12px] font-semibold text-emerald-700",
							children: next ? `Next: ${fromNow(next.place_at)}` : "No pending run"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-5 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Count, {
								n: drops.length,
								label: "Total runs"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Count, {
								n: placed,
								label: "Placed"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Count, {
								n: active,
								label: "In progress"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Count, {
								n: pending,
								label: "Pending"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Count, {
								n: delivered,
								label: "Delivered"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex justify-between text-[13px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Overall progress" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [
							delivered.toLocaleString("en-IN"),
							" / ",
							total.toLocaleString("en-IN")
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 h-2 overflow-hidden rounded-full bg-[#eef3f8]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-[#93c5fd]",
							style: { width: `${pct}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1 flex justify-between text-[12px] text-[#94a3b8]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							placed,
							" of ",
							drops.length,
							" runs sent"
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [pct, "% done"] })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[24px] border border-[#e7eef6] bg-white p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 text-[15px] font-semibold",
					children: "Delivery counters"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: order.items.map((item) => {
						const done = drops.filter((drop) => drop.engagement_type === item.engagement_type).reduce((sum, drop) => sum + sentOf(drop), 0);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-[#eef2f6] p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
										className: "capitalize",
										children: item.engagement_type
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[12px] text-[#64748b]",
										children: [item.quantity ? Math.round(done / item.quantity * 100) : 0, "%"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									k: "Target",
									v: item.quantity
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									k: "Delivered",
									v: done
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									k: "Remaining",
									v: Math.max(0, item.quantity - done)
								})
							]
						}, item.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[24px] border border-[#e7eef6] bg-white p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 font-semibold",
					children: "Live engagement stats"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: order.items.map((item) => {
						const mine = drops.filter((drop) => drop.engagement_type === item.engagement_type);
						const done = mine.reduce((sum, drop) => sum + sentOf(drop), 0);
						const paused = mine.some((drop) => drop.status === "paused");
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: `rounded-2xl p-3 ${TONE[item.engagement_type] || "bg-[#f8fafc]"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-bold uppercase",
									children: item.engagement_type
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[22px] font-bold text-[#0f172a]",
									children: [
										done.toLocaleString("en-IN"),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[13px] font-medium text-[#64748b]",
											children: ["/ ", item.quantity.toLocaleString("en-IN")]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 h-1.5 overflow-hidden rounded-full bg-white/80",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-full bg-[#60a5fa]",
										style: { width: `${item.quantity ? Math.min(100, done / item.quantity * 100) : 0}%` }
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setRunState({ data: {
											orderId: order.id,
											type: item.engagement_type,
											status: paused ? "waiting" : "paused"
										} }).then(load),
										className: "h-8 flex-1 rounded-lg bg-white text-[12px] font-semibold",
										children: paused ? "Resume" : "Pause"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										disabled: item.status === "cancelled",
										onClick: () => setRunState({ data: {
											orderId: order.id,
											type: item.engagement_type,
											status: "cancelled"
										} }).then(load).catch((err) => setError(err instanceof Error ? err.message : "Cancel failed.")),
										className: "h-8 flex-1 rounded-lg bg-[#2563eb] text-[12px] font-semibold text-white disabled:bg-[#cbd5e1]",
										children: item.status === "cancelled" ? "Cancelled" : "Cancel"
									})]
								})
							]
						}, item.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[24px] border border-[#e7eef6] bg-white p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "font-semibold",
							children: ["Run schedule ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "rounded-full bg-[#f1f5f9] px-2 py-0.5 text-[11px] font-medium text-[#64748b]",
								children: [drops.length, " total runs"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded-full bg-emerald-50 px-2 py-1 text-[12px] text-emerald-700",
							children: [placed, " sent"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-[13px] font-semibold",
						children: "Organic delivery timeline"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-3 grid grid-cols-2 gap-2 sm:grid-cols-4",
						children: order.items.map((item) => {
							const done = drops.filter((drop) => drop.engagement_type === item.engagement_type).reduce((sum, drop) => sum + sentOf(drop), 0);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl bg-[#fff8eb] px-2 py-3 text-center text-[12px]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [
									done.toLocaleString("en-IN"),
									"/",
									item.quantity.toLocaleString("en-IN")
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "uppercase text-[#94a3b8]",
									children: item.engagement_type
								})]
							}, item.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-3",
						children: sorted.map((drop, index) => {
							running.set(drop.engagement_type, (running.get(drop.engagement_type) ?? 0) + (drop.status === "cancelled" ? 0 : drop.quantity));
							const hot = drop.status === "placing" || drop.status === "placed";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: `rounded-2xl border p-3 ${hot ? "border-amber-200 bg-amber-50/50" : "border-[#eef2f6] bg-[#f8fbff]"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-wrap items-center gap-2",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: `grid size-8 place-items-center rounded-full text-[12px] font-bold text-white ${hot ? "bg-amber-500" : "bg-[#1d4ed8]"}`,
															children: ["#", index + 1]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "rounded-full bg-white px-2 py-0.5 text-[11px] font-semibold",
															children: label(drop.status)
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-[13px] font-bold text-amber-600",
															children: [
																"+",
																drop.quantity.toLocaleString("en-IN"),
																" ",
																drop.engagement_type
															]
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "mt-1 truncate text-[12px] text-[#2563eb]",
													children: ["via ", drop.service_label || "provider service"]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-[12px] text-[#64748b]",
													children: [
														drop.status === "placed" ? "Run place ho chuka hai" : clock(drop.place_at),
														" ",
														drop.status === "waiting" ? `· Next in ${fromNow(drop.place_at)}` : ""
													]
												}),
												drop.status === "placed" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-[12px] font-semibold text-emerald-700",
													children: [
														drop.sent == null ? "Count pending" : `${drop.sent.toLocaleString("en-IN")}/${drop.quantity.toLocaleString("en-IN")} ${drop.count_source === "video" ? "video pe" : "provider delivered"}`,
														" · ",
														drop.remains == null ? "remains pending" : `${drop.remains.toLocaleString("en-IN")} bacha`,
														drop.live_status ? ` · ${drop.live_status}` : "",
														typeof drop.video_now === "number" ? ` · video abhi ${drop.video_now.toLocaleString("en-IN")}` : ""
													]
												}),
												drop.provider_order_id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-[12px]",
													children: ["Order #", drop.provider_order_id]
												}),
												drop.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-[12px] text-rose-600",
													children: drop.error
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-right",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-[10px] font-semibold tracking-wide text-[#94a3b8]",
													children: "PROVIDER"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "max-w-40 truncate text-[12px] font-semibold text-[#2563eb]",
													children: drop.service_label || "Pending"
												}),
												(drop.status === "waiting" || drop.status === "paused") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => openEdit(drop),
													className: "mt-2 text-[12px] font-semibold text-[#2563eb]",
													children: "Edit"
												}),
												drop.provider_order_id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => checkDropStatus({ data: drop.id }).then((row) => setStatusNote(`#${drop.provider_order_id}: ${row.status}${row.remains ? `, remains ${row.remains}` : ""}`)).catch((err) => setError(err instanceof Error ? err.message : "Status failed.")),
													className: "mt-1 block text-[12px] font-semibold text-[#0f766e]",
													children: "Check now"
												})
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-[11px] font-semibold text-[#64748b]",
										children: "SCHEDULED BY THIS RUN"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-1 grid grid-cols-2 gap-2 sm:grid-cols-4",
										children: order.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-xl bg-[#fff8eb] px-2 py-2 text-center text-[11px]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [
												Math.min(item.quantity, running.get(item.engagement_type) ?? 0).toLocaleString("en-IN"),
												"/",
												item.quantity.toLocaleString("en-IN")
											] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "uppercase text-[#94a3b8]",
												children: [item.engagement_type, " scheduled"]
											})]
										}, item.id))
									})
								]
							}, drop.id);
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-[16px] font-semibold",
				children: "Per-service history"
			}),
			order.items.map((item) => {
				const mine = drops.filter((drop) => drop.engagement_type === item.engagement_type).sort((a, b) => a.place_at.localeCompare(b.place_at));
				const done = mine.reduce((sum, drop) => sum + sentOf(drop), 0);
				const waiting = mine.filter((drop) => drop.status === "waiting" || drop.status === "paused");
				const shown = open[item.engagement_type] !== false;
				const nextRun = waiting[0];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-[24px] border border-[#e7eef6] bg-white p-4 shadow-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-semibold capitalize",
									children: item.service_name || item.engagement_type
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-[12px] text-[#64748b]",
									children: order.link
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: item.quantity.toLocaleString("en-IN") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setRunState({ data: {
											orderId: order.id,
											type: item.engagement_type,
											status: waiting.some((drop) => drop.status === "paused") ? "waiting" : "paused"
										} }).then(load),
										className: "rounded-full border px-3 py-1 text-[12px] font-semibold",
										children: "Pause"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setRunState({ data: {
											orderId: order.id,
											type: item.engagement_type,
											status: "cancelled"
										} }).then(load),
										className: "grid size-8 place-items-center rounded-full border text-rose-500",
										children: "×"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-[#eef4ff] px-2 py-1 text-[10px] font-bold text-[#2563eb]",
										children: mine.length === 0 ? "NO RUNS" : waiting.length ? "PENDING" : "DONE"
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[12px] font-bold tracking-wide text-emerald-600",
								children: "LIVE DELIVERY TRACKING"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[12px] text-emerald-700",
								children: nextRun ? `Next: ${fromNow(nextRun.place_at)}` : "No pending run"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 grid grid-cols-5 border-y border-[#eef2f6] py-3 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Count, {
									n: mine.length,
									label: "Total runs"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Count, {
									n: mine.filter((drop) => drop.status === "placed").length,
									label: "Placed"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Count, {
									n: mine.filter((drop) => drop.status === "placing").length,
									label: "Processing"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Count, {
									n: waiting.length,
									label: "Pending"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Count, {
									n: done,
									label: "Delivered"
								})
							]
						}),
						shown && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "divide-y divide-[#eef2f6]",
							children: mine.map((drop, index) => {
								const sum = mine.slice(0, index + 1).filter((row) => row.status !== "cancelled").reduce((totalQty, row) => totalQty + row.quantity, 0);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center justify-between gap-3 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "grid size-8 place-items-center rounded-full bg-[#1d4ed8] text-[12px] font-bold text-white",
											children: ["#", index + 1]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[13px]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "rounded-full bg-[#eef4ff] px-2 py-0.5 text-[11px] font-semibold text-[#2563eb]",
													children: label(drop.status)
												}),
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", {
													className: "text-emerald-600",
													children: [
														"+",
														drop.quantity,
														" ",
														item.engagement_type
													]
												}),
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[#64748b]",
													children: [
														"Scheduled: ",
														Math.min(item.quantity, sum),
														" / ",
														item.quantity
													]
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[12px] text-[#64748b]",
											children: [
												drop.status === "placed" ? `Run place ho chuka hai · ${drop.pct == null ? "live % pending" : `${drop.pct}% deliver`} · ${drop.remains == null ? "remains pending" : `${drop.remains} bacha`}` : clock(drop.place_at),
												" ",
												drop.status === "waiting" ? `(in ${fromNow(drop.place_at)})` : ""
											]
										})] })]
									}), (drop.status === "waiting" || drop.status === "paused") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => openEdit(drop),
										className: "rounded-full border px-3 py-1 text-[12px] font-semibold",
										children: "Edit"
									})]
								}, drop.id);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setOpen((current) => ({
								...current,
								[item.engagement_type]: !shown
							})),
							className: "mt-2 w-full text-center text-[12px] font-semibold text-[#64748b]",
							children: shown ? "Hide schedule" : "Show schedule"
						})
					]
				}, item.id);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[24px] border border-[#e7eef6] bg-white p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 font-semibold",
					children: "Order details"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3 text-[13px] sm:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[#94a3b8]",
							children: "Created"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: new Date(order.created_at).toLocaleString("en-IN", {
							month: "short",
							day: "numeric",
							year: "numeric",
							hour: "2-digit",
							minute: "2-digit"
						}) })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[#94a3b8]",
							children: "Total price"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: inr(order.total_paise) })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[#94a3b8]",
							children: "Variance"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [
							"±",
							order.variance_percent,
							"%"
						] })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[#94a3b8]",
							children: "Peak hours"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: order.organic ? "Enabled" : "Off" })] })
					]
				})]
			}),
			statusNote && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl bg-[#ecfeff] px-3 py-2 text-[13px]",
				children: statusNote
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[13px] text-rose-600",
				children: error
			}),
			edit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40 grid place-items-center bg-black/30 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "w-full max-w-md rounded-3xl bg-white p-5 shadow-2xl",
					onSubmit: async (event) => {
						event.preventDefault();
						try {
							await editScheduledDrop({ data: {
								id: edit.id,
								quantity: Number(qty),
								placeAt: new Date(when).toISOString()
							} });
							setEdit(null);
							load();
						} catch (err) {
							setError(err instanceof Error ? err.message : "Could not save this run.");
						}
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-[18px] font-bold",
								children: "Edit scheduled run"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[12px] text-[#64748b]",
								children: "Modify the quantity or scheduled time for this pending run"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setEdit(null),
								className: "text-[#94a3b8]",
								children: "×"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 inline-flex gap-2 rounded-full bg-[#f8fafc] px-3 py-1 text-[12px] capitalize",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: edit.engagement_type }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Run #", editIndex] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-3 block text-[13px] font-semibold",
							children: ["Quantity to deliver", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: qty,
								onChange: (event) => setQty(event.target.value.replace(/[^\d]/g, "")),
								className: "mt-1 h-11 w-full rounded-xl border border-[#bfdbfe] bg-[#f8fbff] px-3"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-[12px] text-[#94a3b8]",
							children: ["Original: ", edit.quantity]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-[13px] font-semibold",
							children: "Scheduled time"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex flex-wrap gap-2",
							children: [
								1,
								3,
								6,
								12,
								24
							].map((hours) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setWhen(toLocal(new Date(Date.now() + hours * 36e5).toISOString())),
								className: "rounded-full border px-3 py-1 text-[12px] font-semibold",
								children: [
									"+",
									hours,
									"h"
								]
							}, hours))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "datetime-local",
							value: when,
							onChange: (event) => setWhen(event.target.value),
							className: "mt-3 h-11 w-full rounded-xl border px-3"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-[12px] text-[#94a3b8]",
							children: ["Original: ", clock(edit.place_at)]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setEdit(null),
								className: "h-10 rounded-xl border px-4 text-[13px]",
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "h-10 rounded-xl bg-[#2563eb] px-4 text-[13px] font-bold text-white",
								children: "Save changes"
							})]
						})
					]
				})
			})
		]
	});
}
function Count({ n, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-[20px] font-bold",
		children: n.toLocaleString("en-IN")
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-[10px] uppercase tracking-wide text-[#94a3b8]",
		children: label
	})] });
}
function Line({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "mt-1 flex justify-between text-[13px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[#64748b]",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: v.toLocaleString("en-IN") })]
	});
}
function label(status) {
	if (status === "placed") return "Place ho chuka hai";
	if (status === "placing") return "Placing";
	if (status === "paused") return "Paused";
	if (status === "cancelled") return "Cancelled";
	if (status === "failed") return "Failed";
	return "Scheduled";
}
function fromNow(iso) {
	const min = Math.round((new Date(iso).getTime() - Date.now()) / 6e4);
	if (min <= 1) return "less than a minute";
	if (min < 60) return `${min} minutes`;
	const hours = Math.round(min / 60);
	return hours === 1 ? "about 1 hour" : `about ${hours} hours`;
}
function clock(iso) {
	return new Date(iso).toLocaleString("en-IN", {
		month: "short",
		day: "numeric",
		hour: "numeric",
		minute: "2-digit"
	});
}
function toLocal(iso) {
	const date = new Date(iso);
	const pad = (n) => String(n).padStart(2, "0");
	return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}
//#endregion
export { DetailPage as component };
