import { u as getSql } from "./organic-DU6S6wDh.mjs";
import { t as hashPassword$1 } from "./password-VlpK0Xix.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/seed-desk.server-CwE-y2J9.js
var ADMIN_EMAIL = "admin@magiciansmm.com";
var ADMIN_PASSWORD = "Magician#8841";
var ADMIN_CREDIT_PAISE = 2e5;
/** One admin desk with ₹2,000 so the panel can be tested without a payment gateway. */
async function seedTestDesk() {
	const sql = await getSql();
	const inserted = await sql`
    insert into "user" (id, name, email, "emailVerified", "createdAt", "updatedAt")
    values (${crypto.randomUUID()}, 'Admin', ${ADMIN_EMAIL}, true, now(), now())
    on conflict (email) do nothing
    returning id
  `;
	const id = (inserted[0]?.id ? inserted : await sql`select id from "user" where email = ${ADMIN_EMAIL} limit 1`)[0]?.id;
	if (!id) return;
	if (inserted.length > 0) {
		const hash = await hashPassword$1(ADMIN_PASSWORD);
		await sql`
      insert into "account" (id, "accountId", "providerId", "userId", password, "createdAt", "updatedAt")
      values (${crypto.randomUUID()}, ${id}, 'credential', ${id}, ${hash}, now(), now())
    `;
		await sql`
      insert into wallets (user_id, balance_paise)
      values (${id}, ${ADMIN_CREDIT_PAISE})
      on conflict (user_id) do nothing
    `;
		await sql`
      insert into wallet_transactions (id, user_id, kind, amount_paise, note)
      values (${crypto.randomUUID()}, ${id}, 'credit', ${ADMIN_CREDIT_PAISE}, 'Admin opening credit. ₹2,000.')
    `;
	}
	await sql`
    insert into user_roles (user_id, role)
    values (${id}, 'admin')
    on conflict (user_id) do update set role = 'admin'
  `;
}
//#endregion
export { seedTestDesk };
