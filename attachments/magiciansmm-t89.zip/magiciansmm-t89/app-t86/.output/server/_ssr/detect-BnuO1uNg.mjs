import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-DY5Pyta6.mjs";
import { ct as Activity } from "../_libs/lucide-react.mjs";
import { z as createSsrRpc } from "./shell-CfBlaVSk.mjs";
import { n as StaffOnly, t as Authed } from "./gate-DNi4gEUE.mjs";
import { t as listTikTokVideos } from "./tiktok.functions-nU2h4tOs.mjs";
import { a as ResponsiveContainer, i as Area, n as YAxis, o as Tooltip, r as XAxis, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/detect-BnuO1uNg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var detectMedia = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("768fbb2bc3dbe9e0d5796c71f1990a86d7fe0434c0e618e1b81b25dd70e4f535"));
var detectInsights = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((mediaId) => {
	const id = String(mediaId ?? "").trim();
	if (!/^\d+$/.test(id)) throw new Error("Media id galat hai.");
	return id;
}).handler(createSsrRpc("93d3f976c157b34e55b08057955b2bfaac9c7af5f737c53582dccc10d619bf50"));
function zoneOf(risk) {
	if (risk >= 70) return {
		key: "red",
		color: "#fe2c55",
		fill: "#fe2c55",
		label: "Red · botting detect ho jayegi"
	};
	if (risk >= 40) return {
		key: "orange",
		color: "#f59e0b",
		fill: "#f59e0b",
		label: "Orange · middle detection"
	};
	return {
		key: "green",
		color: "#22c55e",
		fill: "#22c55e",
		label: "Green · botting detect hone ka chance sabse kam"
	};
}
function curve(total, kind) {
	const rows = [];
	for (let i = 0; i <= 8; i++) {
		const t = i / 8;
		const rise = kind === "organic" ? (1 - Math.exp(-3.2 * t)) / (1 - Math.exp(-3.2)) : kind === "linear" ? t : kind === "spike" ? Math.pow(t, 3.4) : Math.pow(t, 5) * .25;
		rows.push({
			label: i === 0 ? "0h" : i === 8 ? "2h" : "",
			value: Math.max(0, Math.round(total * rise))
		});
	}
	return rows;
}
function analyze(raw, post) {
	const views = raw.views || raw.impressions || raw.reach || 0;
	const likes = Math.max(raw.likes || 0, post?.like_count || 0);
	const saves = raw.saved || 0;
	const shares = raw.shares || 0;
	const comments = Math.max(raw.comments || 0, post?.comments_count || 0);
	const flags = [];
	const shapes = {
		views: "organic",
		likes: "organic",
		saves: "organic",
		shares: "organic"
	};
	if (views < 20) return {
		views,
		likes,
		saves,
		shares,
		comments,
		risk: 0,
		approve: 0,
		reject: 0,
		note: "Views bahut kam hain. Score tab banega jab post thodi chale.",
		flags: ["Instagram ne itne views nahi diye ki graph judge ho sake."],
		shapes
	};
	const likeRate = likes / views;
	const saveRate = saves / views;
	const shareRate = shares / views;
	const engage = (likes + comments + saves + shares) / views;
	let risk = 12;
	if (engage < .0045) {
		risk += 34;
		shapes.views = "linear";
		flags.push("Views ke saath likes, saves, shares almost nahi. Bot views jaisa pattern.");
	} else if (engage < .012) {
		risk += 16;
		shapes.views = "linear";
		flags.push("Engagement views se kaafi neeche hai.");
	} else if (engage > .12) {
		risk += 22;
		flags.push("Engagement average se bahut upar hai. Bought likes ho sakte hain.");
	}
	if (likeRate > .15) {
		risk += 16;
		shapes.likes = "spike";
		flags.push("Like rate organic se bahut upar hai.");
	} else if (likeRate < .004 && views > 200) {
		risk += 12;
		shapes.likes = "flat";
		flags.push("Likes views ke against bahut kam hain.");
	}
	if (likes > 20 && saves === 0 && shares === 0) {
		risk += 20;
		shapes.saves = "flat";
		shapes.shares = "flat";
		shapes.likes = shapes.likes === "organic" ? "spike" : shapes.likes;
		flags.push("Sirf likes hain. Saves aur shares zero hain, yeh bought likes jaisa hai.");
	}
	if (saveRate > .08 && saves > views) {
		risk += 8;
		flags.push("Saves views se zyada aa rahe hain. Count mismatch, score soft rakha hai.");
	} else if (saveRate > .08) {
		risk += 10;
		shapes.saves = "spike";
		flags.push("Save rate unusual high hai.");
	}
	if (shareRate > .05) {
		risk += 10;
		shapes.shares = "spike";
		flags.push("Share rate unusual high hai.");
	}
	if (comments === 0 && likes > 40) {
		risk += 6;
		flags.push("Comments zero hain. Likes saste hote hain, comments nahi.");
	}
	if (flags.length === 0) flags.push("Ratios organic range ke paas hain. Line smooth rise phir flat hai.");
	risk = Math.max(8, Math.min(100, Math.round(risk)));
	const zone = zoneOf(risk);
	return {
		views,
		likes,
		saves,
		shares,
		comments,
		risk,
		approve: 100 - risk,
		reject: risk,
		note: zone.label,
		flags,
		shapes
	};
}
function StudioChart({ title, total, color, kind, hint }) {
	const id = `fill-${title}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-[#eceff3] bg-white p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[13px] text-[#6b7280]",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[28px] font-semibold leading-none tracking-tight",
				children: total.toLocaleString("en-IN")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 mt-1 text-[11px] text-[#9ca3af]",
				children: hint
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-36",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
						data: curve(total, kind),
						margin: {
							top: 8,
							right: 4,
							left: 0,
							bottom: 0
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
								id,
								x1: "0",
								y1: "0",
								x2: "0",
								y2: "1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
									offset: "0%",
									stopColor: color,
									stopOpacity: .35
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
									offset: "100%",
									stopColor: color,
									stopOpacity: .02
								})]
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "label",
								tick: {
									fontSize: 11,
									fill: "#9ca3af"
								},
								axisLine: false,
								tickLine: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								orientation: "right",
								tick: {
									fontSize: 11,
									fill: "#9ca3af"
								},
								axisLine: false,
								tickLine: false,
								width: 36
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
								type: "monotone",
								dataKey: "value",
								stroke: color,
								strokeWidth: 2,
								fill: `url(#${id})`,
								dot: false
							})
						]
					})
				})
			})
		]
	});
}
function Page() {
	const [platform, setPlatform] = (0, import_react.useState)("instagram");
	const [username, setUsername] = (0, import_react.useState)("");
	const [media, setMedia] = (0, import_react.useState)([]);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [counts, setCounts] = (0, import_react.useState)(null);
	const [note, setNote] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const params = new URLSearchParams(window.location.search);
		if (params.get("tt") === "connected") {
			setPlatform("tiktok");
			setNote("TikTok connect ho gaya. Video pe click karo.");
		}
		if (params.get("tt") === "error") setNote(params.get("reason") || "TikTok connect fail.");
	}, []);
	(0, import_react.useEffect)(() => {
		setMedia([]);
		setSelected(null);
		setCounts(null);
		if (platform === "instagram") {
			detectMedia().then((result) => {
				setUsername(result.username);
				setMedia(result.media);
			}).catch((err) => setNote(err instanceof Error ? err.message : "Media load nahi hui."));
			return;
		}
		listTikTokVideos().then((result) => {
			setUsername(result.username);
			setMedia(result.videos.map((video) => ({
				id: video.id,
				caption: video.caption,
				permalink: video.permalink,
				like_count: video.like_count,
				comments_count: video.comments_count,
				view_count: video.view_count,
				share_count: video.share_count
			})));
			if (!result.connected) setNote("");
		}).catch((err) => setNote(err instanceof Error ? err.message : "TikTok videos nahi mili."));
	}, [platform]);
	async function check(item) {
		setSelected(item);
		setBusy(true);
		setNote("");
		try {
			if (platform === "tiktok") {
				setCounts({
					views: item.view_count ?? 0,
					likes: item.like_count ?? 0,
					comments: item.comments_count ?? 0,
					shares: item.share_count ?? 0,
					saved: 0
				});
				return;
			}
			setCounts(await detectInsights({ data: item.id }));
		} catch (err) {
			setCounts(null);
			setNote(err instanceof Error ? err.message : "Insights fail.");
		} finally {
			setBusy(false);
		}
	}
	const verdict = counts ? analyze(counts, selected ?? void 0) : null;
	const zone = verdict && verdict.views >= 20 ? zoneOf(verdict.risk) : null;
	const scoreLine = verdict ? curve(verdict.risk, verdict.risk >= 70 ? "spike" : verdict.risk >= 40 ? "linear" : "organic").map((row, i, all) => ({
		...row,
		label: i === 0 ? "0" : i === all.length - 1 ? String(verdict.risk) : row.label === "2h" ? "" : ""
	})) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-[#eceff3] bg-white p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "flex items-center gap-2 text-[20px] font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-9 place-items-center rounded-xl bg-[#111827] text-white",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-4" })
						}), "Video analysis"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex rounded-full bg-[#f3f4f6] p-1 text-[13px] font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								setPlatform("instagram");
								setCounts(null);
								setSelected(null);
							},
							className: `rounded-full px-3 py-1.5 ${platform === "instagram" ? "bg-white" : "text-[#6b7280]"}`,
							children: "Instagram"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								setPlatform("tiktok");
								setCounts(null);
								setSelected(null);
								setNote("");
							},
							className: `rounded-full px-3 py-1.5 ${platform === "tiktok" ? "bg-white" : "text-[#6b7280]"}`,
							children: "TikTok"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-[12px] text-[#6b7280]",
					children: platform === "instagram" ? `@${username || "account"} · line ka shape batata hai delivery organic hai ya bot jaisi. Instagram hourly history nahi bhejta.` : username ? `@${username} · TikTok public videos. Saves API nahi deta.` : "TikTok connect karo. Allow ke baad public videos yahan aayengi."
				})]
			}),
			platform === "tiktok" && media.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-[#eceff3] bg-white p-6 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[13px] text-[#6b7280]",
						children: "TikTok account connect nahi hai."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/api/tiktok/start",
						className: "mt-3 inline-flex h-11 items-center rounded-xl bg-[#111827] px-4 text-[13px] font-bold text-white",
						children: "Connect TikTok"
					}),
					note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-[12px] text-rose-600",
						children: note
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-[#eceff3] bg-white p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[12px] font-medium text-[#6b7280]",
						children: "Recent posts"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 space-y-2",
						children: media.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => check(item),
							className: `w-full rounded-xl px-3 py-2 text-left ${selected?.id === item.id ? "bg-[#f3f4f6]" : "hover:bg-[#fafafa]"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[13px] font-medium",
								children: item.caption?.slice(0, 90) || item.permalink || item.id
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[11px] text-[#9ca3af]",
								children: [
									item.media_type,
									" · ",
									item.like_count ?? 0,
									" likes"
								]
							})]
						}) }, item.id))
					}),
					note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-[12px] text-rose-600",
						children: note
					})
				]
			}),
			busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[13px] text-[#6b7280]",
				children: "Graph ban raha hai..."
			}),
			verdict && zone && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 md:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioChart, {
						title: "Views",
						total: verdict.views,
						color: "#2b7fff",
						kind: verdict.shapes.views,
						hint: verdict.shapes.views === "organic" ? "Smooth rise, phir slow" : "Seedha ya sudden rise · bot jaisa"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioChart, {
						title: "Likes",
						total: verdict.likes,
						color: "#fe2c55",
						kind: verdict.shapes.likes,
						hint: verdict.shapes.likes === "flat" ? "Flat · views ke saath nahi chale" : verdict.shapes.likes === "spike" ? "End pe spike" : "Views ke saath organic"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioChart, {
						title: "Saves",
						total: verdict.saves,
						color: "#22c55e",
						kind: verdict.shapes.saves,
						hint: verdict.shapes.saves === "flat" ? "Zero ya flat" : "Save curve"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioChart, {
						title: "Shares",
						total: verdict.shares,
						color: "#f59e0b",
						kind: verdict.shapes.shares,
						hint: verdict.shapes.shares === "flat" ? "Zero ya flat" : "Share curve"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-[#eceff3] bg-white p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[13px] text-[#6b7280]",
						children: "Bot score"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[28px] font-semibold",
						style: { color: zone.color },
						children: [verdict.risk, "%"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[12px]",
						style: { color: zone.color },
						children: zone.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[12px] text-[#6b7280]",
						children: [
							"Approve ",
							verdict.approve,
							"% · Reject ",
							verdict.reject,
							"% · Comments ",
							verdict.comments
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 h-44",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
								data: scoreLine,
								margin: {
									top: 8,
									right: 4,
									left: 0,
									bottom: 0
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
										id: "scoreFill",
										x1: "0",
										y1: "0",
										x2: "0",
										y2: "1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
											offset: "0%",
											stopColor: zone.color,
											stopOpacity: .35
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
											offset: "100%",
											stopColor: zone.color,
											stopOpacity: .02
										})]
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "label",
										tick: {
											fontSize: 11,
											fill: "#9ca3af"
										},
										axisLine: false,
										tickLine: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										orientation: "right",
										domain: [0, 100],
										ticks: [
											30,
											60,
											100
										],
										tick: {
											fontSize: 11,
											fill: "#9ca3af"
										},
										axisLine: false,
										tickLine: false,
										width: 32
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
										type: "monotone",
										dataKey: "value",
										stroke: zone.color,
										strokeWidth: 2,
										fill: "url(#scoreFill)",
										dot: false
									})
								]
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 list-disc pl-5 text-[12px] text-[#4b5563]",
						children: verdict.flags.map((flag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: flag }, flag))
					})
				]
			})] })
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Authed, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StaffOnly, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {}) }) });
//#endregion
export { SplitComponent as component };
