import { r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-DY5Pyta6.mjs";
import { u as getSql } from "./organic-DU6S6wDh.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
import { g as requireAdmin } from "./admin.server-B6p1lYbS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/detect.functions-DtDrwN2X.js
async function tokenFor(userId) {
	const row = (await (await getSql())`
    select access_token, username from instagram_oauth
    where user_id = ${userId}
    order by created_at desc
    limit 1
  `)[0];
	if (!row?.access_token) throw new Error("Pehle Instagram Accounts se account connect karo.");
	return row;
}
async function listConnectedMedia(userId) {
	const { access_token, username } = await tokenFor(userId);
	const url = new URL("https://graph.instagram.com/me/media");
	url.searchParams.set("fields", "id,caption,media_type,permalink,timestamp,like_count,comments_count,thumbnail_url");
	url.searchParams.set("access_token", access_token);
	url.searchParams.set("limit", "12");
	const res = await fetch(url);
	const body = await res.json().catch(() => ({}));
	if (!res.ok) throw new Error(body.error?.message || "Instagram media list nahi mili.");
	return {
		username,
		media: body.data ?? []
	};
}
async function mediaInsights(userId, mediaId) {
	const { access_token } = await tokenFor(userId);
	const metrics = [
		"reach",
		"likes",
		"comments",
		"saved",
		"shares",
		"views",
		"impressions",
		"total_interactions"
	];
	const counts = {};
	for (const metric of metrics) {
		const url = new URL(`https://graph.instagram.com/${mediaId}/insights`);
		url.searchParams.set("metric", metric);
		url.searchParams.set("access_token", access_token);
		const res = await fetch(url);
		const body = await res.json().catch(() => ({}));
		if (!res.ok) continue;
		for (const item of body.data ?? []) {
			const value = item.values?.[0]?.value ?? item.value ?? 0;
			counts[item.name] = Number(value) || 0;
		}
	}
	if (Object.keys(counts).length === 0) throw new Error("Is post ke insights nahi mile. Account professional hona chahiye.");
	return counts;
}
var detectMedia_createServerFn_handler = createServerRpc({
	id: "768fbb2bc3dbe9e0d5796c71f1990a86d7fe0434c0e618e1b81b25dd70e4f535",
	name: "detectMedia",
	filename: "src/lib/detect.functions.ts"
}, (opts) => detectMedia.__executeServer(opts));
var detectMedia = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(detectMedia_createServerFn_handler, async ({ context }) => {
	await requireAdmin(context.userId);
	return listConnectedMedia(context.userId);
});
var detectInsights_createServerFn_handler = createServerRpc({
	id: "93d3f976c157b34e55b08057955b2bfaac9c7af5f737c53582dccc10d619bf50",
	name: "detectInsights",
	filename: "src/lib/detect.functions.ts"
}, (opts) => detectInsights.__executeServer(opts));
var detectInsights = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((mediaId) => {
	const id = String(mediaId ?? "").trim();
	if (!/^\d+$/.test(id)) throw new Error("Media id galat hai.");
	return id;
}).handler(detectInsights_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	return mediaInsights(context.userId, data);
});
//#endregion
export { detectInsights_createServerFn_handler, detectMedia_createServerFn_handler };
