import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as adminSaveGateway, et as inr, g as adminPaymentClaims, v as adminReviewPayment } from "./shell-CfBlaVSk.mjs";
import { t as Authed } from "./gate-DNi4gEUE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.payments-CO4pDq0f.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EMPTY = {
	id: "",
	name: "",
	account_title: "",
	account_number: "",
	ifsc: "",
	instructions: "",
	qr_image: "",
	min_paise: 1e4,
	max_paise: 1e7,
	enabled: true,
	archived: false,
	pay_mode: "manual",
	pay_currency: "INR",
	network: "",
	pay_kind: "upi"
};
function shrink(file) {
	return new Promise((resolve, reject) => {
		const image = new Image();
		image.onload = () => {
			const canvas = document.createElement("canvas");
			const scale = Math.min(1, 900 / image.width);
			canvas.width = Math.max(1, image.width * scale);
			canvas.height = Math.max(1, image.height * scale);
			canvas.getContext("2d")?.drawImage(image, 0, 0, canvas.width, canvas.height);
			resolve(canvas.toDataURL("image/jpeg", .72));
		};
		image.onerror = () => reject(/* @__PURE__ */ new Error("Could not read that image."));
		image.src = URL.createObjectURL(file);
	});
}
function parseAddrs(network, fallback) {
	const rows = network.split("\n").map((line) => {
		const [net, address] = line.split("|").map((part) => part.trim());
		return address ? {
			network: net || "TRC20",
			address
		} : null;
	}).filter((row) => Boolean(row));
	if (rows.length === 0 && fallback) rows.push({
		network: "TRC20",
		address: fallback
	});
	return rows.length ? rows : [{
		network: "TRC20",
		address: ""
	}];
}
function Payments() {
	const [gates, setGates] = (0, import_react.useState)([]);
	const [form, setForm] = (0, import_react.useState)(EMPTY);
	const [claims, setClaims] = (0, import_react.useState)([]);
	const [message, setMessage] = (0, import_react.useState)("");
	const [reason, setReason] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("pending");
	const [openShot, setOpenShot] = (0, import_react.useState)("");
	const [razor, setRazor] = (0, import_react.useState)({
		id: "",
		title: "",
		upi: "",
		qr: "",
		min: 100,
		max: 1e5
	});
	const [jazz, setJazz] = (0, import_react.useState)({
		id: "",
		title: "",
		number: "",
		iban: "",
		qr: "",
		min: 100,
		max: 5e5
	});
	const [crypto, setCrypto] = (0, import_react.useState)({
		id: "",
		rate: 90,
		min: 5,
		max: 5e3,
		qr: "",
		addresses: [{
			network: "TRC20",
			address: ""
		}, {
			network: "BEP20",
			address: ""
		}]
	});
	function load() {
		adminPaymentClaims().then((result) => {
			setGates(result.gateways);
			setClaims(result.claims);
			const razorGate = result.gateways.find((gate) => gate.pay_kind === "razorpay");
			if (razorGate) setRazor({
				id: razorGate.id,
				title: razorGate.account_title,
				upi: razorGate.account_number,
				qr: razorGate.qr_image,
				min: razorGate.pay_currency === "INR" ? razorGate.min_paise / 100 : 100,
				max: razorGate.max_paise / 100 || 1e5
			});
			const jazzGate = result.gateways.find((gate) => gate.pay_kind === "jazzcash");
			if (jazzGate) setJazz({
				id: jazzGate.id,
				title: jazzGate.account_title,
				number: jazzGate.account_number,
				iban: jazzGate.ifsc,
				qr: jazzGate.qr_image,
				min: jazzGate.pay_currency === "PKR" ? jazzGate.min_paise / 100 : 100,
				max: jazzGate.max_paise / 100 || 5e5
			});
			const cryptoGate = result.gateways.find((gate) => gate.pay_kind === "crypto" || gate.pay_kind === "usdt");
			if (cryptoGate) setCrypto({
				id: cryptoGate.id,
				rate: Number(cryptoGate.ifsc) || 90,
				min: cryptoGate.pay_currency === "USD" ? cryptoGate.min_paise / 100 : 5,
				max: cryptoGate.pay_currency === "USD" ? cryptoGate.max_paise / 100 : 5e3,
				qr: cryptoGate.qr_image,
				addresses: parseAddrs(cryptoGate.network, cryptoGate.account_number)
			});
		}).catch((err) => setMessage(err instanceof Error ? err.message : "Could not load payments."));
	}
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pay-desk mx-auto w-full min-w-0 max-w-3xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-semibold uppercase tracking-[0.18em] text-[#2563eb]",
					children: "Admin"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-[28px] font-bold",
					children: "Payments"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[13px] text-[#64748b]",
					children: "Razorpay, JazzCash aur Crypto yahin se set karo. Min aur max isi currency mein save hote hain. Customer Pay dabaye to QR, account aur addresses dikhte hain. Approve ke baad wallet credit hota hai."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "pay-card space-y-3 rounded-[24px] border border-[#e7eef6] bg-white p-3 sm:p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "Deposit methods"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pay-card rounded-2xl border p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: "Razorpay"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[12px] text-[#64748b]",
								children: "Min default 100 INR"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 grid gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: razor.title,
										onChange: (event) => setRazor({
											...razor,
											title: event.target.value
										}),
										placeholder: "Account name",
										className: "h-11 rounded-xl border px-3 text-[13px]"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: razor.upi,
										onChange: (event) => setRazor({
											...razor,
											upi: event.target.value
										}),
										placeholder: "UPI number",
										className: "h-11 rounded-xl border px-3 text-[13px]"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: razor.min,
											onChange: (event) => setRazor({
												...razor,
												min: Number(event.target.value) || 0
											}),
											placeholder: "Min INR",
											className: "h-11 rounded-xl border px-3 text-[13px]"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: razor.max,
											onChange: (event) => setRazor({
												...razor,
												max: Number(event.target.value) || 0
											}),
											placeholder: "Max INR",
											className: "h-11 rounded-xl border px-3 text-[13px]"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex h-11 cursor-pointer items-center rounded-xl border px-3 text-[13px] font-semibold",
										children: ["Upload UPI QR", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "file",
											accept: "image/*",
											className: "hidden",
											onChange: async (event) => {
												const file = event.target.files?.[0];
												if (file) setRazor({
													...razor,
													qr: await shrink(file)
												});
											}
										})]
									}),
									razor.qr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: razor.qr,
										alt: "",
										className: "h-24 w-24 rounded-xl border object-contain"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: async () => {
											await adminSaveGateway({ data: {
												id: razor.id,
												name: "Razorpay",
												account_title: razor.title,
												account_number: razor.upi,
												ifsc: "",
												instructions: "Pay this UPI, then submit the transaction id and screenshot.",
												qr_image: razor.qr,
												min_rupees: razor.min || 100,
												max_rupees: razor.max || 1e5,
												enabled: true,
												archived: false,
												pay_mode: "manual",
												pay_currency: "INR",
												network: "",
												pay_kind: "razorpay"
											} });
											setMessage("Razorpay saved. Min " + (razor.min || 100) + " INR.");
											load();
										},
										className: "h-11 rounded-xl bg-[#2563eb] text-[13px] font-bold text-white",
										children: "Save Razorpay"
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pay-card rounded-2xl border p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: "JazzCash"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[12px] text-[#64748b]",
								children: "Min default 100 PKR"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 grid gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: jazz.title,
										onChange: (event) => setJazz({
											...jazz,
											title: event.target.value
										}),
										placeholder: "Account name",
										className: "h-11 rounded-xl border px-3 text-[13px]"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: jazz.number,
										onChange: (event) => setJazz({
											...jazz,
											number: event.target.value
										}),
										placeholder: "JazzCash number",
										className: "h-11 rounded-xl border px-3 text-[13px]"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: jazz.iban,
										onChange: (event) => setJazz({
											...jazz,
											iban: event.target.value
										}),
										placeholder: "IBAN",
										className: "h-11 rounded-xl border px-3 text-[13px]"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: jazz.min,
											onChange: (event) => setJazz({
												...jazz,
												min: Number(event.target.value) || 0
											}),
											placeholder: "Min PKR",
											className: "h-11 rounded-xl border px-3 text-[13px]"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: jazz.max,
											onChange: (event) => setJazz({
												...jazz,
												max: Number(event.target.value) || 0
											}),
											placeholder: "Max PKR",
											className: "h-11 rounded-xl border px-3 text-[13px]"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex h-11 cursor-pointer items-center rounded-xl border px-3 text-[13px] font-semibold",
										children: ["Upload JazzCash QR", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "file",
											accept: "image/*",
											className: "hidden",
											onChange: async (event) => {
												const file = event.target.files?.[0];
												if (file) setJazz({
													...jazz,
													qr: await shrink(file)
												});
											}
										})]
									}),
									jazz.qr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: jazz.qr,
										alt: "",
										className: "h-24 w-24 rounded-xl border object-contain"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: async () => {
											await adminSaveGateway({ data: {
												id: jazz.id,
												name: "JazzCash",
												account_title: jazz.title,
												account_number: jazz.number,
												ifsc: jazz.iban,
												instructions: "JazzCash pe pay karo, phir TID aur screenshot submit karo.",
												qr_image: jazz.qr,
												min_rupees: jazz.min || 100,
												max_rupees: jazz.max || 5e5,
												enabled: true,
												archived: false,
												pay_mode: "manual",
												pay_currency: "PKR",
												network: "",
												pay_kind: "jazzcash"
											} });
											setMessage("JazzCash saved. Min " + (jazz.min || 100) + " PKR.");
											load();
										},
										className: "h-11 rounded-xl bg-[#2563eb] text-[13px] font-bold text-white",
										children: "Save JazzCash"
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pay-card rounded-2xl border p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: "Crypto"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[12px] text-[#64748b]",
								children: "Min default $5. TRC20, BEP20, ya koi bhi network."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 grid min-w-0 gap-2",
								children: [
									crypto.addresses.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid min-w-0 gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid min-w-0 grid-cols-[1fr_auto] gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												value: row.network,
												onChange: (event) => setCrypto({
													...crypto,
													addresses: crypto.addresses.map((item, at) => at === index ? {
														...item,
														network: event.target.value.toUpperCase()
													} : item)
												}),
												placeholder: "TRC20",
												className: "h-11 min-w-0 rounded-xl border px-3 text-[13px]"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setCrypto({
													...crypto,
													addresses: crypto.addresses.filter((_, at) => at !== index)
												}),
												className: "h-11 rounded-xl border px-3 text-[12px]",
												children: "Remove"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: row.address,
											onChange: (event) => setCrypto({
												...crypto,
												addresses: crypto.addresses.map((item, at) => at === index ? {
													...item,
													address: event.target.value.trim()
												} : item)
											}),
											placeholder: "Wallet address",
											className: "h-11 min-w-0 w-full rounded-xl border px-3 text-[13px]"
										})]
									}, index)),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setCrypto({
											...crypto,
											addresses: [...crypto.addresses, {
												network: "BEP20",
												address: ""
											}]
										}),
										className: "h-10 w-full rounded-xl border text-[12px] font-semibold",
										children: "Add another address"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid min-w-0 grid-cols-1 gap-2 sm:grid-cols-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												value: crypto.rate,
												onChange: (event) => setCrypto({
													...crypto,
													rate: Number(event.target.value) || 0
												}),
												placeholder: "INR per 1 USDT",
												className: "h-11 rounded-xl border px-3 text-[13px]"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												value: crypto.min,
												onChange: (event) => setCrypto({
													...crypto,
													min: Number(event.target.value) || 0
												}),
												placeholder: "Min USD",
												className: "h-11 rounded-xl border px-3 text-[13px]"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												value: crypto.max,
												onChange: (event) => setCrypto({
													...crypto,
													max: Number(event.target.value) || 0
												}),
												placeholder: "Max USD",
												className: "h-11 rounded-xl border px-3 text-[13px]"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex h-11 cursor-pointer items-center rounded-xl border px-3 text-[13px] font-semibold",
										children: ["Upload crypto QR", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "file",
											accept: "image/*",
											className: "hidden",
											onChange: async (event) => {
												const file = event.target.files?.[0];
												if (file) setCrypto({
													...crypto,
													qr: await shrink(file)
												});
											}
										})]
									}),
									crypto.qr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: crypto.qr,
										alt: "",
										className: "h-24 w-24 rounded-xl border object-contain"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: async () => {
											const addresses = crypto.addresses.filter((row) => row.address);
											await adminSaveGateway({ data: {
												id: crypto.id,
												name: "Crypto",
												account_title: "Crypto",
												account_number: addresses[0]?.address || "",
												ifsc: String(crypto.rate || 90),
												instructions: "Send only on the network written next to the address.",
												qr_image: crypto.qr,
												min_rupees: crypto.min || 5,
												max_rupees: crypto.max || 5e3,
												enabled: true,
												archived: false,
												pay_mode: "manual",
												pay_currency: "USD",
												network: addresses.map((row) => `${row.network || "TRC20"} | ${row.address}`).join("\n"),
												pay_kind: "crypto"
											} });
											setMessage("Crypto saved. Min $" + (crypto.min || 5) + ".");
											load();
										},
										className: "h-11 rounded-xl bg-[#2563eb] text-[13px] font-bold text-white",
										children: "Save Crypto"
									})
								]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "pay-card rounded-[24px] border border-[#e7eef6] bg-white p-3 sm:p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: form.id ? "Edit gateway" : "Add payment gateway"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: form.pay_kind || "other",
								onChange: (event) => setForm({
									...form,
									pay_kind: event.target.value
								}),
								className: "h-11 rounded-xl border px-3 text-[13px]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "upi",
										children: "Instant UPI"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "razorpay",
										children: "Razorpay — Key ID in account number, Key Secret in instructions"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "usdt",
										children: "USDT TRC-20 — address in account number, INR rate in IFSC (90)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "jazzcash",
										children: "JazzCash"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "crypto",
										children: "Pay with Crypto"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "talk",
										children: "Talk to Admin"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "other",
										children: "Other manual"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: form.name,
								onChange: (event) => setForm({
									...form,
									name: event.target.value
								}),
								placeholder: "Name shown to the user",
								className: "h-11 rounded-xl border px-3 text-[13px]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: form.account_title,
								onChange: (event) => setForm({
									...form,
									account_title: event.target.value
								}),
								placeholder: "Account title",
								className: "h-11 rounded-xl border px-3 text-[13px]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: form.account_number,
								onChange: (event) => setForm({
									...form,
									account_number: event.target.value
								}),
								placeholder: "Account / wallet number",
								className: "h-11 rounded-xl border px-3 text-[13px]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: form.ifsc,
								onChange: (event) => setForm({
									...form,
									ifsc: event.target.value
								}),
								placeholder: "IFSC, bank ke liye",
								className: "h-11 rounded-xl border px-3 text-[13px]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: form.instructions,
								onChange: (event) => setForm({
									...form,
									instructions: event.target.value
								}),
								placeholder: "Instructions",
								className: "h-11 rounded-xl border px-3 text-[13px]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: form.pay_mode || "manual",
									onChange: (event) => setForm({
										...form,
										pay_mode: event.target.value
									}),
									className: "h-11 rounded-xl border px-3 text-[13px]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "manual",
										children: "Manual — admin approves"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "auto",
										children: "Automatic gateway"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: form.pay_currency || "INR",
									onChange: (event) => setForm({
										...form,
										pay_currency: event.target.value.toUpperCase()
									}),
									placeholder: "Currency INR / USD / USDT",
									className: "h-11 rounded-xl border px-3 text-[13px]"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: form.network || "",
								onChange: (event) => setForm({
									...form,
									network: event.target.value
								}),
								placeholder: "Extra note",
								className: "h-20 w-full min-w-0 rounded-xl border px-3 py-2 text-[13px]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: form.min_paise / 100,
									onChange: (event) => setForm({
										...form,
										min_paise: Math.floor(Number(event.target.value) || 0) * 100
									}),
									placeholder: "Min ₹",
									className: "h-11 rounded-xl border px-3 text-[13px]"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: form.max_paise / 100,
									onChange: (event) => setForm({
										...form,
										max_paise: Math.floor(Number(event.target.value) || 0) * 100
									}),
									placeholder: "Max ₹",
									className: "h-11 rounded-xl border px-3 text-[13px]"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 text-[13px]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: form.enabled,
									onChange: (event) => setForm({
										...form,
										enabled: event.target.checked
									})
								}), " Enabled"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex h-11 cursor-pointer items-center rounded-xl border px-3 text-[13px] font-semibold",
								children: ["Upload QR", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									accept: "image/*",
									className: "hidden",
									onChange: async (event) => {
										const file = event.target.files?.[0];
										if (!file) return;
										setForm({
											...form,
											qr_image: await shrink(file)
										});
									}
								})]
							}),
							form.qr_image && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: form.qr_image,
								alt: "",
								className: "h-32 w-32 rounded-xl border object-contain"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: async () => {
							await adminSaveGateway({ data: {
								...form,
								min_rupees: form.min_paise / 100,
								max_rupees: form.max_paise / 100,
								archived: form.archived
							} });
							setForm(EMPTY);
							setMessage("Gateway saved.");
							load();
						},
						className: "mt-3 h-11 w-full rounded-xl bg-[#2563eb] text-[13px] font-bold text-white",
						children: "Save gateway"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setForm(EMPTY),
						className: "mt-2 h-10 w-full rounded-xl border text-[12px] font-semibold",
						children: "Add another"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-2 text-[13px]",
						children: gates.map((gate) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex min-w-0 flex-wrap items-center justify-between gap-2 rounded-xl bg-[#f8fafc] px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "pay-break min-w-0",
								children: [
									gate.name,
									" · ",
									gate.enabled ? "on" : "off",
									" ",
									gate.archived ? "· archived" : ""
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setForm(gate),
									className: "font-semibold text-[#2563eb]",
									children: "Edit"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: async () => {
										await adminSaveGateway({ data: {
											...gate,
											min_rupees: gate.min_paise / 100,
											max_rupees: gate.max_paise / 100,
											archived: true,
											enabled: false,
											qr_image: ""
										} });
										load();
									},
									className: "font-semibold text-rose-600",
									children: "Archive"
								})]
							})]
						}, gate.id))
					})
				]
			}),
			message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl bg-[#eff6ff] px-3 py-2 text-[13px]",
				children: message
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					"pending",
					"approved",
					"declined",
					"all"
				].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setFilter(item),
					className: `rounded-full px-3 py-1 text-[12px] font-semibold ${filter === item ? "bg-[#2563eb] text-white" : "bg-white"}`,
					children: item
				}, item))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "space-y-3",
				children: [claims.filter((claim) => filter === "all" || claim.status === filter).map((claim) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "rounded-2xl border border-[#e7eef6] bg-white p-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setOpenShot(claim.screenshot),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: claim.screenshot,
								alt: "",
								className: "h-28 w-24 rounded-xl object-cover"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold",
									children: claim.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "truncate text-[12px] text-[#64748b]",
									children: [
										claim.email,
										" · ",
										claim.gateway_name || "Gateway"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-[14px] font-bold",
									children: [
										inr(claim.amount_paise),
										" · ",
										claim.id
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[12px] text-[#64748b]",
									children: [
										claim.reference || "No UTR",
										" · ",
										claim.status,
										" · ",
										new Date(claim.created_at).toLocaleString("en-IN", {
											month: "short",
											day: "numeric",
											hour: "numeric",
											minute: "2-digit"
										})
									]
								}),
								claim.reject_reason && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[12px] text-rose-600",
									children: claim.reject_reason
								}),
								claim.status === "pending" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: reason,
										onChange: (event) => setReason(event.target.value),
										placeholder: "Reject reason",
										className: "h-9 w-full rounded-lg border px-2 text-[12px]"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: async () => {
												await adminReviewPayment({ data: {
													id: claim.id,
													approve: true
												} });
												load();
											},
											className: "h-9 rounded-lg bg-emerald-600 px-3 text-[12px] font-bold text-white",
											children: "Approve"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: async () => {
												await adminReviewPayment({ data: {
													id: claim.id,
													approve: false,
													reason
												} });
												load();
											},
											className: "h-9 rounded-lg border border-rose-200 px-3 text-[12px] font-bold text-rose-600",
											children: "Decline"
										})]
									})]
								})
							]
						})]
					})
				}, claim.id)), claims.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-center text-[13px] text-[#94a3b8]",
					children: "No payment screenshots yet."
				})]
			}),
			openShot && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setOpenShot(""),
				className: "fixed inset-0 z-40 grid place-items-center bg-black/70 p-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: openShot,
					alt: "Payment proof",
					className: "max-h-[80vh] rounded-2xl"
				})
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Authed, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Payments, {}) });
//#endregion
export { SplitComponent as component };
