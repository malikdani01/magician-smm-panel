import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as adminCredit, et as inr, f as adminCustomers, p as adminDeleteCustomer } from "./shell-CfBlaVSk.mjs";
import { t as Authed } from "./gate-DNi4gEUE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.customers-BGjYSRPj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Customers() {
	const [rows, setRows] = (0, import_react.useState)([]);
	const [note, setNote] = (0, import_react.useState)("");
	const [credit, setCredit] = (0, import_react.useState)({});
	function load() {
		adminCustomers().then(setRows).catch((err) => setNote(err instanceof Error ? err.message : "Could not load customers."));
	}
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-semibold uppercase tracking-[0.18em] text-[#2563eb]",
					children: "Admin"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-[28px] font-bold",
					children: "Customers"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[13px] text-[#64748b]",
					children: "Who signed in, what they spent, and who to remove."
				})
			] }),
			note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl bg-[#eff6ff] px-3 py-2 text-[13px]",
				children: note
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-2xl border border-[#e7eef6] bg-white p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-semibold",
								children: [
									row.name,
									" ",
									row.role === "admin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-[#dbeafe] px-2 py-0.5 text-[10px] font-bold text-[#1d4ed8]",
										children: "ADMIN"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[12px] text-[#64748b]",
								children: row.email
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-[13px]",
								children: [
									inr(row.balance_paise),
									" · ",
									row.orders,
									" orders · ",
									new Date(row.created_at).toLocaleString("en-IN", {
										month: "short",
										day: "numeric",
										hour: "numeric",
										minute: "2-digit"
									})
								]
							})
						] }), row.role !== "admin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: async () => {
								if (!confirm(`Remove ${row.email}?`)) return;
								await adminDeleteCustomer({ data: row.id });
								load();
							},
							className: "rounded-lg border border-rose-200 px-3 py-1 text-[12px] font-semibold text-rose-600",
							children: "Remove"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: credit[row.id] ?? "",
							onChange: (event) => setCredit((current) => ({
								...current,
								[row.id]: event.target.value.replace(/[^\d]/g, "")
							})),
							placeholder: "Add ₹",
							className: "h-10 w-28 rounded-xl border px-3 text-[13px]"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: async () => {
								await adminCredit({ data: {
									userId: row.id,
									rupees: Number(credit[row.id] || 0)
								} });
								setCredit((current) => ({
									...current,
									[row.id]: ""
								}));
								load();
							},
							className: "h-10 rounded-xl bg-[#2563eb] px-3 text-[12px] font-bold text-white",
							children: "Add funds"
						})]
					})]
				}, row.id))
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Authed, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Customers, {}) });
//#endregion
export { SplitComponent as component };
