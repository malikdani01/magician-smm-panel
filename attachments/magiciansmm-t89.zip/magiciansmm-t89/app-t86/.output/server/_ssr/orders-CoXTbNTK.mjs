import { C as require_jsx_runtime, g as Outlet, p as useRouterState, x as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/orders-CoXTbNTK.js
var import_jsx_runtime = require_jsx_runtime();
function OrdersLayout() {
	const path = useRouterState({ select: (state) => state.location.pathname });
	if (path === "/orders" || path === "/orders/") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/engagement-orders" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
}
//#endregion
export { OrdersLayout as component };
