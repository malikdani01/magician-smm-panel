import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, S as useRouter, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as riskLabel, S as ratioReport, T as windowHours, _ as mixFromRatios, a as answerOrganic, b as planDrops, c as formatDuration, f as growthPreview, g as mixDrops, h as mixCurve, i as SETTINGS_RATIO_DEFAULTS, n as PROVIDER_MIN, o as autoRuns, p as growthTemplate, r as REAL_BAND, t as DEFAULT_PACE, v as organicOpening, w as trimPct, x as presetWeights } from "./organic-DU6S6wDh.mjs";
import { $ as Brain, C as Rocket, J as Clock, M as Lock, O as Music2, P as Link2, T as RefreshCw, V as Heart, W as Eye, Z as Calendar, b as Send, ct as Activity, d as Sparkles, g as Share2, h as ShieldAlert, i as Wallet, k as MessageCircle, m as ShieldCheck, n as X, nt as Bookmark, t as Zap, u as Sprout, v as Settings2, z as Instagram } from "../_libs/lucide-react.mjs";
import { H as engagementSections, K as getCatalog, M as askPanelAi, Q as getWallet, V as engagementFloors, Z as getPrefs, et as inr, ft as panelRates, pt as placeOrder } from "./shell-CfBlaVSk.mjs";
import { t as Authed } from "./gate-DNi4gEUE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/engagement-order-DQgu5yrh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ORDER_TYPES = [
	"views",
	"likes",
	"shares",
	"reposts",
	"saves",
	"comments"
];
var PRESETS = [
	1e4,
	5e4,
	1e5,
	5e5,
	1e6
];
var TYPE_TONE = {
	views: {
		title: "text-[#0f172a]",
		icon: "text-sky-500"
	},
	likes: {
		title: "text-emerald-600",
		icon: "text-rose-500"
	},
	shares: {
		title: "text-[#2563eb]",
		icon: "text-[#2563eb]"
	},
	reposts: {
		title: "text-emerald-600",
		icon: "text-emerald-500"
	},
	saves: {
		title: "text-amber-600",
		icon: "text-amber-500"
	},
	comments: {
		title: "text-fuchsia-300",
		icon: "text-fuchsia-300"
	}
};
var ICONS = {
	views: Eye,
	likes: Heart,
	shares: Share2,
	reposts: RefreshCw,
	saves: Bookmark,
	comments: MessageCircle
};
function lineQty(item, base, overrides) {
	if (overrides[item.engagement_type] != null) return overrides[item.engagement_type];
	if (item.is_base) return base;
	return Math.round(base * item.ratio_bps / 1e4);
}
var MIX_COPY = {
	light: "Light: a quiet post. Fewer likes and very few comments or shares.",
	recommended: "Recommended: the same mix real posts get with this many views. Safest and looks the most natural.",
	viral: "Viral push: about double a normal post, like content that is taking off.",
	custom: "Your own amounts: set them as a % of views (they follow the views if you change them) or as exact numbers."
};
function linePrice(item, quantity, panel) {
	if (quantity <= 0) return 0;
	const set = panel[item.engagement_type];
	if (set > 0) return Math.max(1, Math.round(quantity / 1e3 * set));
	const rate = item.price_per_10k_paise || item.price_per_1k_paise * 10;
	return Math.max(1, Math.round(quantity * rate / 1e4));
}
function Switch({ on, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		role: "switch",
		"aria-checked": on,
		onClick,
		className: `relative h-7 w-12 shrink-0 rounded-full transition ${on ? "bg-[#3b82f6]" : "bg-[#dbe4ee]"}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-0.5 size-6 rounded-full bg-white shadow transition ${on ? "left-5" : "left-0.5"}` })
	});
}
function EngagementConsole() {
	const router = useRouter();
	const [bundles, setBundles] = (0, import_react.useState)([]);
	const [platform, setPlatform] = (0, import_react.useState)("instagram");
	const [link, setLink] = (0, import_react.useState)("");
	const [base, setBase] = (0, import_react.useState)(1e4);
	const [custom, setCustom] = (0, import_react.useState)("10000");
	const [enabled, setEnabled] = (0, import_react.useState)(ORDER_TYPES);
	const [sections, setSections] = (0, import_react.useState)({
		views: true,
		likes: true,
		saves: true,
		shares: true,
		reposts: true,
		comments: false
	});
	const [overrides, setOverrides] = (0, import_react.useState)({});
	const [pace, setPace] = (0, import_react.useState)({});
	const [open, setOpen] = (0, import_react.useState)(null);
	const [runsOpen, setRunsOpen] = (0, import_react.useState)(null);
	const [curves, setCurves] = (0, import_react.useState)(() => {
		const weights = presetWeights("natural");
		return {
			views: weights,
			likes: weights,
			saves: weights,
			shares: weights,
			reposts: weights,
			comments: weights
		};
	});
	const [pattern, setPattern] = (0, import_react.useState)(223);
	const [picker, setPicker] = (0, import_react.useState)(false);
	const [family, setFamily] = (0, import_react.useState)("random-walk");
	const [algo, setAlgo] = (0, import_react.useState)(true);
	const [ratiosOn, setRatiosOn] = (0, import_react.useState)(true);
	const [qtyMode, setQtyMode] = (0, import_react.useState)("exact");
	const [pcts, setPcts] = (0, import_react.useState)(() => mixCurve("recommended", 1e4));
	const [pctText, setPctText] = (0, import_react.useState)(() => Object.fromEntries(Object.entries(mixCurve("recommended", 1e4)).map(([type, pct]) => [type, trimPct(pct)])));
	const [mixPreset, setMixPreset] = (0, import_react.useState)("recommended");
	const [savedRatios, setSavedRatios] = (0, import_react.useState)(SETTINGS_RATIO_DEFAULTS);
	const [ask, setAsk] = (0, import_react.useState)(false);
	const [chat, setChat] = (0, import_react.useState)([]);
	const [aiPending, setAiPending] = (0, import_react.useState)(false);
	const [mixNote, setMixNote] = (0, import_react.useState)("");
	const [draft, setDraft] = (0, import_react.useState)("");
	const [floors, setFloors] = (0, import_react.useState)({
		views: 100,
		likes: 10,
		shares: 10,
		saves: 50,
		reposts: 10
	});
	const [scheduleOpen, setScheduleOpen] = (0, import_react.useState)(false);
	const [scheduleStart] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	const [runDrafts, setRunDrafts] = (0, import_react.useState)([]);
	const [panel, setPanel] = (0, import_react.useState)({});
	const [qtyText, setQtyText] = (0, import_react.useState)({});
	const [hourText, setHourText] = (0, import_react.useState)({});
	const [runsText, setRunsText] = (0, import_react.useState)({});
	const [balance, setBalance] = (0, import_react.useState)(0);
	const [error, setError] = (0, import_react.useState)("");
	const [focusQty, setFocusQty] = (0, import_react.useState)(null);
	const [pending, setPending] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		engagementFloors({ data: platform }).then((next) => setFloors((current) => ({
			...current,
			...next
		}))).catch(() => void 0);
		engagementSections({ data: platform }).then((next) => setSections(next)).catch(() => void 0);
		panelRates({ data: platform }).then((next) => setPanel(next || {})).catch(() => setPanel({}));
	}, [platform]);
	(0, import_react.useEffect)(() => {
		if (qtyMode === "percent" || mixPreset !== "custom" || !ratiosOn || base < 100) return;
		const mix = mixFromRatios(base, savedRatios, floors);
		setOverrides(mix);
		setQtyText({});
		const parts = Object.entries(mix).map(([type, qty]) => `${type} ${savedRatios[type]}% = ${qty.toLocaleString("en-IN")}`);
		setMixNote(parts.length ? `Settings ratios: ${parts.join(", ")}. Jo minimum se neeche tha, woh minimum pe chipak gaya.` : "Settings mein likes, saves, shares aur reposts 0% hain.");
	}, [
		base,
		ratiosOn,
		floors,
		savedRatios,
		qtyMode,
		mixPreset
	]);
	(0, import_react.useEffect)(() => {
		if (qtyMode !== "percent" && mixPreset === "custom") return;
		setOverrides((current) => {
			const next = { ...current };
			for (const [type, pct] of Object.entries(pcts)) next[type] = Math.max(0, Math.round(base * pct / 100));
			return next;
		});
		setQtyText({});
	}, [
		qtyMode,
		base,
		pcts,
		mixPreset
	]);
	(0, import_react.useEffect)(() => {
		getCatalog().then((catalog) => setBundles(catalog.bundles)).catch((err) => setError(err instanceof Error ? err.message : "Catalog failed."));
		getWallet().then((wallet) => setBalance(wallet.balance_paise)).catch(() => setBalance(0));
		getPrefs().then((prefs) => {
			try {
				setSavedRatios({
					...SETTINGS_RATIO_DEFAULTS,
					...JSON.parse(prefs.ratios_json || "{}")
				});
			} catch {
				setSavedRatios(SETTINGS_RATIO_DEFAULTS);
			}
		}).catch(() => setSavedRatios(SETTINGS_RATIO_DEFAULTS));
	}, []);
	const bundle = bundles.find((item) => item.platform === platform) ?? bundles[0];
	const sectionOn = (type) => sections[type] !== false && (type !== "comments" || sections.comments === true);
	const shown = (bundle?.items ?? []).filter((item) => ORDER_TYPES.includes(item.engagement_type) && sectionOn(item.engagement_type));
	const qtyOf = (item) => {
		if (!enabled.includes(item.engagement_type)) return 0;
		const floor = floors[item.engagement_type] ?? (item.is_base ? 100 : 1);
		if (qtyMode === "percent" && !item.is_base && overrides[item.engagement_type] != null) return Math.min(item.max_quantity, Math.max(0, lineQty(item, base, overrides)));
		return Math.min(item.max_quantity, Math.max(floor, lineQty(item, base, overrides)));
	};
	const active = shown.filter((item) => enabled.includes(item.engagement_type));
	const billed = (type, fallback) => {
		const rows = runDrafts.filter((row) => row.type === type);
		if (!rows.length) return fallback;
		return rows.filter((row) => row.on).reduce((sum, row) => sum + Math.max(0, Math.floor(Number(row.amount) || 0)), 0);
	};
	const quantities = Object.fromEntries(active.map((item) => [item.engagement_type, billed(item.engagement_type, qtyOf(item))]));
	const totalPaise = active.reduce((sum, item) => sum + linePrice(item, billed(item.engagement_type, qtyOf(item)), panel), 0);
	const totalQty = active.reduce((sum, item) => sum + billed(item.engagement_type, qtyOf(item)), 0);
	const report = ratioReport(quantities);
	const canPay = balance >= totalPaise && totalPaise > 0;
	const schedule = mixDrops(active.map((item) => {
		const current = paceFor(item.engagement_type);
		const requested = chosenRuns(item.engagement_type, Math.max(qtyOf(item), 1));
		return {
			type: item.engagement_type,
			quantity: qtyOf(item),
			runs: requested,
			hours: windowHours(current, requested, base),
			curve: curves[item.engagement_type] ?? curves.views,
			variance: current.variance,
			peak: current.peak,
			min: floors[item.engagement_type]
		};
	}), scheduleStart);
	const scheduleStamp = schedule.map((drop) => `${drop.type}|${drop.at.toISOString()}|${drop.amount}`).join("~");
	const scheduleRef = (0, import_react.useRef)(schedule);
	scheduleRef.current = schedule;
	function localStamp(date) {
		const pad = (part) => String(part).padStart(2, "0");
		return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
	}
	(0, import_react.useEffect)(() => {
		setRunDrafts(scheduleRef.current.map((drop, index) => ({
			key: `${drop.type}-${index}`,
			type: drop.type,
			at: localStamp(drop.at),
			amount: String(drop.amount),
			on: true
		})));
	}, [scheduleStamp]);
	function patchRun(key, next) {
		setRunDrafts((current) => current.map((row) => row.key === key ? {
			...row,
			...next
		} : row));
	}
	function setBaseQty(next) {
		const value = Math.max(100, Math.min(1e7, Math.floor(next) || 100));
		setBase(value);
		setCustom(String(value));
		setQtyText({});
		if (qtyMode !== "percent" && mixPreset === "custom") setRatiosOn(true);
	}
	function applyMixPreset(id) {
		const next = mixCurve(id, base);
		const text = {};
		for (const [type, pct] of Object.entries(next)) text[type] = trimPct(pct);
		setPcts(next);
		setPctText(text);
		setRatiosOn(false);
		setMixPreset(id);
	}
	(0, import_react.useEffect)(() => {
		if (mixPreset === "custom") return;
		const next = mixCurve(mixPreset, base);
		const text = {};
		for (const [type, pct] of Object.entries(next)) text[type] = trimPct(pct);
		setPcts(next);
		setPctText(text);
	}, [base, mixPreset]);
	function paceFor(type) {
		return pace[type] ?? DEFAULT_PACE;
	}
	function chosenRuns(type, quantity) {
		const chunk = floors[type] ?? PROVIDER_MIN[type] ?? 10;
		const max = quantity > chunk ? Math.max(1, Math.floor(quantity / (chunk + 1))) : 1;
		const raw = runsText[type];
		if (raw != null && raw !== "") {
			const typed = Math.floor(Number(raw));
			if (typed >= 1 && typed <= max) return typed;
		}
		const current = paceFor(type);
		if (current.runsMode === "manual" && current.runs > 0) return Math.min(max, current.runs);
		return autoRuns(Math.max(quantity, 1), type);
	}
	function applyWindow(type, next) {
		const keys = type === "views" ? [
			"views",
			"likes",
			"saves",
			"shares",
			"reposts",
			"comments"
		] : [type];
		setPace((current) => {
			const updated = { ...current };
			for (const key of keys) updated[key] = {
				...updated[key] ?? DEFAULT_PACE,
				...next
			};
			return updated;
		});
		if (type === "views" && next.customHours) setHourText((current) => {
			const text = { ...current };
			for (const key of keys) text[key] = String(next.customHours);
			return text;
		});
	}
	function patchPace(type, next) {
		setPace((current) => {
			const prev = current[type] ?? DEFAULT_PACE;
			return {
				...current,
				[type]: {
					...prev,
					...next
				}
			};
		});
	}
	function applyMix(mix) {
		const next = mix && Object.keys(mix).length ? mix : mixFromRatios(base, savedRatios, floors);
		setOverrides((current) => ({
			...current,
			...next
		}));
		setQtyText({});
		setEnabled((current) => Array.from(/* @__PURE__ */ new Set([
			...current,
			"likes",
			"shares",
			"reposts",
			"saves"
		])));
		return next;
	}
	async function askOrganic(question) {
		const text = question.trim();
		if (!text || aiPending) return;
		const viewsPace = paceFor("views");
		const runs = viewsPace.runsMode === "manual" && viewsPace.runs > 0 ? viewsPace.runs : autoRuns(Math.max(quantities.views || base, 1), "views");
		const hours = windowHours(viewsPace, runs, base);
		const finish = new Date(Date.now() + hours * 3600 * 1e3).toLocaleString("en-IN", {
			month: "short",
			day: "numeric",
			hour: "numeric",
			minute: "2-digit"
		});
		setChat((current) => [...current, {
			role: "user",
			text
		}]);
		setDraft("");
		setAiPending(true);
		const local = () => answerOrganic(text, {
			quantities,
			health: report.health,
			botting: report.botting,
			hours,
			runs,
			peak: viewsPace.peak,
			finish,
			ratios: savedRatios
		});
		try {
			const result = await askPanelAi({ data: {
				question: text,
				context: `Link pasted: ${/^https?:\/\//.test(link.trim())}. Views ${quantities.views || base}, likes ${quantities.likes || 0}, shares ${quantities.shares || 0}, saves ${quantities.saves || 0}, reposts ${quantities.reposts || 0}. Health ${report.health}/100. Botting risk ${report.botting}%. Runs ${runs}. Window ${hours.toFixed(1)} hours. Peak ${viewsPace.peak ? "on" : "off"}. Finish ${finish}.`
			} });
			setChat((current) => [...current, {
				role: "assistant",
				text: result.text,
				apply: result.apply,
				mix: result.mix
			}]);
		} catch {
			setChat((current) => [...current, {
				role: "assistant",
				text: local(),
				apply: /ratio|suggest|best|mix/i.test(text)
			}]);
		} finally {
			setAiPending(false);
		}
	}
	function openAssistant() {
		const linkReady = /^https?:\/\//.test(link.trim());
		setChat([{
			role: "assistant",
			text: organicOpening({
				linkReady,
				quantities,
				botting: report.botting
			})
		}]);
		setDraft("");
		setAsk(true);
	}
	async function submit() {
		if (!bundle) return;
		setError("");
		if (!/^https?:\/\//.test(link.trim())) {
			setError("Please enter a valid link.");
			return;
		}
		if (enabled.includes("views") && (!custom || Number(custom) < (floors.views || 100))) {
			setError(`Below ${floors.views || 100} not allowed.`);
			return;
		}
		if (active.length === 0) {
			setError("Turn on at least one service.");
			return;
		}
		for (const item of active) {
			const floor = floors[item.engagement_type] ?? (item.is_base ? 100 : 1);
			const raw = qtyText[item.engagement_type];
			if (raw !== void 0 && (raw === "" || Number(raw) < floor)) {
				setError(`Below ${floor} not allowed.`);
				return;
			}
			const current = paceFor(item.engagement_type);
			if (current.window === "custom") {
				const hoursRaw = hourText[item.engagement_type] ?? String(current.customHours || "");
				if (hoursRaw === "" || Number(hoursRaw) < 1) {
					setError("Below 1 not allowed.");
					return;
				}
			}
			if (current.runsMode === "manual") {
				const runsRaw = runsText[item.engagement_type] ?? String(current.runs || "");
				const chunk = floors[item.engagement_type] ?? 10;
				const maxRuns = qtyOf(item) > chunk ? Math.max(1, Math.floor(qtyOf(item) / (chunk + 1))) : 1;
				if (runsRaw === "" || Number(runsRaw) < 1) {
					setError("Below 1 not allowed.");
					return;
				}
				if (Number(runsRaw) > maxRuns) {
					setError(`Above ${maxRuns} not allowed.`);
					return;
				}
			}
		}
		if (!canPay) {
			setError("Insufficient balance.");
			return;
		}
		setPending(true);
		try {
			const source = runDrafts.length ? runDrafts : schedule.map((drop, index) => ({
				key: `${drop.type}-${index}`,
				type: drop.type,
				at: localStamp(drop.at),
				amount: String(drop.amount),
				on: true
			}));
			const orderQuantities = Object.fromEntries(active.map((item) => {
				const rows = source.filter((row) => row.type === item.engagement_type && row.on);
				const qty = rows.length ? rows.reduce((sum, row) => sum + Math.max(0, Math.floor(Number(row.amount) || 0)), 0) : qtyOf(item);
				return [item.engagement_type, qty];
			}).filter((entry) => entry[1] > 0));
			const drops = source.filter((row) => row.on && orderQuantities[row.type] > 0).map((row) => ({
				type: row.type,
				amount: Math.floor(Number(row.amount) || 0),
				at: new Date(row.at).toISOString()
			})).filter((row) => row.amount > 0 && !Number.isNaN(new Date(row.at).getTime()));
			if (drops.length === 0) {
				setError("Kam se kam ek run on rakho.");
				return;
			}
			for (const drop of drops) {
				const floor = floors[drop.type] ?? 1;
				if (drop.amount < floor) {
					setError(`Below ${floor} not allowed for ${drop.type}.`);
					return;
				}
			}
			const viewsPace = paceFor("views");
			const delivery = {};
			for (const item of active) {
				if (!orderQuantities[item.engagement_type]) continue;
				const current = paceFor(item.engagement_type);
				const lineRuns = chosenRuns(item.engagement_type, Math.max(quantities[item.engagement_type] || base, 1));
				delivery[item.engagement_type] = {
					hours: windowHours(current, lineRuns, base),
					runs: lineRuns,
					variance: current.variance,
					peak: current.peak,
					curve: curves[item.engagement_type] ?? curves.views ?? [.02, 1]
				};
			}
			const viewsRuns = delivery.views?.runs ?? autoRuns(quantities.views || base, "views");
			await placeOrder({ data: {
				bundleId: bundle.id,
				link: link.trim(),
				baseQuantity: base,
				organic: algo,
				intervalHours: Math.max(1, Math.round((delivery.views?.hours ?? windowHours(viewsPace, viewsRuns, base)) / Math.max(1, viewsRuns))),
				variancePercent: viewsPace.variance,
				enabledTypes: Object.keys(orderQuantities),
				quantities: orderQuantities,
				delivery,
				drops
			} });
			await router.navigate({ to: "/engagement-orders" });
		} catch (err) {
			setError(err instanceof Error ? err.message : "Order failed.");
		} finally {
			setPending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl space-y-4 pb-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[28px] border border-[#e7eef6] bg-white p-5 shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-start justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1.5 rounded-full bg-[#f4f7fb] px-3 py-1 text-[10px] font-semibold tracking-[0.16em] text-[#64748b]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-emerald-400" }), " ENGAGEMENT CONSOLE"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-10 place-items-center rounded-2xl bg-[#e8f1ff] text-[#3b82f6]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rocket, { className: "size-4" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "font-['Playfair_Display',Georgia,serif] text-[34px] leading-none font-bold text-[#1e3a5f]",
						children: ["Organic ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "italic text-[#2458c5]",
							children: "Full Engagement"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-sm text-[13px] text-[#64748b]",
						children: "One link — every engagement type, dispatched with humanlike organic pacing."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleCard, {
							on: algo,
							tone: "emerald",
							title: "AI Organic Algorithm",
							badge: "ACTIVE",
							text: "Unique S-curve · Random variance · Anti-bot",
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "size-4" }),
							onClick: () => setAlgo((value) => !value)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleCard, {
							on: ratiosOn,
							tone: "blue",
							title: "AI Smart Ratios",
							badge: "SETTINGS",
							text: "Likes, saves, shares, reposts = Settings %",
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" }),
							onClick: () => setRatiosOn((value) => !value)
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[24px] border border-[#e7eef6] bg-white p-4 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mb-3 flex items-center gap-2 text-[15px] font-semibold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rocket, { className: "size-4 text-[#64748b]" }), " Select Platform"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlatformButton, {
						active: platform === "instagram",
						onClick: () => setPlatform("instagram"),
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Instagram, { className: "size-4" }),
						label: "INSTAGRAM",
						gradient: "from-emerald-400 via-teal-400 to-violet-500"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlatformButton, {
						active: platform === "tiktok",
						onClick: () => setPlatform("tiktok"),
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music2, { className: "size-4" }),
						label: "TIKTOK",
						gradient: "from-cyan-300 to-emerald-300"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[24px] border border-[#e7eef6] bg-white p-4 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "flex items-center gap-2 text-[15px] font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "size-4 text-[#64748b]" }), " Video/Post Link"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: openAssistant,
						className: "inline-flex items-center gap-1 rounded-full border border-amber-200 bg-amber-50 px-3 py-1 text-[12px] font-semibold text-amber-700",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5" }), " Ask AI"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: link,
					onChange: (event) => setLink(event.target.value),
					placeholder: platform === "tiktok" ? "https://tiktok.com/..." : "https://instagram.com/...",
					className: "h-12 w-full rounded-2xl border border-transparent bg-[#eef5fb] px-4 text-[14px] outline-none focus:border-[#93c5fd]"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[24px] border border-[#e7eef6] bg-white p-4 shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "mb-3 flex items-center gap-2 text-[15px] font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4 text-[#64748b]" }), " Base Views Quantity"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: PRESETS.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setBaseQty(preset),
							className: `h-10 min-w-14 rounded-xl px-3 text-[13px] font-semibold ${base === preset ? "bg-[#111827] text-white" : "bg-[#f3f6fa] text-[#334155]"}`,
							children: preset >= 1e6 ? "1M" : `${preset / 1e3}K`
						}, preset))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-3 flex items-center gap-2 text-[13px] text-[#64748b]",
						children: [
							"or custom:",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: focusQty === "views-custom" ? custom : String(billed("views", Number(custom) || base)),
								inputMode: "numeric",
								onFocus: () => {
									setFocusQty("views-custom");
									setCustom(String(billed("views", Number(custom) || base)));
								},
								onBlur: () => setFocusQty(null),
								onChange: (event) => {
									const raw = event.target.value.replace(/[^\d]/g, "");
									setCustom(raw);
									const next = Number(raw);
									if (next >= (floors.views || 100)) setBaseQty(Math.min(1e7, next));
								},
								className: "h-10 w-28 rounded-xl bg-[#eef5fb] px-3 font-semibold text-[#0f172a] outline-none"
							}),
							"views"
						]
					}),
					custom !== "" && Number(custom) < (floors.views || 100) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-[12px] font-semibold text-rose-600",
						children: [
							"Below ",
							floors.views || 100,
							" not allowed"
						]
					}),
					mixNote && custom !== "" && Number(custom) >= (floors.views || 100) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-[12px] text-[#1d4ed8]",
						children: mixNote
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-end justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-[18px] font-semibold",
						children: "Engagement Breakdown"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[13px] text-[#64748b]",
						children: "Customize organic settings per type"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "rounded-full bg-[#111827] px-3 py-1 text-[12px] font-semibold text-white",
						children: [active.length, " active"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-3 rounded-2xl border border-emerald-300/40 bg-emerald-400/10 px-3 py-2 text-[12px] font-semibold text-emerald-200",
					children: "Organic ratios applied. Engagement matches real post patterns; likes, comments and shares arrive naturally after views."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-2 grid grid-cols-3 gap-2",
					children: [
						["light", "Light"],
						["recommended", "Recommended"],
						["viral", "Viral push"]
					].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => applyMixPreset(id),
						className: `h-11 rounded-2xl px-1 text-[11px] font-semibold sm:text-[13px] ${mixPreset === id ? "bg-[#111827] text-white" : "bg-[#f3f6fa] text-[#334155]"}`,
						children: [label, id === "recommended" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-1 rounded-full bg-emerald-500 px-1.5 py-0.5 text-[9px] font-bold text-white",
							children: "BEST"
						})]
					}, id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setMixPreset("custom"),
					className: `mb-2 h-10 rounded-2xl px-4 text-[13px] font-semibold ${mixPreset === "custom" ? "bg-[#111827] text-white" : "bg-[#f3f6fa] text-[#334155]"}`,
					children: "Your own amounts"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							if (mixPreset === "custom") {
								const next = {};
								const text = {};
								for (const row of shown) {
									if (row.is_base) continue;
									const qty = qtyOf(row);
									const pct = Math.round(qty / Math.max(base, 1) * 1e4) / 100;
									next[row.engagement_type] = pct;
									text[row.engagement_type] = trimPct(pct);
								}
								setPcts((current) => ({
									...current,
									...next
								}));
								setPctText((current) => ({
									...current,
									...text
								}));
							}
							setRatiosOn(false);
							setQtyMode("percent");
						},
						className: `h-11 rounded-2xl text-[13px] font-semibold ${qtyMode === "percent" ? "bg-[#111827] text-white" : "bg-[#f3f6fa] text-[#334155]"}`,
						children: "% of views"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							setQtyMode("exact");
							setRatiosOn(false);
							setQtyText({});
						},
						className: `h-11 rounded-2xl text-[13px] font-semibold ${qtyMode === "exact" ? "bg-[#111827] text-white" : "bg-[#f3f6fa] text-[#334155]"}`,
						children: "Exact number"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-[12px] text-[#64748b]",
					children: MIX_COPY[mixPreset]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-3",
					children: shown.map((item) => {
						const on = enabled.includes(item.engagement_type);
						const quantity = on ? billed(item.engagement_type, qtyOf(item)) : 0;
						const requested = chosenRuns(item.engagement_type, Math.max(quantity, 1));
						const currentPace = paceFor(item.engagement_type);
						const hours = windowHours(currentPace, requested, base);
						const rows = planDrops({
							quantity,
							type: item.engagement_type,
							runs: requested,
							hours,
							curve: curves[item.engagement_type] ?? curves.views,
							variance: currentPace.variance,
							peak: currentPace.peak,
							min: floors[item.engagement_type]
						});
						const runs = rows.length || requested;
						const floor = floors[item.engagement_type] ?? (item.is_base ? 100 : 1);
						const qtyRaw = item.is_base ? custom : qtyText[item.engagement_type] ?? String(quantity);
						const Icon = ICONS[item.engagement_type] ?? Eye;
						const tone = TYPE_TONE[item.engagement_type] ?? TYPE_TONE.views;
						const risk = riskLabel(currentPace.variance);
						const low = rows.length ? Math.min(...rows.map((row) => row.amount)) : 0;
						const high = rows.length ? Math.max(...rows.map((row) => row.amount)) : 0;
						const average = rows.length ? quantity / rows.length : 0;
						const spreadDown = Math.max(0, Math.round(average - low));
						const spreadUp = Math.max(0, Math.round(high - average));
						const chunk = floors[item.engagement_type] ?? PROVIDER_MIN[item.engagement_type] ?? 10;
						const maxRuns = quantity > chunk ? Math.max(1, Math.floor(quantity / (chunk + 1))) : 1;
						const manual = runsText[item.engagement_type] != null && runsText[item.engagement_type] !== "" || paceFor(item.engagement_type).runsMode === "manual";
						const usePercent = qtyMode === "percent" && !item.is_base;
						const pctShown = pctText[item.engagement_type] ?? trimPct(pcts[item.engagement_type] ?? (base > 0 ? quantity / base * 100 : 0));
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-[24px] border border-[#e7eef6] bg-white p-4 shadow-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0 flex-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: `size-4 ${tone.icon}` }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: `font-semibold ${tone.title}`,
															children: item.name.replace(/^(Stage|House|Aisle|Pocket|Cue) /, "") || item.engagement_type
														}),
														item.is_base && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "rounded bg-[#111827] px-1.5 py-0.5 text-[9px] font-bold text-white",
															children: "BASE"
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "mt-1 text-[11px] font-semibold tracking-wide text-[#3b82f6]",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "mr-1 inline size-3" }),
														runs,
														" RUNS · ",
														formatDuration(hours).replace("~", "~").toUpperCase(),
														" · min ",
														chunk,
														"/order"
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-[11px] text-[#94a3b8]",
													children: [
														"Min: ",
														(floors[item.engagement_type] ?? item.min_quantity).toLocaleString("en-IN"),
														" • Max: ",
														item.max_quantity.toLocaleString("en-IN"),
														" • ",
														panel[item.engagement_type] ? `${inr(panel[item.engagement_type])} / 1k` : "Bundle rate"
													]
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											disabled: !on,
											value: usePercent ? pctShown : focusQty === item.engagement_type ? qtyRaw : String(quantity),
											inputMode: usePercent ? "decimal" : "numeric",
											onFocus: () => {
												setFocusQty(item.engagement_type);
												if (usePercent) {
													setPctText((current) => ({
														...current,
														[item.engagement_type]: pctShown
													}));
													return;
												}
												const shownQty = String(quantity);
												if (item.is_base) setCustom(shownQty);
												else setQtyText((current) => ({
													...current,
													[item.engagement_type]: shownQty
												}));
											},
											onBlur: () => {
												setFocusQty(null);
												if (!usePercent) return;
												const next = Math.min(100, Math.max(0, Number(pctText[item.engagement_type]) || 0));
												setPcts((current) => ({
													...current,
													[item.engagement_type]: next
												}));
												setPctText((current) => ({
													...current,
													[item.engagement_type]: trimPct(next)
												}));
											},
											onChange: (event) => {
												if (usePercent) {
													const raw = event.target.value.replace(/[^\d.]/g, "").replace(/(\..*)\./g, "$1");
													setPctText((current) => ({
														...current,
														[item.engagement_type]: raw
													}));
													setRatiosOn(false);
													setMixPreset("custom");
													if (raw === "" || raw === ".") {
														setPcts((current) => ({
															...current,
															[item.engagement_type]: 0
														}));
														return;
													}
													const next = Number(raw);
													if (!Number.isNaN(next)) setPcts((current) => ({
														...current,
														[item.engagement_type]: Math.min(100, Math.max(0, next))
													}));
													return;
												}
												const raw = event.target.value.replace(/[^\d]/g, "");
												if (item.is_base) {
													setCustom(raw);
													const next = Number(raw);
													if (raw !== "" && next >= floor) setBaseQty(Math.min(1e7, next));
													return;
												}
												setQtyText((current) => ({
													...current,
													[item.engagement_type]: raw
												}));
												setRatiosOn(false);
												setMixPreset("custom");
												const next = Number(raw);
												if (raw !== "" && next >= floor) setOverrides((current) => ({
													...current,
													[item.engagement_type]: Math.min(item.max_quantity, next)
												}));
											},
											className: "h-10 w-20 rounded-full border border-[#e7eef6] bg-white text-center text-[13px] font-semibold outline-none"
										}),
										usePercent && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[12px] font-bold text-[#c4b5fd]",
											children: "%"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "w-16 text-right text-[13px] font-semibold text-[#64748b]",
											children: on ? inr(linePrice(item, quantity, panel)) : "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
											on,
											onClick: () => {
												setEnabled((current) => current.includes(item.engagement_type) ? current.filter((type) => type !== item.engagement_type) : [...current, item.engagement_type]);
											}
										})
									]
								}),
								on && !item.is_base && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-[12px] font-semibold text-[#67e8f9]",
									children: qtyMode === "percent" ? `= ${quantity.toLocaleString("en-IN")} ${item.engagement_type}` : `= ${trimPct(base > 0 ? quantity / base * 100 : 0)}% of views`
								}),
								on && !item.is_base && REAL_BAND[item.engagement_type] && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-[12px] text-[#94a3b8]",
									children: [
										"Real posts: ",
										REAL_BAND[item.engagement_type],
										" · suggested ",
										Math.round(base * (mixCurve("recommended", base)[item.engagement_type] ?? 0) / 100).toLocaleString("en-IN")
									]
								}),
								on && qtyRaw !== "" && Number(qtyRaw) < floor && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-[12px] font-semibold text-rose-600",
									children: [
										"Below ",
										floor,
										" not allowed"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setOpen(open === item.engagement_type ? null : item.engagement_type),
									className: "mx-auto mt-3 flex items-center gap-1 text-[11px] font-semibold tracking-wide text-[#94a3b8]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, { className: "size-3" }),
										" SETTINGS ",
										open === item.engagement_type ? "▴" : "▾"
									]
								}),
								open === item.engagement_type && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 space-y-3 border-t border-[#eef2f6] pt-3 text-[13px]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] font-semibold tracking-wide text-[#94a3b8]",
											children: "DELIVERY TIME"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex flex-wrap gap-2",
											children: [
												"auto",
												"6h",
												"12h",
												"24h",
												"48h",
												"custom"
											].map((window) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => applyWindow(item.engagement_type, { window }),
												className: `rounded-full px-3 py-1 text-[12px] font-semibold ${paceFor(item.engagement_type).window === window ? "bg-[#111827] text-white" : "bg-[#f3f6fa]"}`,
												children: window === "auto" ? "Auto" : window === "custom" ? "Custom" : window
											}, window))
										}),
										paceFor(item.engagement_type).window === "custom" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "block",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													inputMode: "numeric",
													value: hourText[item.engagement_type] ?? String(paceFor(item.engagement_type).customHours || ""),
													placeholder: "hours",
													onChange: (event) => {
														const raw = event.target.value.replace(/[^\d]/g, "");
														setHourText((current) => ({
															...current,
															[item.engagement_type]: raw
														}));
														const next = Number(raw);
														if (raw !== "" && next >= 1) applyWindow(item.engagement_type, {
															window: "custom",
															customHours: Math.min(720, next)
														});
													},
													className: "h-10 w-24 rounded-xl bg-[#f3f6fa] px-3 text-[14px] font-semibold outline-none"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[12px] text-[#64748b]",
													children: [
														"hours. This line finishes in ",
														formatDuration(hours).replace("~", ""),
														"."
													]
												})]
											}), (hourText[item.engagement_type] ?? "") !== "" && Number(hourText[item.engagement_type]) < 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-[12px] font-semibold text-rose-600",
												children: "Below 1 not allowed"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] font-semibold tracking-wide text-[#94a3b8]",
												children: "NUMBER OF RUNS"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[11px] text-[#94a3b8]",
												children: [
													"max ",
													maxRuns,
													" (",
													quantity.toLocaleString("en-IN"),
													" ÷ ",
													quantity > chunk ? chunk + 1 : chunk,
													")"
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => {
													setRunsText((current) => {
														const next = { ...current };
														delete next[item.engagement_type];
														return next;
													});
													patchPace(item.engagement_type, {
														runsMode: "auto",
														runs: 0
													});
												},
												className: `h-10 rounded-xl px-4 font-semibold ${manual ? "bg-[#f3f6fa] text-[#334155]" : "bg-[#111827] text-white"}`,
												children: "Auto"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												inputMode: "numeric",
												value: runsText[item.engagement_type] ?? (manual ? String(paceFor(item.engagement_type).runs || "") : ""),
												placeholder: manual ? "runs" : `${runs} runs (auto)`,
												onChange: (event) => {
													const raw = event.target.value.replace(/[^\d]/g, "");
													setRunsText((current) => ({
														...current,
														[item.engagement_type]: raw
													}));
													const next = Number(raw);
													if (raw !== "" && next >= 1 && next <= maxRuns) patchPace(item.engagement_type, {
														runsMode: "manual",
														runs: next
													});
													else patchPace(item.engagement_type, {
														runsMode: "manual",
														runs: 0
													});
												},
												className: "h-10 min-w-0 flex-1 rounded-xl bg-[#f3f6fa] px-3 font-semibold text-[#0f172a] outline-none placeholder:font-medium placeholder:text-[#94a3b8]"
											})]
										}),
										runsText[item.engagement_type] !== void 0 && runsText[item.engagement_type] !== "" && Number(runsText[item.engagement_type]) < 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[12px] font-semibold text-rose-600",
											children: "Below 1 not allowed"
										}),
										runsText[item.engagement_type] !== void 0 && Number(runsText[item.engagement_type]) > maxRuns && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[12px] font-semibold text-rose-600",
											children: [
												"Above ",
												maxRuns,
												" not allowed"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] font-semibold tracking-wide text-[#94a3b8]",
												children: "RANDOM VARIANCE"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "rounded-full bg-amber-100 px-2 py-0.5 text-[11px] font-bold text-amber-700",
												children: [
													"±",
													paceFor(item.engagement_type).variance,
													"%"
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "range",
											min: 10,
											max: 50,
											value: paceFor(item.engagement_type).variance,
											onChange: (event) => patchPace(item.engagement_type, { variance: Number(event.target.value) }),
											className: "w-full accent-amber-500"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: `rounded-2xl border p-3 ${risk.tone === "amber" ? "border-amber-200 bg-amber-50" : risk.tone === "rose" ? "border-rose-200 bg-rose-50" : "border-emerald-200 bg-emerald-50"}`,
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "mb-2 flex items-center justify-between font-semibold",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Detection Risk" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "rounded-full bg-white px-2 py-0.5 text-[11px]",
														children: risk.label
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "h-2 overflow-hidden rounded-full bg-white",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: `h-full rounded-full ${risk.tone === "rose" ? "bg-rose-500" : risk.tone === "emerald" ? "bg-emerald-500" : "bg-amber-400"}`,
														style: { width: `${Math.min(100, paceFor(item.engagement_type).variance * 1.6)}%` }
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: `mt-2 text-[12px] ${risk.tone === "rose" ? "text-rose-700" : risk.tone === "emerald" ? "text-emerald-700" : "text-amber-700"}`,
													children: risk.hint
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between rounded-2xl bg-[#f8fafc] px-3 py-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Per run:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
												"-",
												spreadDown.toLocaleString("en-IN"),
												" to +",
												spreadUp.toLocaleString("en-IN")
											] })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											role: "switch",
											"aria-checked": paceFor(item.engagement_type).peak,
											onClick: () => patchPace(item.engagement_type, { peak: !paceFor(item.engagement_type).peak }),
											className: `flex w-full cursor-pointer items-center justify-between rounded-2xl px-3 py-2 text-left ${paceFor(item.engagement_type).peak ? "bg-amber-50 ring-1 ring-amber-200" : "bg-[#f4f7fb]"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "flex items-center gap-1 text-[12px] font-semibold tracking-wide text-[#334155]",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5" }),
													" PEAK HOURS BOOST",
													paceFor(item.engagement_type).peak && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "rounded-full bg-amber-500 px-1.5 text-[10px] font-bold text-white",
														children: "ON"
													})
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] text-[#94a3b8]",
												children: paceFor(item.engagement_type).peak ? "Bigger drops between 6–11 PM IST" : "More during 6-11 PM IST"
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `relative h-7 w-12 shrink-0 rounded-full transition ${paceFor(item.engagement_type).peak ? "bg-[#3b82f6]" : "bg-[#dbe4ee]"}`,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-0.5 size-6 rounded-full bg-white shadow transition ${paceFor(item.engagement_type).peak ? "left-5" : "left-0.5"}` })
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-2xl bg-[#f8fafc] p-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "mb-2 flex items-center gap-1 font-semibold",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-4" }), " Schedule Preview"]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "grid grid-cols-3 gap-2 text-center",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
															n: String(rows.length),
															l: "orders"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
															n: formatDuration(hours / Math.max(1, runs)),
															l: "interval"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
															n: rows[rows.length - 1]?.at.toLocaleString("en-IN", {
																month: "short",
																day: "numeric",
																hour: "numeric",
																minute: "2-digit"
															}) ?? "",
															l: "finish"
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: () => setRunsOpen(runsOpen === item.engagement_type ? null : item.engagement_type),
													className: "mt-3 flex w-full items-center justify-center gap-1 text-[12px] font-semibold text-[#64748b]",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "tracking-widest text-[#cbd5e1]",
															children: "≡"
														}),
														" ",
														rows.length,
														" YoYoMedia orders ",
														runsOpen === item.engagement_type ? "▴" : "▾"
													]
												}),
												runsOpen === item.engagement_type && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
													className: "mt-2 max-h-56 space-y-2 overflow-auto text-[12px]",
													children: rows.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
														className: "flex items-center justify-between gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "flex items-center gap-2",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "grid size-5 place-items-center rounded-full bg-[#111827] text-[10px] font-bold text-white",
																children: index + 1
															}), index === 0 ? "places now" : row.at.toLocaleString("en-IN", {
																month: "short",
																day: "numeric",
																hour: "numeric",
																minute: "2-digit"
															})]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "font-semibold text-[#0f172a]",
															children: ["+", row.amount.toLocaleString("en-IN")]
														})]
													}, index))
												})
											]
										})
									]
								})
							]
						}, item.engagement_type);
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Delivery, {
				pattern,
				picker,
				family,
				onFamily: setFamily,
				onTogglePicker: () => setPicker((value) => !value),
				onPattern: (id) => {
					setPattern(id);
					setFamily(growthTemplate(id).name);
					setPicker(false);
				},
				onNew: () => {
					const next = 1 + Math.floor(Math.random() * 552);
					setPattern(next);
					setFamily(growthTemplate(next).name);
				},
				quantities,
				pace,
				curves
			}),
			report.off && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[24px] border border-amber-200 bg-amber-50 p-4 text-[13px]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-semibold text-amber-800",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "mr-1 inline size-4" }),
							" Ratios look off — order will still place",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "ml-2 rounded-full bg-white px-2 py-0.5 text-[11px]",
								children: [
									"Botting ",
									report.botting,
									"% · Health ",
									report.health,
									"/100"
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex flex-wrap gap-2",
						children: report.checks.map((check) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded-full bg-white px-2 py-1 text-[11px]",
							children: [
								check.label,
								": ",
								check.pct.toFixed(2),
								"%"
							]
						}, check.key))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 list-disc pl-5 text-[12px] text-amber-900",
						children: report.suggestions.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, line))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-[12px] text-amber-800",
						children: "Tip: Instagram's organic norms are ~4–10% likes, ~0.3–1.5% comments per view. Stay close to these for the most natural-looking growth."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "overflow-hidden rounded-[24px] border border-[#cfe8dc] bg-[#f4fbf7]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setScheduleOpen((open) => !open),
					className: "flex h-12 w-full items-center justify-center gap-2 text-[14px] font-semibold text-[#1f2937]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[#64748b]",
							children: scheduleOpen ? "⌃" : "⌄"
						}),
						scheduleOpen ? "Hide" : "Show",
						" Schedule (",
						runDrafts.filter((row) => row.on).length,
						"/",
						schedule.length,
						")"
					]
				}), scheduleOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-h-[420px] space-y-2 overflow-auto px-3 pb-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-1 text-[11px] text-[#64748b]",
							children: "Tick ho to run on hai aur place hoga. Box khali ho to run off hai, order nahi lagega."
						}),
						runDrafts.slice(0, 80).map((row) => {
							const Icon = ICONS[row.type] ?? Eye;
							const tone = TYPE_TONE[row.type] ?? TYPE_TONE.views;
							const when = new Date(row.at);
							let running = 0;
							for (const item of runDrafts) {
								if (item.type !== row.type || !item.on) continue;
								if (item.at > row.at || item.at === row.at && item.key > row.key) continue;
								running += Math.max(0, Math.floor(Number(item.amount) || 0));
							}
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `flex flex-wrap items-center gap-2 rounded-2xl bg-[#e7f6ee] px-3 py-2 ${row.on ? "" : "opacity-50"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										role: "checkbox",
										"aria-checked": row.on,
										"aria-label": row.on ? "Run on" : "Run off",
										onClick: () => patchRun(row.key, { on: !row.on }),
										className: `grid size-6 shrink-0 place-items-center rounded-[6px] border ${row.on ? "border-[#f97316] bg-[#f97316] text-white" : "border-[#94a3b8] bg-white text-transparent"}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
											viewBox: "0 0 20 20",
											className: "size-4",
											fill: "none",
											stroke: "currentColor",
											strokeWidth: "2.6",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4 10.5 8 14.5 16 5.5" })
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "datetime-local",
										disabled: !row.on,
										value: row.at,
										onChange: (event) => patchRun(row.key, { at: event.target.value }),
										className: "h-8 w-[168px] rounded-lg border border-[#d7e7de] bg-white px-2 text-[12px] text-[#334155] disabled:opacity-60"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1 rounded-full bg-[#111827] px-2 py-1 text-[12px] font-bold text-white",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: `size-3.5 ${tone.icon}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: row.amount,
											disabled: !row.on,
											inputMode: "numeric",
											onChange: (event) => patchRun(row.key, { amount: event.target.value.replace(/[^\d]/g, "") }),
											className: "w-16 bg-transparent text-right outline-none disabled:opacity-60"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-white px-2 py-1 text-[12px] font-semibold text-[#334155]",
										children: row.on && !Number.isNaN(when.getTime()) ? `=${running.toLocaleString("en-IN")}` : "off"
									})
								]
							}, row.key);
						}),
						runDrafts.length > 80 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "px-2 text-[12px] text-[#64748b]",
							children: [
								"Pehle 80 runs yahan hain. Baaki ",
								runDrafts.length - 80,
								" runs isi pattern pe place honge."
							]
						}),
						schedule.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-2 pb-2 text-[12px] text-[#64748b]",
							children: "Quantity set karo, schedule yahin dikhega."
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[24px] border border-[#e7eef6] bg-white p-4 shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[28px] font-bold text-[#2458c5]",
						children: [
							inr(totalPaise),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[16px] font-semibold text-[#64748b]",
								children: "total"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[13px] text-[#64748b]",
						children: [
							totalQty.toLocaleString("en-IN"),
							" engagements • ",
							active.length,
							" types"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-[12px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center gap-1 text-[#64748b]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-3" }),
									" Balance: ",
									inr(balance)
								]
							}), balance < totalPaise && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold text-rose-500",
								children: "Insufficient balance"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: !canPay || pending,
							onClick: submit,
							className: "h-11 flex-1 rounded-xl bg-[#3b82f6] text-[14px] font-semibold text-white disabled:opacity-60",
							children: pending ? "Placing…" : `Place Order — ${inr(totalPaise)}`
						})]
					}),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-[13px] text-rose-600",
						children: error
					})
				]
			}),
			ask && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40 grid place-items-center bg-black/25 p-4",
				onClick: () => setAsk(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex max-h-[88vh] w-full max-w-[440px] flex-col overflow-hidden rounded-[28px] border border-[#e7eef6] bg-white shadow-2xl",
					onClick: (event) => event.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between px-5 pt-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center gap-2 font-['Playfair_Display',Georgia,serif] text-[22px] font-semibold text-[#1f2937]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4 text-amber-500" }), " Organic AI Assistant"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-[13px] text-[#64748b]",
								children: "Analyzes your link and gives real-time engagement guidance."
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setAsk(false),
								className: "grid size-8 place-items-center rounded-full text-[#94a3b8] hover:bg-[#f4f7fb]",
								"aria-label": "Close",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 border-t border-[#eef2f6] px-5 py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2 text-[12px] font-semibold",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full border border-[#e7eef6] px-3 py-1 lowercase",
											children: platform
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full border border-[#e7eef6] px-3 py-1 text-[#94a3b8]",
											children: platform === "tiktok" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music2, { className: "size-3.5" }) : "—"
										}),
										/^https?:\/\//.test(link.trim()) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "max-w-[180px] truncate rounded-full bg-emerald-50 px-3 py-1 text-emerald-700",
											children: link.trim()
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "inline-flex items-center gap-1 text-amber-500",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-3.5" }), " paste a link"]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex flex-wrap gap-2 text-[13px] font-semibold text-[#334155]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1 rounded-full border border-[#e7eef6] px-3 py-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5 text-[#64748b]" }),
											" ",
											(quantities.views ?? 0).toLocaleString("en-IN"),
											" Views"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1 rounded-full border border-[#e7eef6] px-3 py-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "size-3.5 text-rose-400" }),
											" ",
											(quantities.likes ?? 0).toLocaleString("en-IN"),
											" Likes"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 flex items-center gap-1 text-[13px] text-[#334155]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3.5 text-amber-500" }),
										" Health: ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [report.health, "/100"] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[#94a3b8]",
											children: "•"
										}),
										" Botting risk: ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [report.botting, "%"] })
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 space-y-3 overflow-auto border-t border-[#eef2f6] px-5 py-4",
							children: [
								chat.map((message, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: message.role === "user" ? "ml-8 rounded-2xl bg-[#111827] px-3 py-2 text-[13px] text-white" : "rounded-2xl bg-[#eef5fb] px-3 py-3 text-[13px] leading-relaxed whitespace-pre-line text-[#1e293b]",
									children: [message.text, message.apply && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => {
											const next = applyMix(message.mix);
											setChat((current) => [...current, {
												role: "assistant",
												text: `Applied ${next.likes.toLocaleString("en-IN")} likes, ${next.saves.toLocaleString("en-IN")} saves, ${next.shares.toLocaleString("en-IN")} shares, ${next.reposts.toLocaleString("en-IN")} reposts.`
											}]);
										},
										className: "mt-2 rounded-full bg-white px-3 py-1 text-[12px] font-semibold text-[#2458c5]",
										children: "Apply this mix"
									})]
								}, index)),
								aiPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[12px] text-[#64748b]",
									children: "Asking the free model…"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap gap-2",
									children: [
										"Is this safe?",
										"How long will delivery take?",
										"How many more likes should I add?",
										"Suggest the best ratio"
									].map((prompt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => askOrganic(prompt),
										className: "rounded-full border border-amber-200 px-3 py-1 text-[12px] font-semibold text-amber-700",
										children: prompt
									}, prompt))
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "flex items-center gap-2 border-t border-[#eef2f6] px-4 py-3",
							onSubmit: (event) => {
								event.preventDefault();
								askOrganic(draft);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: draft,
								onChange: (event) => setDraft(event.target.value),
								placeholder: "Type your question...",
								className: "h-11 min-w-0 flex-1 rounded-full bg-[#e8f1fb] px-4 text-[13px] outline-none"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: "grid size-11 place-items-center rounded-full bg-[#e7b38a] text-white",
								"aria-label": "Send",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
							})]
						})
					]
				})
			})
		]
	});
}
function ToggleCard({ on, title, badge, text, icon, tone, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex items-center gap-3 rounded-2xl border p-3 ${tone === "emerald" ? "border-emerald-100 bg-emerald-50/70" : "border-sky-100 bg-sky-50/70"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid size-9 place-items-center rounded-full bg-white text-[#0f766e]",
				children: icon
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[13px] font-semibold",
					children: [
						title,
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-1 rounded-full bg-emerald-100 px-1.5 text-[9px] text-emerald-700",
							children: badge
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] text-[#64748b]",
					children: text
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
				on,
				onClick
			})
		]
	});
}
function PlatformButton({ active, onClick, icon, label, gradient }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: `inline-flex h-11 items-center gap-2 rounded-full px-4 text-[12px] font-bold tracking-wide ${active ? `bg-gradient-to-r ${gradient} text-white` : "bg-[#f3f6fa] text-[#64748b]"}`,
		children: [
			icon,
			" ",
			label
		]
	});
}
function Stat({ n, l }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl bg-white p-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[16px] font-bold",
			children: n
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] text-[#94a3b8]",
			children: l
		})]
	});
}
var PREVIEW_TYPES = [
	{
		key: "views",
		label: "Views",
		Icon: Eye,
		tint: "text-[#7c5c3a]"
	},
	{
		key: "likes",
		label: "Likes",
		Icon: Heart,
		tint: "text-rose-500"
	},
	{
		key: "saves",
		label: "Saves",
		Icon: Bookmark,
		tint: "text-[#3b82f6]"
	},
	{
		key: "shares",
		label: "Shares",
		Icon: Share2,
		tint: "text-[#2563eb]"
	},
	{
		key: "reposts",
		label: "Reposts",
		Icon: RefreshCw,
		tint: "text-[#0ea5e9]"
	}
];
function EngagementRate({ quantities }) {
	const views = Math.max(0, Math.floor(quantities.views || 0));
	const likes = Math.max(0, Math.floor(quantities.likes || 0));
	const shares = Math.max(0, Math.floor(quantities.shares || 0));
	const saves = Math.max(0, Math.floor(quantities.saves || 0));
	const rate = (qty) => views > 0 ? qty / views * 100 : 0;
	const text = (qty) => `${rate(qty).toFixed(2)}%`;
	const total = likes + shares + saves;
	const overall = rate(total);
	const rows = [
		{
			label: "Likes",
			qty: likes,
			color: "#60a5fa"
		},
		{
			label: "Shares",
			qty: shares,
			color: "#22d3ee"
		},
		{
			label: "Saves",
			qty: saves,
			color: "#f472b6"
		},
		{
			label: "Shares + Saves",
			qty: shares + saves,
			color: "#a78bfa"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-[28px] border border-[#e7eef6] bg-white p-4 shadow-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[18px] font-bold text-[#0f172a]",
					children: "Live Engagement Rate Preview"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[12px] text-[#94a3b8]",
					children: "Full order engagement analytics"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full border border-emerald-300 px-2 py-1 text-[11px] font-bold text-emerald-600",
					children: "LIVE"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl bg-[#f4f7fb] p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-semibold text-[#64748b]",
							children: "Views"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[22px] font-bold text-[#0f172a]",
							children: views.toLocaleString("en-IN")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[12px] text-[#64748b]",
							children: "Base 100%"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl bg-[#f4f7fb] p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-semibold text-[#64748b]",
							children: "Total Engagement"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[22px] font-bold text-[#0f172a]",
							children: total.toLocaleString("en-IN")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[12px] text-[#64748b]",
							children: text(total)
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 space-y-2",
				children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-[#e7eef6] px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between text-[12px] font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							row.qty.toLocaleString("en-IN"),
							" · ",
							text(row.qty)
						] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 h-1.5 overflow-hidden rounded-full bg-[#eef2f6]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-1.5 rounded-full",
							style: {
								width: `${Math.max(0, Math.min(100, rate(row.qty)))}%`,
								background: row.color
							}
						})
					})]
				}, row.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 rounded-2xl bg-[#111827] px-3 py-3 text-white",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[12px] text-white/70",
						children: "Overall Engagement Rate"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[28px] font-bold",
						children: [overall.toFixed(2), "%"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[11px] text-white/60",
						children: [
							total.toLocaleString("en-IN"),
							" engagements / ",
							views.toLocaleString("en-IN"),
							" views"
						]
					})
				]
			})
		]
	});
}
function Delivery({ pattern, picker, family, onFamily, onTogglePicker, onPattern, onNew, quantities, pace, curves }) {
	const specs = [
		{
			key: "views",
			color: "#c084fc",
			label: "Views"
		},
		{
			key: "likes",
			color: "#60a5fa",
			label: "Likes"
		},
		{
			key: "shares",
			color: "#22d3ee",
			label: "Shares"
		},
		{
			key: "saves",
			color: "#f472b6",
			label: "Saves"
		}
	];
	const delivery = {};
	for (const spec of specs) {
		const qty = quantities[spec.key] ?? 0;
		const current = pace[spec.key] ?? DEFAULT_PACE;
		const runs = qty > 0 && current.runsMode === "manual" && current.runs > 0 ? current.runs : autoRuns(Math.max(qty, 1), spec.key);
		delivery[spec.key] = {
			hours: qty > 0 ? windowHours(current, Math.max(runs, 1), quantities.views || 1e4) : 0,
			runs: qty > 0 ? runs : 0,
			variance: current.variance,
			peak: current.peak,
			curve: curves[spec.key] ?? curves.views
		};
	}
	const preview = growthPreview({
		quantities,
		delivery
	});
	const drawn = preview.drawn;
	const span = preview.span;
	const width = 640;
	const height = 230;
	const left = 36;
	const top = 12;
	const innerW = 596;
	const innerH = 190;
	const linePath = (points) => points.map((point, index) => {
		const x = left + index / (points.length - 1) * innerW;
		const y = top + (1 - point) * innerH;
		return `${index === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
	}).join(" ");
	const area = `${linePath(drawn.find((item) => item.key === "views")?.points ?? [])} L632,202 L${left},202 Z`;
	const marks = [
		0,
		.25,
		.5,
		.75,
		1
	].map((t) => {
		const hoursAt = span * t;
		return {
			t,
			label: t === 0 ? "Start" : hoursAt < 48 ? `${Math.round(hoursAt)}h` : `${(hoursAt / 24).toFixed(1)}d`
		};
	});
	const cards = PREVIEW_TYPES.map((type) => {
		const qty = quantities[type.key] ?? 0;
		const current = pace[type.key] ?? DEFAULT_PACE;
		const runs = current.runsMode === "manual" && current.runs > 0 ? current.runs : autoRuns(Math.max(qty, 1), type.key);
		return {
			...type,
			qty,
			runs: qty > 0 ? runs : 0,
			window: current.window === "auto" ? "Auto" : current.window === "custom" ? `${current.customHours}h` : current.window,
			variance: current.variance
		};
	}).filter((card) => card.qty > 0 || card.key === "views");
	const total = Object.values(quantities).reduce((sum, value) => sum + value, 0);
	const runSum = cards.reduce((sum, card) => sum + card.runs, 0);
	const hours = Math.max(...cards.map((card) => windowHours(pace[card.key] ?? DEFAULT_PACE, Math.max(card.runs, 1), quantities.views || 1e4)), .1);
	const bot = preview.bot;
	const botTone = bot.score <= 20 ? "border-emerald-300 text-emerald-700" : bot.score <= 40 ? "border-teal-300 text-teal-700" : bot.score <= 60 ? "border-amber-300 text-amber-700" : bot.score <= 80 ? "border-orange-300 text-orange-700" : "border-rose-300 text-rose-700";
	const botBar = bot.score <= 20 ? "#22c55e" : bot.score <= 40 ? "#14b8a6" : bot.score <= 60 ? "#f59e0b" : bot.score <= 80 ? "#f97316" : "#ef4444";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-[28px] border border-[#e7eef6] bg-white p-4 shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-11 shrink-0 place-items-center rounded-2xl bg-[#e8f1ff] text-[#3b82f6]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[18px] font-bold text-[#0f172a]",
								children: "Live Organic Growth Preview"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[12px] text-[#94a3b8]",
								children: "Bursts + pauses • Service-wise natural steps"
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: `inline-flex h-9 items-center rounded-full border px-3 text-[12px] font-semibold ${botTone}`,
							children: ["Bot ", bot.score]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap items-center gap-2 text-[12px] font-semibold",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1 rounded-full bg-[#3b82f6] px-3 py-1 text-white",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-3.5" }),
									" ",
									total.toLocaleString("en-IN"),
									" total"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1 rounded-full bg-[#f1f5f9] px-3 py-1 text-[#334155]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-3.5" }),
									" ",
									runSum,
									" runs"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1 rounded-full bg-[#f1f5f9] px-3 py-1 text-[#334155]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5" }),
									" ",
									formatDuration(hours)
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex flex-wrap gap-2 text-[12px] text-[#64748b]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1 rounded-full bg-[#f8fafc] px-2 py-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-[#c084fc]" }),
									" ",
									(quantities.views ?? 0).toLocaleString("en-IN")
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1 rounded-full bg-[#f8fafc] px-2 py-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-[#60a5fa]" }),
									" ",
									(quantities.likes ?? 0).toLocaleString("en-IN")
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1 rounded-full bg-[#f8fafc] px-2 py-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-[#22d3ee]" }),
									" ",
									(quantities.shares ?? 0).toLocaleString("en-IN")
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1 rounded-full bg-[#f8fafc] px-2 py-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-[#f472b6]" }),
									" ",
									(quantities.saves ?? 0).toLocaleString("en-IN")
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						viewBox: `0 0 ${width} ${height}`,
						className: "mt-2 h-64 w-full rounded-2xl bg-[#0b1220]",
						children: [
							[
								.25,
								.5,
								.75
							].map((tick) => {
								const y = top + (1 - tick) * innerH;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
									x1: left,
									x2: 632,
									y1: y,
									y2: y,
									stroke: "#1e293b"
								}, tick);
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
								d: area,
								fill: "#c084fc",
								opacity: "0.16"
							}),
							drawn.filter((line) => line.qty > 0).map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
								d: linePath(line.points),
								fill: "none",
								stroke: line.color,
								strokeWidth: line.key === "views" ? 2.8 : 2.2,
								strokeLinejoin: "round",
								strokeLinecap: "round"
							}, line.key)),
							marks.map((mark) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
								x: left + mark.t * innerW,
								y: 222,
								textAnchor: mark.t === 0 ? "start" : mark.t === 1 ? "end" : "middle",
								fontSize: "10",
								fill: "#94a3b8",
								children: mark.label
							}, mark.label))
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex flex-wrap justify-center gap-3 text-[12px] text-[#64748b]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-[#c084fc]" }), " Views"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-[#60a5fa]" }), " Likes"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-[#22d3ee]" }), " Shares"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-[#f472b6]" }), " Saves"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `mt-3 rounded-2xl border p-3 ${botTone}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[14px] font-bold",
									children: [
										"Bot score ",
										bot.score,
										"/100"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "rounded-full border px-2 py-0.5 text-[11px] font-semibold",
									children: [
										bot.band,
										" · ",
										bot.name
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 h-2 overflow-hidden rounded-full bg-[#e7eef6]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-2 rounded-full",
									style: {
										width: `${bot.score}%`,
										background: botBar
									}
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-[12px] font-semibold",
								children: bot.action
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 space-y-2",
								children: (bot.checks ?? []).map((check) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `rounded-xl border px-3 py-2 text-[12px] ${check.ok ? "border-emerald-200 bg-emerald-50 text-emerald-800" : "border-rose-200 bg-rose-50 text-rose-800"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-bold",
											children: check.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-0.5",
											children: check.why
										}),
										check.fix ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-0.5 font-semibold",
											children: check.fix
										}) : null
									]
								}, check.label))
							}),
							(bot.checks ?? []).every((check) => check.ok) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-[12px] font-semibold",
								children: "Sab selected services ka graph theek hai. Ab order place kar sakte ho."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-[12px] font-semibold",
								children: "Jis service ka graph kharab hai, pehle upar diya hua fix karo. Phir order lagao."
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EngagementRate, { quantities }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-[28px] border border-[#e7eef6] bg-white p-4 shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[18px] font-bold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sprout, { className: "mr-1 inline size-4 text-emerald-500" }), " Per-Type Organic Delivery Preview"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[13px] text-[#64748b]",
						children: "Each type has its own organic settings"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2 text-[12px] font-semibold",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1 rounded-full bg-[#111827] px-3 py-1 text-white",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-3.5" }),
									" ",
									total.toLocaleString("en-IN")
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1 rounded-full bg-[#f1f5f9] px-3 py-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5" }),
									" ",
									runSum,
									" runs"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1 rounded-full bg-[#f1f5f9] px-3 py-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5" }),
									" ",
									formatDuration(hours)
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid grid-cols-5 gap-2",
						children: cards.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl bg-[#f4f7fb] px-2 py-3 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(card.Icon, { className: `mx-auto size-4 ${card.tint}` }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-[16px] font-bold",
									children: card.runs
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-[#94a3b8]",
									children: card.window
								})
							]
						}, card.key))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 rounded-2xl bg-[#f4f7fb] p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-[13px] font-semibold text-[#334155]",
							children: "Per-Type Settings"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "grid gap-1 text-[13px] sm:grid-cols-2",
							children: cards.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(card.Icon, { className: `size-3.5 ${card.tint}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									card.label,
									": ",
									card.window,
									" · ±",
									card.variance,
									"%"
								] })]
							}, card.key))
						})]
					})
				]
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Authed, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EngagementConsole, {}) });
//#endregion
export { SplitComponent as component };
