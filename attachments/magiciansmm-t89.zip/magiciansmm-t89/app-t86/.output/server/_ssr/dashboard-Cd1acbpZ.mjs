import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as Receipt, I as Library, J as Clock, K as Database, Q as Cable, T as RefreshCw, U as Globe, ct as Activity, f as ShoppingBag, i as Wallet, q as CodeXml, r as WandSparkles, y as Server } from "../_libs/lucide-react.mjs";
import { At as useCurrentUserState, D as apiBalances, J as getDeskRole, Z as getPrefs, et as inr, q as getDashboard } from "./shell-CfBlaVSk.mjs";
import { t as Authed } from "./gate-DNi4gEUE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-Cd1acbpZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var welcome_banner_default = "/assets/welcome-banner-D_YPOlOJ.jpg";
function greeting() {
	const hour = (/* @__PURE__ */ new Date()).getHours();
	if (hour < 12) return "Good morning,";
	if (hour < 18) return "Good afternoon,";
	return "Good evening,";
}
var API_ICONS = [
	CodeXml,
	Server,
	Database,
	Globe,
	Cable
];
var TONES = [
	{
		wash: "from-violet-600 to-fuchsia-500",
		Icon: Wallet
	},
	{
		wash: "from-sky-500 to-indigo-500",
		Icon: ShoppingBag
	},
	{
		wash: "from-emerald-500 to-teal-400",
		Icon: Activity
	},
	{
		wash: "from-amber-500 to-orange-400",
		Icon: Receipt
	}
];
function Dashboard() {
	const { user } = useCurrentUserState();
	const [data, setData] = (0, import_react.useState)(null);
	const [name, setName] = (0, import_react.useState)("");
	const [admin, setAdmin] = (0, import_react.useState)(false);
	const [balances, setBalances] = (0, import_react.useState)([]);
	const [checking, setChecking] = (0, import_react.useState)(false);
	const [checkedAt, setCheckedAt] = (0, import_react.useState)("");
	function loadBalances() {
		setChecking(true);
		apiBalances().then((rows) => {
			setBalances(rows);
			setCheckedAt((/* @__PURE__ */ new Date()).toLocaleTimeString("en-IN", {
				hour: "2-digit",
				minute: "2-digit"
			}));
		}).catch(() => setBalances([])).finally(() => setChecking(false));
	}
	(0, import_react.useEffect)(() => {
		getDashboard().then(setData).catch(() => setData(null));
		getPrefs().then((prefs) => setName(prefs.full_name || "")).catch(() => setName(""));
		getDeskRole().then((role) => {
			if (role !== "admin") return;
			setAdmin(true);
			loadBalances();
		}).catch(() => setAdmin(false));
	}, []);
	const display = name || user?.displayName || "Member";
	const cards = [
		[
			"BALANCE",
			data ? inr(data.balance_paise) : "—",
			"Available funds"
		],
		[
			"TOTAL ORDERS",
			String(data?.order_count ?? 0),
			`${data?.order_count ?? 0} completed`
		],
		[
			"ACTIVE",
			String(data?.queued_count ?? 0),
			"In progress"
		],
		[
			"TOTAL SPENT",
			data ? inr(data.spend_paise) : "—",
			"All time"
		]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "welcome-banner relative aspect-[1874/839] overflow-hidden rounded-[28px]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: welcome_banner_default,
						alt: "",
						className: "absolute inset-0 h-full w-full object-cover object-center"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-black/80 via-black/25 to-transparent" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "welcome-shine" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 max-w-lg p-6 md:p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rise-in text-[13px] text-white/85",
								children: greeting()
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "rise-in rise-d1 text-[34px] font-extrabold leading-none text-white md:text-[42px]",
								children: ["Welcome back, ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "name-glow text-amber-300",
									children: display
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rise-in rise-d2 mt-2 max-w-sm text-[13px] text-white/85",
								children: "Your SMM panel is ready. Place a drip, check APIs, add credit."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/engagement-order",
									className: "btn-live inline-flex h-11 items-center rounded-full bg-amber-300 px-5 text-[13px] font-semibold text-slate-950",
									children: "Create New Order"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/mass",
									className: "btn-pop rise-d4 inline-flex h-11 items-center rounded-full border border-white/50 bg-black/30 px-5 text-[13px] font-semibold text-white backdrop-blur",
									children: "Mass Order"
								})]
							})
						]
					})
				]
			}),
			admin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "api-balance",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "api-balance-head",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "api-balance-mark",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeXml, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "API balance" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5" }),
								" ",
								checkedAt ? `Checked ${checkedAt}` : "Not checked yet",
								" · Full engagement APIs only"
							] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: loadBalances,
							disabled: checking,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `size-3.5 ${checking ? "animate-spin" : ""}` }),
								" ",
								checking ? "Checking" : "Refresh"
							]
						})
					]
				}), balances.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "api-balance-empty",
					children: checking ? "Balances la rahe hain…" : "Koi API save nahi. Full engagement APIs mein URL + key daalo."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: balances.map((row, index) => {
					const Icon = API_ICONS[index % API_ICONS.length];
					const code = row.currency.toUpperCase();
					const tone = code === "INR" ? "cyan" : code === "USD" || row.low ? "pink" : "";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						style: { animationDelay: `${index * 50}ms` },
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "api-balance-icon",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate capitalize",
										children: row.label.replaceAll(":", " · ")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", {
										className: "block truncate",
										children: [
											row.host,
											" · key ***",
											row.keyTail
										]
									}),
									row.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
										className: "api-balance-error",
										children: row.error
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "api-balance-amt",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									className: tone,
									children: row.error ? "—" : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										row.balance.toLocaleString("en-IN"),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.currency })
									] })
								}), row.low && !row.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "Low · refill" })]
							})
						]
					}, `${row.host}-${row.keyTail}-${row.label}`);
				}) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: cards.map(([label, value, hint], index) => {
					const tone = TONES[index % TONES.length];
					const Icon = tone.Icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: `stat-pop relative overflow-hidden rounded-2xl bg-gradient-to-br p-4 text-white ${tone.wash}`,
						style: { animationDelay: `${index * 60}ms` },
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-2 grid size-8 place-items-center rounded-xl bg-white/20",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] font-semibold tracking-wide text-white/80",
								children: label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[22px] font-extrabold",
								children: value
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[12px] text-white/75",
								children: hint
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								viewBox: "0 0 120 36",
								className: "mt-2 h-8 w-full opacity-80",
								"aria-hidden": true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
									d: "M0 28 C 18 26, 24 18, 40 20 S 62 8, 78 14 100 6 120 10",
									fill: "none",
									stroke: "white",
									strokeWidth: "2"
								})
							})
						]
					}, label);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: "All Orders"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-[13px] text-[#94a3b8]",
							children: data?.recent.length ? `${data.recent.length} recent` : "No engagement orders yet"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/engagement-order",
							className: "mt-4 inline-flex h-10 items-center rounded-full bg-[#3b82f6] px-4 text-[13px] font-semibold text-white",
							children: "Create First Order"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: "Single Orders"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-[13px] text-[#94a3b8]",
							children: "Browse a service and place one order"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/catalog",
							className: "mt-4 inline-flex h-10 items-center rounded-full bg-[#3b82f6] px-4 text-[13px] font-semibold text-white",
							children: "Place Order"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-2 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/engagement-order",
						className: "flex items-center justify-between rounded-2xl border p-3 text-[12px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WandSparkles, { className: "mb-1 size-4 text-violet-300" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
								className: "block",
								children: "Full Engagement"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[#94a3b8]",
								children: "Views + Likes + Saves"
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "→" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/wallet",
						className: "flex items-center justify-between rounded-2xl border p-3 text-[12px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "mb-1 size-4 text-emerald-300" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
								className: "block",
								children: "Add Funds"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[#94a3b8]",
								children: data ? inr(data.balance_paise) : "Deposit to wallet"
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "→" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/catalog",
						className: "flex items-center justify-between rounded-2xl border p-3 text-[12px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Library, { className: "mb-1 size-4 text-cyan-300" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
								className: "block",
								children: "All Services"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[#94a3b8]",
								children: "Browse catalog"
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "→" })]
					})
				]
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Authed, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, {}) });
//#endregion
export { SplitComponent as component };
