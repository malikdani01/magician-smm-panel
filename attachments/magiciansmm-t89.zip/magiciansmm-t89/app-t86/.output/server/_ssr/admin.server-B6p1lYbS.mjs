import { t as __exportAll } from "./rolldown-runtime-D7D4PA-g.mjs";
import { n as PROVIDER_MIN, u as getSql } from "./organic-DU6S6wDh.mjs";
import { n as dripEnabled, r as fetchProviderCatalog, t as detectPlatform } from "./providers.server-BTYWPfD2.mjs";
import { t as usdQtyToPaise } from "./fx-Ci4OJEB9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.server-B6p1lYbS.js
var admin_server_exports = /* @__PURE__ */ __exportAll({
	addCustomService: () => addCustomService,
	adminGateways: () => adminGateways,
	bindingMap: () => bindingMap,
	creditCustomer: () => creditCustomer,
	deleteProvider: () => deleteProvider,
	deskRole: () => deskRole,
	enabledCatalog: () => enabledCatalog,
	findManagedById: () => findManagedById,
	findManagedByProviderId: () => findManagedByProviderId,
	listBindings: () => listBindings,
	listClaims: () => listClaims,
	listCustomers: () => listCustomers,
	listManaged: () => listManaged,
	listProviders: () => listProviders,
	managedToLive: () => managedToLive,
	myClaims: () => myClaims,
	panelTypeRates: () => panelTypeRates,
	paymentDesk: () => paymentDesk,
	providerKeys: () => providerKeys,
	publicGateways: () => publicGateways,
	removeCustomer: () => removeCustomer,
	requireAdmin: () => requireAdmin,
	reviewClaim: () => reviewClaim,
	saveBindings: () => saveBindings,
	saveGateway: () => saveGateway,
	saveManaged: () => saveManaged,
	savePaymentDesk: () => savePaymentDesk,
	saveProvider: () => saveProvider,
	saveServiceActiveLimit: () => saveServiceActiveLimit,
	serviceActiveLimit: () => serviceActiveLimit,
	submitClaim: () => submitClaim,
	syncManagedServices: () => syncManagedServices,
	syncProviderCatalog: () => syncProviderCatalog
});
var PLATFORMS = ["instagram", "tiktok"];
var TYPES = [
	"views",
	"likes",
	"saves",
	"shares",
	"reposts",
	"comments"
];
var ENGAGEMENT_SLOTS = PLATFORMS.flatMap((platform) => TYPES.map((type) => `${platform}:${type}`));
async function deskRole(userId) {
	return (await (await getSql())`select role from user_roles where user_id = ${userId} limit 1`)[0]?.role === "admin" ? "admin" : "customer";
}
async function requireAdmin(userId) {
	if (await deskRole(userId) !== "admin") throw new Error("Admin only.");
}
async function bindingMap() {
	const rows = await listBindings();
	return Object.fromEntries(rows.filter((row) => row.section_enabled === false || row.api_key || row.providers?.some((item) => item.api_key)).map((row) => [row.slot, row]));
}
function defaultMin(slot) {
	const type = slot.includes(":") ? slot.split(":")[1] : slot;
	return PROVIDER_MIN[type] ?? 10;
}
function parseProviders(raw, fallbackUrl, fallbackKey) {
	let parsed = [];
	try {
		const value = JSON.parse(raw || "[]");
		if (Array.isArray(value)) parsed = value.map((item) => ({
			api_url: String(item?.api_url || "").trim(),
			api_key: String(item?.api_key || "").trim()
		})).filter((item) => item.api_key);
	} catch {
		parsed = [];
	}
	if (parsed.length === 0 && fallbackKey.trim() && fallbackUrl.trim()) parsed = [{
		api_url: fallbackUrl.trim(),
		api_key: fallbackKey.trim()
	}];
	return parsed;
}
async function serviceActiveLimit() {
	const sql = await getSql();
	await sql`create table if not exists desk_meta (key text primary key, value text not null default '')`;
	const rows = await sql`select value from desk_meta where key = 'service_active_limit' limit 1`;
	const parsed = Math.floor(Number(rows[0]?.value));
	return Number.isFinite(parsed) && parsed >= 1 ? parsed : 1;
}
async function saveServiceActiveLimit(value) {
	const sql = await getSql();
	await sql`create table if not exists desk_meta (key text primary key, value text not null default '')`;
	const next = Math.max(1, Math.min(20, Math.floor(value) || 1));
	await sql`
    insert into desk_meta (key, value) values ('service_active_limit', ${String(next)})
    on conflict (key) do update set value = ${String(next)}
  `;
	return next;
}
async function listBindings() {
	const sql = await getSql();
	await sql`alter table provider_bindings add column if not exists price_per_1k_paise integer not null default 0`;
	await sql`alter table provider_bindings add column if not exists section_enabled boolean not null default true`;
	const rows = await sql`
    select slot, api_url, api_key, service_id, coalesce(pick_mode, 'auto') as pick_mode,
           coalesce(min_quantity, 0)::int as min_quantity,
           coalesce(price_per_1k_paise, 0)::int as price_per_1k_paise,
           coalesce(section_enabled, true) as section_enabled,
           coalesce(providers_json, '') as providers_json
    from provider_bindings
  `;
	const map = Object.fromEntries(rows.map((row) => [row.slot, row]));
	return [...ENGAGEMENT_SLOTS, "single"].map((slot) => {
		const row = map[slot];
		const fallback = defaultMin(slot);
		if (!row) return {
			slot,
			api_url: "",
			api_key: "",
			service_id: "",
			pick_mode: "auto",
			min_quantity: fallback,
			price_per_1k_paise: 0,
			section_enabled: !slot.endsWith(":comments"),
			providers: []
		};
		const providers = parseProviders(row.providers_json || "", row.api_url, row.api_key);
		const first = providers[0];
		return {
			...row,
			api_url: first?.api_url || row.api_url || "",
			api_key: first?.api_key || row.api_key,
			pick_mode: "auto",
			service_id: "",
			min_quantity: row.min_quantity > 0 ? row.min_quantity : fallback,
			price_per_1k_paise: Math.max(0, Number(row.price_per_1k_paise) || 0),
			section_enabled: row.section_enabled !== false,
			providers
		};
	});
}
async function panelTypeRates(platform) {
	const rows = await listBindings();
	const rates = {};
	for (const type of TYPES) {
		const row = rows.find((item) => item.slot === `${platform}:${type}`);
		if (row && row.price_per_1k_paise > 0) rates[type] = row.price_per_1k_paise;
	}
	return rates;
}
async function saveBindings(rows) {
	const sql = await getSql();
	await sql`alter table provider_bindings add column if not exists price_per_1k_paise integer not null default 0`;
	await sql`alter table provider_bindings add column if not exists section_enabled boolean not null default true`;
	const allowed = /* @__PURE__ */ new Set([...ENGAGEMENT_SLOTS, "single"]);
	for (const row of rows) {
		if (!allowed.has(row.slot)) continue;
		const providers = (row.providers || []).map((item) => ({
			api_url: String(item.api_url || "").trim().slice(0, 200),
			api_key: String(item.api_key || "").trim().slice(0, 200)
		})).filter((item) => item.api_key && item.api_url).slice(0, 8);
		const first = providers[0];
		const url = first?.api_url || "";
		const key = first?.api_key || "";
		const minQuantity = Math.max(1, Math.floor(Number(row.min_quantity) || defaultMin(row.slot)));
		const price = Math.max(0, Math.round(Number(row.price_per_1k_paise) || 0));
		const open = row.section_enabled !== false;
		const packed = JSON.stringify(providers);
		await sql`
      insert into provider_bindings (slot, api_url, api_key, service_id, pick_mode, min_quantity, price_per_1k_paise, providers_json, section_enabled)
      values (${row.slot}, ${url}, ${key}, '', 'auto', ${minQuantity}, ${price}, ${packed}, ${open})
      on conflict (slot) do update set
        api_url = ${url}, api_key = ${key}, service_id = '', pick_mode = 'auto',
        min_quantity = ${minQuantity}, price_per_1k_paise = ${price}, providers_json = ${packed},
        section_enabled = ${open}
    `;
	}
}
async function listProviders() {
	return (await getSql())`
    select id, name, api_url, api_key, enabled, last_error, last_sync::text as last_sync
    from smm_providers
    order by name
  `;
}
async function saveProvider(input) {
	const sql = await getSql();
	const id = input.id || crypto.randomUUID();
	const name = input.name.trim().slice(0, 60);
	const url = input.api_url.trim().slice(0, 200);
	const key = input.api_key.trim().slice(0, 200);
	if (!name || !url || !key) throw new Error("Name, API URL and API key are required.");
	await sql`
    insert into smm_providers (id, name, api_url, api_key, enabled)
    values (${id}, ${name}, ${url}, ${key}, ${input.enabled})
    on conflict (id) do update set name = ${name}, api_url = ${url}, api_key = ${key}, enabled = ${input.enabled}
  `;
	return id;
}
async function deleteProvider(id) {
	const sql = await getSql();
	const providerId = String(id || "").trim();
	if (!providerId) throw new Error("Missing provider.");
	await sql`update managed_services set enabled = false where provider_row_id = ${providerId}`;
	if ((await sql`delete from smm_providers where id = ${providerId} returning id`).length === 0) throw new Error("Provider not found.");
}
async function providerKeys(providerRowId) {
	if (!providerRowId) return null;
	return (await (await getSql())`
    select api_url, api_key from smm_providers where id = ${providerRowId} and enabled = true limit 1
  `)[0] ?? null;
}
async function writeCatalog(providerRowId, rows) {
	const sql = await getSql();
	let added = 0;
	let updated = 0;
	for (const row of rows) {
		const providerId = String(row.service);
		const price = usdQtyToPaise(Number(row.rate) || 0, 1e3);
		const existing = await sql`
      select customized from managed_services
      where provider_row_id = ${providerRowId} and provider_service_id = ${providerId}
      limit 1
    `;
		if (existing[0]?.customized) continue;
		const description = String(row.description || "").slice(0, 500);
		const platform = detectPlatform(String(row.category || ""), String(row.name || ""));
		if (existing.length) {
			await sql`
        update managed_services
        set name = ${String(row.name)}, category = ${String(row.category)}, platform = ${platform},
            description = ${description}, price_per_1k_paise = ${price},
            min_quantity = ${Math.floor(Number(row.min) || 1)}, max_quantity = ${Math.floor(Number(row.max) || 1)},
            drip_allowed = ${dripEnabled(row.dripfeed ?? row.drip_feed)}, updated_at = now()
        where provider_row_id = ${providerRowId} and provider_service_id = ${providerId} and customized = false
      `;
			updated += 1;
		} else {
			await sql`
        insert into managed_services (
          id, source, provider_service_id, provider_row_id, platform, category, name, description,
          price_per_1k_paise, min_quantity, max_quantity, drip_allowed, enabled, customized
        ) values (
          ${crypto.randomUUID()}, 'api', ${providerId}, ${providerRowId}, ${platform}, ${String(row.category)}, ${String(row.name)}, ${description},
          ${price}, ${Math.floor(Number(row.min) || 1)}, ${Math.floor(Number(row.max) || 1)}, ${dripEnabled(row.dripfeed ?? row.drip_feed)}, true, false
        )
      `;
			added += 1;
		}
	}
	return {
		total: rows.length,
		added,
		updated
	};
}
async function syncProviderCatalog(providerId) {
	const sql = await getSql();
	const provider = (await sql`
    select api_url, api_key, enabled from smm_providers where id = ${providerId} limit 1
  `)[0];
	if (!provider) throw new Error("Provider not found.");
	if (!provider.enabled) throw new Error("Turn the provider on before fetching.");
	try {
		const result = await writeCatalog(providerId, await fetchProviderCatalog(provider.api_url, provider.api_key));
		await sql`update smm_providers set last_sync = now(), last_error = '' where id = ${providerId}`;
		return result;
	} catch (error) {
		await sql`update smm_providers set last_error = ${(error instanceof Error ? error.message : "Fetch failed.").slice(0, 240)} where id = ${providerId}`;
		throw error;
	}
}
async function syncManagedServices() {
	const providers = (await listProviders()).filter((row) => row.enabled);
	if (providers.length === 0) {
		const single = (await listBindings()).find((row) => row.slot === "single");
		return writeCatalog("", await fetchProviderCatalog(single?.api_url || void 0, single?.api_key || void 0));
	}
	let total = 0;
	let added = 0;
	let updated = 0;
	for (const provider of providers) {
		const result = await syncProviderCatalog(provider.id);
		total += result.total;
		added += result.added;
		updated += result.updated;
	}
	return {
		total,
		added,
		updated
	};
}
async function listManaged(query = "") {
	const rows = await (await getSql())`
    select id, source, provider_service_id, platform, category, name, description,
           price_per_1k_paise, min_quantity, max_quantity, drip_allowed, enabled
    from managed_services
    order by platform, category, name
  `;
	const needle = query.trim().toLowerCase();
	const filtered = needle ? rows.filter((row) => `${row.provider_service_id} ${row.name} ${row.category} ${row.platform}`.toLowerCase().includes(needle)) : rows;
	return {
		total: rows.length,
		services: filtered.slice(0, 120)
	};
}
async function saveManaged(input) {
	await (await getSql())`
    update managed_services
    set name = ${input.name.slice(0, 180)},
        category = ${input.category.slice(0, 160)},
        platform = ${input.platform.slice(0, 32)},
        description = ${input.description.slice(0, 500)},
        price_per_1k_paise = ${Math.max(1, Math.floor(input.price_per_1k_paise))},
        min_quantity = ${Math.max(1, Math.floor(input.min_quantity))},
        max_quantity = ${Math.max(1, Math.floor(input.max_quantity))},
        drip_allowed = ${Boolean(input.drip_allowed)},
        enabled = ${Boolean(input.enabled)},
        customized = true,
        updated_at = now()
    where id = ${input.id}
  `;
}
async function addCustomService(input) {
	const sql = await getSql();
	const id = crypto.randomUUID();
	await sql`
    insert into managed_services (
      id, source, provider_service_id, platform, category, name, description,
      price_per_1k_paise, min_quantity, max_quantity, drip_allowed, enabled, customized
    ) values (
      ${id}, 'custom', ${input.provider_service_id.slice(0, 40)}, ${input.platform.slice(0, 32)},
      ${input.category.slice(0, 160)}, ${input.name.slice(0, 180)}, ${input.description.slice(0, 500)},
      ${Math.max(1, Math.floor(input.price_per_1k_paise))}, ${Math.max(1, Math.floor(input.min_quantity))},
      ${Math.max(1, Math.floor(input.max_quantity))}, ${Boolean(input.drip_allowed)}, ${Boolean(input.enabled)}, true
    )
  `;
	return id;
}
function managedToLive(row) {
	return {
		id: Number(row.provider_service_id) || 0,
		platform: row.platform,
		category: row.category,
		name: row.name,
		min: row.min_quantity,
		max: row.max_quantity,
		rateUsd: row.price_per_1k_paise / 8400,
		note: row.description,
		dripAllowed: Boolean(row.drip_allowed),
		managedId: row.id,
		providerName: row.provider_name || ""
	};
}
async function enabledCatalog() {
	const sql = await getSql();
	if (!(await sql`select count(*)::int as n from managed_services`)[0]?.n) return null;
	return await sql`
    select m.id, m.source, m.provider_service_id, m.platform, m.category, m.name, m.description,
           m.price_per_1k_paise, m.min_quantity, m.max_quantity, m.drip_allowed, m.enabled,
           coalesce(p.name, '') as provider_name
    from managed_services m
    left join smm_providers p on p.id = m.provider_row_id
    where m.enabled = true
    order by m.platform, m.category, m.name
  `;
}
async function findManagedById(id) {
	return (await (await getSql())`
    select id, source, provider_service_id, provider_row_id, platform, category, name, description,
           price_per_1k_paise, min_quantity, max_quantity, drip_allowed, enabled
    from managed_services
    where id = ${id}
    limit 1
  `)[0] ?? null;
}
async function findManagedByProviderId(providerServiceId) {
	return (await (await getSql())`
    select id, source, provider_service_id, provider_row_id, platform, category, name, description,
           price_per_1k_paise, min_quantity, max_quantity, drip_allowed, enabled
    from managed_services
    where provider_service_id = ${providerServiceId} and enabled = true
    order by updated_at desc
    limit 1
  `)[0] ?? null;
}
async function listCustomers() {
	return (await getSql())`
    select u.id, u.name, u.email, u."createdAt"::text as created_at,
           coalesce(r.role, 'customer') as role,
           coalesce(w.balance_paise, 0)::int as balance_paise,
           (select count(*)::int from engagement_orders o where o.user_id = u.id) as orders
    from "user" u
    left join user_roles r on r.user_id = u.id
    left join wallets w on w.user_id = u.id
    order by u."createdAt" desc
  `;
}
async function creditCustomer(userId, paise, note) {
	const sql = await getSql();
	await sql`
    insert into wallets (user_id, balance_paise) values (${userId}, ${paise})
    on conflict (user_id) do update set balance_paise = wallets.balance_paise + ${paise}, updated_at = now()
  `;
	await sql`
    insert into wallet_transactions (id, user_id, kind, amount_paise, note)
    values (${crypto.randomUUID()}, ${userId}, 'credit', ${paise}, ${note.slice(0, 180)})
  `;
}
async function paymentDesk() {
	return (await (await getSql())`
    select qr_image, upi_id, note from payment_settings where id = 'desk' limit 1
  `)[0] ?? {
		qr_image: "",
		upi_id: "",
		note: ""
	};
}
async function savePaymentDesk(input) {
	const sql = await getSql();
	const image = input.qr_image.startsWith("data:image/") ? input.qr_image.slice(0, 7e5) : "";
	await sql`
    insert into payment_settings (id, qr_image, upi_id, note)
    values ('desk', ${image}, ${input.upi_id.slice(0, 80)}, ${input.note.slice(0, 240)})
    on conflict (id) do update set qr_image = ${image}, upi_id = ${input.upi_id.slice(0, 80)}, note = ${input.note.slice(0, 240)}
  `;
}
async function ensureGatewayCols(sql) {
	await sql`alter table payment_gateways add column if not exists pay_mode text not null default 'manual'`;
	await sql`alter table payment_gateways add column if not exists pay_currency text not null default 'INR'`;
	await sql`alter table payment_gateways add column if not exists network text not null default ''`;
	await sql`alter table payment_gateways add column if not exists pay_kind text not null default 'other'`;
	await sql`alter table payment_gateways alter column ifsc type text`;
	await sql`update payment_gateways set min_paise = 10000, pay_currency = 'INR' where pay_kind = 'razorpay' and min_paise = 20000`;
	await sql`update payment_gateways set pay_currency = 'PKR', min_paise = 10000 where pay_kind = 'jazzcash' and coalesce(pay_currency, 'INR') = 'INR' and min_paise in (10000, 20000)`;
	await sql`update payment_gateways set pay_currency = 'USD', min_paise = 500 where pay_kind in ('usdt', 'crypto') and coalesce(pay_currency, 'INR') <> 'USD' and min_paise in (10000, 20000)`;
}
async function publicGateways() {
	const sql = await getSql();
	await ensureGatewayCols(sql);
	return sql`
    select id, name, account_title, account_number, ifsc, instructions, qr_image, min_paise, max_paise, enabled, sort_order,
           coalesce(pay_mode, 'manual') as pay_mode, coalesce(pay_currency, 'INR') as pay_currency, coalesce(network, '') as network,
           coalesce(pay_kind, 'other') as pay_kind
    from payment_gateways
    where enabled = true and archived = false
    order by sort_order, name
  `;
}
async function adminGateways() {
	const sql = await getSql();
	await ensureGatewayCols(sql);
	return sql`
    select id, name, account_title, account_number, ifsc, instructions, qr_image, min_paise, max_paise, enabled, sort_order, archived,
           coalesce(pay_mode, 'manual') as pay_mode, coalesce(pay_currency, 'INR') as pay_currency, coalesce(network, '') as network,
           coalesce(pay_kind, 'other') as pay_kind
    from payment_gateways
    order by archived, sort_order, name
  `;
}
async function saveGateway(input) {
	const sql = await getSql();
	await ensureGatewayCols(sql);
	const id = input.id || crypto.randomUUID();
	const image = input.qr_image.startsWith("data:image/") ? input.qr_image.slice(0, 7e5) : "";
	const mode = input.pay_mode === "auto" ? "auto" : "manual";
	const currency = String(input.pay_currency || "INR").toUpperCase().replace(/[^A-Z]/g, "").slice(0, 8) || "INR";
	const network = String(input.network || "").slice(0, 4e3);
	const kind = [
		"upi",
		"jazzcash",
		"crypto",
		"talk",
		"other",
		"razorpay",
		"usdt"
	].includes(input.pay_kind) ? input.pay_kind : "other";
	const ifsc = input.ifsc.slice(0, 40);
	await sql`
    insert into payment_gateways (
      id, name, account_title, account_number, ifsc, instructions, qr_image, min_paise, max_paise, enabled, sort_order, archived, pay_mode, pay_currency, network, pay_kind
    ) values (
      ${id}, ${input.name.slice(0, 60)}, ${input.account_title.slice(0, 80)}, ${input.account_number.slice(0, 120)},
      ${ifsc}, ${input.instructions.slice(0, 400)}, ${image},
      ${input.min_paise}, ${input.max_paise}, ${input.enabled}, ${input.sort_order}, ${Boolean(input.archived)},
      ${mode}, ${currency}, ${network}, ${kind}
    )
    on conflict (id) do update set
      name = ${input.name.slice(0, 60)},
      account_title = ${input.account_title.slice(0, 80)},
      account_number = ${input.account_number.slice(0, 120)},
      ifsc = ${ifsc},
      instructions = ${input.instructions.slice(0, 400)},
      qr_image = case when ${image} = '' then payment_gateways.qr_image else ${image} end,
      min_paise = ${input.min_paise},
      max_paise = ${input.max_paise},
      enabled = ${input.enabled},
      sort_order = ${input.sort_order},
      archived = ${Boolean(input.archived)},
      pay_mode = ${mode},
      pay_currency = ${currency},
      network = ${network},
      pay_kind = ${kind}
  `;
	return id;
}
async function submitClaim(userId, amountPaise, screenshot, reference, gatewayId, displayMajor = 0) {
	const shot = screenshot.startsWith("data:image/") ? screenshot.slice(0, 7e5) : "";
	const sql = await getSql();
	await ensureGatewayCols(sql);
	const gate = (await sql`
    select min_paise, max_paise, coalesce(pay_currency, 'INR') as pay_currency from payment_gateways
    where id = ${gatewayId} and enabled = true and archived = false
    limit 1
  `)[0];
	if (!gate) throw new Error("That payment method is not available.");
	const typed = Math.round((Number(displayMajor) || 0) * 100) / 100;
	const minMajor = gate.min_paise / 100;
	const maxMajor = gate.max_paise / 100;
	const gateCur = (gate.pay_currency || "INR").toUpperCase();
	let credit = amountPaise;
	let gateMajor = typed;
	if (typed >= 1) {
		const prefs = await sql`select display_currency from user_prefs where user_id = ${userId} limit 1`;
		const baseRow = await sql`select value from desk_meta where key = 'base_currency' limit 1`;
		const fxRow = await sql`select value from desk_meta where key = 'fx_cache' limit 1`;
		const display = (prefs[0]?.display_currency || baseRow[0]?.value || "INR").toUpperCase();
		const base = (baseRow[0]?.value || "INR").toUpperCase();
		let displayRate = 1;
		let gateRate = 1;
		try {
			const parsed = JSON.parse(fxRow[0]?.value || "{}");
			const shown = Number(parsed.rates?.[display]);
			const native = Number(parsed.rates?.[gateCur]);
			if (display !== base && shown > 0) displayRate = shown;
			if (gateCur !== base && native > 0) gateRate = native;
		} catch {}
		const baseMajor = typed / displayRate;
		gateMajor = baseMajor * gateRate;
		credit = Math.max(1, Math.round(baseMajor * 100));
	} else gateMajor = amountPaise / 100;
	if (gateMajor < minMajor - .02 || gateMajor > maxMajor + .02) throw new Error(`Amount must be between ${minMajor} and ${maxMajor} ${gateCur}.`);
	const ref = reference.trim();
	if (ref.length < 6) throw new Error("Enter the UTR or transaction reference.");
	if ((await sql`
    select id from payment_claims
    where lower(reference) = lower(${ref}) and status in ('pending', 'approved')
    limit 1
  `).length > 0) throw new Error("This UTR is already submitted.");
	const gatesKind = await sql`select coalesce(pay_kind, 'other') as pay_kind, name from payment_gateways where id = ${gatewayId} limit 1`;
	const kind = gatesKind[0]?.pay_kind || "other";
	if ((kind === "jazzcash" || /jazz/i.test(gatesKind[0]?.name || "")) && !shot) throw new Error("Upload the payment screenshot.");
	if (kind === "upi" && !/^\d{12}$/.test(ref)) throw new Error("Enter the 12-digit UTR.");
	if ((kind === "other" || kind === "crypto") && !shot && ref.length < 6) throw new Error("Add the transaction id or a screenshot.");
	const id = `PAY-${Math.floor(1e5 + Math.random() * 9e5)}`;
	await sql`
    insert into payment_claims (id, user_id, amount_paise, screenshot, reference, status, gateway_id)
    values (${id}, ${userId}, ${credit}, ${shot}, ${ref.slice(0, 80)}, 'pending', ${gatewayId})
  `;
	return id;
}
async function myClaims(userId) {
	return (await getSql())`
    select id, amount_paise, status, created_at::text as created_at
    from payment_claims
    where user_id = ${userId}
    order by created_at desc
    limit 20
  `;
}
async function listClaims() {
	return (await getSql())`
    select c.id, c.user_id, u.email, u.name, c.amount_paise, c.screenshot, c.reference, c.status,
           c.created_at::text as created_at, c.gateway_id, coalesce(g.name, 'Payment') as gateway_name, c.reject_reason
    from payment_claims c
    join "user" u on u.id = c.user_id
    left join payment_gateways g on g.id = c.gateway_id
    order by case when c.status = 'pending' then 0 else 1 end, c.created_at desc
    limit 40
  `;
}
async function reviewClaim(claimId, approve, reason = "") {
	const sql = await getSql();
	if (!approve) {
		if ((await sql`
      update payment_claims
      set status = 'declined', reject_reason = ${reason.slice(0, 180)}, reviewed_at = now()
      where id = ${claimId} and status = 'pending'
      returning id
    `).length === 0) throw new Error("This payment is already reviewed.");
		return;
	}
	const claim = (await sql`
    update payment_claims
    set status = 'approved', reviewed_at = now()
    where id = ${claimId} and status = 'pending'
    returning user_id, amount_paise
  `)[0];
	if (!claim) throw new Error("This payment is already reviewed.");
	await creditCustomer(claim.user_id, claim.amount_paise, `Payment ${claimId} approved.`);
}
async function removeCustomer(actorId, userId) {
	if (actorId === userId) throw new Error("You cannot delete the signed-in admin.");
	const sql = await getSql();
	await sql`delete from payment_claims where user_id = ${userId}`;
	await sql`delete from mass_batch_links where user_id = ${userId}`;
	await sql`delete from mass_batches where user_id = ${userId}`;
	await sql`delete from user_prefs where user_id = ${userId}`;
	await sql`delete from support_tickets where user_id = ${userId}`;
	await sql`delete from delivery_drops where user_id = ${userId}`;
	await sql`delete from engagement_order_items where user_id = ${userId}`;
	await sql`delete from engagement_orders where user_id = ${userId}`;
	await sql`delete from wallet_transactions where user_id = ${userId}`;
	await sql`delete from wallets where user_id = ${userId}`;
	await sql`delete from user_roles where user_id = ${userId}`;
	await sql`delete from session where "userId" = ${userId}`;
	await sql`delete from account where "userId" = ${userId}`;
	await sql`delete from "user" where id = ${userId}`;
}
//#endregion
export { saveServiceActiveLimit as C, syncProviderCatalog as D, syncManagedServices as E, saveProvider as S, submitClaim as T, reviewClaim as _, deleteProvider as a, saveManaged as b, listClaims as c, listProviders as d, myClaims as f, requireAdmin as g, removeCustomer as h, creditCustomer as i, listCustomers as l, publicGateways as m, adminGateways as n, deskRole as o, paymentDesk as p, admin_server_exports as r, listBindings as s, addCustomService as t, listManaged as u, saveBindings as v, serviceActiveLimit as w, savePaymentDesk as x, saveGateway as y };
