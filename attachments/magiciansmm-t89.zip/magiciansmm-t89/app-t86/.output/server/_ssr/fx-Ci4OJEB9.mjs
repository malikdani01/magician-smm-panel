//#region node_modules/.nitro/vite/services/ssr/assets/fx-Ci4OJEB9.js
function usdQtyToPaise(ratePerThousandUsd, quantity) {
	if (!Number.isFinite(ratePerThousandUsd) || !Number.isFinite(quantity) || quantity <= 0) return 0;
	return Math.max(1, Math.round(quantity / 1e3 * ratePerThousandUsd * 84 * 100));
}
//#endregion
export { usdQtyToPaise as t };
