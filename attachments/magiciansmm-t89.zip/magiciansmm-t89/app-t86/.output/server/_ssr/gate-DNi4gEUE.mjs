import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as getBearerToken } from "./client-DKNO_Bt1.mjs";
import { At as useCurrentUserState, J as getDeskRole, a as RedirectToSignIn, o as Shell } from "./shell-CfBlaVSk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/gate-DNi4gEUE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StaffOnly({ children }) {
	const [ok, setOk] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		getDeskRole().then((role) => setOk(role === "admin")).catch(() => setOk(false));
	}, []);
	if (ok === null) return null;
	if (!ok) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-3xl border p-6 text-[14px]",
		children: "Admin only. Customer accounts cannot open this page."
	});
	return children;
}
function Authed({ children }) {
	const { user, isPending } = useCurrentUserState();
	const trusted = isPending && Boolean(getBearerToken());
	if (isPending && !trusted) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-4 md:grid-cols-3",
		children: Array.from({ length: 3 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-28 animate-pulse rounded-card bg-card" }, i))
	}) });
	if (!isPending && !user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children });
}
//#endregion
export { StaffOnly as n, Authed as t };
