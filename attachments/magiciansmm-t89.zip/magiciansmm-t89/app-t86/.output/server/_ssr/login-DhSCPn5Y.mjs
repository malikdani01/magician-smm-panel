import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as signIn, i as rememberSessionToken, t as authClient } from "./client-DKNO_Bt1.mjs";
import { ot as ArrowLeft } from "../_libs/lucide-react.mjs";
import { $ as inputClass, j as applyMotion, r as Mark, s as Starfield } from "./shell-CfBlaVSk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-DhSCPn5Y.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var login_mage_default = "/assets/login-mage-KC8viH2A.jpg";
function Login() {
	const [mode, setMode] = (0, import_react.useState)("in");
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		applyMotion();
		const code = new URLSearchParams(window.location.search).get("error") || "";
		if (!code) return;
		setError({
			state_mismatch: "Google session expired. Continue with Google dubara dabao.",
			please_restart_the_process: "Google return host match nahi hua. Dubara try karo.",
			access_denied: "Google ne sign-in cancel kar diya.",
			account_not_linked: "Ye email pehle se email login pe hai. Pehle password se login karo."
		}[code] || `Google sign-in ruk gaya (${code}). Dubara try karo.`);
	}, []);
	async function submit(event) {
		event.preventDefault();
		setError("");
		setPending(true);
		try {
			if (mode === "up") {
				const result = await authClient.signUp.email({
					email,
					password,
					name: name || email.split("@")[0] || "Member",
					callbackURL: "/dashboard"
				});
				if (result.error) throw new Error(result.error.message || "Could not create the account.");
				const token = result.data?.token;
				if (token) rememberSessionToken(token);
			} else {
				const result = await authClient.signIn.email({
					email,
					password,
					callbackURL: "/dashboard"
				});
				if (result.error) throw new Error(result.error.message || "Those details were not accepted.");
				const token = result.data?.token;
				if (token) rememberSessionToken(token);
			}
			window.location.assign("/dashboard");
			return;
		} catch (err) {
			setError(err instanceof Error ? err.message : "Sign-in failed.");
		} finally {
			setPending(false);
		}
	}
	async function continueWithGoogle() {
		setError("");
		setPending(true);
		try {
			if (typeof window !== "undefined" && window.location.hostname.endsWith(".grok-sandbox.com")) {
				await signIn("grok-google", {
					callbackURL: "/dashboard",
					errorCallbackURL: "/login"
				});
				return;
			}
			const result = await authClient.signIn.social({
				provider: "google",
				callbackURL: "/dashboard",
				errorCallbackURL: "/login"
			});
			if (result?.error) {
				const message = result.error.message || "";
				throw new Error(/provider|not found|disabled/i.test(message) ? "Google login server pe set nahi. Niche wale Google Cloud steps Mama ko do." : message);
			}
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not continue.");
			setPending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative min-h-screen overflow-hidden px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: login_mage_default,
				alt: "",
				className: "pointer-events-none absolute inset-0 h-full w-full object-cover object-right"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-gradient-to-r from-[#070312]/90 via-[#070312]/70 to-[#070312]/20" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Starfield, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "inline-flex items-center gap-2 text-sm font-medium text-white/80",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), " Back to home"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "page-motion mx-auto mt-8 w-full max-w-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-6 flex justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card rounded-3xl border p-6 md:p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "rise-in text-3xl text-white",
								children: mode === "in" ? "Welcome back" : "Create your desk"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rise-in rise-d1 mt-1 text-sm text-white/70",
								children: mode === "in" ? "Sign in to your dashboard." : "Free account. Add credit when you are ready."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: submit,
								className: "mt-6 space-y-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										disabled: pending,
										onClick: () => continueWithGoogle(),
										className: "btn-live inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-xl border border-white/20 bg-white text-sm font-semibold text-slate-900 disabled:opacity-50",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoogleMark, {}), "Continue with Google"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-center text-[11px] uppercase tracking-[0.18em] text-white/50",
										children: "or use email"
									}),
									mode === "up" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block space-y-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-semibold text-white/70",
											children: "Name"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											className: "w-full rounded-xl border border-line bg-white/90 px-4 py-3 text-sm text-foreground outline-none focus:border-indigo-400",
											value: name,
											onChange: (e) => setName(e.target.value),
											placeholder: "Your name"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block space-y-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-semibold text-white/70",
											children: "Email"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											className: inputClass,
											type: "email",
											required: true,
											autoComplete: "email",
											value: email,
											onChange: (e) => setEmail(e.target.value),
											placeholder: "name@example.com"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block space-y-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center justify-between text-xs font-semibold text-white/70",
											children: ["Password", mode === "in" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium text-amber-300",
												children: "8+ characters"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											className: inputClass,
											type: "password",
											required: true,
											minLength: 8,
											autoComplete: mode === "up" ? "new-password" : "current-password",
											value: password,
											onChange: (e) => setPassword(e.target.value),
											placeholder: "••••••••"
										})]
									}),
									error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-rose-300",
										children: error
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "submit",
										disabled: pending,
										className: "btn-live inline-flex min-h-12 w-full items-center justify-center rounded-xl bg-amber-300 text-sm font-semibold text-slate-950 disabled:opacity-50",
										children: pending ? "Please wait…" : mode === "in" ? "Sign in" : "Create account"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "w-full text-center text-sm text-white/70",
										onClick: () => {
											setMode(mode === "in" ? "up" : "in");
											setError("");
										},
										children: mode === "in" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Don't have an account? ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold text-amber-300",
											children: "Sign up"
										})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Already have a desk? ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold text-amber-300",
											children: "Sign in"
										})] })
									})
								]
							})
						]
					})]
				})]
			})
		]
	});
}
function GoogleMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 18 18",
		className: "size-4",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#EA4335",
				d: "M9 7.2v3.4h4.7c-.2 1.1-.8 2-1.7 2.6l2.7 2.1c1.6-1.5 2.5-3.6 2.5-6.1 0-.6 0-1.1-.1-1.6H9z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#34A853",
				d: "M9 18c2.4 0 4.4-.8 5.9-2.2l-2.7-2.1c-.8.5-1.8.9-3.2.9-2.4 0-4.5-1.6-5.2-3.9L1 13c1.5 3 4.5 5 8 5z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#4A90E2",
				d: "M3.8 10.7A5.4 5.4 0 0 1 3.5 9c0-.6.1-1.2.3-1.7L1 5C.4 6.2 0 7.6 0 9s.4 2.8 1 4l2.8-2.3z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#FBBC05",
				d: "M9 3.6c1.3 0 2.5.4 3.4 1.3L14.8 2.4C13.2.9 11.2 0 9 0 5.5 0 2.5 2 1 5l2.8 2.3C4.5 5.2 6.6 3.6 9 3.6z"
			})
		]
	});
}
//#endregion
export { Login as component };
