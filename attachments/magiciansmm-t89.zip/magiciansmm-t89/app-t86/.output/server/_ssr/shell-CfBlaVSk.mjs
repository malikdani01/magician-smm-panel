import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link, p as useRouterState, x as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-DY5Pyta6.mjs";
import { o as signOut, t as authClient } from "./client-DKNO_Bt1.mjs";
import { i as hasGateSessionMarker } from "./verify.server-DV020YNI.mjs";
import { A as Menu, D as QrCode, E as Receipt, F as LifeBuoy, I as Library, L as LayoutDashboard, N as ListPlus, R as KeyRound, _ as Settings, a as Users, ct as Activity, et as Boxes, i as Wallet, k as MessageCircle, l as SquarePlus, n as X, r as WandSparkles } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-CfBlaVSk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CURRENCIES = [
	{
		code: "INR",
		symbol: "₹",
		locale: "en-IN",
		name: "Indian Rupee",
		digits: 2,
		flag: "🇮🇳"
	},
	{
		code: "USD",
		symbol: "$",
		locale: "en-US",
		name: "US Dollar",
		digits: 2,
		flag: "🇺🇸"
	},
	{
		code: "PKR",
		symbol: "Rs ",
		locale: "en-PK",
		name: "Pakistani Rupee",
		digits: 2,
		flag: "🇵🇰"
	},
	{
		code: "EUR",
		symbol: "€",
		locale: "de-DE",
		name: "Euro",
		digits: 2,
		flag: "🇪🇺"
	},
	{
		code: "GBP",
		symbol: "£",
		locale: "en-GB",
		name: "British Pound",
		digits: 2,
		flag: "🇬🇧"
	},
	{
		code: "AED",
		symbol: "AED ",
		locale: "en-AE",
		name: "UAE Dirham",
		digits: 2,
		flag: "🇦🇪"
	},
	{
		code: "SAR",
		symbol: "SAR ",
		locale: "ar-SA",
		name: "Saudi Riyal",
		digits: 2,
		flag: "🇸🇦"
	},
	{
		code: "BDT",
		symbol: "৳",
		locale: "bn-BD",
		name: "Bangladeshi Taka",
		digits: 2,
		flag: "🇧🇩"
	},
	{
		code: "TRY",
		symbol: "₺",
		locale: "tr-TR",
		name: "Turkish Lira",
		digits: 2,
		flag: "🇹🇷"
	},
	{
		code: "MYR",
		symbol: "RM ",
		locale: "ms-MY",
		name: "Malaysian Ringgit",
		digits: 2,
		flag: "🇲🇾"
	},
	{
		code: "CAD",
		symbol: "C$",
		locale: "en-CA",
		name: "Canadian Dollar",
		digits: 2,
		flag: "🇨🇦"
	},
	{
		code: "AUD",
		symbol: "A$",
		locale: "en-AU",
		name: "Australian Dollar",
		digits: 2,
		flag: "🇦🇺"
	},
	{
		code: "JPY",
		symbol: "¥",
		locale: "ja-JP",
		name: "Japanese Yen",
		digits: 0,
		flag: "🇯🇵"
	},
	{
		code: "CNY",
		symbol: "¥",
		locale: "zh-CN",
		name: "Chinese Yuan",
		digits: 2,
		flag: "🇨🇳"
	},
	{
		code: "SGD",
		symbol: "S$",
		locale: "en-SG",
		name: "Singapore Dollar",
		digits: 2,
		flag: "🇸🇬"
	},
	{
		code: "QAR",
		symbol: "QAR ",
		locale: "en-QA",
		name: "Qatari Riyal",
		digits: 2,
		flag: "🇶🇦"
	},
	{
		code: "KWD",
		symbol: "KWD ",
		locale: "en-KW",
		name: "Kuwaiti Dinar",
		digits: 3,
		flag: "🇰🇼"
	},
	{
		code: "OMR",
		symbol: "OMR ",
		locale: "en-OM",
		name: "Omani Rial",
		digits: 3,
		flag: "🇴🇲"
	},
	{
		code: "BHD",
		symbol: "BHD ",
		locale: "en-BH",
		name: "Bahraini Dinar",
		digits: 3,
		flag: "🇧🇭"
	},
	{
		code: "NZD",
		symbol: "NZ$",
		locale: "en-NZ",
		name: "New Zealand Dollar",
		digits: 2,
		flag: "🇳🇿"
	},
	{
		code: "CHF",
		symbol: "CHF ",
		locale: "de-CH",
		name: "Swiss Franc",
		digits: 2,
		flag: "🇨🇭"
	},
	{
		code: "ZAR",
		symbol: "R ",
		locale: "en-ZA",
		name: "South African Rand",
		digits: 2,
		flag: "🇿🇦"
	},
	{
		code: "NGN",
		symbol: "₦",
		locale: "en-NG",
		name: "Nigerian Naira",
		digits: 2,
		flag: "🇳🇬"
	},
	{
		code: "IDR",
		symbol: "Rp ",
		locale: "id-ID",
		name: "Indonesian Rupiah",
		digits: 0,
		flag: "🇮🇩"
	},
	{
		code: "THB",
		symbol: "฿",
		locale: "th-TH",
		name: "Thai Baht",
		digits: 2,
		flag: "🇹🇭"
	},
	{
		code: "PHP",
		symbol: "₱",
		locale: "en-PH",
		name: "Philippine Peso",
		digits: 2,
		flag: "🇵🇭"
	},
	{
		code: "VND",
		symbol: "₫",
		locale: "vi-VN",
		name: "Vietnamese Dong",
		digits: 0,
		flag: "🇻🇳"
	},
	{
		code: "EGP",
		symbol: "E£",
		locale: "en-EG",
		name: "Egyptian Pound",
		digits: 2,
		flag: "🇪🇬"
	},
	{
		code: "LKR",
		symbol: "Rs ",
		locale: "si-LK",
		name: "Sri Lankan Rupee",
		digits: 2,
		flag: "🇱🇰"
	},
	{
		code: "NPR",
		symbol: "Rs ",
		locale: "ne-NP",
		name: "Nepalese Rupee",
		digits: 2,
		flag: "🇳🇵"
	},
	{
		code: "KRW",
		symbol: "₩",
		locale: "ko-KR",
		name: "South Korean Won",
		digits: 0,
		flag: "🇰🇷"
	},
	{
		code: "HKD",
		symbol: "HK$",
		locale: "en-HK",
		name: "Hong Kong Dollar",
		digits: 2,
		flag: "🇭🇰"
	},
	{
		code: "MXN",
		symbol: "MX$",
		locale: "es-MX",
		name: "Mexican Peso",
		digits: 2,
		flag: "🇲🇽"
	},
	{
		code: "BRL",
		symbol: "R$",
		locale: "pt-BR",
		name: "Brazilian Real",
		digits: 2,
		flag: "🇧🇷"
	}
];
var CURRENCY_KEY = "mg-display-currency";
var base = CURRENCIES[0];
var display = CURRENCIES[0];
var rates = { INR: 1 };
var fxUpdated = 0;
var fxStale = false;
var tick = 0;
var listeners = /* @__PURE__ */ new Set();
function findCurrency(code) {
	return CURRENCIES.find((item) => item.code === code.toUpperCase()) ?? {
		...CURRENCIES[0],
		code: code.toUpperCase().slice(0, 8)
	};
}
function bump() {
	tick += 1;
	listeners.forEach((fn) => fn());
}
function subscribeCurrency(cb) {
	listeners.add(cb);
	return () => listeners.delete(cb);
}
function currencySnapshot() {
	return `${base.code}|${display.code}|${tick}|${fxUpdated}`;
}
function moneyState() {
	return {
		base,
		display,
		fxUpdated,
		fxStale,
		rate: rateFor(display.code)
	};
}
function applyDisplay(next) {
	display = findCurrency(next.code);
	if (typeof window !== "undefined") try {
		localStorage.setItem(CURRENCY_KEY, display.code);
	} catch {}
	bump();
}
function applyBase(next) {
	base = findCurrency(next.code);
	if (!rates[base.code]) rates = {
		...rates,
		[base.code]: 1
	};
	bump();
}
function applyFx(next) {
	if (next.base) base = findCurrency(next.base);
	const clean = {};
	for (const [code, value] of Object.entries(next.rates || {})) {
		const rate = Number(value);
		if (rate > 0 && Number.isFinite(rate)) clean[code.toUpperCase()] = rate;
	}
	clean[base.code] = 1;
	rates = clean;
	fxUpdated = Number(next.updatedAt) || 0;
	fxStale = Boolean(next.stale);
	bump();
}
function savedDisplayCode() {
	if (typeof window === "undefined") return "";
	try {
		return localStorage.getItem("mg-display-currency") || "";
	} catch {
		return "";
	}
}
function rateFor(code) {
	if (code === base.code) return 1;
	const rate = rates[code];
	return rate > 0 ? rate : 0;
}
function roundTo(value, digits) {
	const factor = 10 ** digits;
	return Math.round((value + Number.EPSILON) * factor) / factor;
}
/** Stored minor units (paise of the base currency) → display major units. */
function fromMinor(minor) {
	const major = (Number(minor) || 0) / 100;
	const rate = rateFor(display.code);
	if (!rate) return major;
	return roundTo(major * rate, display.digits);
}
/** Display major units → stored base minor units. Picks the paise that shows back closest to the typed amount. */
function toBaseMinor(displayMajor) {
	const rate = rateFor(display.code);
	const major = Number(displayMajor) || 0;
	if (!rate) return Math.round(major * 100);
	const target = roundTo(major, display.digits);
	const guess = Math.round(target / rate * 100);
	const span = Math.max(4, Math.ceil(rate) + 2);
	let best = guess;
	let bestErr = Infinity;
	for (let candidate = guess - span; candidate <= guess + span; candidate++) {
		const shown = roundTo(candidate / 100 * rate, display.digits);
		const err = Math.abs(shown - target);
		if (err < bestErr) {
			best = candidate;
			bestErr = err;
		}
	}
	return best;
}
/** Format a number that is already in the user's currency. Does not convert. */
function formatMajor(major) {
	const value = Number(major) || 0;
	const negative = value < 0;
	const abs = roundTo(Math.abs(value), display.digits);
	const whole = Math.abs(abs - Math.round(abs)) < 1e-8;
	const formatted = abs.toLocaleString(display.locale || "en-IN", {
		minimumFractionDigits: whole ? 0 : display.digits,
		maximumFractionDigits: whole ? 0 : display.digits
	});
	return `${negative ? "-" : ""}${display.symbol}${formatted}`;
}
function inr(minor) {
	const negative = (Number(minor) || 0) < 0;
	const formatted = fromMinor(Math.abs(Number(minor) || 0)).toLocaleString(display.locale || "en-IN", {
		minimumFractionDigits: display.digits,
		maximumFractionDigits: display.digits
	});
	return `${negative ? "-" : ""}${display.symbol}${formatted}`;
}
function moneyCode() {
	return display.code;
}
/** Convert a major amount from one currency to another using the loaded rates. Null if a rate is missing. */
function convertMajor(amount, fromCode, toCode) {
	const from = fromCode.toUpperCase();
	const to = toCode.toUpperCase();
	const value = Number(amount) || 0;
	if (from === to) return roundTo(value, findCurrency(to).digits);
	const fromRate = rateFor(from);
	const toRate = rateFor(to);
	if (!fromRate || !toRate) return null;
	return roundTo(value / fromRate * toRate, findCurrency(to).digits);
}
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	return useSessionUserState();
}
function useSessionUserState() {
	const { data, isPending } = authClient.useSession();
	const id = data?.user.id;
	const displayName = data?.user.name ?? null;
	const primaryEmail = data?.user.email ?? null;
	const profileImageUrl = data?.user.image ?? null;
	const user = (0, import_react.useMemo)(() => id ? {
		id,
		displayName,
		primaryEmail,
		profileImageUrl,
		isDevFallback: false
	} : null, [
		id,
		displayName,
		primaryEmail,
		profileImageUrl
	]);
	return (0, import_react.useMemo)(() => ({
		user,
		isPending
	}), [user, isPending]);
}
/**
* Convenience view of `useCurrentUserState().user` for display (e.g.
* `user?.displayName ?? "Guest"`). NOTE: `null` means *loading OR signed out* —
* for redirects/guards use `useCurrentUserState()` and check `isPending`.
*/
function useCurrentUser() {
	return useCurrentUserState().user;
}
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Auth state components — plain wrappers around `useCurrentUserState()`.
*
* With auth on, visitors are signed out until they authenticate — in the sandbox
* live preview too, which does real sign-in. The shared dev user appears only
* when auth is disabled (`VITE_AUTH_ENABLED=false`, the shipped default).
* While the session is still resolving, gates that care about signed-out state
* render nothing so there's no signed-out flash on hard reload.
*/
/** Where `RedirectToSignIn` sends signed-out visitors. Create this route. */
var SIGN_IN_PATH = "/login";
/**
* Client-side redirect to the sign-in route (TanStack `<Navigate>` — NOT a full
* `window.location` reload). A hard navigation re-bootstraps the SPA and re-runs
* session loading, which feels like a second "Loading…" on /login.
*
* Guard routes by waiting out `isPending` first (see `use-current-user`), then
* render this.
*/
function RedirectToSignIn({ to = SIGN_IN_PATH }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to });
}
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var apiBalances = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("e091d7d68feb087d52b3ae7f818ddd8e8b3564792db1a04f043e112a00aa0e37"));
var getCatalog = createServerFn({ method: "GET" }).handler(createSsrRpc("4ec21d13fa60565755ae5acb0c886c85e94db0b0cb0b569120fa094138fd85b5"));
var getDashboard = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("802d2905e75b9f5bd7272b1b69005ed36294d3a93da20afca364091055ddb7a3"));
var listOrders = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input ?? {}).handler(createSsrRpc("425c7b4ca8f20880d0302e9883fb473837e5aa38be46b193cf9259229643e6da"));
var getOrder = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const id = typeof input === "string" ? input : String(input?.id || "");
	if (id.length < 8) throw new Error("Missing order.");
	return id;
}).handler(createSsrRpc("689905743bba58c841cddd71186cff995b2f84d19277e97a76db0b2613a3e1e7"));
var listOrderDrops = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const id = typeof input === "string" ? input : String(input?.id || "");
	if (id.length < 8) throw new Error("Missing order.");
	return id;
}).handler(createSsrRpc("fe8513ef9e9731a88509ee416f381a104bb8ae0f2c80d035051b1134c04d99b9"));
var editScheduledDrop = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const quantity = Math.floor(Number(input?.quantity));
	const placeAt = new Date(String(input?.placeAt || ""));
	if (!input?.id || quantity < 1) throw new Error("Enter a quantity.");
	if (Number.isNaN(placeAt.getTime())) throw new Error("Pick a valid time.");
	return {
		id: String(input.id),
		quantity,
		placeAt: placeAt.toISOString()
	};
}).handler(createSsrRpc("6abbbb84f7dd9113e7fa632bc030b5017899f0cbfc2a6b619b08549df22410b0"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input?.orderId || !input?.type) throw new Error("Missing refill.");
	return {
		orderId: String(input.orderId),
		type: String(input.type)
	};
}).handler(createSsrRpc("9388d398f63351f24215a9f518a29fb50046b0362f277dc715601b4cb9849d7f"));
var checkDropStatus = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (!id) throw new Error("Missing run.");
	return String(id);
}).handler(createSsrRpc("2ff1ea60e023368803ebbea6d0a6ab2b49118d2894bf949eec320fa095d27fe8"));
var setRunState = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (![
		"waiting",
		"paused",
		"cancelled"
	].includes(input?.status)) throw new Error("Bad status.");
	return input;
}).handler(createSsrRpc("1c086f3879843e5526abab4b4f19f6e473e47056a9716df397dda51b5841ca45"));
var setOrderFlow = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input?.orderId || ![
		"waiting",
		"paused",
		"cancelled"
	].includes(input?.status)) throw new Error("Bad order action.");
	return input;
}).handler(createSsrRpc("c8a8b099c70fc06620b0cb3ff1a0e81e497d9192b1a5d6f3377f01b885a32a85"));
var getWallet = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("8507b8b1877b689bad2f7200dd2b5c6c424f63a35db7d7d280b5d6866b5139b5"));
var TOPUPS_MIN = 1e4;
var TOPUPS_MAX = 5e7;
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((amountPaise) => {
	const amount = Math.floor(Number(amountPaise));
	if (!Number.isFinite(amount) || amount < TOPUPS_MIN || amount > TOPUPS_MAX) throw new Error("Amount must be between ₹100 and ₹5,00,000.");
	return amount;
}).handler(createSsrRpc("fe298e400f147ebc637abd9013a1e42b7d6b8fd56f13b658cc8ef186d3146b40"));
var placeOrder = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const link = String(input?.link ?? "").trim();
	let parsed;
	try {
		parsed = new URL(link);
	} catch {
		throw new Error("Paste a full link, including https://.");
	}
	if (parsed.protocol !== "https:" && parsed.protocol !== "http:") throw new Error("The link needs to start with http or https.");
	const baseQuantity = Math.floor(Number(input.baseQuantity));
	const enabledTypes = Array.isArray(input.enabledTypes) ? input.enabledTypes.filter((type) => typeof type === "string") : [];
	const viewsOn = enabledTypes.includes("views");
	if (!Number.isFinite(baseQuantity) || baseQuantity < 0 || baseQuantity > 1e7 || viewsOn && baseQuantity < 100) throw new Error(viewsOn ? "Views quantity must be between 100 and 10,000,000." : "Turn on at least one service.");
	const quantities = {};
	if (input.quantities && typeof input.quantities === "object") for (const [type, value] of Object.entries(input.quantities)) {
		const quantity = Math.floor(Number(value));
		if (Number.isFinite(quantity) && quantity > 0 && quantity <= 5e7) quantities[type] = quantity;
	}
	const delivery = {};
	if (input.delivery && typeof input.delivery === "object") for (const [type, value] of Object.entries(input.delivery)) {
		const hours = Number(value?.hours);
		const runs = Math.floor(Number(value?.runs));
		if (!Number.isFinite(hours) || hours <= 0 || !Number.isFinite(runs) || runs <= 0) continue;
		const curve = Array.isArray(value.curve) ? value.curve.map(Number).filter((point) => Number.isFinite(point)).slice(0, 12) : [];
		delivery[type] = {
			hours: Math.min(720, hours),
			runs: Math.min(500, runs),
			variance: Math.min(50, Math.max(0, Math.floor(Number(value.variance) || 0))),
			peak: Boolean(value.peak),
			curve
		};
	}
	const drops = [];
	if (Array.isArray(input.drops)) for (const drop of input.drops.slice(0, 800)) {
		const type = String(drop?.type ?? "");
		const amount = Math.floor(Number(drop?.amount));
		const at = new Date(String(drop?.at ?? ""));
		if (!type || !Number.isFinite(amount) || amount <= 0 || amount > 5e7 || Number.isNaN(at.getTime())) continue;
		drops.push({
			type,
			amount,
			at: at.toISOString()
		});
	}
	return {
		bundleId: String(input.bundleId ?? ""),
		link,
		baseQuantity,
		organic: Boolean(input.organic),
		intervalHours: Math.min(720, Math.max(1, Math.floor(Number(input.intervalHours) || 1))),
		variancePercent: Math.min(50, Math.max(0, Math.floor(Number(input.variancePercent) || 0))),
		enabledTypes,
		quantities,
		delivery,
		drops
	};
}).handler(createSsrRpc("568cbd336ac8c7208a2f719fcddda15fe5ece9f7dbc8489da0b4a37f54f35bf5"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (typeof id !== "string" || id.length < 8) throw new Error("Missing order.");
	return id;
}).handler(createSsrRpc("c2dccedbed6acbda54546c95947b7f40edd841c845ac4fbe771544e934873d72"));
var listTickets = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("53f8f7504e89ee6fcf5370296775e69d457b024b7850f178d85275d77c13d752"));
var openTicket = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const subject = String(input?.subject ?? "").trim().slice(0, 120);
	const body = String(input?.body ?? "").trim().slice(0, 2e3);
	if (subject.length < 3 || body.length < 8) throw new Error("Write a subject and a short note.");
	return {
		subject,
		body
	};
}).handler(createSsrRpc("eca33ce65d3c798ea431e095459370949a483f7098b8c9cbfa0c02e1b94b2432"));
var getPrefs = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("ef226ec4749f0ffa9300649e7663fc2ee7b1fe191ab987c685522a6eed98da7d"));
var savePrefs = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("8f87cfe60b2883ab601b7f65b94680260c0f81857a5f8957e52407b404746740"));
createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("eb6283091792dfe8565063aad130d0c51bc8f0f32ac264327c788471fb0f9afd"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const value = String(input || "").slice(0, 48);
	if (value.split("|").length < 2) throw new Error("Pick a currency.");
	return value;
}).handler(createSsrRpc("2e28b7ec70f8e3b8b102bd62af2cb33dda347a930b8f73a5bb0c51948cdee570"));
var getMoneyConfig = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("bbf30ab5e228f35fa76c42b6ab72e8b4c8e12743ac157a7d4d4828bc890df068"));
var getDeskLook = createServerFn({ method: "GET" }).handler(createSsrRpc("7f90c234873278b07dff1ab65be14bced54a6864684f3d4b3119335e85c05787"));
var saveDeskLook = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	theme: String(input?.theme || "").slice(0, 4e3),
	motion: String(input?.motion || "").slice(0, 40)
})).handler(createSsrRpc("ae6f69f2c3554dc27dfada48f2e4403848c5c86d220843c79407883baffdbef3"));
var saveDisplayCurrency = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const code = String(input || "").toUpperCase().replace(/[^A-Z]/g, "").slice(0, 8);
	if (code.length < 3) throw new Error("Pick a currency.");
	return code;
}).handler(createSsrRpc("09cf685080a2ace7fae0b6ec2f84dbec82928a6d42677974b3582153e128b019"));
var saveBaseCurrency = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const code = String(input || "").toUpperCase().replace(/[^A-Z]/g, "").slice(0, 8);
	if (code.length < 3) throw new Error("Pick a base currency.");
	return code;
}).handler(createSsrRpc("f335ddc5605aa2f10eae1c072b7ea5f1fd105c347fabea791e94698266e10c5d"));
var refreshFx = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("b279d93c581215f19ea0ae4acec3feb8729f5dd8fbe62785942756dcdd878946"));
var changeDeskPassword = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((password) => {
	const next = String(password ?? "");
	if (next.length < 8) throw new Error("Use at least 8 characters.");
	if (next.length > 128) throw new Error("Password is too long.");
	return next;
}).handler(createSsrRpc("84c7634f59b3238ab68dcf359e1b57c86770a0ed7f4e3729f0c8714583198c69"));
var changeAdminLogin = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const email = String(input?.email ?? "").trim().toLowerCase();
	const password = String(input?.password ?? "");
	if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("Email sahi likho.");
	if (email.length > 120) throw new Error("Email bohot lamba hai.");
	if (password && password.length < 8) throw new Error("Password kam se kam 8 characters ka ho.");
	if (password.length > 128) throw new Error("Password bohot lamba hai.");
	if (!email && !password) throw new Error("Naya email ya password likho.");
	return {
		email,
		password
	};
}).handler(createSsrRpc("83c9156aadd378dc50d4faa4ccbdc8c2d688dd505f74896d8a229b3de78b2322"));
var listInstagram = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("1644135fedf9abfb3f169c5a4ebf56e1f9eec0ff9c200cd5e24a21e462f07594"));
var linkInstagram = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((username) => {
	const name = String(username ?? "").trim().replace(/^@/, "");
	if (!/^[A-Za-z0-9._]{2,30}$/.test(name)) throw new Error("Enter a public username, like your_name.");
	return name;
}).handler(createSsrRpc("da85c88cb832768680358bdf8fb70abaaacd778abf495ef5a11caed8237e2efe"));
createServerFn({ method: "GET" }).handler(createSsrRpc("620cdf05ad3c97342eff45c9a6a3b51b1569192c5a8af304758461d80f78923c"));
var listMassBatches = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("285d1c8d2220576be11ebc42adabdc42c82f23dbbb652830ca5fe13c573e2164"));
var submitMassBatch = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const links = (input.links ?? []).filter((row) => /^https?:\/\//.test(String(row.link ?? "").trim())).slice(0, 100);
	if (!input.bundleId) throw new Error("Apna bundle select karo.");
	if (links.length === 0) throw new Error("Kam se kam 1 valid link daalo.");
	const floors = {
		views: 100,
		likes: 10,
		comments: 10,
		shares: 10,
		saves: 50,
		reposts: 10
	};
	const clampRuns = (value, quantity, floor) => {
		const max = Math.max(1, Math.min(200, Math.floor(quantity / Math.max(1, floor))));
		const asked = Math.floor(Number(value) || 0);
		return Math.max(1, Math.min(max, asked > 0 ? asked : max));
	};
	const platform = input.platform === "tiktok" || input.bundleId === "bundle-tt" ? "tiktok" : "instagram";
	return {
		bundleId: platform === "tiktok" ? "bundle-tt" : "bundle-ig",
		platform,
		campaignName: String(input.campaignName ?? "").trim().slice(0, 80) || "Untitled campaign",
		timeframe: String(input.timeframe ?? "1-3 days"),
		intervalHours: Math.max(1, Math.min(2160, Math.round(Number(input.intervalHours) || 72))),
		links: links.map((row) => {
			const views = Math.round(Number(row.views) || 0);
			if (views < floors.views) throw new Error("Below 100 not allowed for views.");
			const extras = Object.fromEntries(Object.entries(row.extras ?? {}).map(([key, value]) => [key, Math.round(Number(value) || 0)]).filter((entry) => Number(entry[1]) > 0));
			for (const [key, value] of Object.entries(extras)) {
				const floor = floors[key];
				if (floor && Number(value) < floor) throw new Error(`Below ${floor} not allowed for ${key}.`);
			}
			const runs = Object.fromEntries(Object.keys(extras).map((key) => [key, clampRuns(row.runs?.[key], Number(extras[key]), floors[key] || 10)]));
			const allowed = /* @__PURE__ */ new Set([
				"views",
				"likes",
				"comments",
				"shares",
				"saves",
				"reposts"
			]);
			const drops = (Array.isArray(row.drops) ? row.drops : []).map((drop) => ({
				type: String(drop?.type || ""),
				amount: Math.floor(Number(drop?.amount) || 0),
				at: new Date(String(drop?.at || "")).toISOString()
			})).filter((drop) => allowed.has(drop.type) && drop.amount > 0 && !Number.isNaN(new Date(drop.at).getTime()));
			for (const drop of drops) {
				const floor = floors[drop.type] || 1;
				if (drop.amount < floor) throw new Error(`Below ${floor} not allowed for ${drop.type}.`);
			}
			return {
				link: row.link.trim(),
				views,
				viewRuns: clampRuns(row.viewRuns, views, floors.views),
				extras,
				runs,
				drops
			};
		})
	};
}).handler(createSsrRpc("768c1b2bf6d3a16d3d207babecbc4c2e26b12520f45b8076d15d0c1b3b8b4bea"));
var completeMassBatch = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (typeof id !== "string" || id.length < 8) throw new Error("Missing batch.");
	return id;
}).handler(createSsrRpc("aafca77407b378ecf1b60565d25960732ba4402fc175dac369c419ee819c7cc5"));
var placeSingleOrder = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const managedId = String(input?.managedId || "").trim();
	const serviceId = Math.floor(Number(input?.serviceId) || 0);
	const link = String(input?.link ?? "").trim();
	const amount = Math.floor(Number(input?.amount));
	const runs = Math.max(1, Math.min(200, Math.floor(Number(input?.runs) || 1)));
	const intervalMinutes = Math.max(1, Math.min(10080, Math.floor(Number(input?.intervalMinutes) || 1)));
	if (!managedId && !serviceId) throw new Error("Pick a service.");
	if (!/^https?:\/\//i.test(link)) throw new Error("Paste a valid link.");
	if (!Number.isFinite(amount) || amount < 1) throw new Error("Enter an amount.");
	return {
		managedId,
		serviceId,
		link,
		amount,
		drip: Boolean(input?.drip),
		runs,
		intervalMinutes
	};
}).handler(createSsrRpc("87995d9c4d6e2008fd7d74a5132318db419bdce7cdf364199a7f9a75d0946da6"));
var browseLiveServices = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	platform: String(input?.platform || "instagram").slice(0, 32),
	category: String(input?.category || "").slice(0, 160),
	query: String(input?.query || "").slice(0, 80)
})).handler(createSsrRpc("f921deca845381bd70b80b03a9dc493f82ba1e26f49804e5fc98050528895093"));
var engagementFloors = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((platform) => String(platform || "instagram").slice(0, 32)).handler(createSsrRpc("d1e4bdf765d192cc84b4f39d27c52ae7125513cc8dff62ab1a820904dfe7be0c"));
var engagementSections = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((platform) => String(platform || "instagram").slice(0, 32)).handler(createSsrRpc("dafffd431854029bafee17a1cab5c900adc90a214efd481a424d06d06632e1fe"));
var panelRates = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((platform) => String(platform || "instagram").slice(0, 32)).handler(createSsrRpc("6b023a162ab3f3e3384cd081dcc074c485585a1c3d4df39c50e5d92ff7ee00c1"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const views = Math.floor(Number(input?.views));
	if (views < 100) throw new Error("Enter at least 100 views.");
	return {
		views,
		platform: String(input?.platform || "instagram").slice(0, 32)
	};
}).handler(createSsrRpc("38133f825e8703711c4006ea0906e4351b521f1db2ba5a12eb1f1864ffaf98fb"));
var askPanelAi = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const question = String(input?.question ?? "").trim().slice(0, 800);
	if (!question) throw new Error("Ask something first.");
	return {
		question,
		context: String(input?.context ?? "").slice(0, 1200)
	};
}).handler(createSsrRpc("7cc9aa28c0338131d66d443cf22c4c3d456536b0ce5abaf0bbeec1ca970668fe"));
var getDeskRole = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("52c7f8cce72c49abee838305d0a8a5284d7533a82e4a7352526a3be36a3b8a57"));
var adminBindings = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("d89876094e8f8c4d5bbb4990c9fd0b373883105570fb6a274a4dd26489a34ec1"));
var adminSaveBindings = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!Array.isArray(input)) throw new Error("Missing configuration.");
	return input.slice(0, 20).map((row) => ({
		slot: String(row.slot || ""),
		api_url: String(row.api_url || ""),
		api_key: String(row.api_key || ""),
		service_id: "",
		pick_mode: "auto",
		min_quantity: Math.max(1, Math.floor(Number(row.min_quantity) || 1)),
		price_per_1k_paise: Math.max(0, Math.round(Number(row.price_per_1k_paise) || 0)),
		section_enabled: row.section_enabled !== false,
		providers: (Array.isArray(row.providers) ? row.providers : []).slice(0, 8).map((item) => ({
			api_url: String(item?.api_url || ""),
			api_key: String(item?.api_key || "")
		})).filter((item) => item.api_key.trim())
	}));
}).handler(createSsrRpc("c29ef8d9e4c6b2444758ed9a4262ca42798b7d0893f68c5de0092682be8f9c81"));
var adminServiceLimit = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("60022c431e90babb86a739afbb93805b8fc8de0b8c260f0dad2fcc48071a9154"));
var adminSaveServiceLimit = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({ limit: Math.max(1, Math.min(20, Math.floor(Number(input?.limit) || 1))) })).handler(createSsrRpc("ffefb9ab505fa6f15b3383d8a8dd2a79478752d665e92d3b134976fe33c0aa4b"));
var adminProviders = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("a3ee7c25df8ff379a977ad0a104a1d40e1c7908045968c09d31f60c28a0cc060"));
var adminSingleBalances = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("30a3a125387cee1e43eada149960c3556840d9411e53d6f09b9640b6303345f8"));
var adminSaveProvider = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("9412d6305059489308a9a4bec12bf940d7b918560867bf8eab9c4c34f770f7a9"));
var adminDeleteProvider = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (!id) throw new Error("Missing provider.");
	return String(id);
}).handler(createSsrRpc("102c0d443e88bd484bde30e924dd64c38ed30654408347eb703ed6b8c17090f8"));
var adminFetchProvider = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (!id) throw new Error("Missing provider.");
	return String(id);
}).handler(createSsrRpc("5adec3b9ba4ef7feac621cf838dac2a33f1f91bdf23746b74477aa10fab2b394"));
var adminServices = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((query) => String(query || "").slice(0, 80)).handler(createSsrRpc("99e597865b74b368296a71c66cdf09fc30af8a26f3ccddbba01b0eb9076ba975"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("9c2ec77a5f2e2580b771c2fd729f2f990434547f58fcf5777d1c4a8f5ccf9757"));
var adminSaveService = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("10067aa2da3a3f393e4fda1d2a37797dc6caf033ac66d72c64ced17c24b4857d"));
var adminAddService = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input?.name?.trim() || !input?.provider_service_id?.trim()) throw new Error("Service id and name are required.");
	return input;
}).handler(createSsrRpc("ab18ada607b1ab15f9afaa473392a91e5cfe8c6455049e553e742f7267656ba0"));
var adminCustomers = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("cc7b4b5133bb8e04f4340372e54f9bfb03084e95c8cc3bf733356c0f49700d92"));
var adminCredit = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const rupees = Math.floor(Number(input?.rupees));
	if (!input?.userId || !Number.isFinite(rupees) || rupees < 1 || rupees > 1e5) throw new Error("Enter a credit between ₹1 and ₹100,000.");
	return {
		userId: String(input.userId),
		rupees
	};
}).handler(createSsrRpc("33400c8bce68bb01ab9f0e19f010f5bf6b661d2406da74901644800bf54cb642"));
var adminDeleteCustomer = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((userId) => {
	if (!userId) throw new Error("Missing customer.");
	return String(userId);
}).handler(createSsrRpc("f731f994e25fffa90fcad5c2e2a12377eb2fa161ca7efceaaa24228d19ae4b6d"));
createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("a2cf483202c816b71dfc5cc88f700ea45518c52efb4847eda7ce7680bbce07df"));
var listPaymentGateways = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("4ca138b9107fe294dc084ca590048ffd96c744b30a0dea96a235b6d347f5f210"));
var submitPaymentClaim = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const amountPaise = Math.floor(Number(input?.amountPaise));
	const displayMajor = Math.round((Number(input?.displayMajor) || 0) * 100) / 100;
	const screenshot = String(input?.screenshot || "");
	if (displayMajor < 1 && amountPaise < 100) throw new Error("Enter a valid amount.");
	if (screenshot && (!screenshot.startsWith("data:image/") || screenshot.length > 7e5)) throw new Error("Screenshot is too large.");
	if (!input?.gatewayId) throw new Error("Choose a payment method.");
	return {
		amountPaise: Math.max(0, amountPaise),
		screenshot,
		reference: String(input?.reference || "").slice(0, 80),
		gatewayId: String(input.gatewayId),
		displayMajor
	};
}).handler(createSsrRpc("9204fd6efca8dba67626386c120c253732cee4900032d3cef5b42dffa5d88a70"));
var myPaymentClaims = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("26ad85d58d4fffa9dcf81b93dccaf8af05dff0b8d02fbad7e90302482fcd8a0e"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("e96b4ad862ce3c2f2a828377dea4afd7dc8eae1573a3f7660ebcc82caae1017f"));
var adminPaymentClaims = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("2c0f7763a16d4cb37471f3f5e40d5996543cf86e8a2bb1d103ad6caaf8e83e05"));
var adminSaveGateway = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("231e3d07d3950d15a6747cf0f22fcbd803d2af6644d14a7ee98963f288d31957"));
var adminReviewPayment = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	id: String(input?.id || ""),
	approve: Boolean(input?.approve),
	reason: String(input?.reason || "").slice(0, 180)
})).handler(createSsrRpc("8db6486cfeed8cc4e2082c52285ad5af0c5cebafde1b3ad5f715d5fbde750b57"));
var THEMES = [
	{
		id: "midnight",
		name: "Midnight Magic",
		bg: "#07081a",
		card: "#14162e",
		text: "#f5f7ff",
		mute: "#a5b4fc",
		line: "rgba(255,255,255,.1)",
		primary: "#7c3aed",
		accent: "#22d3ee",
		sidebar: "#0b0d1f",
		header: "#0e1028",
		radius: "18px",
		glow: "0.45"
	},
	{
		id: "aurora",
		name: "Aurora",
		bg: "#061018",
		card: "#10202c",
		text: "#f0fdfa",
		mute: "#99f6e4",
		line: "rgba(255,255,255,.1)",
		primary: "#14b8a6",
		accent: "#818cf8",
		sidebar: "#07141c",
		header: "#0b1c26",
		radius: "16px",
		glow: "0.4"
	},
	{
		id: "royal",
		name: "Royal Violet",
		bg: "#120818",
		card: "#241033",
		text: "#faf5ff",
		mute: "#e9d5ff",
		line: "rgba(255,255,255,.12)",
		primary: "#c026d3",
		accent: "#f472b6",
		sidebar: "#160a1e",
		header: "#1b0d26",
		radius: "20px",
		glow: "0.5"
	},
	{
		id: "light",
		name: "Clean Light",
		bg: "#f4f7ff",
		card: "#ffffff",
		text: "#0f172a",
		mute: "#64748b",
		line: "#e2e8f0",
		primary: "#4f46e5",
		accent: "#06b6d4",
		sidebar: "#ffffff",
		header: "#ffffff",
		radius: "16px",
		glow: "0.15"
	}
];
var KEY = "magiciansmm-theme";
function savedTheme() {
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return THEMES[0];
		const parsed = JSON.parse(raw);
		return {
			...THEMES[0],
			...parsed
		};
	} catch {
		return THEMES[0];
	}
}
function applyTheme(theme) {
	const root = document.documentElement;
	root.style.setProperty("--desk-bg", theme.bg);
	root.style.setProperty("--desk-card", theme.card);
	root.style.setProperty("--desk-text", theme.text);
	root.style.setProperty("--desk-mute", theme.mute);
	root.style.setProperty("--desk-line", theme.line);
	root.style.setProperty("--desk-primary", theme.primary);
	root.style.setProperty("--desk-accent", theme.accent);
	root.style.setProperty("--desk-sidebar", theme.sidebar);
	root.style.setProperty("--desk-header", theme.header);
	root.style.setProperty("--desk-radius", theme.radius);
	root.style.setProperty("--desk-glow", theme.glow);
	root.dataset.theme = theme.id;
}
function saveTheme(theme) {
	localStorage.setItem(KEY, JSON.stringify(theme));
	applyTheme(theme);
}
var MOTIONS = [
	{
		id: "rise",
		name: "Rise"
	},
	{
		id: "fade",
		name: "Fade"
	},
	{
		id: "slide-left",
		name: "Slide left"
	},
	{
		id: "slide-right",
		name: "Slide right"
	},
	{
		id: "slide-up",
		name: "Slide up"
	},
	{
		id: "zoom-in",
		name: "Zoom in"
	},
	{
		id: "zoom-out",
		name: "Zoom out"
	},
	{
		id: "flip",
		name: "Flip"
	},
	{
		id: "blur",
		name: "Blur in"
	},
	{
		id: "bounce",
		name: "Bounce"
	},
	{
		id: "swing",
		name: "Swing"
	},
	{
		id: "drop",
		name: "Drop"
	},
	{
		id: "glow",
		name: "Glow pop"
	},
	{
		id: "wipe",
		name: "Wipe"
	},
	{
		id: "magic",
		name: "Magic spin"
	}
];
var MKEY = "magiciansmm-motion";
function savedMotion() {
	try {
		const id = localStorage.getItem(MKEY) || "rise";
		return MOTIONS.some((item) => item.id === id) ? id : "rise";
	} catch {
		return "rise";
	}
}
function applyMotion(id = savedMotion()) {
	document.documentElement.dataset.motion = id;
}
function saveMotion(id) {
	localStorage.setItem(MKEY, id);
	applyMotion(id);
}
var hat_default = "/assets/hat-Bsaw3Kjv.png";
var STARS = Array.from({ length: 48 }, (_, index) => ({
	left: index * 37 % 100,
	top: (index * 19 + index % 5 * 7) % 100,
	duration: 2.4 + index % 8 * .35,
	delay: index % 12 * .22,
	size: index % 6 === 0 ? 6 : index % 3 === 0 ? 4 : 2
}));
function Starfield() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "starfield",
		"aria-hidden": true,
		children: STARS.map((star, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: {
			left: `${star.left}%`,
			top: `${star.top}%`,
			animationDuration: `${star.duration}s`,
			animationDelay: `${star.delay}s`,
			width: star.size,
			height: star.size
		} }, index))
	});
}
var walletCache = {
	at: 0,
	value: null
};
var LINKS = [
	{
		to: "/dashboard",
		label: "Dashboard",
		icon: LayoutDashboard,
		hot: false
	},
	{
		to: "/engagement-order",
		label: "Full Engagement",
		icon: WandSparkles,
		hot: false
	},
	{
		to: "/single-order",
		label: "Single Order",
		icon: SquarePlus,
		hot: false
	},
	{
		to: "/mass",
		label: "Mass Order",
		icon: ListPlus,
		hot: true
	},
	{
		to: "/engagement-orders",
		label: "All Orders",
		icon: Receipt,
		hot: false
	}
];
var STAFF_LINKS = [
	{
		to: "/instagram",
		label: "Instagram Accounts",
		icon: Library,
		hot: false
	},
	{
		to: "/tiktok",
		label: "TikTok Accounts",
		icon: Library,
		hot: false
	},
	{
		to: "/detect",
		label: "Bot Detection",
		icon: Activity,
		hot: false
	}
];
var TAIL_LINKS = [
	{
		to: "/wallet",
		label: "Wallet",
		icon: Wallet,
		hot: false
	},
	{
		to: "/telegram-bot",
		label: "Telegram Bot",
		icon: MessageCircle,
		hot: false
	},
	{
		to: "/support",
		label: "Support",
		icon: LifeBuoy,
		hot: false
	},
	{
		to: "/settings",
		label: "Settings",
		icon: Settings,
		hot: false
	}
];
var ADMIN_LINKS = [
	{
		to: "/admin/services",
		label: "Services",
		icon: Boxes,
		hot: false
	},
	{
		to: "/admin/engagement",
		label: "Engagement APIs",
		icon: KeyRound,
		hot: false
	},
	{
		to: "/admin/payments",
		label: "Payments",
		icon: QrCode,
		hot: false
	},
	{
		to: "/admin/customers",
		label: "Customers",
		icon: Users,
		hot: false
	}
];
function Mark({ compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/",
		className: "flex items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "hat-wrap",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: hat_default,
					alt: "",
					className: `hat-magic w-auto ${compact ? "h-9" : "h-12"}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
					className: "hat-glare",
					style: {
						top: 0,
						right: 2
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
					className: "hat-glare g2",
					style: {
						bottom: 6,
						left: 0
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
					className: "hat-glare g3",
					style: {
						top: "38%",
						right: -2
					}
				})
			]
		}), !compact && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "leading-none",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-[15px] font-extrabold tracking-tight",
				children: "Magician"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-[12px] font-bold text-fuchsia-400",
				children: "SMM Panel"
			})]
		})]
	});
}
function Shell({ children }) {
	const path = useRouterState({ select: (state) => state.location.pathname });
	const { user, isPending } = useCurrentUserState();
	const [balance, setBalance] = (0, import_react.useState)(null);
	const [admin, setAdmin] = (0, import_react.useState)(false);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [avatar, setAvatar] = (0, import_react.useState)("");
	const [deskName, setDeskName] = (0, import_react.useState)("");
	(0, import_react.useSyncExternalStore)(subscribeCurrency, currencySnapshot, currencySnapshot);
	(0, import_react.useEffect)(() => {
		applyTheme(savedTheme());
		applyMotion();
		const local = savedDisplayCode();
		if (local) applyDisplay(findCurrency(local));
		getMoneyConfig().then((config) => {
			applyBase(findCurrency(config.base));
			applyFx(config);
			applyDisplay(findCurrency(config.display || local || config.base));
		}).catch(() => void 0);
		getDeskLook().then((look) => {
			if (look.theme) try {
				applyTheme(JSON.parse(look.theme));
			} catch {}
			if (look.motion) applyMotion(look.motion);
		}).catch(() => void 0);
	}, []);
	(0, import_react.useEffect)(() => {
		setOpen(false);
		getDeskRole().then((role) => setAdmin(role === "admin")).catch(() => setAdmin(false));
		getPrefs().then((prefs) => {
			setAvatar(prefs.avatar_url || "");
			setDeskName(prefs.full_name || "");
		}).catch(() => void 0);
		if (walletCache.value != null && Date.now() - walletCache.at < 2e4) {
			setBalance(walletCache.value);
			return;
		}
		getWallet().then((wallet) => {
			walletCache.at = Date.now();
			walletCache.value = wallet.balance_paise;
			setBalance(wallet.balance_paise);
		}).catch(() => setBalance(null));
	}, [path]);
	const links = admin ? [
		...LINKS,
		...STAFF_LINKS,
		...TAIL_LINKS,
		...ADMIN_LINKS
	] : [...LINKS, ...TAIL_LINKS];
	const initial = (deskName || user?.displayName || user?.primaryEmail || "M").slice(0, 1).toUpperCase();
	const activeOf = (to) => path === to || to !== "/dashboard" && path.startsWith(`${to}/`);
	const menu = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-4 mb-3 flex items-center gap-2.5 rounded-2xl border border-white/60 bg-white/70 px-3 py-2.5 shadow-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid size-9 shrink-0 place-items-center overflow-hidden rounded-full bg-gradient-to-br from-indigo-500 to-cyan-400 text-[12px] font-bold text-white",
					children: avatar ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: avatar,
						alt: "",
						className: "size-full object-cover"
					}) : initial
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-[13px] font-semibold",
						children: deskName || user?.displayName || "Member"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-[10px] text-mute",
						children: user?.primaryEmail || "Signed in"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pulse-dot" })
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "wallet-card mx-4 mb-4 rounded-2xl p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-1 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-3" }), " Wallet balance"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-[26px] font-extrabold tracking-tight",
					children: balance == null ? "—" : inr(balance)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/wallet",
					className: "flex h-9 w-full items-center justify-center gap-1.5 rounded-xl text-[12px] font-semibold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-3.5" }), " Add credit"]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			className: "flex-1 overflow-y-auto px-3 pb-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 px-3 text-[10px] font-semibold uppercase tracking-[0.22em] text-mute",
				children: "Menu"
			}), links.map((link) => {
				const active = activeOf(link.to);
				const Icon = link.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: link.to,
					className: "nav-item mb-1 flex min-h-11 items-center gap-2.5 rounded-2xl px-3 py-2 text-[13px] " + (active ? "bg-indigo-50 font-semibold text-indigo-600 shadow-sm" : "text-slate-600 hover:bg-white/80"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex-1",
							children: link.label
						}),
						link.hot && !active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-gradient-to-r from-rose-500 to-orange-400 px-1.5 py-0.5 text-[8px] font-bold text-white",
							children: "HOT"
						})
					]
				}, link.to);
			})]
		})
	] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-screen md:grid md:grid-cols-[272px_minmax(0,1fr)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Starfield, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "sticky top-0 z-10 hidden h-screen flex-col border-r md:flex",
				style: {
					background: "var(--desk-sidebar)",
					borderColor: "var(--desk-line)"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center justify-between px-5 pb-3 pt-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {})
				}), menu]
			}),
			open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-40 md:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Close menu",
					className: "absolute inset-0 bg-slate-900/40",
					onClick: () => setOpen(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "drawer relative flex h-full w-[min(86vw,320px)] flex-col pt-4 shadow-2xl",
					style: { background: "var(--desk-sidebar)" },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center justify-between px-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setOpen(false),
							className: "grid size-9 place-items-center rounded-full bg-white text-slate-600 shadow-sm",
							"aria-label": "Close",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})]
					}), menu]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 min-w-0 pb-24 md:pb-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-20 flex items-center justify-between border-b px-3 py-3 backdrop-blur-xl",
					style: {
						background: "color-mix(in oklab, var(--desk-header) 88%, transparent)",
						borderColor: "var(--desk-line)"
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setOpen(true),
							className: "grid size-10 place-items-center rounded-2xl bg-white text-slate-700 shadow-sm md:hidden",
							"aria-label": "Open menu",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "md:hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { compact: true })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CurrencyMenu, {}), isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-8" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "page-motion mx-auto max-w-6xl px-4 py-5 md:px-8 md:py-8",
					children
				}, path)]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/support",
				className: "fixed bottom-24 right-4 z-30 grid size-14 place-items-center rounded-full bg-gradient-to-br from-indigo-500 to-cyan-400 text-white shadow-2xl shadow-indigo-500/30 md:bottom-6",
				"aria-label": "Support",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-6" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "fixed inset-x-0 bottom-0 z-20 grid grid-cols-5 border-t backdrop-blur-xl md:hidden",
				style: {
					background: "color-mix(in oklab, var(--desk-sidebar) 92%, transparent)",
					borderColor: "var(--desk-line)"
				},
				children: [LINKS.slice(0, 4).map((link) => {
					const active = activeOf(link.to);
					const Icon = link.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: link.to,
						className: "flex min-h-16 flex-col items-center justify-center gap-1 text-[10px] font-medium " + (active ? "text-indigo-600" : "text-slate-500"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), link.label.split(" ")[0]]
					}, link.to);
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setOpen(true),
					className: "flex min-h-16 flex-col items-center justify-center gap-1 text-[10px] font-medium text-slate-500",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-4" }), "More"]
				})]
			})
		]
	});
}
function CurrencyMenu() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [query, setQuery] = (0, import_react.useState)("");
	(0, import_react.useSyncExternalStore)(subscribeCurrency, currencySnapshot, currencySnapshot);
	const current = moneyState().display;
	const list = CURRENCIES.filter((item) => `${item.code} ${item.name}`.toLowerCase().includes(query.trim().toLowerCase()));
	async function pick(item) {
		applyDisplay(item);
		setOpen(false);
		setQuery("");
		try {
			await saveDisplayCurrency({ data: item.code });
		} catch {}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => setOpen((value) => !value),
			className: "inline-flex h-10 items-center gap-1 rounded-xl border px-2 text-[12px] font-bold",
			style: { borderColor: "var(--desk-line)" },
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: current.flag }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: current.code })]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute right-0 z-50 mt-2 w-64 rounded-2xl border p-2 shadow-2xl",
			style: {
				background: "var(--desk-card)",
				borderColor: "var(--desk-line)"
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: query,
					onChange: (event) => setQuery(event.target.value),
					placeholder: "Search currency",
					className: "mb-2 h-10 w-full rounded-xl px-3 text-[13px] outline-none"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-h-64 overflow-y-auto",
					children: list.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => pick(item),
						className: `flex w-full items-center gap-2 rounded-xl px-2 py-2 text-left text-[12px] ${item.code === current.code ? "bg-violet-500/20" : ""}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.flag }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold",
								children: item.code
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate opacity-70",
								children: item.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-auto",
								children: item.symbol
							})
						]
					}, item.code))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "px-2 pt-2 text-[10px] opacity-60",
					children: [
						moneyState().fxStale ? "Last saved rates" : "Live rates",
						" · stored in ",
						moneyState().base.code
					]
				})
			]
		})]
	});
}
function Panel({ children, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: `glass-card p-5 ${className}`,
		children
	});
}
var inputClass = "w-full rounded-xl border border-line bg-white/90 px-4 py-3 text-sm text-foreground outline-none focus:border-indigo-400";
//#endregion
export { inputClass as $, applyFx as A, useCurrentUserState as At, editScheduledDrop as B, adminSaveServiceLimit as C, savedTheme as Ct, apiBalances as D, submitPaymentClaim as Dt, adminSingleBalances as E, submitMassBatch as Et, changeDeskPassword as F, fromMinor as G, engagementSections as H, checkDropStatus as I, getDeskRole as J, getCatalog as K, completeMassBatch as L, askPanelAi as M, browseLiveServices as N, applyBase as O, subscribeCurrency as Ot, changeAdminLogin as P, getWallet as Q, convertMajor as R, adminSaveService as S, savedMotion as St, adminServices as T, setRunState as Tt, findCurrency as U, engagementFloors as V, formatMajor as W, getOrder as X, getMoneyConfig as Y, getPrefs as Z, adminProviders as _, saveDeskLook as _t, RedirectToSignIn as a, listOrders as at, adminSaveGateway as b, savePrefs as bt, THEMES as c, moneyCode as ct, adminCredit as d, openTicket as dt, inr as et, adminCustomers as f, panelRates as ft, adminPaymentClaims as g, saveBaseCurrency as gt, adminFetchProvider as h, refreshFx as ht, Panel as i, listOrderDrops as it, applyMotion as j, applyDisplay as k, toBaseMinor as kt, adminAddService as l, moneyState as lt, adminDeleteProvider as m, placeSingleOrder as mt, MOTIONS as n, listInstagram as nt, Shell as o, listPaymentGateways as ot, adminDeleteCustomer as p, placeOrder as pt, getDashboard as q, Mark as r, listMassBatches as rt, Starfield as s, listTickets as st, CURRENCIES as t, linkInstagram as tt, adminBindings as u, myPaymentClaims as ut, adminReviewPayment as v, saveDisplayCurrency as vt, adminServiceLimit as w, setOrderFlow as wt, adminSaveProvider as x, saveTheme as xt, adminSaveBindings as y, saveMotion as yt, createSsrRpc as z };
