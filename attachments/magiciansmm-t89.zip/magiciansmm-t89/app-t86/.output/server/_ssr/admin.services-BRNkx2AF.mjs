import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as adminSaveService, T as adminServices, _ as adminProviders, et as inr, h as adminFetchProvider, l as adminAddService, m as adminDeleteProvider, x as adminSaveProvider } from "./shell-CfBlaVSk.mjs";
import { t as Authed } from "./gate-DNi4gEUE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.services-BRNkx2AF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var blank = {
	provider_service_id: "",
	platform: "instagram",
	category: "",
	name: "",
	description: "",
	price_per_1k_paise: 100,
	min_quantity: 10,
	max_quantity: 1e5,
	drip_allowed: false,
	enabled: true
};
function ServicesDesk() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [rows, setRows] = (0, import_react.useState)([]);
	const [total, setTotal] = (0, import_react.useState)(0);
	const [note, setNote] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [edit, setEdit] = (0, import_react.useState)(null);
	const [adding, setAdding] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)(blank);
	const [providers, setProviders] = (0, import_react.useState)([]);
	const [drafts, setDrafts] = (0, import_react.useState)([{
		name: "",
		api_url: "https://yoyomedia.in/api/v2",
		api_key: "",
		enabled: true
	}]);
	function load(next = query) {
		adminServices({ data: next }).then((result) => {
			setRows(result.services);
			setTotal(result.total);
		}).catch((err) => setNote(err instanceof Error ? err.message : "Could not load services."));
	}
	(0, import_react.useEffect)(() => {
		load("");
		adminProviders().then(setProviders).catch(() => setProviders([]));
	}, []);
	async function saveAndFetchAll() {
		const filled = drafts.filter((item) => item.api_key.trim() && item.api_url.trim());
		if (filled.length === 0) {
			setNote("Kam se kam ek API key daalo.");
			return;
		}
		setBusy(true);
		setNote("");
		const notes = [];
		for (const provider of filled) try {
			const saved = await adminSaveProvider({ data: {
				...provider,
				name: provider.name.trim() || "Provider"
			} });
			const result = await adminFetchProvider({ data: saved.id });
			notes.push(`${provider.name || "Provider"}: ${result.total.toLocaleString("en-IN")} services`);
		} catch (err) {
			notes.push(`${provider.name || "Provider"} failed: ${err instanceof Error ? err.message : "fetch failed"}`);
		}
		setDrafts([{
			name: "",
			api_url: "https://yoyomedia.in/api/v2",
			api_key: "",
			enabled: true
		}]);
		setProviders(await adminProviders().catch(() => providers));
		load(query);
		setNote(notes.join(" · "));
		setBusy(false);
	}
	async function toggleDrip(row) {
		const next = !row.drip_allowed;
		setBusy(true);
		try {
			await adminSaveService({ data: {
				...row,
				drip_allowed: next
			} });
			setRows((current) => current.map((item) => item.id === row.id ? {
				...item,
				drip_allowed: next
			} : item));
			setNote(next ? `${row.name}: drip-feed on.` : `${row.name}: drip-feed off. Next fetch isko overwrite nahi karega.`);
		} catch (err) {
			setNote(err instanceof Error ? err.message : "Could not save drip-feed.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-semibold uppercase tracking-[0.18em] text-[#2563eb]",
					children: "Admin"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-[28px] font-bold text-[#0f172a]",
					children: "Services"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[13px] text-[#64748b]",
					children: [total.toLocaleString("en-IN"), " on the book. User single order only shows enabled rows."]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[24px] border border-[#dbeafe] bg-white p-4 shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "Single order providers"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-[12px] text-[#64748b]",
						children: "4-5 providers ki API yahan daalo. Fetch ke baad unki saari services Single Order mein Home, Instagram, Facebook, Twitter sab pe dikhengi. Order usi provider pe jayega jiski service select ki."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-2",
						children: providers.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-xl bg-[#f8fafc] px-3 py-2 text-[12px]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: provider.name }),
								" · ",
								provider.enabled ? "on" : "off",
								" ",
								provider.last_error ? `· ${provider.last_error}` : "",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										disabled: busy,
										onClick: async () => {
											setBusy(true);
											try {
												const result = await adminFetchProvider({ data: provider.id });
												setNote(`${provider.name}: ${result.total.toLocaleString("en-IN")} services refreshed.`);
												load(query);
											} catch (err) {
												setNote(err instanceof Error ? err.message : "Fetch failed.");
											} finally {
												setBusy(false);
											}
										},
										className: "font-semibold text-[#0f766e]",
										children: "Fetch again"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										disabled: busy,
										onClick: async () => {
											setBusy(true);
											try {
												await adminDeleteProvider({ data: provider.id });
												setProviders((current) => current.filter((item) => item.id !== provider.id));
												setNote(`${provider.name} hata diya. API balance se bhi nikal gaya.`);
												load(query);
											} catch (err) {
												setNote(err instanceof Error ? err.message : "Could not remove.");
											} finally {
												setBusy(false);
											}
										},
										className: "ml-3 font-semibold text-rose-600",
										children: "Remove"
									})]
								})
							]
						}, provider.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid gap-3",
						children: [
							drafts.map((draft, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2 rounded-2xl bg-[#f8fafc] p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[12px] font-semibold",
											children: ["API provider ", index + 1]
										}), drafts.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setDrafts(drafts.filter((_, item) => item !== index)),
											className: "text-[12px] font-semibold text-[#b91c1c]",
											children: "Remove"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: draft.name,
										onChange: (event) => setDrafts(drafts.map((item, itemIndex) => itemIndex === index ? {
											...item,
											name: event.target.value
										} : item)),
										placeholder: "Provider name",
										className: "h-11 rounded-xl border border-[#e7eef6] bg-white px-3 text-[13px] outline-none"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: draft.api_url,
										onChange: (event) => setDrafts(drafts.map((item, itemIndex) => itemIndex === index ? {
											...item,
											api_url: event.target.value
										} : item)),
										placeholder: "API URL",
										className: "h-11 rounded-xl border border-[#e7eef6] bg-white px-3 text-[13px] outline-none"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: draft.api_key,
										onChange: (event) => setDrafts(drafts.map((item, itemIndex) => itemIndex === index ? {
											...item,
											api_key: event.target.value
										} : item)),
										placeholder: "API key",
										className: "h-11 rounded-xl border border-[#e7eef6] bg-white px-3 text-[13px] outline-none"
									})
								]
							}, index)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setDrafts([...drafts, {
									name: "",
									api_url: "https://yoyomedia.in/api/v2",
									api_key: "",
									enabled: true
								}]),
								className: "h-10 rounded-xl bg-[#f3f6fa] text-[12px] font-bold text-[#1d4ed8]",
								children: "Add another API"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: busy,
								onClick: saveAndFetchAll,
								className: "h-11 rounded-xl bg-[#2563eb] text-[13px] font-bold text-white disabled:opacity-60",
								children: busy ? "Fetching…" : "Save and fetch all services"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: query,
						onChange: (event) => setQuery(event.target.value),
						placeholder: "Search id, name, category",
						className: "h-11 flex-1 rounded-xl border border-[#e7eef6] px-3 text-[13px] outline-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => load(query),
						className: "rounded-xl border bg-white px-4 text-[13px] font-semibold",
						children: "Search"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setAdding((value) => !value),
						className: "rounded-xl bg-[#0f172a] px-4 text-[13px] font-semibold text-white",
						children: "Add service"
					})
				]
			}),
			adding && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid gap-2 rounded-[24px] border border-[#e7eef6] bg-white p-4",
				onSubmit: async (event) => {
					event.preventDefault();
					setBusy(true);
					try {
						await adminAddService({ data: draft });
						setDraft(blank);
						setAdding(false);
						load(query);
					} catch (err) {
						setNote(err instanceof Error ? err.message : "Could not add.");
					} finally {
						setBusy(false);
					}
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: "Custom service"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								value: draft.provider_service_id,
								onChange: (event) => setDraft({
									...draft,
									provider_service_id: event.target.value
								}),
								placeholder: "Service ID",
								className: "h-10 rounded-xl border px-3 text-[13px]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								value: draft.name,
								onChange: (event) => setDraft({
									...draft,
									name: event.target.value
								}),
								placeholder: "Service title",
								className: "h-10 rounded-xl border px-3 text-[13px]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: draft.category,
								onChange: (event) => setDraft({
									...draft,
									category: event.target.value
								}),
								placeholder: "Category",
								className: "h-10 rounded-xl border px-3 text-[13px]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: draft.platform,
								onChange: (event) => setDraft({
									...draft,
									platform: event.target.value
								}),
								placeholder: "Platform",
								className: "h-10 rounded-xl border px-3 text-[13px]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: draft.price_per_1k_paise,
								onChange: (event) => setDraft({
									...draft,
									price_per_1k_paise: Number(event.target.value)
								}),
								placeholder: "Price per 1k in paise",
								className: "h-10 rounded-xl border px-3 text-[13px]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: draft.description,
								onChange: (event) => setDraft({
									...draft,
									description: event.target.value
								}),
								placeholder: "Description",
								className: "h-10 rounded-xl border px-3 text-[13px]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: draft.min_quantity,
								onChange: (event) => setDraft({
									...draft,
									min_quantity: Number(event.target.value)
								}),
								placeholder: "Minimum",
								className: "h-10 rounded-xl border px-3 text-[13px]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: draft.max_quantity,
								onChange: (event) => setDraft({
									...draft,
									max_quantity: Number(event.target.value)
								}),
								placeholder: "Maximum",
								className: "h-10 rounded-xl border px-3 text-[13px]"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-[13px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: draft.drip_allowed,
							onChange: (event) => setDraft({
								...draft,
								drip_allowed: event.target.checked
							})
						}), " Drip-feed allowed"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-[13px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: draft.enabled,
							onChange: (event) => setDraft({
								...draft,
								enabled: event.target.checked
							})
						}), " Enabled"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "h-10 rounded-xl bg-[#2563eb] text-[13px] font-bold text-white",
						children: "Save custom service"
					})
				]
			}),
			note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl bg-[#eff6ff] px-3 py-2 text-[13px] text-[#1e3a8a]",
				children: note
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "rounded-2xl border border-[#e7eef6] bg-white p-3",
					children: edit?.id === row.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditForm, {
						row: edit,
						onChange: setEdit,
						onCancel: () => setEdit(null),
						onSave: async () => {
							if (!edit) return;
							await adminSaveService({ data: edit });
							setEdit(null);
							load(query);
						}
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[13px] font-semibold",
								children: row.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[12px] text-[#64748b]",
								children: [
									"#",
									row.provider_service_id,
									" · ",
									row.platform,
									" · ",
									row.category
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[12px] text-[#334155]",
								children: [
									inr(row.price_per_1k_paise),
									" / 1k · ",
									row.min_quantity,
									"–",
									row.max_quantity,
									" · ",
									row.enabled ? "enabled" : "disabled"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `mt-1 inline-flex rounded-full px-2 py-0.5 text-[10px] font-bold ${row.drip_allowed ? "bg-emerald-500/20 text-emerald-300" : "bg-white/10 text-[#a5b4fc]"}`,
								children: row.drip_allowed ? "Drip on" : "Drip off"
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								role: "switch",
								"aria-checked": row.drip_allowed,
								disabled: busy,
								onClick: () => toggleDrip(row),
								className: `relative h-7 w-12 rounded-full ${row.drip_allowed ? "bg-violet-500" : "bg-[#3a335f]"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-0.5 size-6 rounded-full bg-white shadow ${row.drip_allowed ? "left-5" : "left-0.5"}` })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setEdit(row),
								className: "rounded-lg border px-3 py-1 text-[12px] font-semibold",
								children: "Edit"
							})]
						})]
					})
				}, row.id))
			})
		]
	});
}
function EditForm({ row, onChange, onSave, onCancel }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: row.name,
				onChange: (event) => onChange({
					...row,
					name: event.target.value
				}),
				className: "h-10 rounded-xl border px-3 text-[13px]"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: row.category,
				onChange: (event) => onChange({
					...row,
					category: event.target.value
				}),
				className: "h-10 rounded-xl border px-3 text-[13px]"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				value: row.description,
				onChange: (event) => onChange({
					...row,
					description: event.target.value
				}),
				className: "min-h-16 rounded-xl border px-3 py-2 text-[13px]"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: row.price_per_1k_paise,
						onChange: (event) => onChange({
							...row,
							price_per_1k_paise: Number(event.target.value)
						}),
						className: "h-10 rounded-xl border px-3 text-[13px]"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: row.min_quantity,
						onChange: (event) => onChange({
							...row,
							min_quantity: Number(event.target.value)
						}),
						className: "h-10 rounded-xl border px-3 text-[13px]"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: row.max_quantity,
						onChange: (event) => onChange({
							...row,
							max_quantity: Number(event.target.value)
						}),
						className: "h-10 rounded-xl border px-3 text-[13px]"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 text-[13px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: row.enabled,
					onChange: (event) => onChange({
						...row,
						enabled: event.target.checked
					})
				}), " Service enabled"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 text-[13px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: row.drip_allowed,
					onChange: (event) => onChange({
						...row,
						drip_allowed: event.target.checked
					})
				}), " User can use drip-feed"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onSave,
					className: "h-10 rounded-xl bg-[#2563eb] px-4 text-[13px] font-bold text-white",
					children: "Save"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onCancel,
					className: "h-10 rounded-xl border px-4 text-[13px]",
					children: "Cancel"
				})]
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Authed, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServicesDesk, {}) });
//#endregion
export { SplitComponent as component };
