import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { dt as openTicket, st as listTickets } from "./shell-CfBlaVSk.mjs";
import { t as Authed } from "./gate-DNi4gEUE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/support-LWIzyRy7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FAQ = [
	["How fast is delivery?", "Orders stay on your ledger and drip by the schedule you set. A provider is not connected yet, so nothing is sent upstream."],
	["Why is Place Order disabled?", "The wallet has to cover the total. Add funds on the wallet page. That credit is local until a gateway is connected."],
	["Can I change ratios?", "Yes. Settings stores your organic ratios, and the order page has a per-type Settings panel."]
];
function Support() {
	const [rows, setRows] = (0, import_react.useState)([]);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [faq, setFaq] = (0, import_react.useState)(false);
	const [chat, setChat] = (0, import_react.useState)(false);
	const [subject, setSubject] = (0, import_react.useState)("");
	const [body, setBody] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	function load() {
		listTickets().then(setRows).catch(() => setRows([]));
	}
	(0, import_react.useEffect)(load, []);
	async function send() {
		try {
			await openTicket({ data: {
				subject,
				body
			} });
			setSubject("");
			setBody("");
			setOpen(false);
			setChat(false);
			setNote("Ticket saved.");
			load();
		} catch (err) {
			setNote(err instanceof Error ? err.message : "Could not open the ticket.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex items-center justify-between rounded-3xl border border-[#e7eef6] bg-white p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-[22px] font-bold",
					children: "Support Center"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[13px] text-[#64748b]",
					children: "Get help with your orders and account"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setOpen(true),
					className: "rounded-xl bg-[#3b82f6] px-3 py-2 text-[13px] font-semibold text-white",
					children: "+ New Ticket"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-4 gap-2 text-center",
				children: [
					["Total Tickets", rows.length],
					["Open", rows.length],
					["Resolved", 0],
					["Avg Response", "~2h"]
				].map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-[#e7eef6] bg-white p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[18px] font-bold",
						children: value
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-[#94a3b8]",
						children: label
					})]
				}, String(label)))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border border-[#e7eef6] bg-white p-6 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: "Your Tickets"
				}), rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-6 text-[13px] text-[#94a3b8]",
					children: [
						"No tickets yet",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						"Need help? Create a support ticket and we'll assist you."
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setOpen(true),
					className: "mt-3 h-10 rounded-xl bg-[#3b82f6] px-4 text-[13px] font-semibold text-white",
					children: "+ Create Your First Ticket"
				})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2 text-left text-[13px]",
					children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-xl bg-[#f8fafc] p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: row.subject }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: row.body })]
					}, row.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex items-center justify-between rounded-3xl border border-[#e7eef6] bg-white p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: "Need Quick Help?"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[12px] text-[#94a3b8]",
					children: "Check our FAQ or contact us directly for urgent issues"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setFaq((value) => !value),
						className: "rounded-xl border px-3 py-2 text-[12px] font-semibold",
						children: "View FAQ"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setChat(true),
						className: "rounded-xl border px-3 py-2 text-[12px] font-semibold",
						children: "Live Chat"
					})]
				})]
			}),
			faq && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: FAQ.map(([q, a]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl bg-white p-3 text-[13px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: q }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[#64748b]",
						children: a
					})]
				}, q))
			}),
			(open || chat) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border border-[#e7eef6] bg-white p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: chat ? "Live chat desk" : "New ticket"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[12px] text-[#94a3b8]",
						children: "Saved on your ledger. No outside agent is connected."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: subject,
						onChange: (event) => setSubject(event.target.value),
						placeholder: "Subject",
						className: "mt-2 h-11 w-full rounded-xl bg-[#f8fafc] px-3"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: body,
						onChange: (event) => setBody(event.target.value),
						placeholder: "What do you need?",
						className: "mt-2 h-24 w-full rounded-xl bg-[#f8fafc] p-3"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: send,
						className: "mt-2 h-10 rounded-xl bg-[#3b82f6] px-4 text-[13px] font-semibold text-white",
						children: "Send"
					})
				]
			}),
			note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-[13px]",
				children: note
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Authed, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Support, {}) });
//#endregion
export { SplitComponent as component };
