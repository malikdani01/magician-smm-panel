import { r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-DY5Pyta6.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
import { C as saveServiceActiveLimit, D as syncProviderCatalog, E as syncManagedServices, S as saveProvider, T as submitClaim, _ as reviewClaim, a as deleteProvider, b as saveManaged, c as listClaims, d as listProviders, f as myClaims, g as requireAdmin, h as removeCustomer, i as creditCustomer, l as listCustomers, m as publicGateways, n as adminGateways, o as deskRole, p as paymentDesk, s as listBindings, t as addCustomService, u as listManaged, v as saveBindings, w as serviceActiveLimit, x as savePaymentDesk, y as saveGateway } from "./admin.server-B6p1lYbS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.functions-C72wviH9.js
var getDeskRole_createServerFn_handler = createServerRpc({
	id: "52c7f8cce72c49abee838305d0a8a5284d7533a82e4a7352526a3be36a3b8a57",
	name: "getDeskRole",
	filename: "src/lib/admin.functions.ts"
}, (opts) => getDeskRole.__executeServer(opts));
var getDeskRole = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getDeskRole_createServerFn_handler, async ({ context }) => deskRole(context.userId));
var adminBindings_createServerFn_handler = createServerRpc({
	id: "d89876094e8f8c4d5bbb4990c9fd0b373883105570fb6a274a4dd26489a34ec1",
	name: "adminBindings",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminBindings.__executeServer(opts));
var adminBindings = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(adminBindings_createServerFn_handler, async ({ context }) => {
	await requireAdmin(context.userId);
	return listBindings();
});
var adminSaveBindings_createServerFn_handler = createServerRpc({
	id: "c29ef8d9e4c6b2444758ed9a4262ca42798b7d0893f68c5de0092682be8f9c81",
	name: "adminSaveBindings",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminSaveBindings.__executeServer(opts));
var adminSaveBindings = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!Array.isArray(input)) throw new Error("Missing configuration.");
	return input.slice(0, 20).map((row) => ({
		slot: String(row.slot || ""),
		api_url: String(row.api_url || ""),
		api_key: String(row.api_key || ""),
		service_id: "",
		pick_mode: "auto",
		min_quantity: Math.max(1, Math.floor(Number(row.min_quantity) || 1)),
		price_per_1k_paise: Math.max(0, Math.round(Number(row.price_per_1k_paise) || 0)),
		section_enabled: row.section_enabled !== false,
		providers: (Array.isArray(row.providers) ? row.providers : []).slice(0, 8).map((item) => ({
			api_url: String(item?.api_url || ""),
			api_key: String(item?.api_key || "")
		})).filter((item) => item.api_key.trim())
	}));
}).handler(adminSaveBindings_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	await saveBindings(data);
	return { ok: true };
});
var adminServiceLimit_createServerFn_handler = createServerRpc({
	id: "60022c431e90babb86a739afbb93805b8fc8de0b8c260f0dad2fcc48071a9154",
	name: "adminServiceLimit",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminServiceLimit.__executeServer(opts));
var adminServiceLimit = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(adminServiceLimit_createServerFn_handler, async ({ context }) => {
	await requireAdmin(context.userId);
	return { limit: await serviceActiveLimit() };
});
var adminSaveServiceLimit_createServerFn_handler = createServerRpc({
	id: "ffefb9ab505fa6f15b3383d8a8dd2a79478752d665e92d3b134976fe33c0aa4b",
	name: "adminSaveServiceLimit",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminSaveServiceLimit.__executeServer(opts));
var adminSaveServiceLimit = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({ limit: Math.max(1, Math.min(20, Math.floor(Number(input?.limit) || 1))) })).handler(adminSaveServiceLimit_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	return { limit: await saveServiceActiveLimit(data.limit) };
});
var adminProviders_createServerFn_handler = createServerRpc({
	id: "a3ee7c25df8ff379a977ad0a104a1d40e1c7908045968c09d31f60c28a0cc060",
	name: "adminProviders",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminProviders.__executeServer(opts));
var adminProviders = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(adminProviders_createServerFn_handler, async ({ context }) => {
	await requireAdmin(context.userId);
	return listProviders();
});
var adminSingleBalances_createServerFn_handler = createServerRpc({
	id: "30a3a125387cee1e43eada149960c3556840d9411e53d6f09b9640b6303345f8",
	name: "adminSingleBalances",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminSingleBalances.__executeServer(opts));
var adminSingleBalances = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(adminSingleBalances_createServerFn_handler, async ({ context }) => {
	await requireAdmin(context.userId);
	const { listSingleOrderBalances } = await import("./providers.server-BTYWPfD2.mjs").then((n) => n.i).then((n) => n.r);
	return listSingleOrderBalances();
});
var adminSaveProvider_createServerFn_handler = createServerRpc({
	id: "9412d6305059489308a9a4bec12bf940d7b918560867bf8eab9c4c34f770f7a9",
	name: "adminSaveProvider",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminSaveProvider.__executeServer(opts));
var adminSaveProvider = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(adminSaveProvider_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	return { id: await saveProvider(data) };
});
var adminDeleteProvider_createServerFn_handler = createServerRpc({
	id: "102c0d443e88bd484bde30e924dd64c38ed30654408347eb703ed6b8c17090f8",
	name: "adminDeleteProvider",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminDeleteProvider.__executeServer(opts));
var adminDeleteProvider = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (!id) throw new Error("Missing provider.");
	return String(id);
}).handler(adminDeleteProvider_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	await deleteProvider(data);
	return { ok: true };
});
var adminFetchProvider_createServerFn_handler = createServerRpc({
	id: "5adec3b9ba4ef7feac621cf838dac2a33f1f91bdf23746b74477aa10fab2b394",
	name: "adminFetchProvider",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminFetchProvider.__executeServer(opts));
var adminFetchProvider = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (!id) throw new Error("Missing provider.");
	return String(id);
}).handler(adminFetchProvider_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	return syncProviderCatalog(data);
});
var adminServices_createServerFn_handler = createServerRpc({
	id: "99e597865b74b368296a71c66cdf09fc30af8a26f3ccddbba01b0eb9076ba975",
	name: "adminServices",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminServices.__executeServer(opts));
var adminServices = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((query) => String(query || "").slice(0, 80)).handler(adminServices_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	return listManaged(data);
});
var adminSyncServices_createServerFn_handler = createServerRpc({
	id: "9c2ec77a5f2e2580b771c2fd729f2f990434547f58fcf5777d1c4a8f5ccf9757",
	name: "adminSyncServices",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminSyncServices.__executeServer(opts));
var adminSyncServices = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(adminSyncServices_createServerFn_handler, async ({ context }) => {
	await requireAdmin(context.userId);
	return syncManagedServices();
});
var adminSaveService_createServerFn_handler = createServerRpc({
	id: "10067aa2da3a3f393e4fda1d2a37797dc6caf033ac66d72c64ced17c24b4857d",
	name: "adminSaveService",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminSaveService.__executeServer(opts));
var adminSaveService = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(adminSaveService_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	await saveManaged(data);
	return { ok: true };
});
var adminAddService_createServerFn_handler = createServerRpc({
	id: "ab18ada607b1ab15f9afaa473392a91e5cfe8c6455049e553e742f7267656ba0",
	name: "adminAddService",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminAddService.__executeServer(opts));
var adminAddService = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input?.name?.trim() || !input?.provider_service_id?.trim()) throw new Error("Service id and name are required.");
	return input;
}).handler(adminAddService_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	return { id: await addCustomService(data) };
});
var adminCustomers_createServerFn_handler = createServerRpc({
	id: "cc7b4b5133bb8e04f4340372e54f9bfb03084e95c8cc3bf733356c0f49700d92",
	name: "adminCustomers",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminCustomers.__executeServer(opts));
var adminCustomers = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(adminCustomers_createServerFn_handler, async ({ context }) => {
	await requireAdmin(context.userId);
	return listCustomers();
});
var adminCredit_createServerFn_handler = createServerRpc({
	id: "33400c8bce68bb01ab9f0e19f010f5bf6b661d2406da74901644800bf54cb642",
	name: "adminCredit",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminCredit.__executeServer(opts));
var adminCredit = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const rupees = Math.floor(Number(input?.rupees));
	if (!input?.userId || !Number.isFinite(rupees) || rupees < 1 || rupees > 1e5) throw new Error("Enter a credit between ₹1 and ₹100,000.");
	return {
		userId: String(input.userId),
		rupees
	};
}).handler(adminCredit_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	await creditCustomer(data.userId, data.rupees * 100, `Admin credit ₹${data.rupees}.`);
	return { ok: true };
});
var adminDeleteCustomer_createServerFn_handler = createServerRpc({
	id: "f731f994e25fffa90fcad5c2e2a12377eb2fa161ca7efceaaa24228d19ae4b6d",
	name: "adminDeleteCustomer",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminDeleteCustomer.__executeServer(opts));
var adminDeleteCustomer = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((userId) => {
	if (!userId) throw new Error("Missing customer.");
	return String(userId);
}).handler(adminDeleteCustomer_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	await removeCustomer(context.userId, data);
	return { ok: true };
});
var getPaymentDesk_createServerFn_handler = createServerRpc({
	id: "a2cf483202c816b71dfc5cc88f700ea45518c52efb4847eda7ce7680bbce07df",
	name: "getPaymentDesk",
	filename: "src/lib/admin.functions.ts"
}, (opts) => getPaymentDesk.__executeServer(opts));
var getPaymentDesk = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getPaymentDesk_createServerFn_handler, async () => {
	const desk = await paymentDesk();
	return {
		upi_id: desk.upi_id,
		note: desk.note,
		qr_image: desk.qr_image
	};
});
var listPaymentGateways_createServerFn_handler = createServerRpc({
	id: "4ca138b9107fe294dc084ca590048ffd96c744b30a0dea96a235b6d347f5f210",
	name: "listPaymentGateways",
	filename: "src/lib/admin.functions.ts"
}, (opts) => listPaymentGateways.__executeServer(opts));
var listPaymentGateways = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listPaymentGateways_createServerFn_handler, async () => publicGateways());
var submitPaymentClaim_createServerFn_handler = createServerRpc({
	id: "9204fd6efca8dba67626386c120c253732cee4900032d3cef5b42dffa5d88a70",
	name: "submitPaymentClaim",
	filename: "src/lib/admin.functions.ts"
}, (opts) => submitPaymentClaim.__executeServer(opts));
var submitPaymentClaim = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const amountPaise = Math.floor(Number(input?.amountPaise));
	const displayMajor = Math.round((Number(input?.displayMajor) || 0) * 100) / 100;
	const screenshot = String(input?.screenshot || "");
	if (displayMajor < 1 && amountPaise < 100) throw new Error("Enter a valid amount.");
	if (screenshot && (!screenshot.startsWith("data:image/") || screenshot.length > 7e5)) throw new Error("Screenshot is too large.");
	if (!input?.gatewayId) throw new Error("Choose a payment method.");
	return {
		amountPaise: Math.max(0, amountPaise),
		screenshot,
		reference: String(input?.reference || "").slice(0, 80),
		gatewayId: String(input.gatewayId),
		displayMajor
	};
}).handler(submitPaymentClaim_createServerFn_handler, async ({ context, data }) => {
	return { id: await submitClaim(context.userId, data.amountPaise, data.screenshot, data.reference, data.gatewayId, data.displayMajor) };
});
var myPaymentClaims_createServerFn_handler = createServerRpc({
	id: "26ad85d58d4fffa9dcf81b93dccaf8af05dff0b8d02fbad7e90302482fcd8a0e",
	name: "myPaymentClaims",
	filename: "src/lib/admin.functions.ts"
}, (opts) => myPaymentClaims.__executeServer(opts));
var myPaymentClaims = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(myPaymentClaims_createServerFn_handler, async ({ context }) => myClaims(context.userId));
var adminSaveQr_createServerFn_handler = createServerRpc({
	id: "e96b4ad862ce3c2f2a828377dea4afd7dc8eae1573a3f7660ebcc82caae1017f",
	name: "adminSaveQr",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminSaveQr.__executeServer(opts));
var adminSaveQr = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(adminSaveQr_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	await savePaymentDesk(data);
	return { ok: true };
});
var adminPaymentClaims_createServerFn_handler = createServerRpc({
	id: "2c0f7763a16d4cb37471f3f5e40d5996543cf86e8a2bb1d103ad6caaf8e83e05",
	name: "adminPaymentClaims",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminPaymentClaims.__executeServer(opts));
var adminPaymentClaims = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(adminPaymentClaims_createServerFn_handler, async ({ context }) => {
	await requireAdmin(context.userId);
	const [desk, claims, gateways] = await Promise.all([
		paymentDesk(),
		listClaims(),
		adminGateways()
	]);
	return {
		desk,
		claims,
		gateways
	};
});
var adminSaveGateway_createServerFn_handler = createServerRpc({
	id: "231e3d07d3950d15a6747cf0f22fcbd803d2af6644d14a7ee98963f288d31957",
	name: "adminSaveGateway",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminSaveGateway.__executeServer(opts));
var adminSaveGateway = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(adminSaveGateway_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	if (!data.name?.trim()) throw new Error("Gateway name is required.");
	return { id: await saveGateway({
		id: data.id || crypto.randomUUID(),
		name: data.name.trim(),
		account_title: data.account_title || "",
		account_number: data.account_number || "",
		ifsc: data.ifsc || "",
		instructions: data.instructions || "",
		qr_image: data.qr_image || "",
		min_paise: Math.max(100, Math.floor(Number(data.min_rupees) || 100) * 100),
		max_paise: Math.max(100, Math.floor(Number(data.max_rupees) || 1e5) * 100),
		enabled: Boolean(data.enabled),
		sort_order: 0,
		archived: Boolean(data.archived),
		pay_mode: data.pay_mode === "auto" ? "auto" : "manual",
		pay_currency: String(data.pay_currency || "INR"),
		network: String(data.network || ""),
		pay_kind: String(data.pay_kind || "other")
	}) };
});
var adminReviewPayment_createServerFn_handler = createServerRpc({
	id: "8db6486cfeed8cc4e2082c52285ad5af0c5cebafde1b3ad5f715d5fbde750b57",
	name: "adminReviewPayment",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminReviewPayment.__executeServer(opts));
var adminReviewPayment = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	id: String(input?.id || ""),
	approve: Boolean(input?.approve),
	reason: String(input?.reason || "").slice(0, 180)
})).handler(adminReviewPayment_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	await reviewClaim(data.id, data.approve, data.reason);
	return { ok: true };
});
//#endregion
export { adminAddService_createServerFn_handler, adminBindings_createServerFn_handler, adminCredit_createServerFn_handler, adminCustomers_createServerFn_handler, adminDeleteCustomer_createServerFn_handler, adminDeleteProvider_createServerFn_handler, adminFetchProvider_createServerFn_handler, adminPaymentClaims_createServerFn_handler, adminProviders_createServerFn_handler, adminReviewPayment_createServerFn_handler, adminSaveBindings_createServerFn_handler, adminSaveGateway_createServerFn_handler, adminSaveProvider_createServerFn_handler, adminSaveQr_createServerFn_handler, adminSaveServiceLimit_createServerFn_handler, adminSaveService_createServerFn_handler, adminServiceLimit_createServerFn_handler, adminServices_createServerFn_handler, adminSingleBalances_createServerFn_handler, adminSyncServices_createServerFn_handler, getDeskRole_createServerFn_handler, getPaymentDesk_createServerFn_handler, listPaymentGateways_createServerFn_handler, myPaymentClaims_createServerFn_handler, submitPaymentClaim_createServerFn_handler };
