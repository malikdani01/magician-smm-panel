import { o as __toESM } from "../_runtime.mjs";
import { t as __exportAll } from "./rolldown-runtime-D7D4PA-g.mjs";
import { C as require_jsx_runtime, S as useRouter, X as require_react, _ as lazyRouteComponent, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, v as createFileRoute, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { L as string, N as number, P as object, R as union, j as literal } from "../_libs/@better-auth/core+[...].mjs";
import { u as getSql } from "./organic-DU6S6wDh.mjs";
import { r as auth, t as getSessionUser } from "./verify.server-DV020YNI.mjs";
import { c as TriangleAlert } from "../_libs/lucide-react.mjs";
import { n as listOrderDrops } from "./drip.server-C0TUW5wc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-BUBrNJ6H.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-CCt1OzTp.css";
var APP_NAME = "Magiciansmm";
var Route$29 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: `${APP_NAME} — Growth desk` },
			{
				name: "description",
				content: "Magiciansmm is a wallet-based growth desk for staged social cues. Orders stay on your ledger until a provider is connected."
			},
			{
				name: "theme-color",
				content: "#2563eb"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Outfit:wght@400;500;600;700&family=Playfair+Display:ital,wght@0,700;1,700;1,800&display=swap"
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$22 = () => import("./routes-BsgV_40Z.mjs");
var Route$28 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$22, "component") });
var $$splitComponentImporter$21 = () => import("./api-access-BHZOydPk.mjs");
var Route$27 = createFileRoute("/api-access")({ component: lazyRouteComponent($$splitComponentImporter$21, "component") });
var $$splitComponentImporter$20 = () => import("./catalog-B-IIem7A.mjs");
var Route$26 = createFileRoute("/catalog")({ component: lazyRouteComponent($$splitComponentImporter$20, "component") });
var $$splitComponentImporter$19 = () => import("./dashboard-Cd1acbpZ.mjs");
var Route$25 = createFileRoute("/dashboard")({ component: lazyRouteComponent($$splitComponentImporter$19, "component") });
var $$splitComponentImporter$18 = () => import("./detect-BnuO1uNg.mjs");
var Route$24 = createFileRoute("/detect")({ component: lazyRouteComponent($$splitComponentImporter$18, "component") });
var $$splitComponentImporter$17 = () => import("./engagement-order-DQgu5yrh.mjs");
var Route$23 = createFileRoute("/engagement-order")({ component: lazyRouteComponent($$splitComponentImporter$17, "component") });
var $$splitComponentImporter$16 = () => import("./engagement-orders-C-rTv0wT.mjs");
var Route$22 = createFileRoute("/engagement-orders")({ component: lazyRouteComponent($$splitComponentImporter$16, "component") });
var $$splitComponentImporter$15 = () => import("./instagram-B136YR8c.mjs");
var Route$21 = createFileRoute("/instagram")({ component: lazyRouteComponent($$splitComponentImporter$15, "component") });
var $$splitComponentImporter$14 = () => import("./login-DhSCPn5Y.mjs");
var Route$20 = createFileRoute("/login")({ component: lazyRouteComponent($$splitComponentImporter$14, "component") });
var $$splitComponentImporter$13 = () => import("./mass-X-A2v4M6.mjs");
var Route$19 = createFileRoute("/mass")({ component: lazyRouteComponent($$splitComponentImporter$13, "component") });
var $$splitComponentImporter$12 = () => import("./order-BadteYGP.mjs");
var Route$18 = createFileRoute("/order")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("./orders-CoXTbNTK.mjs");
var Route$17 = createFileRoute("/orders")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./settings-BzoaB6X4.mjs");
var Route$16 = createFileRoute("/settings")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./single-order-BtCgqbHM.mjs");
var Route$15 = createFileRoute("/single-order")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./support-LWIzyRy7.mjs");
var Route$14 = createFileRoute("/support")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./telegram-bot-CkzH2eur.mjs");
var Route$13 = createFileRoute("/telegram-bot")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./tiktok-C0N7wZtd.mjs");
var Route$12 = createFileRoute("/tiktok")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./wallet-DhxTeVW4.mjs");
var Route$11 = createFileRoute("/wallet")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./admin.customers-BGjYSRPj.mjs");
var Route$10 = createFileRoute("/admin/customers")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./admin.engagement-NSNDJ8XO.mjs");
var Route$9 = createFileRoute("/admin/engagement")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./admin.payments-CO4pDq0f.mjs");
var Route$8 = createFileRoute("/admin/payments")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./admin.services-BRNkx2AF.mjs");
var Route$7 = createFileRoute("/admin/services")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./orders._id-BJXgw0p7.mjs");
var Route$6 = createFileRoute("/orders/$id")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var Route$5 = createFileRoute("/api/auth/$")({ server: { handlers: {
	GET: ({ request }) => auth.handler(request),
	POST: ({ request }) => auth.handler(request)
} } });
var Route$4 = createFileRoute("/api/drops/$id")({ server: { handlers: { GET: async ({ request, params }) => {
	const user = await getSessionUser();
	if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });
	const id = String(params.id || "");
	if (id.length < 8) return Response.json({ error: "Missing order" }, { status: 400 });
	const drops = await listOrderDrops(user.id, id);
	const orders = await (await getSql())`select status from engagement_orders where id = ${id} and user_id = ${user.id}`;
	const placed = drops.filter((d) => d.status === "placed").length;
	console.log(`[drops] poll order ${id.slice(0, 8)} → ${drops.length} runs, ${placed} placed`);
	return Response.json({
		drops,
		status: orders[0]?.status ?? "processing",
		at: Date.now()
	}, { headers: { "cache-control": "no-store, max-age=0" } });
} } } });
var IG_REDIRECT = "https://localhost:8080/api/meta/callback";
var SCOPES$1 = "instagram_business_basic,instagram_business_manage_insights";
function appId() {
	const id = process.env.INSTAGRAM_APP_ID?.trim();
	if (!id) throw new Error("INSTAGRAM_APP_ID .env mein nahi hai.");
	return id;
}
function appSecret() {
	const secret = process.env.INSTAGRAM_APP_SECRET?.trim();
	if (!secret) throw new Error("INSTAGRAM_APP_SECRET .env mein nahi hai.");
	return secret;
}
function instagramAuthorizeUrl(state) {
	const url = new URL("https://www.instagram.com/oauth/authorize");
	url.searchParams.set("client_id", appId());
	url.searchParams.set("redirect_uri", IG_REDIRECT);
	url.searchParams.set("response_type", "code");
	url.searchParams.set("scope", SCOPES$1);
	url.searchParams.set("state", state);
	return url.toString();
}
function pickToken(body) {
	const row = body.access_token ? body : body.data?.[0];
	const accessToken = row?.access_token?.trim();
	if (!accessToken) throw new Error("Instagram ne access token nahi diya.");
	return {
		accessToken,
		igUserId: row?.user_id != null ? String(row.user_id) : ""
	};
}
async function exchangeInstagramCode(code) {
	const form = new URLSearchParams({
		client_id: appId(),
		client_secret: appSecret(),
		grant_type: "authorization_code",
		redirect_uri: IG_REDIRECT,
		code
	});
	const tokenRes = await fetch("https://api.instagram.com/oauth/access_token", {
		method: "POST",
		headers: { "content-type": "application/x-www-form-urlencoded" },
		body: form
	});
	const tokenBody = await tokenRes.json().catch(() => ({}));
	if (!tokenRes.ok) throw new Error(tokenBody.error_message || "Instagram token exchange fail.");
	let { accessToken, igUserId } = pickToken(tokenBody);
	let expiresAt = null;
	const longUrl = new URL("https://graph.instagram.com/access_token");
	longUrl.searchParams.set("grant_type", "ig_exchange_token");
	longUrl.searchParams.set("client_secret", appSecret());
	longUrl.searchParams.set("access_token", accessToken);
	const longRes = await fetch(longUrl);
	if (longRes.ok) {
		const longBody = await longRes.json();
		if (longBody.access_token) {
			accessToken = longBody.access_token;
			if (longBody.expires_in) expiresAt = new Date(Date.now() + longBody.expires_in * 1e3).toISOString();
		}
	}
	const meUrl = new URL("https://graph.instagram.com/me");
	meUrl.searchParams.set("fields", "id,user_id,username");
	meUrl.searchParams.set("access_token", accessToken);
	const meRes = await fetch(meUrl);
	const me = await meRes.json().catch(() => ({}));
	if (!meRes.ok) throw new Error(me.error?.message || "Instagram profile nahi mila.");
	return {
		accessToken,
		igUserId: String(me.user_id || me.id || igUserId),
		username: (me.username || "").replace(/^@/, ""),
		expiresAt
	};
}
async function saveInstagramConnection(input) {
	const sql = await getSql();
	const existing = await sql`
    select id from instagram_oauth
    where user_id = ${input.userId} and ig_user_id = ${input.igUserId}
    limit 1
  `;
	if (existing[0]) {
		await sql`
      update instagram_oauth
      set username = ${input.username},
          access_token = ${input.accessToken},
          expires_at = ${input.expiresAt}
      where id = ${existing[0].id}
    `;
		return existing[0].id;
	}
	const id = crypto.randomUUID();
	await sql`
    insert into instagram_oauth (id, user_id, ig_user_id, username, access_token, expires_at)
    values (${id}, ${input.userId}, ${input.igUserId}, ${input.username}, ${input.accessToken}, ${input.expiresAt})
  `;
	return id;
}
function fail$1(reason) {
	return Response.redirect(`https://localhost:8080/instagram?ig=error&reason=${encodeURIComponent(reason)}`, 302);
}
var Route$3 = createFileRoute("/api/meta/callback")({ server: { handlers: { GET: async ({ request }) => {
	const url = new URL(request.url);
	const denied = url.searchParams.get("error_description") || url.searchParams.get("error");
	if (denied) return fail$1(denied);
	const code = url.searchParams.get("code") || "";
	const state = url.searchParams.get("state") || "";
	const saved = (request.headers.get("cookie") || "").split(";").map((part) => part.trim()).find((part) => part.startsWith("ig_oauth_state="))?.slice(15);
	if (!code || !state || !saved || saved !== state) return fail$1("Login state match nahi hua. Connect dubara dabao.");
	const user = await getSessionUser();
	if (!user) return fail$1("Pehle panel mein login karo, phir Connect dabao.");
	try {
		const connected = await exchangeInstagramCode(code);
		await saveInstagramConnection({
			userId: user.id,
			...connected
		});
	} catch (err) {
		return fail$1(err instanceof Error ? err.message : "Instagram connect fail.");
	}
	return new Response(null, {
		status: 302,
		headers: {
			location: "https://localhost:8080/instagram?ig=connected",
			"set-cookie": "ig_oauth_state=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0",
			"cache-control": "no-store"
		}
	});
} } } });
var Route$2 = createFileRoute("/api/meta/start")({ server: { handlers: { GET: async () => {
	if (!await getSessionUser()) return Response.redirect(new URL("/login", "https://localhost:8080"), 302);
	const state = crypto.randomUUID();
	let location;
	try {
		location = instagramAuthorizeUrl(state);
	} catch (err) {
		const reason = err instanceof Error ? err.message : "Instagram app id missing";
		return Response.redirect(`https://localhost:8080/instagram?ig=error&reason=${encodeURIComponent(reason)}`, 302);
	}
	return new Response(null, {
		status: 302,
		headers: {
			location,
			"set-cookie": `ig_oauth_state=${state}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=600`,
			"cache-control": "no-store"
		}
	});
} } } });
var SCOPES = "user.info.basic,video.list";
function clientKey() {
	const key = process.env.TIKTOK_CLIENT_KEY?.trim();
	if (!key) throw new Error("TIKTOK_CLIENT_KEY .env mein nahi hai.");
	return key;
}
function clientSecret() {
	const secret = process.env.TIKTOK_CLIENT_SECRET?.trim();
	if (!secret) throw new Error("TIKTOK_CLIENT_SECRET .env mein nahi hai.");
	return secret;
}
function tiktokRedirect() {
	const uri = process.env.TIKTOK_REDIRECT_URI?.trim();
	if (!uri) throw new Error("TIKTOK_REDIRECT_URI .env mein nahi hai.");
	return uri;
}
function tiktokAuthorizeUrl(state) {
	const url = new URL("https://www.tiktok.com/v2/auth/authorize/");
	url.searchParams.set("client_key", clientKey());
	url.searchParams.set("redirect_uri", tiktokRedirect());
	url.searchParams.set("response_type", "code");
	url.searchParams.set("scope", SCOPES);
	url.searchParams.set("state", state);
	return url.toString();
}
async function saveTikTokState(state, userId) {
	const sql = await getSql();
	await sql`delete from tiktok_oauth_state where created_at < now() - interval '15 minutes'`;
	await sql`insert into tiktok_oauth_state (state, user_id) values (${state}, ${userId})`;
}
async function takeTikTokState(state) {
	return (await (await getSql())`
    delete from tiktok_oauth_state
    where state = ${state} and created_at > now() - interval '15 minutes'
    returning user_id
  `)[0]?.user_id || "";
}
async function exchangeTikTokCode(code) {
	const form = new URLSearchParams({
		client_key: clientKey(),
		client_secret: clientSecret(),
		code,
		grant_type: "authorization_code",
		redirect_uri: tiktokRedirect()
	});
	const tokenRes = await fetch("https://open.tiktokapis.com/v2/oauth/token/", {
		method: "POST",
		headers: { "content-type": "application/x-www-form-urlencoded" },
		body: form
	});
	const token = await tokenRes.json().catch(() => ({}));
	if (!tokenRes.ok || !token.access_token) throw new Error(token.error_description || token.error || "TikTok token nahi mila.");
	const me = await (await fetch("https://open.tiktokapis.com/v2/user/info/?fields=open_id,display_name", { headers: { authorization: `Bearer ${token.access_token}` } })).json().catch(() => ({}));
	const openId = me.data?.user?.open_id || token.open_id || "";
	return {
		openId,
		username: me.data?.user?.display_name || openId,
		accessToken: token.access_token,
		refreshToken: token.refresh_token || "",
		expiresAt: token.expires_in ? new Date(Date.now() + token.expires_in * 1e3).toISOString() : null
	};
}
async function saveTikTokConnection(input) {
	const sql = await getSql();
	const existing = await sql`
    select id from tiktok_oauth
    where user_id = ${input.userId} and open_id = ${input.openId}
    limit 1
  `;
	if (existing[0]) {
		await sql`
      update tiktok_oauth
      set username = ${input.username},
          access_token = ${input.accessToken},
          refresh_token = ${input.refreshToken},
          expires_at = ${input.expiresAt}
      where id = ${existing[0].id}
    `;
		return existing[0].id;
	}
	const id = crypto.randomUUID();
	await sql`
    insert into tiktok_oauth (id, user_id, open_id, username, access_token, refresh_token, expires_at)
    values (${id}, ${input.userId}, ${input.openId}, ${input.username}, ${input.accessToken}, ${input.refreshToken}, ${input.expiresAt})
  `;
	return id;
}
function fail(reason) {
	return Response.redirect(`https://localhost:8080/detect?tt=error&reason=${encodeURIComponent(reason)}`, 302);
}
var Route$1 = createFileRoute("/api/tiktok/callback")({ server: { handlers: { GET: async ({ request }) => {
	const url = new URL(request.url);
	const denied = url.searchParams.get("error_description") || url.searchParams.get("error");
	if (denied) return fail(denied);
	const code = url.searchParams.get("code") || "";
	const state = url.searchParams.get("state") || "";
	if (!code || !state) return fail("TikTok ne code nahi diya. Connect dubara dabao.");
	const userId = await takeTikTokState(state);
	if (!userId) return fail("Login state match nahi hua. Panel pe login karke Connect dubara dabao.");
	try {
		await saveTikTokConnection({
			userId,
			...await exchangeTikTokCode(code)
		});
	} catch (err) {
		return fail(err instanceof Error ? err.message : "TikTok connect fail.");
	}
	return Response.redirect("https://localhost:8080/tiktok?tt=connected", 302);
} } } });
var Route = createFileRoute("/api/tiktok/start")({ server: { handlers: { GET: async () => {
	const user = await getSessionUser();
	if (!user) return Response.redirect("https://localhost:8080/login", 302);
	const state = crypto.randomUUID();
	try {
		await saveTikTokState(state, user.id);
		return Response.redirect(tiktokAuthorizeUrl(state), 302);
	} catch (err) {
		const reason = err instanceof Error ? err.message : "TikTok start fail";
		return Response.redirect(`https://localhost:8080/detect?tt=error&reason=${encodeURIComponent(reason)}`, 302);
	}
} } } });
var IndexRoute = Route$28.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$29
});
var ApiAccessRoute = Route$27.update({
	id: "/api-access",
	path: "/api-access",
	getParentRoute: () => Route$29
});
var CatalogRoute = Route$26.update({
	id: "/catalog",
	path: "/catalog",
	getParentRoute: () => Route$29
});
var DashboardRoute = Route$25.update({
	id: "/dashboard",
	path: "/dashboard",
	getParentRoute: () => Route$29
});
var DetectRoute = Route$24.update({
	id: "/detect",
	path: "/detect",
	getParentRoute: () => Route$29
});
var EngagementOrderRoute = Route$23.update({
	id: "/engagement-order",
	path: "/engagement-order",
	getParentRoute: () => Route$29
});
var EngagementOrdersRoute = Route$22.update({
	id: "/engagement-orders",
	path: "/engagement-orders",
	getParentRoute: () => Route$29
});
var InstagramRoute = Route$21.update({
	id: "/instagram",
	path: "/instagram",
	getParentRoute: () => Route$29
});
var LoginRoute = Route$20.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$29
});
var MassRoute = Route$19.update({
	id: "/mass",
	path: "/mass",
	getParentRoute: () => Route$29
});
var OrderRoute = Route$18.update({
	id: "/order",
	path: "/order",
	getParentRoute: () => Route$29
});
var OrdersRoute = Route$17.update({
	id: "/orders",
	path: "/orders",
	getParentRoute: () => Route$29
});
var SettingsRoute = Route$16.update({
	id: "/settings",
	path: "/settings",
	getParentRoute: () => Route$29
});
var SingleOrderRoute = Route$15.update({
	id: "/single-order",
	path: "/single-order",
	getParentRoute: () => Route$29
});
var SupportRoute = Route$14.update({
	id: "/support",
	path: "/support",
	getParentRoute: () => Route$29
});
var TelegramBotRoute = Route$13.update({
	id: "/telegram-bot",
	path: "/telegram-bot",
	getParentRoute: () => Route$29
});
var TiktokRoute = Route$12.update({
	id: "/tiktok",
	path: "/tiktok",
	getParentRoute: () => Route$29
});
var WalletRoute = Route$11.update({
	id: "/wallet",
	path: "/wallet",
	getParentRoute: () => Route$29
});
var AdminCustomersRoute = Route$10.update({
	id: "/admin/customers",
	path: "/admin/customers",
	getParentRoute: () => Route$29
});
var AdminEngagementRoute = Route$9.update({
	id: "/admin/engagement",
	path: "/admin/engagement",
	getParentRoute: () => Route$29
});
var AdminPaymentsRoute = Route$8.update({
	id: "/admin/payments",
	path: "/admin/payments",
	getParentRoute: () => Route$29
});
var AdminServicesRoute = Route$7.update({
	id: "/admin/services",
	path: "/admin/services",
	getParentRoute: () => Route$29
});
var OrdersIdRoute = Route$6.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => OrdersRoute
});
var ApiAuthSplatRoute = Route$5.update({
	id: "/api/auth/$",
	path: "/api/auth/$",
	getParentRoute: () => Route$29
});
var ApiDropsIdRoute = Route$4.update({
	id: "/api/drops/$id",
	path: "/api/drops/$id",
	getParentRoute: () => Route$29
});
var ApiMetaCallbackRoute = Route$3.update({
	id: "/api/meta/callback",
	path: "/api/meta/callback",
	getParentRoute: () => Route$29
});
var ApiMetaStartRoute = Route$2.update({
	id: "/api/meta/start",
	path: "/api/meta/start",
	getParentRoute: () => Route$29
});
var ApiTiktokCallbackRoute = Route$1.update({
	id: "/api/tiktok/callback",
	path: "/api/tiktok/callback",
	getParentRoute: () => Route$29
});
var ApiTiktokStartRoute = Route.update({
	id: "/api/tiktok/start",
	path: "/api/tiktok/start",
	getParentRoute: () => Route$29
});
var OrdersRouteChildren = { OrdersIdRoute };
var rootRouteChildren = {
	IndexRoute,
	ApiAccessRoute,
	CatalogRoute,
	DashboardRoute,
	DetectRoute,
	EngagementOrderRoute,
	EngagementOrdersRoute,
	InstagramRoute,
	LoginRoute,
	MassRoute,
	OrderRoute,
	OrdersRoute: OrdersRoute._addFileChildren(OrdersRouteChildren),
	SettingsRoute,
	SingleOrderRoute,
	SupportRoute,
	TelegramBotRoute,
	TiktokRoute,
	WalletRoute,
	AdminCustomersRoute,
	AdminEngagementRoute,
	AdminPaymentsRoute,
	AdminServicesRoute,
	ApiAuthSplatRoute,
	ApiDropsIdRoute,
	ApiMetaCallbackRoute,
	ApiMetaStartRoute,
	ApiTiktokCallbackRoute,
	ApiTiktokStartRoute
};
var routeTree = Route$29._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { Route$6 as n, router_exports as t };
