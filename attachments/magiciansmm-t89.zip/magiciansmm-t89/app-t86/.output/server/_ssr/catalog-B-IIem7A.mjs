import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { K as getCatalog, et as inr } from "./shell-CfBlaVSk.mjs";
import { t as Authed } from "./gate-DNi4gEUE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalog-B-IIem7A.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Catalog() {
	const [rows, setRows] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		getCatalog().then((catalog) => setRows(catalog.services)).catch(() => setRows([]));
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-[26px] font-bold",
				children: "All Services"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[13px] text-[#64748b]",
				children: "Browse catalog. Prices are on your book. Nothing is bought from a provider."
			}),
			rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "flex items-center justify-between rounded-2xl border border-[#e7eef6] bg-white p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-semibold capitalize",
					children: [
						row.platform,
						" · ",
						row.name
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[12px] text-[#94a3b8]",
					children: [
						"Min ",
						row.min_quantity.toLocaleString("en-IN"),
						" · Max ",
						row.max_quantity.toLocaleString("en-IN")
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-semibold",
					children: [inr(row.price_per_10k_paise), " / 10k"]
				})]
			}, row.id))
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Authed, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Catalog, {}) });
//#endregion
export { SplitComponent as component };
