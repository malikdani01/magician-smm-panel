import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as riskLabel, T as windowHours, c as formatDuration, g as mixDrops, h as mixCurve, n as PROVIDER_MIN, o as autoRuns, r as REAL_BAND, t as DEFAULT_PACE, w as trimPct } from "./organic-DU6S6wDh.mjs";
import { J as Clock, M as Lock, P as Link2, T as RefreshCw, V as Heart, Y as ChartColumn, Z as Calendar, g as Share2, k as MessageCircle, nt as Bookmark, s as Upload, t as Zap, v as Settings2, x as Search } from "../_libs/lucide-react.mjs";
import { Et as submitMassBatch, K as getCatalog, L as completeMassBatch, Q as getWallet, et as inr, ft as panelRates, rt as listMassBatches } from "./shell-CfBlaVSk.mjs";
import { t as Authed } from "./gate-DNi4gEUE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mass-X-A2v4M6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function freshPace() {
	return {
		...DEFAULT_PACE,
		variance: 25
	};
}
var FRAMES = [
	{
		id: "6 hours",
		label: "6 hours",
		hours: 6
	},
	{
		id: "12 hours",
		label: "12 hours",
		hours: 12
	},
	{
		id: "Under 24 hours",
		label: "Under 24 hours",
		hours: 24
	},
	{
		id: "1-3 days",
		label: "1-3 days",
		hours: 72
	},
	{
		id: "7-14 days",
		label: "7-14 days",
		hours: 336
	},
	{
		id: "Custom time",
		label: "Custom time",
		hours: 0
	},
	{
		id: "Custom date",
		label: "Custom date",
		hours: 0
	}
];
var EXTRA_META = [
	{
		key: "likes",
		label: "Likes",
		icon: Heart
	},
	{
		key: "comments",
		label: "Comments",
		icon: MessageCircle
	},
	{
		key: "shares",
		label: "Shares",
		icon: Share2
	},
	{
		key: "saves",
		label: "Saves",
		icon: Bookmark
	},
	{
		key: "reposts",
		label: "Reposts",
		icon: RefreshCw
	}
];
var FLOORS = {
	views: 100,
	likes: 10,
	comments: 10,
	shares: 10,
	saves: 50,
	reposts: 10
};
function blankExtras() {
	return {
		likes: {
			on: true,
			qty: "300",
			pace: freshPace()
		},
		comments: {
			on: true,
			qty: "10",
			pace: freshPace()
		},
		shares: {
			on: true,
			qty: "50",
			pace: freshPace()
		},
		saves: {
			on: true,
			qty: "80",
			pace: freshPace()
		},
		reposts: {
			on: true,
			qty: "80",
			pace: freshPace()
		}
	};
}
function organicAround(base, floor, salt) {
	let hash = 0;
	for (let index = 0; index < salt.length; index += 1) hash = hash * 33 + salt.charCodeAt(index) >>> 0;
	const swing = .97 + hash % 1e3 / 1e3 * .06;
	return Math.max(floor, Math.round((base || floor) * swing));
}
function applyPcts(extras, views, pcts) {
	const next = { ...extras };
	for (const item of EXTRA_META) {
		const qty = Math.max(0, Math.round(Math.max(0, views) * (pcts[item.key] ?? 0) / 100));
		next[item.key] = {
			...extras[item.key],
			qty: String(qty)
		};
	}
	return next;
}
function rollRow(link, viewBase, extraDefaults, preset, mode, pcts) {
	const views = organicAround(Number(viewBase) || 1e4, FLOORS.views, `${link}:views`);
	const source = mode === "exact" && preset === "custom" ? null : preset === "custom" ? pcts : mixCurve(preset, Math.max(Number(viewBase) || views, 100));
	const extras = source ? applyPcts(extraDefaults, views, source) : { ...extraDefaults };
	return {
		link,
		views: String(views),
		viewPace: freshPace(),
		extras
	};
}
function parseLinks(text) {
	const found = [];
	for (const raw of text.split(/\n+/)) {
		const cell = raw.split(/[,;\t]/)[0]?.trim().replace(/^"|"$/g, "") ?? "";
		if (/^https?:\/\//i.test(cell) && !found.includes(cell)) found.push(cell);
	}
	return found;
}
function priceOf(bundle, views, extras, panel) {
	return ["views", ...Object.keys(extras)].reduce((sum, type) => {
		const qty = type === "views" ? views : extras[type];
		if (!qty) return sum;
		const set = panel[type];
		if (set > 0) return sum + Math.max(1, Math.round(qty / 1e3 * set));
		const item = bundle?.items.find((row) => row.engagement_type === type || type === "views" && row.is_base);
		if (!item) return sum;
		const rate = item.price_per_10k_paise || item.price_per_1k_paise * 10;
		return sum + Math.max(1, Math.round(qty * rate / 1e4));
	}, 0);
}
function localStamp(date) {
	const pad = (part) => String(part).padStart(2, "0");
	return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}
function servicePace(row, type) {
	if (type === "views") return row.viewPace ?? freshPace();
	return row.extras[type]?.pace ?? freshPace();
}
function runsForPace(pace, type, quantity) {
	if (pace.runsMode === "manual" && pace.runs >= 1) return Math.floor(pace.runs);
	return autoRuns(Math.max(quantity, 0), type);
}
function hoursForPace(pace, type, quantity, viewsQty) {
	return windowHours(pace, runsForPace(pace, type, quantity), viewsQty);
}
function leadHours(index, count, hours) {
	if (count <= 1) return 0;
	return index / (count - 1) * Math.min(Math.max(hours, 1) * .12, 6);
}
function rowStamp(row, hours, lead) {
	const extras = EXTRA_META.map((item) => {
		const extra = row.extras[item.key];
		const pace = extra.pace ?? freshPace();
		return `${item.key}:${extra.on ? 1 : 0}:${extra.qty}:${pace.window}:${pace.customHours}:${pace.runsMode}:${pace.runs}:${pace.variance}:${pace.peak ? 1 : 0}`;
	}).join(",");
	const viewPace = row.viewPace ?? freshPace();
	return `${viewPace.window}:${viewPace.customHours}:${viewPace.runsMode}:${viewPace.runs}:${viewPace.variance}:${viewPace.peak ? 1 : 0}|${row.views}|${hours}|${lead.toFixed(3)}|${extras}`;
}
function buildDrafts(row, _hours, start) {
	const lines = [];
	const viewQty = Math.floor(Number(row.views) || 0);
	if (viewQty > 0) {
		const pace = servicePace(row, "views");
		lines.push({
			type: "views",
			quantity: viewQty,
			runs: runsForPace(pace, "views", viewQty),
			hours: hoursForPace(pace, "views", viewQty, viewQty),
			variance: pace.variance,
			peak: pace.peak,
			min: FLOORS.views
		});
	}
	for (const item of EXTRA_META) {
		const extra = row.extras[item.key];
		if (!extra.on) continue;
		const qty = Math.floor(Number(extra.qty) || 0);
		if (qty <= 0) continue;
		const pace = extra.pace ?? freshPace();
		lines.push({
			type: item.key,
			quantity: qty,
			runs: runsForPace(pace, item.key, qty),
			hours: hoursForPace(pace, item.key, qty, viewQty),
			variance: pace.variance,
			peak: pace.peak,
			min: FLOORS[item.key]
		});
	}
	return mixDrops(lines, start).map((drop, index) => ({
		key: `${drop.type}-${index}`,
		type: drop.type,
		at: localStamp(drop.at),
		amount: String(drop.amount)
	}));
}
function draftSums(runs) {
	const totals = {};
	for (const run of runs) totals[run.type] = (totals[run.type] || 0) + Math.max(0, Math.floor(Number(run.amount) || 0));
	return totals;
}
function Mass() {
	const [tab, setTab] = (0, import_react.useState)("create");
	const [bundles, setBundles] = (0, import_react.useState)([]);
	const [bundleId, setBundleId] = (0, import_react.useState)("bundle-ig");
	const [name, setName] = (0, import_react.useState)("");
	const [text, setText] = (0, import_react.useState)("");
	const [rows, setRows] = (0, import_react.useState)([]);
	const [views, setViews] = (0, import_react.useState)("10000");
	const [panel, setPanel] = (0, import_react.useState)({});
	const [frame, setFrame] = (0, import_react.useState)("Under 24 hours");
	const [customDate, setCustomDate] = (0, import_react.useState)("");
	const [customHours, setCustomHours] = (0, import_react.useState)("6");
	const [defaults, setDefaults] = (0, import_react.useState)(blankExtras());
	const [mixPreset, setMixPreset] = (0, import_react.useState)("recommended");
	const [qtyMode, setQtyMode] = (0, import_react.useState)("percent");
	const [pcts, setPcts] = (0, import_react.useState)(() => mixCurve("recommended", 1e4));
	const [pctText, setPctText] = (0, import_react.useState)({});
	const pctsRef = (0, import_react.useRef)(pcts);
	pctsRef.current = pcts;
	const [batches, setBatches] = (0, import_react.useState)([]);
	const [query, setQuery] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("all");
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const [balance, setBalance] = (0, import_react.useState)(0);
	const [note, setNote] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	const [plans, setPlans] = (0, import_react.useState)({});
	const [openPlan, setOpenPlan] = (0, import_react.useState)(null);
	const plansRef = (0, import_react.useRef)(plans);
	plansRef.current = plans;
	function loadBatches() {
		listMassBatches().then(setBatches).catch(() => setBatches([]));
		getWallet().then((wallet) => setBalance(wallet.balance_paise)).catch(() => setBalance(0));
	}
	(0, import_react.useEffect)(() => {
		getCatalog().then((catalog) => setBundles(catalog.bundles)).catch(() => setBundles([]));
		loadBatches();
	}, []);
	const platform = bundleId === "bundle-tt" ? "tiktok" : "instagram";
	const bundle = bundles.find((item) => item.platform === platform) ?? bundles.find((item) => item.id === (platform === "tiktok" ? "bundle-tt" : "bundle-ig"));
	const extras = EXTRA_META;
	(0, import_react.useEffect)(() => {
		panelRates({ data: platform }).then(setPanel).catch(() => setPanel({}));
	}, [platform]);
	(0, import_react.useEffect)(() => {
		const base = Math.floor(Number(views) || 0);
		if (qtyMode === "exact" && mixPreset === "custom") return;
		const source = mixPreset === "custom" ? pctsRef.current : mixCurve(mixPreset, Math.max(base, 100));
		if (mixPreset !== "custom") {
			setPcts(source);
			setPctText(Object.fromEntries(EXTRA_META.map((item) => [item.key, trimPct(source[item.key] ?? 0)])));
		}
		setDefaults((current) => applyPcts(current, base, source));
		if (base < FLOORS.views) return;
		setRows((current) => current.map((row) => {
			const nextViews = organicAround(base, FLOORS.views, `${row.link}:views`);
			return {
				...row,
				views: String(nextViews),
				extras: applyPcts(row.extras, nextViews, source)
			};
		}));
	}, [
		views,
		mixPreset,
		qtyMode
	]);
	function onText(next) {
		setText(next);
		const links = parseLinks(next);
		setRows((current) => links.map((link) => current.find((row) => row.link === link) ?? rollRow(link, views, defaults, mixPreset, qtyMode, pctsRef.current)));
	}
	const hours = (0, import_react.useMemo)(() => {
		if (frame === "Custom time") return Math.max(0, Math.round(Number(customHours) || 0));
		if (frame !== "Custom date") return FRAMES.find((item) => item.id === frame)?.hours ?? 24;
		const end = (/* @__PURE__ */ new Date(`${customDate}T23:59:00`)).getTime();
		if (!customDate || Number.isNaN(end)) return 0;
		return Math.max(1, Math.round((end - Date.now()) / 36e5));
	}, [
		frame,
		customDate,
		customHours
	]);
	(0, import_react.useEffect)(() => {
		setPlans((current) => {
			const next = { ...current };
			let changed = false;
			rows.forEach((row, index) => {
				const lead = leadHours(index, rows.length, Math.max(hours, 1));
				const stamp = rowStamp(row, hours, lead);
				if (next[row.link]?.stamp === stamp) return;
				const start = new Date(Date.now() + lead * 3600 * 1e3);
				start.setSeconds(0, 0);
				next[row.link] = {
					stamp,
					runs: buildDrafts(row, Math.max(1, hours - lead), start)
				};
				changed = true;
			});
			for (const link of Object.keys(next)) if (!rows.some((row) => row.link === link)) {
				delete next[link];
				changed = true;
			}
			return changed ? next : current;
		});
	}, [rows, hours]);
	function runsFor(row, index) {
		const lead = leadHours(index, rows.length, Math.max(hours, 1));
		const stamp = rowStamp(row, hours, lead);
		const saved = plans[row.link];
		if (saved?.stamp === stamp) return saved.runs;
		const start = new Date(Date.now() + lead * 3600 * 1e3);
		start.setSeconds(0, 0);
		return buildDrafts(row, Math.max(1, hours - lead), start);
	}
	function patchRun(link, index, key, patch) {
		const row = rows.find((item) => item.link === link);
		if (!row) return;
		const lead = leadHours(index, rows.length, Math.max(hours, 1));
		const stamp = rowStamp(row, hours, lead);
		const runs = (plansRef.current[link]?.stamp === stamp ? plansRef.current[link].runs : runsFor(row, index)).map((item) => item.key === key ? {
			...item,
			...patch
		} : item);
		const sums = draftSums(runs);
		const extrasNext = { ...row.extras };
		for (const item of EXTRA_META) {
			if (!extrasNext[item.key].on) continue;
			const total = sums[item.key] || 0;
			if (total > 0) extrasNext[item.key] = {
				...extrasNext[item.key],
				qty: String(total)
			};
		}
		const nextRow = {
			...row,
			views: sums.views > 0 ? String(sums.views) : row.views,
			extras: extrasNext
		};
		const nextStamp = rowStamp(nextRow, hours, lead);
		setPlans((current) => ({
			...current,
			[link]: {
				stamp: nextStamp,
				runs
			}
		}));
		setRows((current) => current.map((item) => item.link === link ? nextRow : item));
	}
	const total = rows.reduce((sum, row, index) => {
		const sums = draftSums(runsFor(row, index));
		const picked = Object.fromEntries(extras.filter((item) => row.extras[item.key].on).map((item) => [item.key, sums[item.key] || Number(row.extras[item.key].qty) || 0]));
		return sum + priceOf(bundle, sums.views || Number(row.views) || 0, picked, panel);
	}, 0);
	async function submit() {
		if (rows.some((row) => row.views === "" || Number(row.views) < FLOORS.views)) {
			setNote("Views khali hai ya 100 se kam. Below 100 not allowed.");
			return;
		}
		for (const row of rows) {
			for (const item of extras) {
				if (!row.extras[item.key].on) continue;
				const raw = row.extras[item.key].qty;
				if (raw === "") {
					setNote(`${item.label} khali hai. Minimum ${FLOORS[item.key]} allowed hai.`);
					return;
				}
				if (Number(raw) < FLOORS[item.key]) {
					setNote(`Below ${FLOORS[item.key]} not allowed for ${item.label}.`);
					return;
				}
			}
			const runs = runsFor(row, rows.indexOf(row));
			for (const run of runs) {
				const amount = Math.floor(Number(run.amount) || 0);
				const floor = FLOORS[run.type] || 1;
				if (amount < floor) {
					setNote(`${run.type} ka run ${amount} hai. Minimum ${floor} hona chahiye.`);
					return;
				}
				if (!run.at || Number.isNaN(new Date(run.at).getTime())) {
					setNote(`${run.type} ka delivery time sahi nahi hai.`);
					return;
				}
			}
		}
		if (rows.length === 0) {
			setNote("Kam se kam 1 valid link daalo.");
			return;
		}
		if ((frame === "Custom date" || frame === "Custom time") && hours < 1) {
			setNote(frame === "Custom time" ? "Custom time hours mein likho." : "Custom date choose karo.");
			return;
		}
		if (balance < total) {
			setNote("Wallet does not cover this batch. Add credit first.");
			return;
		}
		setPending(true);
		setNote("");
		try {
			const result = await submitMassBatch({ data: {
				bundleId: platform === "tiktok" ? "bundle-tt" : "bundle-ig",
				platform,
				campaignName: name,
				timeframe: frame === "Custom date" ? `Custom · ${customDate}` : frame === "Custom time" ? `Custom · ${hours}h` : frame,
				intervalHours: hours,
				links: rows.map((row, index) => {
					const planned = runsFor(row, index);
					const sums = draftSums(planned);
					return {
						link: row.link,
						views: sums.views || Number(row.views),
						viewRuns: planned.filter((run) => run.type === "views").length || 1,
						extras: Object.fromEntries(extras.filter((item) => row.extras[item.key].on && (sums[item.key] || Number(row.extras[item.key].qty)) > 0).map((item) => [item.key, sums[item.key] || Number(row.extras[item.key].qty)])),
						runs: Object.fromEntries(extras.filter((item) => row.extras[item.key].on && (sums[item.key] || Number(row.extras[item.key].qty)) > 0).map((item) => [item.key, planned.filter((run) => run.type === item.key).length || 1])),
						drops: planned.map((run) => ({
							type: run.type,
							amount: Math.floor(Number(run.amount) || 0),
							at: new Date(run.at).toISOString()
						}))
					};
				})
			} });
			setNote(`${result.placed} placed · ${result.failed} failed · ${inr(result.total_paise)}.`);
			setText("");
			setRows([]);
			setTab("batches");
			loadBatches();
		} catch (err) {
			setNote(err instanceof Error ? err.message : "Batch stopped.");
		} finally {
			setPending(false);
		}
	}
	const shown = batches.filter((batch) => {
		const named = batch.campaign_name.toLowerCase().includes(query.trim().toLowerCase());
		const statusOk = status === "all" || batch.status === status || status === "failed" && batch.status === "partial";
		return named && statusOk;
	});
	const completed = batches.filter((batch) => batch.status === "completed").length;
	const processing = batches.filter((batch) => batch.status === "processing").length;
	const failed = batches.filter((batch) => batch.status === "failed" || batch.status === "partial").length;
	const rate = batches.length ? Math.round(completed / batches.length * 100) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl space-y-4 pb-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 rounded-2xl bg-[#eef3f8] p-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setTab("create"),
				className: `inline-flex h-11 items-center justify-center gap-2 rounded-xl text-[14px] font-semibold ${tab === "create" ? "bg-white shadow-sm" : "text-[#64748b]"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-4" }), " Create"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setTab("batches"),
				className: `inline-flex h-11 items-center justify-center gap-2 rounded-xl text-[14px] font-semibold ${tab === "batches" ? "bg-white shadow-sm" : "text-[#64748b]"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4" }), " Batches"]
			})]
		}), tab === "create" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-3xl border border-[#f3e3c3] bg-[#fffaf3] p-4 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-semibold text-[#1f2937]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mr-1 text-amber-500",
							children: "✦"
						}), " Mass Order — Bulk Engagement"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-[12px] leading-relaxed text-[#64748b]",
						children: "Multiple links ek saath order karo. Paste karo ya CSV/TXT file upload karo, har link customize karo, batch me submit karo aur history me track karo."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-3xl border border-[#e7eef6] bg-white p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center gap-2 font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[#64748b]",
								children: "◎"
							}), " Apna Bundle"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: bundleId,
							onChange: (event) => setBundleId(event.target.value),
							className: "mt-2 h-11 w-full rounded-xl border border-[#e7eef6] bg-[#f3f7fb] px-3 text-[14px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "bundle-ig",
								children: "Instagram"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "bundle-tt",
								children: "TikTok"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-[12px] text-[#94a3b8]",
							children: platform === "tiktok" ? "TikTok select hai. Order Full Engagement APIs ke TikTok views, likes, shares, saves, comments aur reposts se place hoga." : "Instagram select hai. Order Full Engagement APIs ke Instagram views, likes, shares, saves, comments aur reposts se place hoga."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-[11px] font-semibold tracking-[0.14em] text-[#94a3b8]",
							children: "CAMPAIGN NAME (OPTIONAL)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: name,
							onChange: (event) => setName(event.target.value),
							placeholder: "e.g. Diwali Reels Mega Campaign 2026",
							className: "mt-1 h-11 w-full rounded-xl bg-[#e7f0f8] px-3 text-[14px] outline-none"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-3xl border border-[#e7eef6] bg-white p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center gap-2 font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "size-4" }), " Links"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "inline-flex cursor-pointer items-center gap-1 rounded-full border border-[#e7eef6] px-3 py-1 text-[12px] font-semibold",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-3.5" }),
									" Upload CSV / TXT",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "file",
										accept: ".csv,.txt,text/plain",
										className: "hidden",
										onChange: async (event) => {
											const file = event.target.files?.[0];
											if (!file) return;
											onText(`${text}\n${await file.text()}`);
											event.target.value = "";
										}
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: text,
							onChange: (event) => onText(event.target.value),
							placeholder: "Ek line par ek link.\nhttps://instagram.com/p/abc\nhttps://instagram.com/p/xyz\n\nYa CSV upload karo (first column = link).",
							className: "h-36 w-full resize-y rounded-2xl border border-[#e7eef6] p-3 text-[13px] outline-none"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-[12px] text-[#94a3b8]",
							children: [rows.length, " valid link(s)"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-[11px] font-semibold tracking-[0.14em] text-[#94a3b8]",
							children: "DEFAULT BASE QUANTITY (VIEWS)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: views,
								inputMode: "numeric",
								onChange: (event) => setViews(event.target.value.replace(/[^\d]/g, "")),
								className: "h-11 w-full rounded-xl bg-[#e7f0f8] px-3 text-[15px] outline-none"
							})
						}),
						views !== "" && Number(views) < 100 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-[12px] font-semibold text-rose-600",
							children: "Below 100 not allowed"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-[11px] font-semibold tracking-[0.14em] text-[#94a3b8]",
							children: "DEFAULT TIMEFRAME"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: frame,
							onChange: (event) => setFrame(event.target.value),
							className: "mt-1 h-11 w-full rounded-xl border border-[#e7eef6] bg-white px-3",
							children: FRAMES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item.id,
								children: item.label
							}, item.id))
						}),
						frame === "Custom date" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							value: customDate,
							onChange: (event) => setCustomDate(event.target.value),
							className: "mt-2 h-11 w-full rounded-xl bg-[#e7f0f8] px-3"
						}),
						frame === "Custom time" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-2 flex h-11 items-center gap-2 rounded-xl bg-[#e7f0f8] px-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: customHours,
								inputMode: "numeric",
								onChange: (event) => setCustomHours(event.target.value.replace(/[^\d]/g, "")),
								className: "w-full bg-transparent text-[15px] outline-none",
								placeholder: "Hours"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[12px] text-[#64748b]",
								children: "hours"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-[12px] text-[#94a3b8]",
							children: hours > 0 ? `Ek hi delivery time sab services ke liye. ${hours} hours ke andar views, likes, comments, shares, saves aur reposts complete honge.` : "Custom time ya date choose karo. Wahi ek window sab services pe lagegi."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-[11px] font-semibold tracking-[0.14em] text-[#94a3b8]",
							children: "ENGAGEMENT MIX"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 grid grid-cols-2 gap-2",
							children: [[
								["light", "Light"],
								["recommended", "Recommended"],
								["viral", "Viral push"]
							].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setMixPreset(id),
								className: `h-11 rounded-2xl px-2 text-[12px] font-semibold ${mixPreset === id ? "bg-[#111827] text-white" : "bg-[#f3f6fa] text-[#334155]"}`,
								children: [label, id === "recommended" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-1 rounded-full bg-emerald-500 px-1.5 py-0.5 text-[9px] font-bold text-white",
									children: "BEST"
								})]
							}, id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setMixPreset("custom"),
								className: `h-11 rounded-2xl px-2 text-[12px] font-semibold ${mixPreset === "custom" ? "bg-[#111827] text-white" : "bg-[#f3f6fa] text-[#334155]"}`,
								children: "Your own amounts"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									if (mixPreset === "custom" && qtyMode !== "percent") {
										const base = Math.max(1, Number(views) || 1);
										const next = {};
										for (const item of EXTRA_META) next[item.key] = Math.round((Number(defaults[item.key].qty) || 0) / base * 1e5) / 1e3;
										setPcts((current) => ({
											...current,
											...next
										}));
									}
									setQtyMode("percent");
								},
								className: `h-11 rounded-2xl text-[13px] font-semibold ${qtyMode === "percent" ? "bg-[#111827] text-white" : "bg-[#f3f6fa] text-[#334155]"}`,
								children: "% of views"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setQtyMode("exact"),
								className: `h-11 rounded-2xl text-[13px] font-semibold ${qtyMode === "exact" ? "bg-[#111827] text-white" : "bg-[#f3f6fa] text-[#334155]"}`,
								children: "Exact number"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-[12px] text-[#64748b]",
							children: [
								mixPreset === "light" && "Light: a quiet post. Fewer likes and very few comments or shares.",
								mixPreset === "recommended" && "Recommended: the same mix real posts get with this many views.",
								mixPreset === "viral" && "Viral push: about double a normal post, like content that is taking off.",
								mixPreset === "custom" && "Your own amounts. % of views follows the views. Exact number stays as you type it."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-[11px] font-semibold tracking-[0.14em] text-[#94a3b8]",
							children: "DEFAULT EXTRA ENGAGEMENT (OPTIONAL)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 grid grid-cols-1 gap-2",
							children: extras.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: `flex items-center gap-2 rounded-2xl border border-[#eef2f6] px-3 py-2 text-[13px] ${defaults[item.key].on ? "" : "opacity-55"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: defaults[item.key].on,
										onChange: () => {
											const next = !defaults[item.key].on;
											setDefaults((current) => ({
												...current,
												[item.key]: {
													...current[item.key],
													on: next
												}
											}));
											setRows((current) => current.map((entry) => ({
												...entry,
												extras: {
													...entry.extras,
													[item.key]: {
														...entry.extras[item.key],
														on: next
													}
												}
											})));
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-3.5 text-[#64748b]" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex-1",
										children: item.label
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: qtyMode === "percent" ? pctText[item.key] ?? trimPct(pcts[item.key] ?? 0) : defaults[item.key].qty,
										inputMode: qtyMode === "percent" ? "decimal" : "numeric",
										"aria-label": `${item.label} ${qtyMode === "percent" ? "percent" : "quantity"}`,
										onChange: (event) => {
											if (qtyMode === "percent") {
												const raw = event.target.value.replace(/[^\d.]/g, "").replace(/(\..*)\./g, "$1");
												const pct = raw === "" || raw === "." ? 0 : Math.min(100, Number(raw) || 0);
												const nextPcts = {
													...pctsRef.current,
													[item.key]: pct
												};
												setMixPreset("custom");
												setPcts(nextPcts);
												setPctText((current) => ({
													...current,
													[item.key]: raw
												}));
												const base = Math.floor(Number(views) || 0);
												setDefaults((current) => applyPcts(current, base, nextPcts));
												setRows((current) => current.map((entry) => ({
													...entry,
													extras: applyPcts(entry.extras, Math.floor(Number(entry.views) || 0), nextPcts)
												})));
												return;
											}
											const qty = event.target.value.replace(/[^\d]/g, "");
											setMixPreset("custom");
											setDefaults((current) => ({
												...current,
												[item.key]: {
													...current[item.key],
													qty
												}
											}));
											setRows((current) => current.map((entry) => ({
												...entry,
												extras: {
													...entry.extras,
													[item.key]: {
														...entry.extras[item.key],
														qty
													}
												}
											})));
										},
										className: "h-8 w-20 rounded-full bg-[#eef5fb] text-center text-[13px] font-semibold outline-none"
									}),
									qtyMode === "percent" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[11px] font-bold text-[#7c6bff]",
										children: ["% = ", Number(defaults[item.key].qty || 0).toLocaleString("en-IN")]
									}),
									defaults[item.key].on && defaults[item.key].qty !== "" && Number(defaults[item.key].qty) < FLOORS[item.key] && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[11px] font-semibold text-rose-600",
										children: ["min ", FLOORS[item.key]]
									})
								]
							}, item.key))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-[11px] text-[#94a3b8]",
							children: [
								"Upar se tick ya untick karo to har link pe wahi service on ya off ho jayegi. Kisi ek link pe alag se bhi tick ya untick kar sakte ho. Jo service untick hai uska order, quantity aur runs place nahi honge. Light, Recommended ya Viral push pe views badlo to likes, comments, shares, saves aur reposts khud set ho jate hain. Real posts: likes ",
								REAL_BAND.likes,
								", comments ",
								REAL_BAND.comments,
								", shares ",
								REAL_BAND.shares,
								", saves ",
								REAL_BAND.saves,
								"."
							]
						}),
						rows.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 max-h-[70vh] space-y-4 overflow-auto pr-1",
							children: rows.map((row, index) => {
								const planned = runsFor(row, index);
								const patchPace = (type, patch) => {
									setRows((current) => current.map((item) => {
										if (item.link !== row.link) return item;
										if (type === "views") return {
											...item,
											viewPace: {
												...servicePace(item, "views"),
												...patch
											}
										};
										const key = type;
										return {
											...item,
											extras: {
												...item.extras,
												[key]: {
													...item.extras[key],
													pace: {
														...item.extras[key].pace ?? freshPace(),
														...patch
													}
												}
											}
										};
									}));
								};
								const serviceLine = (type, label, qty, on, onQty, onToggle) => {
									const mine = planned.filter((item) => item.type === type);
									const open = openPlan === `${row.link}::${type}`;
									const pace = servicePace(row, type);
									const quantity = Math.floor(Number(qty) || 0);
									const chunk = PROVIDER_MIN[type] ?? FLOORS[type] ?? 10;
									const maxRuns = Math.max(1, Math.floor(quantity / (quantity > chunk ? chunk + 1 : Math.max(1, chunk))));
									const runs = runsForPace(pace, type, quantity);
									const lineHours = hoursForPace(pace, type, quantity, Math.floor(Number(row.views) || quantity || 100));
									const risk = riskLabel(pace.variance);
									const amounts = mine.map((item) => Math.floor(Number(item.amount) || 0));
									const average = amounts.reduce((sum, amount) => sum + amount, 0) / Math.max(1, amounts.length);
									const spreadDown = amounts.length ? Math.max(0, Math.round(average - Math.min(...amounts))) : 0;
									const spreadUp = amounts.length ? Math.max(0, Math.round(Math.max(...amounts) - average)) : 0;
									const manual = pace.runsMode === "manual";
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `rounded-2xl border border-white/10 bg-black/20 px-2 py-2 ${on ? "" : "opacity-45"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1",
												children: [
													onToggle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
														type: "checkbox",
														checked: on,
														onChange: onToggle
													}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-4" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "w-16",
														children: label
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
														value: qty,
														inputMode: "numeric",
														disabled: !on,
														onChange: (event) => onQty(event.target.value.replace(/[^\d]/g, "")),
														className: "h-7 w-20 rounded-lg bg-white text-center"
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												disabled: !on,
												onClick: () => setOpenPlan(open ? null : `${row.link}::${type}`),
												className: "mx-auto mt-2 flex items-center gap-1 text-[11px] font-semibold tracking-wide text-[#94a3b8] disabled:opacity-40",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, { className: "size-3" }),
													" SETTINGS ",
													open ? "▴" : "▾"
												]
											}),
											open && on && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-2 space-y-3 border-t border-white/10 pt-3",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-[11px] font-semibold tracking-wide text-[#94a3b8]",
														children: "DELIVERY TIME"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "flex flex-wrap gap-1.5",
														children: [
															"auto",
															"6h",
															"12h",
															"24h",
															"48h",
															"custom"
														].map((windowId) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => patchPace(type, { window: windowId }),
															className: `rounded-full px-3 py-1 text-[12px] font-semibold ${pace.window === windowId ? "bg-white text-[#111827]" : "bg-white/10 text-white"}`,
															children: windowId === "auto" ? "Auto" : windowId === "custom" ? "Custom" : windowId
														}, windowId))
													}),
													pace.window === "custom" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
														className: "flex items-center gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
															inputMode: "numeric",
															value: pace.customHours || "",
															placeholder: "hours",
															onChange: (event) => {
																const raw = event.target.value.replace(/[^\d]/g, "");
																const next = Number(raw);
																patchPace(type, {
																	window: "custom",
																	customHours: raw === "" ? 0 : Math.min(720, next || 0)
																});
															},
															className: "h-9 w-24 rounded-xl bg-white px-3 text-[14px] font-semibold text-[#0f172a] outline-none"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-[11px] text-[#94a3b8]",
															children: ["hours · ", formatDuration(lineHours)]
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center justify-between",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-[11px] font-semibold tracking-wide text-[#94a3b8]",
															children: "NUMBER OF RUNS"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
															className: "text-[11px] text-[#94a3b8]",
															children: ["max ", maxRuns]
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => patchPace(type, {
																runsMode: "auto",
																runs: 0
															}),
															className: `h-9 rounded-xl px-3 text-[12px] font-semibold ${manual ? "bg-white/10 text-white" : "bg-white text-[#111827]"}`,
															children: "Auto"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
															inputMode: "numeric",
															value: manual ? String(pace.runs || "") : "",
															placeholder: manual ? "runs" : `${runs} runs (auto)`,
															onChange: (event) => {
																const raw = event.target.value.replace(/[^\d]/g, "");
																const next = Number(raw);
																if (raw !== "" && next >= 1) patchPace(type, {
																	runsMode: "manual",
																	runs: Math.min(maxRuns, next)
																});
																else patchPace(type, {
																	runsMode: "manual",
																	runs: 0
																});
															},
															className: "h-9 min-w-0 flex-1 rounded-xl bg-white px-3 font-semibold text-[#0f172a] outline-none placeholder:font-medium placeholder:text-[#94a3b8]"
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center justify-between",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-[11px] font-semibold tracking-wide text-[#94a3b8]",
															children: "RANDOM VARIANCE"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "rounded-full bg-amber-100 px-2 py-0.5 text-[11px] font-bold text-amber-700",
															children: [
																"±",
																pace.variance,
																"%"
															]
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
														type: "range",
														min: 10,
														max: 50,
														value: pace.variance,
														onChange: (event) => patchPace(type, { variance: Number(event.target.value) }),
														className: "w-full accent-amber-500"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: `rounded-2xl border p-3 ${risk.tone === "amber" ? "border-amber-200 bg-amber-50" : risk.tone === "rose" ? "border-rose-200 bg-rose-50" : "border-emerald-200 bg-emerald-50"}`,
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "mb-2 flex items-center justify-between font-semibold text-[#0f172a]",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Detection Risk" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "rounded-full bg-white px-2 py-0.5 text-[11px]",
																	children: risk.label
																})]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "h-2 overflow-hidden rounded-full bg-white",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																	className: `h-full rounded-full ${risk.tone === "rose" ? "bg-rose-500" : risk.tone === "emerald" ? "bg-emerald-500" : "bg-amber-400"}`,
																	style: { width: `${Math.min(100, pace.variance * 1.6)}%` }
																})
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																className: `mt-2 text-[12px] ${risk.tone === "rose" ? "text-rose-700" : risk.tone === "emerald" ? "text-emerald-700" : "text-amber-700"}`,
																children: risk.hint
															})
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center justify-between rounded-2xl bg-white/10 px-3 py-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Per run:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
															"-",
															spreadDown.toLocaleString("en-IN"),
															" to +",
															spreadUp.toLocaleString("en-IN")
														] })]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														onClick: () => patchPace(type, { peak: !pace.peak }),
														className: `flex w-full items-center justify-between rounded-2xl px-3 py-2 text-left ${pace.peak ? "bg-amber-50 text-[#0f172a]" : "bg-white/10"}`,
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
															className: "flex items-center gap-1 text-[12px] font-semibold tracking-wide",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5" }), " PEAK HOURS BOOST"]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-[11px] text-[#94a3b8]",
															children: "More during 6-11 PM IST"
														})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: `relative h-7 w-12 shrink-0 rounded-full ${pace.peak ? "bg-[#3b82f6]" : "bg-[#dbe4ee]"}`,
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-0.5 size-6 rounded-full bg-white shadow ${pace.peak ? "left-5" : "left-0.5"}` })
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "rounded-2xl bg-white/10 p-3",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
																className: "mb-2 flex items-center gap-1 font-semibold",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-4" }), " Schedule Preview"]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "grid grid-cols-3 gap-2 text-center",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-[16px] font-bold",
																		children: mine.length
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-[10px] text-[#94a3b8]",
																		children: "orders"
																	})] }),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-[16px] font-bold",
																		children: formatDuration(lineHours / Math.max(1, runs))
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-[10px] text-[#94a3b8]",
																		children: "interval"
																	})] }),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-[12px] font-bold",
																		children: mine[mine.length - 1]?.at.replace("T", " ") ?? ""
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-[10px] text-[#94a3b8]",
																		children: "finish"
																	})] })
																]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "mt-2 max-h-56 space-y-1 overflow-auto",
																children: mine.map((run, runIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "flex items-center gap-1",
																	children: [
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																			className: "grid size-5 place-items-center rounded-full bg-white text-[10px] font-bold text-[#111827]",
																			children: runIndex + 1
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
																			type: "datetime-local",
																			value: run.at,
																			onChange: (event) => patchRun(row.link, index, run.key, { at: event.target.value }),
																			className: "h-7 min-w-0 flex-1 rounded-lg bg-white px-1 text-[11px] text-[#0f172a]"
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
																			value: run.amount,
																			inputMode: "numeric",
																			onChange: (event) => patchRun(row.link, index, run.key, { amount: event.target.value.replace(/[^\d]/g, "") }),
																			className: "h-7 w-14 rounded-lg bg-white text-center text-[11px] text-[#0f172a]"
																		})
																	]
																}, run.key))
															})
														]
													})
												]
											})
										]
									}, type);
								};
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "overflow-hidden rounded-3xl border border-[#7c6bff]/50 bg-[#120c22] text-[12px] shadow-[0_0_24px_rgba(124,107,255,0.18)]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-2 border-b border-white/10 bg-gradient-to-r from-violet-600/30 to-cyan-500/20 px-3 py-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "rounded-full bg-gradient-to-r from-violet-500 to-cyan-400 px-3 py-1 text-[11px] font-bold tracking-wide text-white",
											children: ["Order ", index + 1]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[11px] font-semibold text-cyan-100",
											children: [planned.length, " runs"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] font-semibold uppercase tracking-[0.14em] text-[#94a3b8]",
												children: "Link"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 truncate rounded-xl border border-white/10 bg-black/20 px-2 py-1.5 font-semibold text-white",
												children: row.link
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mb-2 mt-3 text-[10px] font-semibold uppercase tracking-[0.14em] text-[#94a3b8]",
												children: "Services"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-2 space-y-2",
												children: [
													serviceLine("views", "Views", row.views, true, (next) => setRows((current) => current.map((item) => {
														if (item.link !== row.link) return item;
														const nextViews = Math.floor(Number(next) || 0);
														if (qtyMode === "exact" && mixPreset === "custom") return {
															...item,
															views: next
														};
														const line = mixPreset === "custom" ? pcts : mixCurve(mixPreset, Math.max(Number(views) || nextViews, 100));
														return {
															...item,
															views: next,
															extras: applyPcts(item.extras, nextViews, line)
														};
													}))),
													row.views !== "" && Number(row.views) < 100 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-rose-600",
														children: "Views min 100"
													}),
													extras.map((item) => serviceLine(item.key, item.label, row.extras[item.key].qty, row.extras[item.key].on, (qty) => setRows((current) => current.map((entry) => entry.link === row.link ? {
														...entry,
														extras: {
															...entry.extras,
															[item.key]: {
																...entry.extras[item.key],
																qty
															}
														}
													} : entry)), () => setRows((current) => current.map((entry) => entry.link === row.link ? {
														...entry,
														extras: {
															...entry.extras,
															[item.key]: {
																...entry.extras[item.key],
																on: !entry.extras[item.key].on
															}
														}
													} : entry))))
												]
											})
										]
									})]
								}, row.link);
							})
						})
					]
				}),
				rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex items-center gap-2 rounded-2xl border border-[#f3e3c3] bg-[#fff8e8] px-3 py-3 text-[13px] text-amber-800",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4" }), " Kam se kam 1 valid link daalo."]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-3xl border border-[#e7eef6] bg-white p-4 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[14px] text-[#64748b]",
						children: [
							rows.length,
							" order(s) ready • Total ",
							inr(total)
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: pending || rows.length === 0,
						onClick: submit,
						className: "mt-3 inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-[#5aa2f3] text-[15px] font-semibold text-white disabled:opacity-60",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-4" }),
							" ",
							pending ? "Submitting…" : "Submit All Orders"
						]
					})]
				}),
				note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-center text-[13px] text-[#334155]",
					children: note
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "TOTAL BATCHES",
							value: String(batches.length)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "COMPLETED",
							value: String(completed),
							tone: "text-emerald-500"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "PROCESSING",
							value: String(processing)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "FAILED / PARTIAL",
							value: String(failed),
							tone: "text-rose-500"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "SUCCESS RATE",
							value: `${rate}%`,
							tone: "text-orange-500"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-2 rounded-3xl border border-[#e7eef6] bg-white p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex h-11 items-center gap-2 rounded-xl bg-[#e7f0f8] px-3 text-[#94a3b8]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: query,
								onChange: (event) => setQuery(event.target.value),
								placeholder: "Search by campaign name...",
								className: "w-full bg-transparent text-[14px] text-[#0f172a] outline-none"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: status,
							onChange: (event) => setStatus(event.target.value),
							className: "h-11 w-full rounded-xl border border-[#e7eef6] bg-white px-3 text-[14px]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "all",
									children: "All statuses"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "completed",
									children: "Completed"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "processing",
									children: "Processing"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "failed",
									children: "Failed / partial"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: loadBatches,
							className: "inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-[#e7eef6] text-[14px] font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4" }), " Refresh"]
						})
					]
				}),
				shown.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "grid min-h-40 place-items-center rounded-3xl border border-[#e7eef6] bg-white px-6 py-10 text-center text-[14px] text-[#94a3b8]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "mx-auto mb-3 size-6" }), "No batches yet. Create one from the \"Create\" tab."] })
				}) : shown.map((batch) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-3xl border border-[#e7eef6] bg-white p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setOpenId(openId === batch.id ? null : batch.id),
						className: "w-full text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: batch.campaign_name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[12px] text-[#94a3b8]",
								children: [
									batch.platform,
									" · ",
									batch.timeframe,
									" · ",
									new Date(batch.created_at).toLocaleString("en-IN", {
										month: "short",
										day: "numeric",
										hour: "numeric",
										minute: "2-digit"
									})
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `rounded-full px-2 py-1 text-[11px] font-bold uppercase ${batch.status === "completed" ? "bg-emerald-50 text-emerald-600" : batch.status === "processing" ? "bg-sky-50 text-sky-600" : "bg-rose-50 text-rose-600"}`,
								children: batch.status
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-[13px] text-[#334155]",
							children: [
								batch.placed_count,
								"/",
								batch.link_count,
								" links · ",
								inr(batch.total_paise)
							]
						})]
					}), openId === batch.id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 space-y-2 border-t border-[#eef2f6] pt-3 text-[12px]",
						children: [
							batch.links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl bg-[#f8fafc] px-3 py-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate font-semibold",
										children: link.link
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[#64748b]",
										children: [
											link.order_number ?? "No order",
											" · ",
											link.status,
											" · ",
											inr(link.total_paise)
										]
									}),
									link.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-rose-600",
										children: link.error
									})
								]
							}, link.link)),
							batch.status === "processing" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: async () => {
									await completeMassBatch({ data: batch.id });
									loadBatches();
								},
								className: "h-10 w-full rounded-xl bg-[#111827] text-[13px] font-semibold text-white",
								children: "Mark batch complete"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[#94a3b8]",
								children: "YoYoMedia already has the placed links. Mark complete only updates this desk."
							})
						]
					})]
				}, batch.id))
			]
		})]
	});
}
function Stat({ label, value, tone = "text-[#0f172a]" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-[#e7eef6] bg-white px-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] font-semibold tracking-[0.14em] text-[#94a3b8]",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: `mt-1 text-[28px] font-semibold ${tone}`,
			children: value
		})]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Authed, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mass, {}) });
//#endregion
export { SplitComponent as component };
