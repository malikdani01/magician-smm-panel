import { r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-DY5Pyta6.mjs";
import { z as createSsrRpc } from "./shell-CfBlaVSk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tiktok.functions-nU2h4tOs.js
var listTikTokVideos = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("47df4f76b2a619a11a9900bd3da647ea0d37ab5d21171cec377d5166f7648f24"));
//#endregion
export { listTikTokVideos as t };
