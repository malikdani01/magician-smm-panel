import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as adminSaveServiceLimit, u as adminBindings, w as adminServiceLimit, y as adminSaveBindings } from "./shell-CfBlaVSk.mjs";
import { t as Authed } from "./gate-DNi4gEUE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.engagement-NSNDJ8XO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TYPES = [
	"views",
	"likes",
	"saves",
	"shares",
	"reposts",
	"comments"
];
function EngagementApis() {
	const [rows, setRows] = (0, import_react.useState)([]);
	const [platform, setPlatform] = (0, import_react.useState)("instagram");
	const [note, setNote] = (0, import_react.useState)("");
	const [rateText, setRateText] = (0, import_react.useState)({});
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [activeLimit, setActiveLimit] = (0, import_react.useState)("1");
	(0, import_react.useEffect)(() => {
		adminBindings().then((list) => setRows(list.filter((row) => row.slot !== "single"))).catch((err) => setNote(err instanceof Error ? err.message : "Could not load."));
		adminServiceLimit().then((row) => setActiveLimit(String(row.limit))).catch(() => setActiveLimit("1"));
	}, []);
	function patch(slot, next) {
		setRows((current) => current.map((row) => row.slot === slot ? {
			...row,
			...next
		} : row));
	}
	function setProvider(slot, index, next) {
		setRows((current) => current.map((row) => {
			if (row.slot !== slot) return row;
			const providers = row.providers.length ? [...row.providers] : [{
				api_url: "",
				api_key: ""
			}];
			providers[index] = {
				...providers[index],
				...next
			};
			const first = providers.find((item) => item.api_key.trim()) || providers[0];
			return {
				...row,
				providers,
				api_url: first?.api_url || "",
				api_key: first?.api_key || ""
			};
		}));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-semibold uppercase tracking-[0.18em] text-[#2563eb]",
					children: "Admin"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-[28px] font-bold",
					children: "Full engagement APIs"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[13px] text-[#64748b]",
					children: "Har type ka provider yahan. Panel ka rate bhi yahin set karo — per 1,000. Service provider se aayegi, price tumhari."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2",
				children: ["instagram", "tiktok"].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setPlatform(item),
					className: `h-11 rounded-xl text-[13px] font-bold uppercase ${platform === item ? "bg-[#2563eb] text-white" : "bg-white text-[#334155]"}`,
					children: item
				}, item))
			}),
			TYPES.map((type) => {
				const slot = `${platform}:${type}`;
				const row = rows.find((item) => item.slot === slot);
				if (!row) return null;
				const providers = row.providers.length ? row.providers : [{
					api_url: row.api_url || "",
					api_key: row.api_key || ""
				}];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-[24px] border border-[#e7eef6] bg-white p-4 shadow-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-semibold capitalize",
								children: type
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								role: "switch",
								"aria-checked": row.section_enabled !== false,
								onClick: () => patch(slot, { section_enabled: row.section_enabled === false }),
								className: `relative h-7 w-12 rounded-full ${row.section_enabled === false ? "bg-[#3a335f]" : "bg-violet-500"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-0.5 size-6 rounded-full bg-white shadow ${row.section_enabled === false ? "left-0.5" : "left-5"}` })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `mt-1 text-[11px] font-bold uppercase ${row.section_enabled === false ? "text-rose-400" : "text-emerald-400"}`,
							children: row.section_enabled === false ? "Hidden on Full Engagement" : "Showing on Full Engagement"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid gap-3",
							children: [
								providers.map((provider, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-2 rounded-2xl bg-[#f8fafc] p-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[12px] font-semibold text-[#334155]",
												children: ["API provider ", index + 1]
											}), providers.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => patch(slot, { providers: providers.filter((_, item) => item !== index) }),
												className: "text-[12px] font-semibold text-[#b91c1c]",
												children: "Remove"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: provider.api_url,
											onChange: (event) => setProvider(slot, index, { api_url: event.target.value }),
											placeholder: "Provider API URL",
											className: "h-11 rounded-xl border border-[#e7eef6] bg-white px-3 text-[13px] outline-none"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: provider.api_key,
											onChange: (event) => setProvider(slot, index, { api_key: event.target.value }),
											placeholder: "API key",
											className: "h-11 rounded-xl border border-[#e7eef6] bg-white px-3 text-[13px] outline-none"
										})
									]
								}, `${slot}-${index}`)),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => patch(slot, { providers: [...providers, {
										api_url: "",
										api_key: ""
									}] }),
									className: "h-10 rounded-xl bg-[#f3f6fa] text-[12px] font-bold text-[#1d4ed8]",
									children: "Add another API"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-[12px] font-semibold text-[#334155]",
									children: ["Panel rate per 1,000 (₹)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										inputMode: "decimal",
										value: rateText[slot] ?? (row.price_per_1k_paise ? String(row.price_per_1k_paise / 100) : ""),
										onChange: (event) => {
											const raw = event.target.value.replace(/[^\d.]/g, "").replace(/(\..*)\./g, "$1");
											setRateText((current) => ({
												...current,
												[slot]: raw
											}));
											const rupees = Number(raw);
											patch(slot, { price_per_1k_paise: raw === "" || !Number.isFinite(rupees) ? 0 : Math.round(rupees * 100) });
										},
										placeholder: "e.g. 5",
										className: "mt-1 h-11 w-full rounded-xl border border-[#e7eef6] px-3 text-[13px] outline-none"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[11px] text-[#64748b]",
									children: [
										"1000 ",
										type,
										" ka panel charge. Jo yahan save karoge wahi price chalegi. Khali chhodo to purana bundle rate chalega."
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-[12px] font-semibold text-[#334155]",
									children: ["Minimum quantity", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										inputMode: "numeric",
										value: row.min_quantity ? String(row.min_quantity) : "",
										onChange: (event) => {
											const raw = event.target.value.replace(/[^\d]/g, "");
											patch(slot, { min_quantity: raw === "" ? 0 : Number(raw) });
										},
										className: "mt-1 h-11 w-full rounded-xl border border-[#e7eef6] px-3 text-[13px] outline-none"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-[#94a3b8]",
									children: "Har run ek hi provider pe. Views, likes, shares, saves, reposts alag-alag rotate hote hain. Pehle Non Drop / No Drop / Stable / Guaranteed / Refill. Drop 15% se zyada, Unknown, ya no-refill reject. Sab busy hon to sabse kam remains wale pe, aur uski doosri no-drop service ID pe."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-[#94a3b8]",
									children: "Keywords: Non Drop, No Drop, ND, Zero Drop, Guaranteed, 100% Guaranteed, Permanent, Stable, Instant, Instant Start, Fast Start, 0-5 Minutes Start, Immediate Start, Instant Delivery, High Quality, No Loss, Lifetime Guarantee. Sirf Refill likha ho to Non Drop nahi maana jayega. Reject: Drop %, High Drop, Refill Only, Slow Start, Delayed Start, Gradual Delivery, Drip Feed, Unknown, Unstable, Low Quality, Start 12 Hours, Start 24 Hours. Keyword na mile to same category ki suitable service pe order lagta hai. Pending ya In Progress Service ID skip hoti hai."
								})
							]
						})
					]
				}, slot);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block rounded-2xl border border-[#e7eef6] bg-white p-4 text-[13px] font-semibold text-[#334155]",
				children: [
					"Max active orders per Service ID",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						inputMode: "numeric",
						value: activeLimit,
						onChange: (event) => setActiveLimit(event.target.value.replace(/[^\d]/g, "")),
						className: "mt-2 h-11 w-full rounded-xl border border-[#e7eef6] px-3 text-[13px] outline-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-[11px] font-normal text-[#94a3b8]",
						children: "Default 1. Pending ya In Progress wali Service ID skip hoti hai. Sab busy hon to sabse kam load wali pe order lagta hai. Complete hone ke baad wahi ID dubara chalti hai."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: busy,
				onClick: async () => {
					setBusy(true);
					setNote("");
					try {
						const single = (await adminBindings()).find((row) => row.slot === "single");
						await adminSaveBindings({ data: single ? [...rows, single] : rows });
						await adminSaveServiceLimit({ data: { limit: Math.max(1, Number(activeLimit) || 1) } });
						setNote(`${platform} configuration saved.`);
					} catch (err) {
						setNote(err instanceof Error ? err.message : "Save failed.");
					} finally {
						setBusy(false);
					}
				},
				className: "h-12 w-full rounded-xl bg-[#2563eb] text-[14px] font-bold text-white disabled:opacity-60",
				children: busy ? "Saving…" : `Save ${platform} configuration`
			}),
			note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-[13px] text-[#1e3a8a]",
				children: note
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Authed, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EngagementApis, {}) });
//#endregion
export { SplitComponent as component };
