import { t as __exportAll } from "./rolldown-runtime-D7D4PA-g.mjs";
import { g as mixDrops, u as getSql } from "./organic-DU6S6wDh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/drip.server-C0TUW5wc.js
var drip_server_exports = /* @__PURE__ */ __exportAll({
	armOrder: () => armOrder,
	editDrop: () => editDrop,
	flushDueDrops: () => flushDueDrops,
	listOrderDrops: () => listOrderDrops,
	refillType: () => refillType,
	scheduleFixed: () => scheduleFixed,
	setDropState: () => setDropState,
	setOrderRunState: () => setOrderRunState,
	setTypeState: () => setTypeState,
	startDropWorker: () => startDropWorker
});
var globalWorker = globalThis;
var CORE_TYPES = /* @__PURE__ */ new Set([
	"views",
	"likes",
	"saves",
	"shares",
	"reposts",
	"comments",
	"followers"
]);
function guessKind(text) {
	const name = text.toLowerCase();
	if (/\breposts?\b/.test(name)) return "reposts";
	if (/\b(saves?|favourites?|favorites?)\b/.test(name)) return "saves";
	if (/\bshares?\b/.test(name)) return "shares";
	if (/\bcomments?\b/.test(name)) return "comments";
	if (/\bfollowers?\b/.test(name)) return "followers";
	if (/\blikes?\b/.test(name)) return "likes";
	if (/\bviews?\b/.test(name)) return "views";
	return "views";
}
async function providersFor(platform, kind) {
	const { bindingMap } = await import("./admin.server-B6p1lYbS.mjs").then((n) => n.r);
	const found = [];
	const push = (apiUrl, apiKey) => {
		const key = String(apiKey || "").trim();
		const url = String(apiUrl || "").trim();
		if (!key || !url || found.some((item) => item.apiKey === key)) return;
		found.push({
			apiUrl: url,
			apiKey: key
		});
	};
	try {
		const bindings = await bindingMap();
		const slot = bindings[`${platform}:${kind}`] || (kind === "single" ? bindings.single : void 0);
		for (const item of slot?.providers || []) push(item.api_url, item.api_key);
		push(slot?.api_url, slot?.api_key);
	} catch {}
	return found;
}
async function rememberVideoBase(orderId, link) {
	const sql = await getSql();
	await sql`alter table engagement_orders add column if not exists video_base text`;
	await sql`alter table engagement_orders add column if not exists video_now text`;
	if ((await sql`select video_base from engagement_orders where id = ${orderId} limit 1`)[0]?.video_base) return;
	try {
		const { readVideoCounts } = await import("./video-stats-DmQJiLTY.mjs");
		const counts = await readVideoCounts(link);
		if (!counts) return;
		const packed = JSON.stringify({
			...counts,
			snap: "order"
		});
		await sql`update engagement_orders set video_base = ${packed}, video_now = ${packed} where id = ${orderId}`;
	} catch {}
}
async function videoDelivered(orderId) {
	const row = (await (await getSql())`
    select video_base, video_now from engagement_orders where id = ${orderId} limit 1
  `)[0];
	if (!row?.video_base || !row.video_now) return null;
	const { parseCounts, countKeys } = await import("./video-stats-DmQJiLTY.mjs");
	const base = parseCounts(row.video_base);
	const now = parseCounts(row.video_now);
	if (!base || !now) return null;
	const left = {};
	for (const key of countKeys()) left[key] = Math.max(0, now[key] - base[key]);
	return left;
}
async function attachVideo(rows) {
	if (rows.length === 0) return rows;
	const sql = await getSql();
	await sql`alter table engagement_orders add column if not exists video_base text`;
	await sql`alter table engagement_orders add column if not exists video_now text`;
	const orderId = rows[0].order_id;
	const order = (await sql`
    select link, created_at::text as created_at, video_base, video_now from engagement_orders where id = ${orderId} limit 1
  `)[0];
	if (!order?.link) return rows;
	const { parseCounts, readVideoCounts, countKeys } = await import("./video-stats-DmQJiLTY.mjs");
	let now = parseCounts(order.video_now);
	if (!now || Date.now() - now.at > 4e3) try {
		const fresh = await readVideoCounts(order.link);
		if (fresh) {
			now = fresh;
			await sql`update engagement_orders set video_now = ${JSON.stringify({
				...fresh,
				snap: "order"
			})} where id = ${orderId}`;
		}
	} catch {}
	if (!now) return rows;
	let base = parseCounts(order.video_base);
	let snapped = false;
	try {
		snapped = JSON.parse(order.video_base || "{}").snap === "order";
	} catch {
		snapped = false;
	}
	const opened = new Date(order.created_at || 0).getTime();
	let lateGuess = Boolean(base && !snapped && opened > 0 && base.at - opened > 2e4);
	if (base && !snapped && !lateGuess) {
		const items = await sql`
      select engagement_type, quantity from engagement_order_items where order_id = ${orderId}
    `;
		const ordered = Object.fromEntries(items.map((item) => [item.engagement_type, item.quantity]));
		const start = base;
		lateGuess = countKeys().some((key) => {
			const want = Number(ordered[key] || 0);
			return want > 0 && start[key] === 0 && now[key] > 0 && now[key] < want;
		});
	}
	if (!base || lateGuess) {
		base = {
			...now,
			at: Date.now()
		};
		await sql`update engagement_orders set video_base = ${JSON.stringify({
			...base,
			snap: "order"
		})} where id = ${orderId}`;
	}
	const left = {};
	for (const key of countKeys()) left[key] = Math.max(0, now[key] - base[key]);
	return rows.map((row) => {
		const key = row.engagement_type;
		if (!countKeys().includes(key)) return row;
		const metric = key;
		const videoNow = now[metric];
		if (row.status !== "placed" || left[metric] == null) return {
			...row,
			video_now: videoNow
		};
		const give = Math.min(row.quantity, left[metric]);
		left[metric] -= give;
		return {
			...row,
			sent: give,
			remains: Math.max(0, row.quantity - give),
			pct: row.quantity > 0 ? Math.round(give / row.quantity * 100) : 0,
			video_now: videoNow,
			count_source: "video"
		};
	});
}
async function armOrder(input) {
	const sql = await getSql();
	const { bindingMap } = await import("./admin.server-B6p1lYbS.mjs").then((n) => n.r);
	let bindings = {};
	try {
		bindings = await bindingMap();
	} catch (error) {
		console.error("[drops] bindings", error);
	}
	for (const line of input.lines) {
		const slot = bindings[`${input.platform}:${line.engagement_type}`];
		if (!((slot?.providers || []).some((item) => item.api_key && item.api_url) || Boolean(slot?.api_key && slot?.api_url))) throw new Error("No Provider Available");
	}
	await rememberVideoBase(input.orderId, input.link);
	const custom = (input.drops ?? []).filter((drop) => drop.amount > 0 && input.lines.some((line) => line.engagement_type === drop.type));
	const mixed = custom.length ? custom.map((drop) => ({
		type: drop.type,
		at: new Date(drop.at),
		amount: Math.floor(drop.amount)
	})).filter((drop) => !Number.isNaN(drop.at.getTime()) && drop.amount > 0).sort((a, b) => a.at.getTime() - b.at.getTime()) : mixDrops(input.lines.map((line) => {
		const plan = input.plans[line.engagement_type];
		const binding = bindings[`${input.platform}:${line.engagement_type}`];
		return {
			type: line.engagement_type,
			quantity: line.quantity,
			runs: plan?.runs ?? 4,
			hours: plan?.hours ?? 24,
			curve: plan?.curve,
			variance: plan?.variance ?? 25,
			peak: Boolean(plan?.peak),
			min: binding?.min_quantity || void 0
		};
	}), Number.isNaN(new Date(input.plans[input.lines[0]?.engagement_type || ""]?.start || "").getTime()) ? /* @__PURE__ */ new Date() : new Date(input.plans[input.lines[0]?.engagement_type || ""]?.start || Date.now()));
	const { liftOffMinimum, PROVIDER_MIN } = await import("./organic-DU6S6wDh.mjs").then((n) => n.y).then((n) => n.g);
	const placed = liftOffMinimum(mixed, (type) => bindings[`${input.platform}:${type}`]?.min_quantity || PROVIDER_MIN[type] || 1);
	for (const drop of placed) {
		const binding = bindings[`${input.platform}:${drop.type}`];
		const serviceId = binding?.pick_mode === "random" ? "random" : binding?.service_id || null;
		await sql`
      insert into delivery_drops (
        id, order_id, user_id, platform, link, engagement_type, quantity, place_at, status,
        provider_service_id, api_url, api_key
      ) values (
        ${crypto.randomUUID()}, ${input.orderId}, ${input.userId}, ${input.platform}, ${input.link},
        ${drop.type}, ${drop.amount}, ${drop.at.toISOString()}, 'waiting',
        ${serviceId}, ${binding?.api_url || null}, ${binding?.api_key || null}
      )
    `;
	}
	await flushDueDrops(input.orderId);
}
async function listOrderDrops(userId, orderId) {
	const sql = await getSql();
	const read = () => sql`
    select id, order_id, engagement_type, quantity, place_at::text as place_at, status, provider_order_id, service_label, error
    from delivery_drops
    where user_id = ${userId} and order_id = ${orderId}
    order by place_at asc
  `;
	let rows = await read();
	if (rows.length === 0) {
		await backfillDrops(userId, orderId);
		rows = await read();
	}
	try {
		await flushDueDrops(orderId);
	} catch (error) {
		console.error("[drops] flush on list", error);
	}
	return attachVideo(await attachLive(await read()));
}
async function backfillDrops(userId, orderId) {
	const sql = await getSql();
	if ((await sql`select id from delivery_drops where user_id = ${userId} and order_id = ${orderId} limit 1`).length > 0) return;
	const order = (await sql`
    select platform, link, interval_hours, variance_percent, created_at::text as created_at
    from engagement_orders
    where id = ${orderId} and user_id = ${userId}
  `)[0];
	if (!order) return;
	const created = new Date(order.created_at).getTime();
	if (!Number.isFinite(created) || Date.now() - created > 216e5) return;
	const items = await sql`
    select engagement_type, quantity from engagement_order_items
    where order_id = ${orderId} and user_id = ${userId} and quantity > 0
  `;
	if (items.length === 0) return;
	const plans = {};
	for (const item of items) {
		const chunk = item.engagement_type === "views" ? 100 : item.engagement_type === "saves" ? 50 : 10;
		const runs = Math.max(1, Math.floor(item.quantity / chunk));
		const gap = Math.max(1, Number(order.interval_hours) || 1);
		plans[item.engagement_type] = {
			hours: Math.max(gap, gap * Math.max(runs - 1, 1)),
			runs,
			variance: order.variance_percent ?? 25,
			start: (/* @__PURE__ */ new Date()).toISOString()
		};
	}
	await armOrder({
		userId,
		orderId,
		platform: order.platform,
		link: order.link,
		lines: items,
		plans
	});
}
async function serviceActiveLimit() {
	const sql = await getSql();
	await sql`create table if not exists desk_meta (key text primary key, value text not null default '')`;
	const rows = await sql`select value from desk_meta where key = 'service_active_limit' limit 1`;
	const parsed = Math.floor(Number(rows[0]?.value));
	return Number.isFinite(parsed) && parsed >= 1 ? parsed : 1;
}
async function activeServiceLoads(platform, type) {
	const sql = await getSql();
	await sql`alter table delivery_drops add column if not exists provider_status text`;
	const rows = await sql`
    select api_key, provider_service_id, count(*)::int as n
    from delivery_drops
    where platform = ${platform}
      and engagement_type = ${type}
      and status = 'placed'
      and provider_service_id is not null
      and lower(coalesce(provider_status, 'pending')) not in ('completed', 'complete', 'partial', 'canceled', 'cancelled', 'failed', 'refunded')
    group by api_key, provider_service_id
  `;
	const loads = {};
	for (const row of rows) {
		const key = String(row.api_key || "");
		const service = String(row.provider_service_id || "");
		if (!key || !service) continue;
		loads[`${key}::${service}`] = Number(row.n) || 0;
	}
	return loads;
}
async function pendingLoads(type, providers) {
	const sql = await getSql();
	const { providerOrderStatus, providerPhase, readRemains } = await import("./providers.server-BTYWPfD2.mjs").then((n) => n.i).then((n) => n.r);
	const keys = new Set(providers.map((item) => item.apiKey));
	const rows = await sql`
    select api_key, api_url, provider_order_id, quantity
    from delivery_drops
    where engagement_type = ${type} and status = 'placed' and provider_order_id is not null
    order by place_at desc
    limit 30
  `;
	const loads = {};
	for (const row of rows) {
		const key = String(row.api_key || "");
		if (!key || !keys.has(key) || !row.provider_order_id) continue;
		try {
			const status = await providerOrderStatus(row.provider_order_id, row.api_url || void 0, key);
			const phase = providerPhase(status.status);
			const remains = readRemains(status.status, status.remains);
			const left = phase === "open" || remains == null ? row.quantity : remains;
			loads[key] = (loads[key] || 0) + left;
		} catch {
			loads[key] = (loads[key] || 0) + row.quantity;
		}
	}
	return loads;
}
async function attachLive(rows) {
	if (rows.length === 0) return rows;
	const { providerOrderStatus, providerPhase, readRemains } = await import("./providers.server-BTYWPfD2.mjs").then((n) => n.i).then((n) => n.r);
	const keys = await (await getSql())`
    select id, api_url, api_key from delivery_drops where order_id = ${rows[0].order_id} and status = 'placed'
  `;
	const byId = new Map(keys.map((row) => [row.id, row]));
	return Promise.all(rows.map(async (row) => {
		const meta = byId.get(row.id);
		if (row.status !== "placed" || !meta?.api_key || !row.provider_order_id) return row;
		try {
			const status = await providerOrderStatus(row.provider_order_id, meta.api_url || void 0, meta.api_key);
			const phase = providerPhase(status.status);
			const parsed = readRemains(status.status, status.remains);
			const left = phase === "open" || parsed == null ? row.quantity : Math.max(0, Math.min(row.quantity, parsed));
			const sent = phase === "open" ? 0 : Math.max(0, row.quantity - left);
			const pct = sent == null || row.quantity <= 0 ? null : Math.round(sent / row.quantity * 100);
			return {
				...row,
				sent,
				remains: left,
				pct,
				live_status: status.status,
				start_count: status.startCount || null
			};
		} catch {
			return {
				...row,
				sent: null,
				remains: null,
				pct: null,
				live_status: "pending"
			};
		}
	}));
}
async function flushDueDrops(orderId) {
	const sql = await getSql();
	await sql`
    update delivery_drops
    set status = 'failed', error = ${"gaveup: quantity is below the provider minimum"}
    where status = 'waiting' and coalesce(error, '') ilike '%accepts quantity%'
  `;
	await sql`
    update delivery_drops set status = 'waiting'
    where status = 'placing' and place_at < now() - interval '2 minutes'
      and order_id not in (select id from engagement_orders where status in ('paused', 'cancelled'))
  `;
	await sql`
    update delivery_drops set status = 'waiting', error = 'retry 1: recovered'
    where status = 'failed'
      and place_at > now() - interval '12 hours'
      and coalesce(error, '') not like 'gaveup%'
      and coalesce(error, '') not like 'retry%'
      and order_id not in (select id from engagement_orders where status in ('paused', 'cancelled'))
  `;
	const due = orderId ? await sql`
        select id, order_id, user_id, platform, link, engagement_type, quantity, provider_service_id, api_url, api_key, error
        from delivery_drops
        where status = 'waiting' and place_at <= now() and order_id = ${orderId}
          and order_id not in (select id from engagement_orders where status in ('paused', 'cancelled'))
        order by place_at asc
        limit 30
      ` : await sql`
        select id, order_id, user_id, platform, link, engagement_type, quantity, provider_service_id, api_url, api_key, error
        from delivery_drops
        where status = 'waiting' and place_at <= now()
          and order_id not in (select id from engagement_orders where status in ('paused', 'cancelled'))
        order by place_at asc
        limit 30
      `;
	if (due.length > 0) console.log(`[drops] ${due.length} due${orderId ? ` for ${orderId.slice(0, 8)}` : ""}`);
	else if (orderId) {
		const waiting = await sql`
      select id, order_id, user_id, platform, link, engagement_type, quantity, provider_service_id, api_url, api_key, error, place_at::text as place_at
      from delivery_drops
      where order_id = ${orderId} and status = 'waiting'
        and order_id not in (select id from engagement_orders where status in ('paused', 'cancelled'))
      order by place_at asc
    `;
		const now = Date.now();
		const overdue = waiting.filter((drop) => new Date(drop.place_at || 0).getTime() <= now + 5e3);
		if (overdue.length > 0) {
			console.log(`[drops] ${overdue.length} overdue by clock for ${orderId.slice(0, 8)}`);
			due.push(...overdue);
		} else if (waiting[0]) {
			const mins = Math.round((new Date(waiting[0].place_at || 0).getTime() - now) / 6e4);
			if (mins <= 2) console.log(`[drops] next ${waiting[0].engagement_type} in ${mins}m`);
		}
	}
	const { placeChunk, providerOrderStatus, providerPhase, NO_PROVIDER } = await import("./providers.server-BTYWPfD2.mjs").then((n) => n.i).then((n) => n.r);
	for (const drop of due) {
		if ((await sql`
      update delivery_drops set status = 'placing' where id = ${drop.id} and status = 'waiting' returning id
    `).length === 0) {
			console.log(`[drops] skip ${drop.engagement_type} ${drop.id.slice(0, 8)} — already claimed`);
			continue;
		}
		const open = await sql`
      select provider_order_id, api_url, api_key, quantity, engagement_type
      from delivery_drops
      where order_id = ${drop.order_id}
        and status = 'placed'
        and id <> ${drop.id}
      order by place_at asc
      limit 12
    `;
		const videoLeft = await videoDelivered(drop.order_id);
		let blocked = false;
		for (const prev of open) {
			const kind = prev.engagement_type;
			if (videoLeft && (videoLeft[kind] ?? 0) >= prev.quantity && videoLeft) {
				videoLeft[kind] -= prev.quantity;
				continue;
			}
			if (!prev.provider_order_id || !prev.api_key) {
				blocked = true;
				break;
			}
			try {
				const status = await providerOrderStatus(prev.provider_order_id, prev.api_url || void 0, prev.api_key);
				const phase = providerPhase(status.status);
				await sql`update delivery_drops set provider_status = ${String(status.status || "pending").toLowerCase().slice(0, 40)} where provider_order_id = ${prev.provider_order_id}`;
				if (phase !== "complete" && phase !== "closed") {
					blocked = true;
					break;
				}
			} catch {
				blocked = true;
				break;
			}
		}
		if (blocked) {
			const when = new Date(Date.now() + 6e4).toISOString();
			console.log(`[drops] hold ${drop.engagement_type} ${drop.id.slice(0, 8)} — previous run not 100% delivered`);
			await sql`
        update delivery_drops
        set status = 'waiting', place_at = ${when}, error = ${"hold: previous run is not 100% delivered yet"}
        where id = ${drop.id}
      `;
			continue;
		}
		const caps = await sql`
      select quantity from engagement_order_items
      where order_id = ${drop.order_id} and user_id = ${drop.user_id} and engagement_type = ${drop.engagement_type}
      limit 1
    `;
		if (caps[0]) {
			const used = await sql`
        select coalesce(sum(quantity), 0)::int as qty from delivery_drops
        where order_id = ${drop.order_id} and user_id = ${drop.user_id} and engagement_type = ${drop.engagement_type}
          and status in ('placed', 'placing') and id <> ${drop.id}
      `;
			const room = caps[0].quantity - (used[0]?.qty ?? 0);
			if (room < 1) {
				await sql`update delivery_drops set status = 'cancelled', error = ${"stopped: ordered quantity is already placed"} where id = ${drop.id}`;
				continue;
			}
			if (drop.quantity > room) {
				drop.quantity = room;
				await sql`update delivery_drops set quantity = ${room} where id = ${drop.id}`;
			}
		}
		try {
			const core = CORE_TYPES.has(drop.engagement_type);
			const pinnedId = String(drop.provider_service_id || "");
			const sent = /^\d+$/.test(pinnedId) && Boolean(drop.api_key) && Boolean(drop.api_url) ? await (async () => {
				const { placeExactOnProvider } = await import("./providers.server-BTYWPfD2.mjs").then((n) => n.i).then((n) => n.r);
				const exact = await placeExactOnProvider({
					serviceId: pinnedId,
					link: drop.link,
					quantity: drop.quantity,
					apiUrl: drop.api_url || void 0,
					apiKey: drop.api_key || void 0
				});
				return {
					orderId: exact.orderId,
					serviceId: exact.serviceId,
					label: `#${exact.serviceId}`,
					apiUrl: drop.api_url || "",
					apiKey: drop.api_key || "",
					quantity: drop.quantity
				};
			})() : core ? await (async () => {
				const providers = await providersFor(drop.platform, drop.engagement_type);
				if (providers.length === 0) throw new Error(NO_PROVIDER);
				const history = await sql`
              select api_key, provider_service_id, provider_order_id, api_url, quantity
              from delivery_drops
              where order_id = ${drop.order_id} and engagement_type = ${drop.engagement_type} and status = 'placed'
            `;
				const usedKeys = history.map((row) => String(row.api_key || "")).filter(Boolean);
				const usedServiceIds = {};
				for (const row of history) {
					const key = String(row.api_key || "");
					const service = String(row.provider_service_id || "");
					if (!key || !service) continue;
					usedServiceIds[key] = [...usedServiceIds[key] || [], service];
				}
				const pendingByKey = await pendingLoads(drop.engagement_type, providers);
				const activeByService = await activeServiceLoads(drop.platform, drop.engagement_type);
				const serviceLimit = await serviceActiveLimit();
				return placeChunk({
					platform: drop.platform,
					type: drop.engagement_type,
					link: drop.link,
					quantity: drop.quantity,
					providers,
					usedKeys,
					usedServiceIds,
					pendingByKey,
					activeByService,
					serviceLimit
				});
			})() : await (async () => {
				const kind = guessKind(drop.engagement_type);
				const providers = await providersFor(drop.platform, kind === drop.engagement_type ? kind : "single");
				const pool = providers.length ? providers : await providersFor(drop.platform, "single");
				if (pool.length === 0) throw new Error(NO_PROVIDER);
				console.log(`[drops] single ${kind} x${drop.quantity} searching ${pool.length} APIs`);
				return placeChunk({
					platform: drop.platform,
					type: kind,
					link: drop.link,
					quantity: drop.quantity,
					providers: pool,
					activeByService: await activeServiceLoads(drop.platform, kind),
					serviceLimit: await serviceActiveLimit()
				});
			})();
			await sql`
        update delivery_drops
        set status = 'placed', provider_status = 'pending', provider_order_id = ${sent.orderId}, service_label = ${sent.label}, provider_service_id = ${sent.serviceId}, api_url = ${sent.apiUrl || null}, api_key = ${sent.apiKey || null}, quantity = ${sent.quantity || drop.quantity}, error = null
        where id = ${drop.id}
      `;
			console.log(`[drops] placed ${drop.engagement_type} x${drop.quantity} via #${sent.serviceId} for order ${drop.order_id.slice(0, 8)} → ${sent.orderId}`);
			await sql`
        update engagement_order_items
        set delivered = coalesce((
          select sum(quantity)::int from delivery_drops
          where order_id = ${drop.order_id} and user_id = ${drop.user_id} and engagement_type = ${drop.engagement_type} and status = 'placed'
        ), 0),
            status = 'processing'
        where order_id = ${drop.order_id} and user_id = ${drop.user_id} and engagement_type = ${drop.engagement_type}
      `;
		} catch (error) {
			const message = error instanceof Error ? error.message : "Provider rejected this drop.";
			const permanent = /accepts quantity|no api key|disabled|no provider available|multiples of/i.test(message);
			const attempts = Number((drop.error || "").match(/^retry (\d+)/)?.[1] || 0);
			if (!permanent && attempts < 2) {
				const when = new Date(Date.now() + 12e4).toISOString();
				console.error(`[drops] retry ${attempts + 1} ${drop.engagement_type} x${drop.quantity}: ${message}`);
				await sql`
          update delivery_drops
          set status = 'waiting', place_at = ${when}, error = ${`retry ${attempts + 1}: ${message}`.slice(0, 280)}
          where id = ${drop.id}
        `;
			} else {
				console.error(`[drops] FAIL ${drop.engagement_type} x${drop.quantity}: ${message}`);
				await sql`update delivery_drops set status = 'failed', error = ${`gaveup: ${message}`.slice(0, 280)} where id = ${drop.id}`;
			}
		}
		await refreshOrderStatus(drop.order_id, drop.user_id);
	}
}
async function refreshOrderStatus(orderId, userId) {
	const sql = await getSql();
	const row = (await sql`
    select
      count(*) filter (where status = 'waiting' or status = 'placing')::int as waiting,
      count(*) filter (where status = 'failed')::int as failed,
      count(*) filter (where status = 'placed')::int as placed
    from delivery_drops
    where order_id = ${orderId} and user_id = ${userId}
  `)[0];
	let status = "processing";
	if (row && row.waiting === 0) {
		if (row.failed > 0 && row.placed === 0) status = "failed";
		else {
			const { providerOrderStatus, providerPhase } = await import("./providers.server-BTYWPfD2.mjs").then((n) => n.i).then((n) => n.r);
			const placed = await sql`
        select provider_order_id, api_url, api_key
        from delivery_drops
        where order_id = ${orderId} and user_id = ${userId} and status = 'placed'
      `;
			let open = false;
			for (const drop of placed) {
				if (!drop.provider_order_id || !drop.api_key || !drop.api_url) {
					open = true;
					continue;
				}
				try {
					const live = await providerOrderStatus(drop.provider_order_id, drop.api_url, drop.api_key);
					await sql`update delivery_drops set provider_status = ${String(live.status || "pending").toLowerCase().slice(0, 40)} where provider_order_id = ${drop.provider_order_id}`;
					if (providerPhase(live.status) === "open") open = true;
				} catch {
					open = true;
				}
			}
			if (!open) status = row.failed > 0 ? "partial" : "complete";
		}
	}
	await sql`update engagement_orders set status = ${status} where id = ${orderId} and user_id = ${userId}`;
}
async function scheduleFixed(input) {
	const sql = await getSql();
	const start = Date.now();
	const runs = Math.max(1, Math.min(200, input.runs));
	const gap = Math.max(1, input.intervalMinutes) * 60 * 1e3;
	for (let index = 0; index < runs; index += 1) await sql`
      insert into delivery_drops (
        id, order_id, user_id, platform, link, engagement_type, quantity, place_at, status,
        provider_service_id, api_url, api_key
      ) values (
        ${crypto.randomUUID()}, ${input.orderId}, ${input.userId}, ${input.platform}, ${input.link},
        ${input.engagementType}, ${input.amount}, ${new Date(start + gap * index).toISOString()}, 'waiting',
        ${input.providerServiceId}, ${input.apiUrl}, ${input.apiKey}
      )
    `;
	await flushDueDrops(input.orderId);
}
async function editDrop(userId, id, quantity, placeAt) {
	if ((await (await getSql())`
    update delivery_drops
    set quantity = ${quantity}, place_at = ${placeAt}
    where id = ${id} and user_id = ${userId} and status in ('waiting', 'paused')
    returning id
  `).length === 0) throw new Error("Only a pending run can be edited.");
}
async function setDropState(userId, id, status) {
	if ((await (await getSql())`
    update delivery_drops
    set status = ${status}
    where id = ${id} and user_id = ${userId} and status in ('waiting', 'paused')
    returning id
  `).length === 0) throw new Error("That run is already placed.");
}
async function refundUnused(userId, orderId, type) {
	const sql = await getSql();
	await sql`alter table engagement_order_items add column if not exists refunded_paise integer not null default 0`;
	await sql`alter table engagement_orders add column if not exists refunded_paise integer not null default 0`;
	const items = await sql`
    select id, engagement_type, quantity, price_paise, coalesce(refunded_paise, 0)::int as refunded_paise
    from engagement_order_items
    where user_id = ${userId} and order_id = ${orderId}
  `;
	let total = 0;
	for (const item of items) {
		if (type && item.engagement_type !== type) continue;
		const placed = await sql`
      select coalesce(sum(quantity), 0)::int as qty
      from delivery_drops
      where user_id = ${userId} and order_id = ${orderId} and engagement_type = ${item.engagement_type} and status = 'placed'
    `;
		const usedQty = Math.min(item.quantity, placed[0]?.qty ?? 0);
		const usedPaise = item.quantity > 0 ? Math.round(item.price_paise * usedQty / item.quantity) : item.price_paise;
		const back = Math.max(0, item.price_paise - usedPaise - item.refunded_paise);
		if (back < 1) continue;
		await sql`update engagement_order_items set refunded_paise = coalesce(refunded_paise, 0) + ${back} where id = ${item.id}`;
		total += back;
	}
	if (total < 1) return 0;
	const { creditCustomer } = await import("./admin.server-B6p1lYbS.mjs").then((n) => n.r);
	const label = type ? `${type} cancelled` : "order cancelled";
	await creditCustomer(userId, total, `Refund ${orderId.slice(0, 8)} ${label}. Placed runs were kept.`);
	await sql`update engagement_orders set refunded_paise = coalesce(refunded_paise, 0) + ${total} where id = ${orderId} and user_id = ${userId}`;
	return total;
}
async function setOrderRunState(userId, orderId, status) {
	const sql = await getSql();
	if ((await sql`select id from engagement_orders where id = ${orderId} and user_id = ${userId}`).length === 0) throw new Error("Order not found.");
	if (status === "cancelled") {
		await sql`update engagement_orders set status = 'cancelled' where id = ${orderId} and user_id = ${userId}`;
		await sql`
      update delivery_drops
      set status = 'cancelled', error = ${"cancelled with the full order"}
      where order_id = ${orderId} and user_id = ${userId} and status in ('waiting', 'paused', 'placing')
    `;
		await sql`update engagement_order_items set status = 'cancelled' where order_id = ${orderId} and user_id = ${userId} and status <> 'complete'`;
		const open = await sql`
      select provider_order_id, api_url, api_key
      from delivery_drops
      where order_id = ${orderId} and user_id = ${userId} and status = 'placed' and provider_order_id is not null
    `;
		const { cancelProviderOrder } = await import("./providers.server-BTYWPfD2.mjs").then((n) => n.i).then((n) => n.r);
		for (const row of open) try {
			await cancelProviderOrder(row.provider_order_id, row.api_url || void 0, row.api_key || void 0);
		} catch {}
		await refundUnused(userId, orderId);
		return;
	}
	if (status === "paused") {
		await sql`update engagement_orders set status = 'paused' where id = ${orderId} and user_id = ${userId}`;
		await sql`
      update delivery_drops
      set status = 'paused', error = ${"paused with the full order"}
      where order_id = ${orderId} and user_id = ${userId} and status in ('waiting', 'placing')
    `;
		return;
	}
	await sql`update engagement_orders set status = 'processing' where id = ${orderId} and user_id = ${userId} and status = 'paused'`;
	await sql`
    update delivery_drops
    set status = 'waiting', error = null
    where order_id = ${orderId} and user_id = ${userId} and status = 'paused'
  `;
}
async function setTypeState(userId, orderId, type, status) {
	const sql = await getSql();
	if (status === "cancelled") {
		await sql`
      update delivery_drops
      set status = 'cancelled', error = ${"cancelled"}
      where user_id = ${userId} and order_id = ${orderId} and engagement_type = ${type} and status in ('waiting', 'paused', 'placing')
    `;
		await sql`
      update engagement_order_items
      set status = 'cancelled'
      where user_id = ${userId} and order_id = ${orderId} and engagement_type = ${type}
    `;
		const open = await sql`
      select provider_order_id, api_url, api_key
      from delivery_drops
      where user_id = ${userId} and order_id = ${orderId} and engagement_type = ${type}
        and status = 'placed' and provider_order_id is not null
    `;
		const { cancelProviderOrder } = await import("./providers.server-BTYWPfD2.mjs").then((n) => n.i).then((n) => n.r);
		for (const row of open) try {
			await cancelProviderOrder(row.provider_order_id, row.api_url || void 0, row.api_key || void 0);
		} catch {}
		await refundUnused(userId, orderId, type);
		return;
	}
	await sql`
    update delivery_drops
    set status = ${status}, error = null
    where user_id = ${userId} and order_id = ${orderId} and engagement_type = ${type} and status in ('waiting', 'paused')
  `;
}
async function refillType(userId, orderId, type) {
	const sql = await getSql();
	const target = (await sql`
    select quantity from engagement_order_items
    where user_id = ${userId} and order_id = ${orderId} and engagement_type = ${type}
    limit 1
  `)[0]?.quantity ?? 0;
	const placed = await sql`
    select coalesce(sum(quantity), 0)::int as qty from delivery_drops
    where user_id = ${userId} and order_id = ${orderId} and engagement_type = ${type} and status = 'placed'
  `;
	if (((await sql`
    select count(*)::int as n from delivery_drops
    where user_id = ${userId} and order_id = ${orderId} and engagement_type = ${type} and status in ('waiting', 'paused', 'placing')
  `)[0]?.n ?? 0) > 0) throw new Error("Pending runs are still scheduled for this type.");
	const remaining = target - (placed[0]?.qty ?? 0);
	if (remaining < 1) throw new Error("Nothing left to refill.");
	const sample = (await sql`
    select platform, link, provider_service_id, api_url, api_key
    from delivery_drops
    where user_id = ${userId} and order_id = ${orderId} and engagement_type = ${type}
    order by place_at desc
    limit 1
  `)[0];
	if (!sample) throw new Error("No earlier run to copy.");
	const at = new Date(Date.now() + 6e4).toISOString();
	await sql`
    insert into delivery_drops (
      id, order_id, user_id, platform, link, engagement_type, quantity, place_at, status,
      provider_service_id, api_url, api_key
    ) values (
      ${crypto.randomUUID()}, ${orderId}, ${userId}, ${sample.platform}, ${sample.link}, ${type}, ${remaining}, ${at}, 'waiting',
      ${sample.provider_service_id}, ${sample.api_url}, ${sample.api_key}
    )
  `;
}
function startDropWorker() {
	if (globalWorker.__dropWorker) return;
	console.log("[drops] worker started");
	let ticks = 0;
	globalWorker.__dropWorker = setInterval(() => {
		ticks += 1;
		if (ticks % 12 === 0) console.log("[drops] worker alive");
		flushDueDrops().catch((error) => console.error("[drops]", error));
	}, 5e3);
	flushDueDrops().catch((error) => console.error("[drops]", error));
}
//#endregion
export { listOrderDrops as n, drip_server_exports as t };
