import { r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-DY5Pyta6.mjs";
import { u as getSql } from "./organic-DU6S6wDh.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
import { i as creditCustomer, m as publicGateways } from "./admin.server-B6p1lYbS.mjs";
import { createHmac, randomBytes } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/deposit.functions-D6Zxb2vn.js
var USDT_CONTRACT = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t";
async function sql() {
	const db = await getSql();
	await db`
    create table if not exists wallet_deposits (
      id text primary key,
      user_id text not null,
      gateway text not null,
      amount_paise integer not null,
      pay_amount text not null default '',
      pay_currency text not null default 'INR',
      address text not null default '',
      rate numeric not null default 0,
      reference text not null default '',
      screenshot text not null default '',
      provider_ref text not null default '',
      status text not null default 'open',
      expires_at timestamptz,
      created_at timestamptz not null default now()
    )
  `;
	return db;
}
function depositId() {
	return `DEP${randomBytes(6).toString("hex").toUpperCase()}`;
}
function usdtAddress(gate) {
	const direct = gate.account_number.trim();
	if (/^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(direct)) return direct;
	for (const line of (gate.network || "").split("\n")) {
		const parts = line.split("|").map((part) => part.trim());
		const address = parts[2] || parts[0] || "";
		if (/^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(address)) return address;
	}
	return "";
}
function usdtRate(gate) {
	const fromIfsc = Number(gate.ifsc);
	if (fromIfsc >= 1 && fromIfsc <= 1e4) return fromIfsc;
	const match = `${gate.instructions} ${gate.network}`.match(/(\d+(?:\.\d+)?)/);
	const parsed = Number(match?.[1]);
	if (parsed >= 1 && parsed <= 1e4) return parsed;
	return 90;
}
async function gates() {
	return await publicGateways();
}
async function depositConfig() {
	const rows = await gates();
	const razor = rows.find((row) => row.pay_kind === "razorpay" || row.account_number.startsWith("rzp_"));
	const usdt = rows.find((row) => row.pay_kind === "usdt") || rows.find((row) => row.pay_kind === "crypto" && usdtAddress(row));
	const rate = usdt ? usdtRate(usdt) : 90;
	return {
		razorpay: Boolean(razor?.account_number && razor.instructions.trim()),
		razorMin: razor && razor.pay_currency === "INR" ? razor.min_paise / 100 : 100,
		razorMax: razor ? razor.max_paise / 100 : 1e5,
		usdtAddress: usdt ? usdtAddress(usdt) : "",
		usdtRate: rate,
		usdtMin: usdt?.pay_currency === "USD" ? Math.max(5, usdt.min_paise / 100) : 5,
		usdtMaxInr: usdt ? usdt.max_paise / 100 : 5e5
	};
}
async function listDeposits(userId) {
	const db = await sql();
	await db`update wallet_deposits set status = 'expired' where user_id = ${userId} and status = 'open' and expires_at < now()`;
	return db`
    select id, gateway, amount_paise, pay_amount, pay_currency, address, rate::float as rate, reference, status,
           provider_ref, expires_at::text as expires_at, created_at::text as created_at
    from wallet_deposits
    where user_id = ${userId}
    order by created_at desc
    limit 30
  `;
}
async function openUsdt(userId, inr) {
	const config = await depositConfig();
	if (!config.usdtAddress) throw new Error("Admin ne TRC-20 wallet address save nahi kiya. Payments mein USDT gateway ka account number address hona chahiye.");
	const rupees = Math.round(inr);
	const minInr = Math.round(config.usdtMin * config.usdtRate);
	if (rupees < minInr) throw new Error(`Minimum deposit is $${config.usdtMin} (${minInr} INR).`);
	if (rupees > config.usdtMaxInr) throw new Error("Amount is above the gateway limit.");
	const db = await sql();
	if ((await db`select id from wallet_deposits where user_id = ${userId} and gateway = 'USDT' and status = 'open' limit 1`)[0]) throw new Error("Pehle wala USDT deposit cancel karo, phir naya kholo.");
	const used = await db`select pay_amount from wallet_deposits where address = ${config.usdtAddress} and status = 'open'`;
	const taken = new Set(used.map((row) => row.pay_amount));
	const base = Math.round(rupees / config.usdtRate * 100) / 100;
	let exact = base;
	for (let attempt = 0; attempt < 90; attempt += 1) {
		const cents = 1 + Math.floor(Math.random() * 99);
		const next = Math.round((base + cents / 100) * 100) / 100;
		if (!taken.has(next.toFixed(2))) {
			exact = next;
			break;
		}
	}
	const credit = Math.round(exact * config.usdtRate * 100);
	const id = depositId();
	await db`
    insert into wallet_deposits (id, user_id, gateway, amount_paise, pay_amount, pay_currency, address, rate, status, expires_at)
    values (${id}, ${userId}, 'USDT', ${credit}, ${exact.toFixed(2)}, 'USDT', ${config.usdtAddress}, ${config.usdtRate}, 'open', now() + interval '3 hours')
  `;
	const row = (await listDeposits(userId)).find((item) => item.id === id);
	if (!row) throw new Error("Deposit could not be opened.");
	return row;
}
async function cancelDeposit(userId, id) {
	if (!(await (await sql())`
    update wallet_deposits set status = 'cancelled'
    where id = ${id} and user_id = ${userId} and status = 'open'
    returning id
  `)[0]) throw new Error("This deposit is already closed.");
	return { ok: true };
}
async function attachShot(userId, id, screenshot) {
	if (!screenshot.startsWith("data:image/") || screenshot.length > 7e5) throw new Error("Screenshot is too large.");
	if (!(await (await sql())`
    update wallet_deposits set screenshot = ${screenshot.slice(0, 7e5)}
    where id = ${id} and user_id = ${userId} and status = 'open'
    returning id
  `)[0]) throw new Error("This deposit is already closed.");
	return { ok: true };
}
async function tronTransfers(address) {
	const url = `https://api.trongrid.io/v1/accounts/${address}/transactions/trc20?only_to=true&limit=40&contract_address=${USDT_CONTRACT}`;
	const response = await fetch(url, { headers: { accept: "application/json" } });
	if (!response.ok) throw new Error("TRON network check failed. Thodi der baad Check payment dabao.");
	return (await response.json()).data || [];
}
async function checkUsdt(userId, id, txid = "") {
	const db = await sql();
	const row = (await db`
    select id, user_id, gateway, amount_paise, pay_amount, pay_currency, address, rate::float as rate, reference, status,
           provider_ref, expires_at::text as expires_at, created_at::text as created_at
    from wallet_deposits
    where id = ${id} and user_id = ${userId}
    limit 1
  `)[0];
	if (!row) throw new Error("Deposit not found.");
	if (row.status === "paid") return {
		status: "paid",
		credited: row.amount_paise
	};
	if (row.status !== "open") throw new Error("This deposit is closed.");
	if (row.expires_at && new Date(row.expires_at).getTime() < Date.now()) {
		await db`update wallet_deposits set status = 'expired' where id = ${id} and status = 'open'`;
		throw new Error("This deposit expired. Naya amount choose karke dubara kholo.");
	}
	const transfers = await tronTransfers(row.address);
	const wanted = txid.trim();
	const expected = String(Math.round(Number(row.pay_amount) * 1e6));
	const opened = new Date(row.created_at).getTime() - 12e4;
	const hit = transfers.find((tx) => {
		if ((tx.token_info?.symbol || "USDT") !== "USDT") return false;
		if (tx.to !== row.address) return false;
		if ((tx.block_timestamp || 0) < opened) return false;
		if (wanted) return tx.transaction_id === wanted;
		return tx.value === expected;
	});
	if (!hit?.transaction_id) return {
		status: "waiting",
		message: wanted ? "Ye TXID abhi is address pe nahi mila. Ek minute baad phir check karo." : "Payment abhi chain pe nahi dikha. Exact amount bhejo, phir Check payment dabao."
	};
	if ((await db`select id from wallet_deposits where reference = ${hit.transaction_id} and status = 'paid' limit 1`)[0]) throw new Error("Ye TXID pehle hi credit ho chuka hai.");
	const received = Number(hit.value || 0) / 1e6;
	const credit = wanted ? Math.round(received * Number(row.rate) * 100) : row.amount_paise;
	if (credit < 100) throw new Error("Received amount is too small.");
	if (!(await db`
    update wallet_deposits
    set status = 'paid', reference = ${hit.transaction_id}, amount_paise = ${credit}, pay_amount = ${received.toFixed(2)}
    where id = ${id} and status = 'open'
    returning id
  `)[0]) return {
		status: "paid",
		credited: credit
	};
	await creditCustomer(userId, credit, `USDT deposit ${id}`);
	return {
		status: "paid",
		credited: credit
	};
}
async function startRazorpay(userId, inr) {
	const gate = (await gates()).find((row) => row.pay_kind === "razorpay" || row.account_number.startsWith("rzp_"));
	const key = gate?.account_number.trim() || "";
	const secret = gate?.instructions.trim() || "";
	if (!key.startsWith("rzp_") || secret.length < 8) throw new Error("Admin ne Razorpay Key ID aur Key Secret save nahi kiye. Payments mein account number = Key ID, instructions = Key Secret.");
	const rupees = Math.round(inr);
	const min = Math.max(200, (gate?.min_paise || 2e4) / 100);
	const max = (gate?.max_paise || 1e7) / 100;
	if (rupees < min || rupees > max) throw new Error(`Amount must be between ₹${min} and ₹${max}.`);
	const paise = rupees * 100;
	const id = depositId();
	const response = await fetch("https://api.razorpay.com/v1/orders", {
		method: "POST",
		headers: {
			authorization: `Basic ${Buffer.from(`${key}:${secret}`).toString("base64")}`,
			"content-type": "application/json"
		},
		body: JSON.stringify({
			amount: paise,
			currency: "INR",
			receipt: id,
			notes: { userId }
		})
	});
	const order = await response.json();
	if (!response.ok || !order.id) throw new Error(order.error?.description || "Razorpay order could not be created.");
	await (await sql())`
    insert into wallet_deposits (id, user_id, gateway, amount_paise, pay_amount, pay_currency, provider_ref, status, expires_at)
    values (${id}, ${userId}, 'Razorpay', ${paise}, ${rupees.toFixed(2)}, 'INR', ${order.id}, 'open', now() + interval '30 minutes')
  `;
	return {
		id,
		key,
		orderId: order.id,
		amount: paise,
		currency: "INR"
	};
}
async function confirmRazorpay(userId, id, orderId, paymentId, signature) {
	const secret = (await gates()).find((row) => row.pay_kind === "razorpay" || row.account_number.startsWith("rzp_"))?.instructions.trim() || "";
	if (createHmac("sha256", secret).update(`${orderId}|${paymentId}`).digest("hex") !== signature) throw new Error("Razorpay signature did not match.");
	const row = (await (await sql())`
    update wallet_deposits
    set status = 'paid', reference = ${paymentId.slice(0, 80)}
    where id = ${id} and user_id = ${userId} and provider_ref = ${orderId} and status = 'open'
    returning amount_paise
  `)[0];
	if (!row) return { status: "paid" };
	await creditCustomer(userId, row.amount_paise, `Razorpay ${id}`);
	return {
		status: "paid",
		credited: row.amount_paise
	};
}
var getDepositDesk_createServerFn_handler = createServerRpc({
	id: "b1ae4c1a0b5eff32155b74736bdcf465f5eb0af21e51f2b8da9fe9c653920585",
	name: "getDepositDesk",
	filename: "src/lib/deposit.functions.ts"
}, (opts) => getDepositDesk.__executeServer(opts));
var getDepositDesk = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getDepositDesk_createServerFn_handler, async ({ context }) => ({
	config: await depositConfig(),
	deposits: await listDeposits(context.userId)
}));
var openUsdtDeposit_createServerFn_handler = createServerRpc({
	id: "5b07ee47958fc2c01e82993fafeee2544ec66907245d64d4d2e96230408d3eb1",
	name: "openUsdtDeposit",
	filename: "src/lib/deposit.functions.ts"
}, (opts) => openUsdtDeposit.__executeServer(opts));
var openUsdtDeposit = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const inr = Math.round(Number(input?.inr));
	if (!Number.isFinite(inr) || inr < 1) throw new Error("Enter a valid amount.");
	return { inr };
}).handler(openUsdtDeposit_createServerFn_handler, async ({ context, data }) => openUsdt(context.userId, data.inr));
var cancelWalletDeposit_createServerFn_handler = createServerRpc({
	id: "53a1f822c70843fcbf43cb5342882aaca528b7b58f8724b34754783b0ea201cd",
	name: "cancelWalletDeposit",
	filename: "src/lib/deposit.functions.ts"
}, (opts) => cancelWalletDeposit.__executeServer(opts));
var cancelWalletDeposit = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input?.id) throw new Error("Missing deposit.");
	return { id: String(input.id) };
}).handler(cancelWalletDeposit_createServerFn_handler, async ({ context, data }) => cancelDeposit(context.userId, data.id));
var checkWalletDeposit_createServerFn_handler = createServerRpc({
	id: "9d9811be9e2c367b8d5828ac29403a1e2270d71f4dfa3e6b07b82855f56322d2",
	name: "checkWalletDeposit",
	filename: "src/lib/deposit.functions.ts"
}, (opts) => checkWalletDeposit.__executeServer(opts));
var checkWalletDeposit = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	id: String(input?.id || ""),
	txid: String(input?.txid || "").trim()
})).handler(checkWalletDeposit_createServerFn_handler, async ({ context, data }) => {
	if (!data.id) throw new Error("Missing deposit.");
	return checkUsdt(context.userId, data.id, data.txid);
});
var saveDepositShot_createServerFn_handler = createServerRpc({
	id: "c339e900427b4fe3a45195a7a48c5a81e45af9e0634f40109dab1f3a7064103a",
	name: "saveDepositShot",
	filename: "src/lib/deposit.functions.ts"
}, (opts) => saveDepositShot.__executeServer(opts));
var saveDepositShot = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input?.id) throw new Error("Missing deposit.");
	return {
		id: String(input.id),
		screenshot: String(input.screenshot || "")
	};
}).handler(saveDepositShot_createServerFn_handler, async ({ context, data }) => attachShot(context.userId, data.id, data.screenshot));
var startRazorpayDeposit_createServerFn_handler = createServerRpc({
	id: "491e96f1d6c6d8608f925cbac01db32da2f26a5bdce86bc02ed036b9a75e9333",
	name: "startRazorpayDeposit",
	filename: "src/lib/deposit.functions.ts"
}, (opts) => startRazorpayDeposit.__executeServer(opts));
var startRazorpayDeposit = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const inr = Math.round(Number(input?.inr));
	if (!Number.isFinite(inr) || inr < 1) throw new Error("Enter a valid amount.");
	return { inr };
}).handler(startRazorpayDeposit_createServerFn_handler, async ({ context, data }) => startRazorpay(context.userId, data.inr));
var confirmRazorpayDeposit_createServerFn_handler = createServerRpc({
	id: "5de11bed71183fba67b2af4462a4f13f10799e54a416af658b9baccae3e739b3",
	name: "confirmRazorpayDeposit",
	filename: "src/lib/deposit.functions.ts"
}, (opts) => confirmRazorpayDeposit.__executeServer(opts));
var confirmRazorpayDeposit = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	id: String(input?.id || ""),
	orderId: String(input?.orderId || ""),
	paymentId: String(input?.paymentId || ""),
	signature: String(input?.signature || "")
})).handler(confirmRazorpayDeposit_createServerFn_handler, async ({ context, data }) => confirmRazorpay(context.userId, data.id, data.orderId, data.paymentId, data.signature));
//#endregion
export { cancelWalletDeposit_createServerFn_handler, checkWalletDeposit_createServerFn_handler, confirmRazorpayDeposit_createServerFn_handler, getDepositDesk_createServerFn_handler, openUsdtDeposit_createServerFn_handler, saveDepositShot_createServerFn_handler, startRazorpayDeposit_createServerFn_handler };
