import { r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-DY5Pyta6.mjs";
import { m as listGrowthCatalog, u as getSql } from "./organic-DU6S6wDh.mjs";
import { t as hashPassword$1 } from "./password-VlpK0Xix.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
import { g as requireAdmin } from "./admin.server-B6p1lYbS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/panel.functions-Bj03DTy0.js
async function ensureWallet(userId) {
	const sql = await getSql();
	await sql`
    insert into wallets (user_id, balance_paise)
    values (${userId}, 0)
    on conflict (user_id) do nothing
  `;
	return sql;
}
function moneyLines(items, baseQuantity, enabled, quantities) {
	const lines = [];
	for (const item of items) {
		if (!enabled.has(item.engagement_type)) continue;
		const override = quantities?.[item.engagement_type];
		const raw = typeof override === "number" && Number.isFinite(override) && override > 0 ? override : item.is_base ? baseQuantity : Math.round(baseQuantity * item.ratio_bps / 1e4);
		if (raw <= 0) continue;
		const quantity = Math.min(item.max_quantity, Math.round(raw));
		if (quantity <= 0) continue;
		const rate = item.price_per_10k_paise || item.price_per_1k_paise * 10;
		const price_paise = Math.max(1, Math.round(quantity * rate / 1e4));
		lines.push({
			engagement_type: item.engagement_type,
			service_name: item.name,
			quantity,
			price_paise
		});
	}
	return lines;
}
async function withPanelPrices(platform, lines) {
	const { panelTypeRates } = await import("./admin.server-B6p1lYbS.mjs").then((n) => n.r);
	const rates = await panelTypeRates(platform);
	return lines.map((line) => {
		const paise = rates[line.engagement_type];
		if (!paise) return line;
		return {
			...line,
			price_paise: Math.max(1, Math.round(line.quantity / 1e3 * paise))
		};
	});
}
var catalogMemo = null;
var commentsSeeded = false;
var apiBalances_createServerFn_handler = createServerRpc({
	id: "e091d7d68feb087d52b3ae7f818ddd8e8b3564792db1a04f043e112a00aa0e37",
	name: "apiBalances",
	filename: "src/lib/panel.functions.ts"
}, (opts) => apiBalances.__executeServer(opts));
var apiBalances = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(apiBalances_createServerFn_handler, async ({ context }) => {
	const { deskRole } = await import("./admin.server-B6p1lYbS.mjs").then((n) => n.r);
	if (await deskRole(context.userId) !== "admin") return [];
	const { listApiBalances } = await import("./providers.server-BTYWPfD2.mjs").then((n) => n.i).then((n) => n.r);
	return listApiBalances();
});
var getCatalog_createServerFn_handler = createServerRpc({
	id: "4ec21d13fa60565755ae5acb0c886c85e94db0b0cb0b569120fa094138fd85b5",
	name: "getCatalog",
	filename: "src/lib/panel.functions.ts"
}, (opts) => getCatalog.__executeServer(opts));
var getCatalog = createServerFn({ method: "GET" }).handler(getCatalog_createServerFn_handler, async () => {
	const sql = await getSql();
	if (!commentsSeeded) {
		await sql`
      insert into services (id, platform, engagement_type, name, price_per_1k_paise, min_quantity, max_quantity) values
        ('tt-comments', 'tiktok', 'comments', 'Cue comments', 900, 10, 100000)
      on conflict (id) do nothing
    `;
		await sql`
      insert into bundle_items (id, bundle_id, service_id, engagement_type, ratio_bps, is_base) values
        ('bi-tt-c', 'bundle-tt', 'tt-comments', 'comments', 80, false)
      on conflict (id) do nothing
    `;
		commentsSeeded = true;
		catalogMemo = null;
	}
	if (catalogMemo) return catalogMemo;
	const services = await sql`
    select id, platform, engagement_type, name, price_per_1k_paise, coalesce(price_per_10k_paise, price_per_1k_paise * 10) as price_per_10k_paise, min_quantity, max_quantity
    from services
    order by platform, engagement_type
  `;
	const bundles = await sql`select id, name, platform, tagline from bundles order by name`;
	const items = await sql`
    select
      bi.id,
      bi.bundle_id,
      bi.engagement_type,
      bi.ratio_bps,
      bi.is_base,
      s.id as service_id,
      s.name,
      s.price_per_1k_paise,
      coalesce(s.price_per_10k_paise, s.price_per_1k_paise * 10) as price_per_10k_paise,
      s.min_quantity,
      s.max_quantity
    from bundle_items bi
    join services s on s.id = bi.service_id
    order by bi.is_base desc, bi.engagement_type
  `;
	catalogMemo = {
		services,
		bundles: bundles.map((bundle) => ({
			...bundle,
			items: items.filter((item) => item.bundle_id === bundle.id).map(({ bundle_id: _bundleId, ...item }) => item)
		})),
		providers_connected: 0
	};
	return catalogMemo;
});
var getDashboard_createServerFn_handler = createServerRpc({
	id: "802d2905e75b9f5bd7272b1b69005ed36294d3a93da20afca364091055ddb7a3",
	name: "getDashboard",
	filename: "src/lib/panel.functions.ts"
}, (opts) => getDashboard.__executeServer(opts));
var getDashboard = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getDashboard_createServerFn_handler, async ({ context }) => {
	const sql = await ensureWallet(context.userId);
	const wallet = await sql`
      select balance_paise from wallets where user_id = ${context.userId}
    `;
	const counts = await sql`
      select
        count(*)::int as order_count,
        count(*) filter (where status = 'queued')::int as queued_count,
        coalesce(sum(total_paise), 0)::int as spend_paise
      from engagement_orders
      where user_id = ${context.userId}
    `;
	const recent = await loadOrders(context.userId, 5);
	const days = await sql`
      select to_char(created_at, 'YYYY-MM-DD') as day, coalesce(sum(total_paise), 0)::int as spend_paise
      from engagement_orders
      where user_id = ${context.userId}
      group by 1
      order by 1 asc
      limit 14
    `;
	const row = counts[0];
	return {
		balance_paise: wallet[0]?.balance_paise ?? 0,
		order_count: row?.order_count ?? 0,
		queued_count: row?.queued_count ?? 0,
		spend_paise: row?.spend_paise ?? 0,
		recent,
		days
	};
});
async function loadOrders(userId, limit, orderId) {
	const sql = await getSql();
	await sql`alter table engagement_orders add column if not exists preview_json text`;
	const orders = orderId ? await sql`
        select id, order_number, bundle_id, platform, link, base_quantity, total_paise, status,
               organic, interval_hours, variance_percent, provider_state, preview_json, created_at::text as created_at
        from engagement_orders
        where user_id = ${userId} and id = ${orderId}
      ` : await sql`
        select id, order_number, bundle_id, platform, link, base_quantity, total_paise, status,
               organic, interval_hours, variance_percent, provider_state, preview_json, created_at::text as created_at
        from engagement_orders
        where user_id = ${userId}
        order by created_at desc
        limit ${limit}
      `;
	if (orders.length === 0) return [];
	const items = orderId ? await sql`
        select id, order_id, engagement_type, service_name, quantity, delivered, price_paise, status
        from engagement_order_items
        where user_id = ${userId} and order_id = ${orderId}
        order by engagement_type
      ` : await sql`
        select id, order_id, engagement_type, service_name, quantity, delivered, price_paise, status
        from engagement_order_items
        where user_id = ${userId}
        order by engagement_type
      `;
	return orders.map((order) => ({
		...order,
		organic: Boolean(order.organic),
		items: items.filter((item) => item.order_id === order.id).map(({ order_id: _orderId, ...item }) => item)
	}));
}
var listOrders_createServerFn_handler = createServerRpc({
	id: "425c7b4ca8f20880d0302e9883fb473837e5aa38be46b193cf9259229643e6da",
	name: "listOrders",
	filename: "src/lib/panel.functions.ts"
}, (opts) => listOrders.__executeServer(opts));
var listOrders = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input ?? {}).handler(listOrders_createServerFn_handler, async ({ context }) => loadOrders(context.userId, 50));
var getOrder_createServerFn_handler = createServerRpc({
	id: "689905743bba58c841cddd71186cff995b2f84d19277e97a76db0b2613a3e1e7",
	name: "getOrder",
	filename: "src/lib/panel.functions.ts"
}, (opts) => getOrder.__executeServer(opts));
var getOrder = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const id = typeof input === "string" ? input : String(input?.id || "");
	if (id.length < 8) throw new Error("Missing order.");
	return id;
}).handler(getOrder_createServerFn_handler, async ({ context, data }) => {
	return (await loadOrders(context.userId, 1, data))[0] ?? null;
});
var listOrderDrops_createServerFn_handler = createServerRpc({
	id: "fe8513ef9e9731a88509ee416f381a104bb8ae0f2c80d035051b1134c04d99b9",
	name: "listOrderDrops",
	filename: "src/lib/panel.functions.ts"
}, (opts) => listOrderDrops.__executeServer(opts));
var listOrderDrops = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const id = typeof input === "string" ? input : String(input?.id || "");
	if (id.length < 8) throw new Error("Missing order.");
	return id;
}).handler(listOrderDrops_createServerFn_handler, async ({ context, data }) => {
	const { listOrderDrops: load } = await import("./drip.server-C0TUW5wc.mjs").then((n) => n.t);
	return load(context.userId, data);
});
var editScheduledDrop_createServerFn_handler = createServerRpc({
	id: "6abbbb84f7dd9113e7fa632bc030b5017899f0cbfc2a6b619b08549df22410b0",
	name: "editScheduledDrop",
	filename: "src/lib/panel.functions.ts"
}, (opts) => editScheduledDrop.__executeServer(opts));
var editScheduledDrop = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const quantity = Math.floor(Number(input?.quantity));
	const placeAt = new Date(String(input?.placeAt || ""));
	if (!input?.id || quantity < 1) throw new Error("Enter a quantity.");
	if (Number.isNaN(placeAt.getTime())) throw new Error("Pick a valid time.");
	return {
		id: String(input.id),
		quantity,
		placeAt: placeAt.toISOString()
	};
}).handler(editScheduledDrop_createServerFn_handler, async ({ context, data }) => {
	const { editDrop } = await import("./drip.server-C0TUW5wc.mjs").then((n) => n.t);
	await editDrop(context.userId, data.id, data.quantity, data.placeAt);
	return { ok: true };
});
var refillEngagement_createServerFn_handler = createServerRpc({
	id: "9388d398f63351f24215a9f518a29fb50046b0362f277dc715601b4cb9849d7f",
	name: "refillEngagement",
	filename: "src/lib/panel.functions.ts"
}, (opts) => refillEngagement.__executeServer(opts));
var refillEngagement = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input?.orderId || !input?.type) throw new Error("Missing refill.");
	return {
		orderId: String(input.orderId),
		type: String(input.type)
	};
}).handler(refillEngagement_createServerFn_handler, async ({ context, data }) => {
	const { refillType } = await import("./drip.server-C0TUW5wc.mjs").then((n) => n.t);
	await refillType(context.userId, data.orderId, data.type);
	return { ok: true };
});
var checkDropStatus_createServerFn_handler = createServerRpc({
	id: "2ff1ea60e023368803ebbea6d0a6ab2b49118d2894bf949eec320fa095d27fe8",
	name: "checkDropStatus",
	filename: "src/lib/panel.functions.ts"
}, (opts) => checkDropStatus.__executeServer(opts));
var checkDropStatus = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (!id) throw new Error("Missing run.");
	return String(id);
}).handler(checkDropStatus_createServerFn_handler, async ({ context, data }) => {
	const sql = (await import("./organic-DU6S6wDh.mjs").then((n) => n.y).then((n) => n.C)).getSql;
	const drop = (await (await sql())`
      select provider_order_id, api_url, api_key from delivery_drops
      where id = ${data} and user_id = ${context.userId}
      limit 1
    `)[0];
	if (!drop?.provider_order_id) throw new Error("This run has no provider order yet.");
	const { providerOrderStatus } = await import("./providers.server-BTYWPfD2.mjs").then((n) => n.i).then((n) => n.r);
	return providerOrderStatus(drop.provider_order_id, drop.api_url || void 0, drop.api_key || void 0);
});
var setRunState_createServerFn_handler = createServerRpc({
	id: "1c086f3879843e5526abab4b4f19f6e473e47056a9716df397dda51b5841ca45",
	name: "setRunState",
	filename: "src/lib/panel.functions.ts"
}, (opts) => setRunState.__executeServer(opts));
var setRunState = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (![
		"waiting",
		"paused",
		"cancelled"
	].includes(input?.status)) throw new Error("Bad status.");
	return input;
}).handler(setRunState_createServerFn_handler, async ({ context, data }) => {
	const { setDropState, setTypeState } = await import("./drip.server-C0TUW5wc.mjs").then((n) => n.t);
	if (data.id) await setDropState(context.userId, data.id, data.status);
	else if (data.orderId && data.type) await setTypeState(context.userId, data.orderId, data.type, data.status);
	else throw new Error("Missing run.");
	return { ok: true };
});
var setOrderFlow_createServerFn_handler = createServerRpc({
	id: "c8a8b099c70fc06620b0cb3ff1a0e81e497d9192b1a5d6f3377f01b885a32a85",
	name: "setOrderFlow",
	filename: "src/lib/panel.functions.ts"
}, (opts) => setOrderFlow.__executeServer(opts));
var setOrderFlow = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input?.orderId || ![
		"waiting",
		"paused",
		"cancelled"
	].includes(input?.status)) throw new Error("Bad order action.");
	return input;
}).handler(setOrderFlow_createServerFn_handler, async ({ context, data }) => {
	const { setOrderRunState } = await import("./drip.server-C0TUW5wc.mjs").then((n) => n.t);
	await setOrderRunState(context.userId, data.orderId, data.status);
	return { ok: true };
});
var getWallet_createServerFn_handler = createServerRpc({
	id: "8507b8b1877b689bad2f7200dd2b5c6c424f63a35db7d7d280b5d6866b5139b5",
	name: "getWallet",
	filename: "src/lib/panel.functions.ts"
}, (opts) => getWallet.__executeServer(opts));
var getWallet = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getWallet_createServerFn_handler, async ({ context }) => {
	const sql = await ensureWallet(context.userId);
	const wallet = await sql`
      select balance_paise from wallets where user_id = ${context.userId}
    `;
	const transactions = await sql`
      select id, kind, amount_paise, note, created_at::text as created_at
      from wallet_transactions
      where user_id = ${context.userId}
      order by created_at desc
      limit 40
    `;
	return {
		balance_paise: wallet[0]?.balance_paise ?? 0,
		transactions
	};
});
var TOPUPS_MIN = 1e4;
var TOPUPS_MAX = 5e7;
var creditWallet_createServerFn_handler = createServerRpc({
	id: "fe298e400f147ebc637abd9013a1e42b7d6b8fd56f13b658cc8ef186d3146b40",
	name: "creditWallet",
	filename: "src/lib/panel.functions.ts"
}, (opts) => creditWallet.__executeServer(opts));
var creditWallet = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((amountPaise) => {
	const amount = Math.floor(Number(amountPaise));
	if (!Number.isFinite(amount) || amount < TOPUPS_MIN || amount > TOPUPS_MAX) throw new Error("Amount must be between ₹100 and ₹5,00,000.");
	return amount;
}).handler(creditWallet_createServerFn_handler, async ({ context, data }) => {
	const sql = await ensureWallet(context.userId);
	const id = crypto.randomUUID();
	await sql`
      update wallets
      set balance_paise = balance_paise + ${data}, updated_at = now()
      where user_id = ${context.userId}
    `;
	await sql`
      insert into wallet_transactions (id, user_id, kind, amount_paise, note)
      values (
        ${id},
        ${context.userId},
        'credit',
        ${data},
        'UPI desk credit. No payment gateway is connected — balance is on your ledger.'
      )
    `;
	return { balance_paise: (await sql`
      select balance_paise from wallets where user_id = ${context.userId}
    `)[0]?.balance_paise ?? 0 };
});
var placeOrder_createServerFn_handler = createServerRpc({
	id: "568cbd336ac8c7208a2f719fcddda15fe5ece9f7dbc8489da0b4a37f54f35bf5",
	name: "placeOrder",
	filename: "src/lib/panel.functions.ts"
}, (opts) => placeOrder.__executeServer(opts));
var placeOrder = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const link = String(input?.link ?? "").trim();
	let parsed;
	try {
		parsed = new URL(link);
	} catch {
		throw new Error("Paste a full link, including https://.");
	}
	if (parsed.protocol !== "https:" && parsed.protocol !== "http:") throw new Error("The link needs to start with http or https.");
	const baseQuantity = Math.floor(Number(input.baseQuantity));
	const enabledTypes = Array.isArray(input.enabledTypes) ? input.enabledTypes.filter((type) => typeof type === "string") : [];
	const viewsOn = enabledTypes.includes("views");
	if (!Number.isFinite(baseQuantity) || baseQuantity < 0 || baseQuantity > 1e7 || viewsOn && baseQuantity < 100) throw new Error(viewsOn ? "Views quantity must be between 100 and 10,000,000." : "Turn on at least one service.");
	const quantities = {};
	if (input.quantities && typeof input.quantities === "object") for (const [type, value] of Object.entries(input.quantities)) {
		const quantity = Math.floor(Number(value));
		if (Number.isFinite(quantity) && quantity > 0 && quantity <= 5e7) quantities[type] = quantity;
	}
	const delivery = {};
	if (input.delivery && typeof input.delivery === "object") for (const [type, value] of Object.entries(input.delivery)) {
		const hours = Number(value?.hours);
		const runs = Math.floor(Number(value?.runs));
		if (!Number.isFinite(hours) || hours <= 0 || !Number.isFinite(runs) || runs <= 0) continue;
		const curve = Array.isArray(value.curve) ? value.curve.map(Number).filter((point) => Number.isFinite(point)).slice(0, 12) : [];
		delivery[type] = {
			hours: Math.min(720, hours),
			runs: Math.min(500, runs),
			variance: Math.min(50, Math.max(0, Math.floor(Number(value.variance) || 0))),
			peak: Boolean(value.peak),
			curve
		};
	}
	const drops = [];
	if (Array.isArray(input.drops)) for (const drop of input.drops.slice(0, 800)) {
		const type = String(drop?.type ?? "");
		const amount = Math.floor(Number(drop?.amount));
		const at = new Date(String(drop?.at ?? ""));
		if (!type || !Number.isFinite(amount) || amount <= 0 || amount > 5e7 || Number.isNaN(at.getTime())) continue;
		drops.push({
			type,
			amount,
			at: at.toISOString()
		});
	}
	return {
		bundleId: String(input.bundleId ?? ""),
		link,
		baseQuantity,
		organic: Boolean(input.organic),
		intervalHours: Math.min(720, Math.max(1, Math.floor(Number(input.intervalHours) || 1))),
		variancePercent: Math.min(50, Math.max(0, Math.floor(Number(input.variancePercent) || 0))),
		enabledTypes,
		quantities,
		delivery,
		drops
	};
}).handler(placeOrder_createServerFn_handler, async ({ context, data }) => {
	const sql = await ensureWallet(context.userId);
	const items = await sql`
      select
        bi.engagement_type,
        bi.ratio_bps,
        bi.is_base,
        s.name,
        s.price_per_1k_paise,
        coalesce(s.price_per_10k_paise, s.price_per_1k_paise * 10) as price_per_10k_paise,
        s.min_quantity,
        s.max_quantity,
        b.platform
      from bundle_items bi
      join services s on s.id = bi.service_id
      join bundles b on b.id = bi.bundle_id
      where bi.bundle_id = ${data.bundleId}
    `;
	if (items.length === 0) throw new Error("That cue set is not on the book.");
	const platform = items[0]?.platform ?? "instagram";
	const { bindingMap } = await import("./admin.server-B6p1lYbS.mjs").then((n) => n.r);
	const { PROVIDER_MIN } = await import("./organic-DU6S6wDh.mjs").then((n) => n.y).then((n) => n.g);
	const bindings = await bindingMap();
	const dropSums = {};
	for (const drop of data.drops) {
		const min = bindings[`${platform}:${drop.type}`]?.min_quantity || PROVIDER_MIN[drop.type] || 1;
		if (drop.amount < min) throw new Error(`Below ${min} not allowed for ${drop.type}.`);
		dropSums[drop.type] = (dropSums[drop.type] || 0) + drop.amount;
	}
	const quantities = data.drops.length ? dropSums : data.quantities;
	const enabled = new Set(data.drops.length ? Object.keys(dropSums) : data.enabledTypes);
	const lines = await withPanelPrices(platform, moneyLines(items, data.baseQuantity, enabled, quantities).map((line) => {
		const slot = bindings[`${platform}:${line.engagement_type}`];
		if (slot && slot.section_enabled === false) throw new Error(`${line.engagement_type} is turned off for this platform.`);
		const min = slot?.min_quantity || PROVIDER_MIN[line.engagement_type] || 1;
		if (line.quantity < min) throw new Error(`Below ${min} not allowed for ${line.engagement_type}.`);
		return line;
	}));
	if (lines.length === 0) throw new Error("Turn on at least one service.");
	for (const line of lines) {
		const slot = bindings[`${platform}:${line.engagement_type}`];
		if (!((slot?.providers || []).some((item) => item.api_key && item.api_url) || Boolean(slot?.api_key && slot?.api_url))) throw new Error("No Provider Available");
	}
	const total = lines.reduce((sum, line) => sum + line.price_paise, 0);
	if (((await sql`
      select balance_paise from wallets where user_id = ${context.userId}
    `)[0]?.balance_paise ?? 0) < total) throw new Error("The wallet does not cover this order. Add credit first.");
	const { askFreeModel } = await import("./providers.server-BTYWPfD2.mjs").then((n) => n.i).then((n) => n.r);
	const { armOrder } = await import("./drip.server-C0TUW5wc.mjs").then((n) => n.t);
	const orderId = crypto.randomUUID();
	const orderNumber = `MAG-${Math.floor(1e5 + Math.random() * 9e5)}`;
	if ((await sql`
      update wallets
      set balance_paise = balance_paise - ${total}, updated_at = now()
      where user_id = ${context.userId} and balance_paise >= ${total}
      returning user_id
    `).length === 0) throw new Error("The wallet does not cover this order. Add credit first.");
	await sql`alter table engagement_orders add column if not exists preview_json text`;
	await sql`
      insert into engagement_orders (
        id, user_id, order_number, bundle_id, platform, link, base_quantity, total_paise,
        status, organic, interval_hours, variance_percent, provider_state, preview_json
      ) values (
        ${orderId}, ${context.userId}, ${orderNumber}, ${data.bundleId}, ${platform}, ${data.link},
        ${data.baseQuantity}, ${total}, 'queued', ${data.organic}, ${data.intervalHours},
        ${data.variancePercent}, 'provider', ${JSON.stringify({
		quantities: data.quantities,
		delivery: data.delivery
	})}
      )
    `;
	for (const line of lines) await sql`
        insert into engagement_order_items (
          id, order_id, user_id, engagement_type, service_name, quantity, delivered, price_paise, status
        ) values (
          ${crypto.randomUUID()}, ${orderId}, ${context.userId}, ${line.engagement_type},
          ${line.service_name}, ${line.quantity}, 0, ${line.price_paise}, 'queued'
        )
      `;
	await armOrder({
		userId: context.userId,
		orderId,
		platform,
		link: data.link,
		lines: lines.map((line) => ({
			engagement_type: line.engagement_type,
			quantity: line.quantity
		})),
		plans: data.delivery ?? {},
		drops: data.drops
	});
	await sql`
      insert into wallet_transactions (id, user_id, kind, amount_paise, note)
      values (
        ${crypto.randomUUID()},
        ${context.userId},
        'debit',
        ${-total},
        ${`Cue ${orderNumber} queued in timed drops.`}
      )
    `;
	if (data.organic) try {
		const aiNote = await askFreeModel("You plan organic social delivery. One short sentence only.", `Platform ${platform}. Quantities: ${lines.map((line) => `${line.engagement_type} ${line.quantity}`).join(", ")}.`);
		if (aiNote) await sql`
            insert into wallet_transactions (id, user_id, kind, amount_paise, note)
            values (${crypto.randomUUID()}, ${context.userId}, 'note', 0, ${aiNote.slice(0, 280)})
          `;
	} catch {}
	return {
		id: orderId,
		order_number: orderNumber,
		total_paise: total
	};
});
var simulateDelivery_createServerFn_handler = createServerRpc({
	id: "c2dccedbed6acbda54546c95947b7f40edd841c845ac4fbe771544e934873d72",
	name: "simulateDelivery",
	filename: "src/lib/panel.functions.ts"
}, (opts) => simulateDelivery.__executeServer(opts));
var simulateDelivery = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (typeof id !== "string" || id.length < 8) throw new Error("Missing order.");
	return id;
}).handler(simulateDelivery_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	if ((await sql`
      update engagement_orders
      set status = 'complete'
      where id = ${data} and user_id = ${context.userId} and status = 'queued'
      returning id
    `).length === 0) throw new Error("That cue is not waiting.");
	await sql`
      update engagement_order_items
      set delivered = quantity, status = 'complete'
      where order_id = ${data} and user_id = ${context.userId}
    `;
	return { ok: true };
});
var listTickets_createServerFn_handler = createServerRpc({
	id: "53f8f7504e89ee6fcf5370296775e69d457b024b7850f178d85275d77c13d752",
	name: "listTickets",
	filename: "src/lib/panel.functions.ts"
}, (opts) => listTickets.__executeServer(opts));
var listTickets = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listTickets_createServerFn_handler, async ({ context }) => {
	return (await getSql())`
      select id, subject, body, created_at::text as created_at
      from support_tickets
      where user_id = ${context.userId}
      order by created_at desc
      limit 20
    `;
});
var openTicket_createServerFn_handler = createServerRpc({
	id: "eca33ce65d3c798ea431e095459370949a483f7098b8c9cbfa0c02e1b94b2432",
	name: "openTicket",
	filename: "src/lib/panel.functions.ts"
}, (opts) => openTicket.__executeServer(opts));
var openTicket = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const subject = String(input?.subject ?? "").trim().slice(0, 120);
	const body = String(input?.body ?? "").trim().slice(0, 2e3);
	if (subject.length < 3 || body.length < 8) throw new Error("Write a subject and a short note.");
	return {
		subject,
		body
	};
}).handler(openTicket_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const id = crypto.randomUUID();
	await sql`
      insert into support_tickets (id, user_id, subject, body)
      values (${id}, ${context.userId}, ${data.subject}, ${data.body})
    `;
	return { id };
});
async function ensurePrefs(userId) {
	const sql = await getSql();
	await sql`alter table user_prefs add column if not exists avatar_url text`;
	await sql`alter table user_prefs add column if not exists display_currency text`;
	await sql`insert into user_prefs (user_id) values (${userId}) on conflict (user_id) do nothing`;
	return sql;
}
var getPrefs_createServerFn_handler = createServerRpc({
	id: "ef226ec4749f0ffa9300649e7663fc2ee7b1fe191ab987c685522a6eed98da7d",
	name: "getPrefs",
	filename: "src/lib/panel.functions.ts"
}, (opts) => getPrefs.__executeServer(opts));
var getPrefs = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getPrefs_createServerFn_handler, async ({ context }) => {
	return (await (await ensurePrefs(context.userId))`
      select full_name, api_key, organic_enabled, ratios_json, avatar_url, display_currency from user_prefs where user_id = ${context.userId}
    `)[0] ?? {
		full_name: null,
		api_key: null,
		organic_enabled: false,
		ratios_json: "{}",
		avatar_url: null,
		display_currency: null
	};
});
var savePrefs_createServerFn_handler = createServerRpc({
	id: "8f87cfe60b2883ab601b7f65b94680260c0f81857a5f8957e52407b404746740",
	name: "savePrefs",
	filename: "src/lib/panel.functions.ts"
}, (opts) => savePrefs.__executeServer(opts));
var savePrefs = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(savePrefs_createServerFn_handler, async ({ context, data }) => {
	const sql = await ensurePrefs(context.userId);
	if (typeof data.full_name === "string") {
		const name = data.full_name.trim().slice(0, 80);
		await sql`update user_prefs set full_name = ${name} where user_id = ${context.userId}`;
		await sql`update "user" set name = ${name}, "updatedAt" = now() where id = ${context.userId}`;
	}
	if (typeof data.organic_enabled === "boolean") await sql`update user_prefs set organic_enabled = ${data.organic_enabled} where user_id = ${context.userId}`;
	if (typeof data.ratios_json === "string") await sql`update user_prefs set ratios_json = ${data.ratios_json.slice(0, 4e3)} where user_id = ${context.userId}`;
	if (typeof data.avatar_url === "string") {
		const photo = data.avatar_url.startsWith("data:image/") ? data.avatar_url.slice(0, 25e4) : "";
		await sql`update user_prefs set avatar_url = ${photo || null} where user_id = ${context.userId}`;
		if (photo) await sql`update "user" set image = ${photo}, "updatedAt" = now() where id = ${context.userId}`;
	}
	if (data.rotateKey) await sql`update user_prefs set api_key = ${`mg_${crypto.randomUUID().replace(/-/g, "")}`} where user_id = ${context.userId}`;
	return (await sql`
      select full_name, api_key, organic_enabled, ratios_json, avatar_url from user_prefs where user_id = ${context.userId}
    `)[0];
});
async function deskMeta(sql) {
	await sql`create table if not exists desk_meta (key text primary key, value text not null default '')`;
	return sql;
}
var getDeskCurrency_createServerFn_handler = createServerRpc({
	id: "eb6283091792dfe8565063aad130d0c51bc8f0f32ac264327c788471fb0f9afd",
	name: "getDeskCurrency",
	filename: "src/lib/panel.functions.ts"
}, (opts) => getDeskCurrency.__executeServer(opts));
var getDeskCurrency = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getDeskCurrency_createServerFn_handler, async () => {
	return (await (await deskMeta(await getSql()))`select value from desk_meta where key = 'currency'`)[0]?.value || "INR|₹|en-IN";
});
var saveDeskCurrency_createServerFn_handler = createServerRpc({
	id: "2e28b7ec70f8e3b8b102bd62af2cb33dda347a930b8f73a5bb0c51948cdee570",
	name: "saveDeskCurrency",
	filename: "src/lib/panel.functions.ts"
}, (opts) => saveDeskCurrency.__executeServer(opts));
var saveDeskCurrency = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const value = String(input || "").slice(0, 48);
	if (value.split("|").length < 2) throw new Error("Pick a currency.");
	return value;
}).handler(saveDeskCurrency_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	await (await deskMeta(await getSql()))`
      insert into desk_meta (key, value) values ('currency', ${data})
      on conflict (key) do update set value = excluded.value
    `;
	return data;
});
var FX_TTL = 216e5;
async function loadFx(sql, base, force) {
	const code = base.toUpperCase();
	const cached = await sql`select value from desk_meta where key = 'fx_cache'`;
	let parsed = null;
	try {
		parsed = JSON.parse(cached[0]?.value || "null");
	} catch {
		parsed = null;
	}
	if (Boolean(parsed && parsed.base === code && parsed.rates && Date.now() - Number(parsed.at) < FX_TTL) && !force && parsed?.rates) return {
		rates: parsed.rates,
		updatedAt: Number(parsed.at) || 0,
		stale: false,
		base: code
	};
	try {
		const response = await fetch(`https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/${code.toLowerCase()}.json`);
		if (!response.ok) throw new Error(`Rate feed ${response.status}`);
		const table = (await response.json())[code.toLowerCase()];
		if (!table || typeof table !== "object") throw new Error("Rate feed was empty.");
		const rates = { [code]: 1 };
		for (const [key, value] of Object.entries(table)) {
			const rate = Number(value);
			if (rate > 0 && Number.isFinite(rate) && rate < 0xe8d4a51000) rates[key.toUpperCase()] = rate;
		}
		const payload = {
			base: code,
			at: Date.now(),
			rates
		};
		await sql`
      insert into desk_meta (key, value) values ('fx_cache', ${JSON.stringify(payload)})
      on conflict (key) do update set value = excluded.value
    `;
		return {
			rates,
			updatedAt: payload.at,
			stale: false,
			base: code
		};
	} catch {
		if (parsed?.rates) return {
			rates: parsed.rates,
			updatedAt: Number(parsed.at) || 0,
			stale: true,
			base: parsed.base || code
		};
		return {
			rates: { [code]: 1 },
			updatedAt: 0,
			stale: true,
			base: code
		};
	}
}
var getMoneyConfig_createServerFn_handler = createServerRpc({
	id: "bbf30ab5e228f35fa76c42b6ab72e8b4c8e12743ac157a7d4d4828bc890df068",
	name: "getMoneyConfig",
	filename: "src/lib/panel.functions.ts"
}, (opts) => getMoneyConfig.__executeServer(opts));
var getMoneyConfig = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getMoneyConfig_createServerFn_handler, async ({ context }) => {
	const sql = await deskMeta(await ensurePrefs(context.userId));
	const base = ((await sql`select value from desk_meta where key = 'base_currency'`)[0]?.value || "INR").toUpperCase();
	const prefs = await sql`select display_currency from user_prefs where user_id = ${context.userId}`;
	return {
		...await loadFx(sql, base, false),
		base,
		display: prefs[0]?.display_currency || ""
	};
});
var getDeskLook_createServerFn_handler = createServerRpc({
	id: "7f90c234873278b07dff1ab65be14bced54a6864684f3d4b3119335e85c05787",
	name: "getDeskLook",
	filename: "src/lib/panel.functions.ts"
}, (opts) => getDeskLook.__executeServer(opts));
var getDeskLook = createServerFn({ method: "GET" }).handler(getDeskLook_createServerFn_handler, async () => {
	const sql = await getSql();
	await sql`create table if not exists desk_meta (key text primary key, value text not null default '')`;
	const rows = await sql`select key, value from desk_meta where key in ('desk_theme', 'desk_motion')`;
	const map = Object.fromEntries(rows.map((row) => [row.key, row.value]));
	return {
		theme: map.desk_theme || "",
		motion: map.desk_motion || ""
	};
});
var saveDeskLook_createServerFn_handler = createServerRpc({
	id: "ae6f69f2c3554dc27dfada48f2e4403848c5c86d220843c79407883baffdbef3",
	name: "saveDeskLook",
	filename: "src/lib/panel.functions.ts"
}, (opts) => saveDeskLook.__executeServer(opts));
var saveDeskLook = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	theme: String(input?.theme || "").slice(0, 4e3),
	motion: String(input?.motion || "").slice(0, 40)
})).handler(saveDeskLook_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	const sql = await getSql();
	await sql`create table if not exists desk_meta (key text primary key, value text not null default '')`;
	await sql`insert into desk_meta (key, value) values ('desk_theme', ${data.theme}) on conflict (key) do update set value = ${data.theme}`;
	await sql`insert into desk_meta (key, value) values ('desk_motion', ${data.motion}) on conflict (key) do update set value = ${data.motion}`;
	return { ok: true };
});
var saveDisplayCurrency_createServerFn_handler = createServerRpc({
	id: "09cf685080a2ace7fae0b6ec2f84dbec82928a6d42677974b3582153e128b019",
	name: "saveDisplayCurrency",
	filename: "src/lib/panel.functions.ts"
}, (opts) => saveDisplayCurrency.__executeServer(opts));
var saveDisplayCurrency = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const code = String(input || "").toUpperCase().replace(/[^A-Z]/g, "").slice(0, 8);
	if (code.length < 3) throw new Error("Pick a currency.");
	return code;
}).handler(saveDisplayCurrency_createServerFn_handler, async ({ context, data }) => {
	await (await ensurePrefs(context.userId))`update user_prefs set display_currency = ${data} where user_id = ${context.userId}`;
	return data;
});
var saveBaseCurrency_createServerFn_handler = createServerRpc({
	id: "f335ddc5605aa2f10eae1c072b7ea5f1fd105c347fabea791e94698266e10c5d",
	name: "saveBaseCurrency",
	filename: "src/lib/panel.functions.ts"
}, (opts) => saveBaseCurrency.__executeServer(opts));
var saveBaseCurrency = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const code = String(input || "").toUpperCase().replace(/[^A-Z]/g, "").slice(0, 8);
	if (code.length < 3) throw new Error("Pick a base currency.");
	return code;
}).handler(saveBaseCurrency_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	const sql = await deskMeta(await getSql());
	await sql`
      insert into desk_meta (key, value) values ('base_currency', ${data})
      on conflict (key) do update set value = excluded.value
    `;
	return {
		...await loadFx(sql, data, true),
		base: data
	};
});
var refreshFx_createServerFn_handler = createServerRpc({
	id: "b279d93c581215f19ea0ae4acec3feb8729f5dd8fbe62785942756dcdd878946",
	name: "refreshFx",
	filename: "src/lib/panel.functions.ts"
}, (opts) => refreshFx.__executeServer(opts));
var refreshFx = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(refreshFx_createServerFn_handler, async ({ context }) => {
	await requireAdmin(context.userId);
	const sql = await deskMeta(await getSql());
	return loadFx(sql, ((await sql`select value from desk_meta where key = 'base_currency'`)[0]?.value || "INR").toUpperCase(), true);
});
var changeDeskPassword_createServerFn_handler = createServerRpc({
	id: "84c7634f59b3238ab68dcf359e1b57c86770a0ed7f4e3729f0c8714583198c69",
	name: "changeDeskPassword",
	filename: "src/lib/panel.functions.ts"
}, (opts) => changeDeskPassword.__executeServer(opts));
var changeDeskPassword = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((password) => {
	const next = String(password ?? "");
	if (next.length < 8) throw new Error("Use at least 8 characters.");
	if (next.length > 128) throw new Error("Password is too long.");
	return next;
}).handler(changeDeskPassword_createServerFn_handler, async ({ context, data }) => {
	const hash = await hashPassword$1(data);
	if ((await (await getSql())`
      update "account"
      set password = ${hash}, "updatedAt" = now()
      where "userId" = ${context.userId} and "providerId" = 'credential'
      returning id
    `).length === 0) throw new Error("This account has no password to change.");
	return { ok: true };
});
var changeAdminLogin_createServerFn_handler = createServerRpc({
	id: "83c9156aadd378dc50d4faa4ccbdc8c2d688dd505f74896d8a229b3de78b2322",
	name: "changeAdminLogin",
	filename: "src/lib/panel.functions.ts"
}, (opts) => changeAdminLogin.__executeServer(opts));
var changeAdminLogin = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const email = String(input?.email ?? "").trim().toLowerCase();
	const password = String(input?.password ?? "");
	if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("Email sahi likho.");
	if (email.length > 120) throw new Error("Email bohot lamba hai.");
	if (password && password.length < 8) throw new Error("Password kam se kam 8 characters ka ho.");
	if (password.length > 128) throw new Error("Password bohot lamba hai.");
	if (!email && !password) throw new Error("Naya email ya password likho.");
	return {
		email,
		password
	};
}).handler(changeAdminLogin_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	const sql = await getSql();
	let email = data.email;
	if (email) {
		if ((await sql`select id from "user" where lower(email) = ${email} and id <> ${context.userId} limit 1`).length) throw new Error("Ye email pehle se kisi account pe hai.");
		await sql`update "user" set email = ${email}, "emailVerified" = true, "updatedAt" = now() where id = ${context.userId}`;
	} else email = (await sql`select email from "user" where id = ${context.userId} limit 1`)[0]?.email || "";
	if (data.password) {
		if ((await sql`
        update "account"
        set password = ${await hashPassword$1(data.password)}, "updatedAt" = now()
        where "userId" = ${context.userId} and "providerId" = 'credential'
        returning id
      `).length === 0) throw new Error("Is account pe password login nahi hai.");
	}
	return {
		ok: true,
		email
	};
});
var listInstagram_createServerFn_handler = createServerRpc({
	id: "1644135fedf9abfb3f169c5a4ebf56e1f9eec0ff9c200cd5e24a21e462f07594",
	name: "listInstagram",
	filename: "src/lib/panel.functions.ts"
}, (opts) => listInstagram.__executeServer(opts));
var listInstagram = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listInstagram_createServerFn_handler, async ({ context }) => {
	await requireAdmin(context.userId);
	return (await getSql())`
      select id, username, created_at::text as created_at
      from instagram_accounts
      where user_id = ${context.userId}
      order by created_at desc
    `;
});
var linkInstagram_createServerFn_handler = createServerRpc({
	id: "da85c88cb832768680358bdf8fb70abaaacd778abf495ef5a11caed8237e2efe",
	name: "linkInstagram",
	filename: "src/lib/panel.functions.ts"
}, (opts) => linkInstagram.__executeServer(opts));
var linkInstagram = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((username) => {
	const name = String(username ?? "").trim().replace(/^@/, "");
	if (!/^[A-Za-z0-9._]{2,30}$/.test(name)) throw new Error("Enter a public username, like your_name.");
	return name;
}).handler(linkInstagram_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	const sql = await getSql();
	if (((await sql`
      select count(*)::int as n from instagram_accounts
      where user_id = ${context.userId} and created_at > now() - interval '30 days'
    `)[0]?.n ?? 0) >= 5) throw new Error("5 accounts already linked in this 30-day window.");
	const id = crypto.randomUUID();
	await sql`
      insert into instagram_accounts (id, user_id, username)
      values (${id}, ${context.userId}, ${data})
    `;
	return {
		id,
		username: data
	};
});
var listGrowthTemplates_createServerFn_handler = createServerRpc({
	id: "620cdf05ad3c97342eff45c9a6a3b51b1569192c5a8af304758461d80f78923c",
	name: "listGrowthTemplates",
	filename: "src/lib/panel.functions.ts"
}, (opts) => listGrowthTemplates.__executeServer(opts));
var listGrowthTemplates = createServerFn({ method: "GET" }).handler(listGrowthTemplates_createServerFn_handler, async () => listGrowthCatalog());
async function ensureMassTables() {
	const sql = await getSql();
	await sql`
    create table if not exists mass_batches (
      id text primary key,
      user_id text not null,
      campaign_name text not null,
      platform text not null,
      bundle_id text not null,
      base_quantity integer not null,
      timeframe text not null,
      link_count integer not null,
      placed_count integer not null,
      failed_count integer not null,
      total_paise integer not null,
      status text not null,
      created_at timestamptz not null default now()
    )
  `;
	await sql`
    create table if not exists mass_batch_links (
      id text primary key,
      batch_id text not null,
      user_id text not null,
      link text not null,
      order_id text,
      order_number text,
      status text not null,
      error text,
      total_paise integer not null default 0
    )
  `;
	return sql;
}
var listMassBatches_createServerFn_handler = createServerRpc({
	id: "285d1c8d2220576be11ebc42adabdc42c82f23dbbb652830ca5fe13c573e2164",
	name: "listMassBatches",
	filename: "src/lib/panel.functions.ts"
}, (opts) => listMassBatches.__executeServer(opts));
var listMassBatches = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listMassBatches_createServerFn_handler, async ({ context }) => {
	const sql = await ensureMassTables();
	const batches = await sql`
      select id, campaign_name, platform, base_quantity, timeframe, link_count, placed_count,
             failed_count, total_paise, status, created_at::text as created_at
      from mass_batches
      where user_id = ${context.userId}
      order by created_at desc
      limit 50
    `;
	if (batches.length === 0) return [];
	const ids = batches.map((batch) => batch.id);
	const links = await sql`
      select batch_id, link, status, error, total_paise, order_number
      from mass_batch_links
      where user_id = ${context.userId}
    `;
	const idSet = new Set(ids);
	return batches.map((batch) => ({
		...batch,
		links: links.filter((link) => idSet.has(link.batch_id)).map(({ link, status, error, total_paise, order_number }) => ({
			link,
			status,
			error,
			total_paise,
			order_number
		}))
	}));
});
var submitMassBatch_createServerFn_handler = createServerRpc({
	id: "768c1b2bf6d3a16d3d207babecbc4c2e26b12520f45b8076d15d0c1b3b8b4bea",
	name: "submitMassBatch",
	filename: "src/lib/panel.functions.ts"
}, (opts) => submitMassBatch.__executeServer(opts));
var submitMassBatch = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const links = (input.links ?? []).filter((row) => /^https?:\/\//.test(String(row.link ?? "").trim())).slice(0, 100);
	if (!input.bundleId) throw new Error("Apna bundle select karo.");
	if (links.length === 0) throw new Error("Kam se kam 1 valid link daalo.");
	const floors = {
		views: 100,
		likes: 10,
		comments: 10,
		shares: 10,
		saves: 50,
		reposts: 10
	};
	const clampRuns = (value, quantity, floor) => {
		const max = Math.max(1, Math.min(200, Math.floor(quantity / Math.max(1, floor))));
		const asked = Math.floor(Number(value) || 0);
		return Math.max(1, Math.min(max, asked > 0 ? asked : max));
	};
	const platform = input.platform === "tiktok" || input.bundleId === "bundle-tt" ? "tiktok" : "instagram";
	return {
		bundleId: platform === "tiktok" ? "bundle-tt" : "bundle-ig",
		platform,
		campaignName: String(input.campaignName ?? "").trim().slice(0, 80) || "Untitled campaign",
		timeframe: String(input.timeframe ?? "1-3 days"),
		intervalHours: Math.max(1, Math.min(2160, Math.round(Number(input.intervalHours) || 72))),
		links: links.map((row) => {
			const views = Math.round(Number(row.views) || 0);
			if (views < floors.views) throw new Error("Below 100 not allowed for views.");
			const extras = Object.fromEntries(Object.entries(row.extras ?? {}).map(([key, value]) => [key, Math.round(Number(value) || 0)]).filter((entry) => Number(entry[1]) > 0));
			for (const [key, value] of Object.entries(extras)) {
				const floor = floors[key];
				if (floor && Number(value) < floor) throw new Error(`Below ${floor} not allowed for ${key}.`);
			}
			const runs = Object.fromEntries(Object.keys(extras).map((key) => [key, clampRuns(row.runs?.[key], Number(extras[key]), floors[key] || 10)]));
			const allowed = /* @__PURE__ */ new Set([
				"views",
				"likes",
				"comments",
				"shares",
				"saves",
				"reposts"
			]);
			const drops = (Array.isArray(row.drops) ? row.drops : []).map((drop) => ({
				type: String(drop?.type || ""),
				amount: Math.floor(Number(drop?.amount) || 0),
				at: new Date(String(drop?.at || "")).toISOString()
			})).filter((drop) => allowed.has(drop.type) && drop.amount > 0 && !Number.isNaN(new Date(drop.at).getTime()));
			for (const drop of drops) {
				const floor = floors[drop.type] || 1;
				if (drop.amount < floor) throw new Error(`Below ${floor} not allowed for ${drop.type}.`);
			}
			return {
				link: row.link.trim(),
				views,
				viewRuns: clampRuns(row.viewRuns, views, floors.views),
				extras,
				runs,
				drops
			};
		})
	};
}).handler(submitMassBatch_createServerFn_handler, async ({ context, data }) => {
	const sql = await ensureMassTables();
	await ensureWallet(context.userId);
	const items = await sql`
      select bi.engagement_type, bi.ratio_bps, bi.is_base, s.name, s.price_per_1k_paise,
             coalesce(s.price_per_10k_paise, s.price_per_1k_paise * 10) as price_per_10k_paise,
             s.min_quantity, s.max_quantity, b.platform
      from bundle_items bi
      join services s on s.id = bi.service_id
      join bundles b on b.id = bi.bundle_id
      where bi.bundle_id = ${data.bundleId}
    `;
	if (items.length === 0 && data.platform !== "tiktok" && data.platform !== "instagram") throw new Error("That bundle is not on the book.");
	const platform = data.platform === "tiktok" ? "tiktok" : "instagram";
	const { bindingMap, panelTypeRates } = await import("./admin.server-B6p1lYbS.mjs").then((n) => n.r);
	const { PROVIDER_MIN, autoRuns } = await import("./organic-DU6S6wDh.mjs").then((n) => n.y).then((n) => n.g);
	const bindings = await bindingMap();
	const rates = await panelTypeRates(platform);
	const named = Object.fromEntries(items.map((item) => [item.engagement_type, item]));
	const batchId = crypto.randomUUID();
	let placed = 0;
	let failed = 0;
	let totalPaise = 0;
	const results = [];
	for (const [index, row] of data.links.entries()) {
		const extras = { ...row.extras };
		const wanted = {
			views: row.views,
			...extras
		};
		try {
			const lines = [];
			for (const type of [
				"views",
				"likes",
				"comments",
				"shares",
				"saves",
				"reposts"
			]) {
				const asked = Math.floor(wanted[type] || 0);
				if (asked <= 0) continue;
				const slot = bindings[`${platform}:${type}`];
				if (slot && slot.section_enabled === false) continue;
				if (!((slot?.providers || []).some((item) => item.api_key && item.api_url) || Boolean(slot?.api_key && slot?.api_url))) throw new Error(`No Provider Available for ${type}. Full Engagement APIs me ${type} lagao.`);
				const quantity = asked;
				const panel = rates[type];
				const item = named[type];
				const price = panel > 0 ? Math.max(1, Math.round(quantity / 1e3 * panel)) : item ? Math.max(1, Math.round(quantity * (item.price_per_10k_paise || item.price_per_1k_paise * 10) / 1e4)) : 0;
				if (price <= 0) throw new Error(`Set a panel rate for ${type}.`);
				lines.push({
					engagement_type: type,
					service_name: item?.name || type,
					quantity,
					price_paise: price
				});
			}
			if (!lines.some((line) => line.engagement_type === "views")) throw new Error("Views API is off or missing.");
			const total = lines.reduce((sum, line) => sum + line.price_paise, 0);
			if (((await sql`
          select balance_paise from wallets where user_id = ${context.userId}
        `)[0]?.balance_paise ?? 0) < total) throw new Error("Wallet does not cover this link.");
			const { armOrder } = await import("./drip.server-C0TUW5wc.mjs").then((n) => n.t);
			const orderId = crypto.randomUUID();
			const orderNumber = `MAG-${Math.floor(1e5 + Math.random() * 9e5)}`;
			if ((await sql`
          update wallets
          set balance_paise = balance_paise - ${total}, updated_at = now()
          where user_id = ${context.userId} and balance_paise >= ${total}
          returning user_id
        `).length === 0) throw new Error("Wallet does not cover this link.");
			await sql`
          insert into engagement_orders (
            id, user_id, order_number, bundle_id, platform, link, base_quantity, total_paise,
            status, organic, interval_hours, variance_percent, provider_state
          ) values (
            ${orderId}, ${context.userId}, ${orderNumber}, ${data.bundleId}, ${platform}, ${row.link},
            ${row.views}, ${total}, 'queued', true, ${data.intervalHours}, 34, 'provider'
          )
        `;
			for (const line of lines) await sql`
            insert into engagement_order_items (
              id, order_id, user_id, engagement_type, service_name, quantity, delivered, price_paise, status
            ) values (
              ${crypto.randomUUID()}, ${orderId}, ${context.userId}, ${line.engagement_type},
              ${line.service_name}, ${line.quantity}, 0, ${line.price_paise}, 'queued'
            )
          `;
			const lead = data.links.length <= 1 ? 0 : index / (data.links.length - 1) * Math.min(data.intervalHours * .12, 6);
			const start = new Date(Date.now() + lead * 3600 * 1e3);
			const hours = Math.max(1, data.intervalHours - lead);
			const plans = {};
			for (const line of lines) {
				const min = Math.max(1, PROVIDER_MIN[line.engagement_type] || 10);
				const cap = line.quantity > min ? Math.max(1, Math.floor(line.quantity / (min + 1))) : 1;
				const asked = line.engagement_type === "views" ? row.viewRuns : row.runs?.[line.engagement_type];
				plans[line.engagement_type] = {
					hours,
					runs: Math.max(1, Math.min(cap, Math.floor(Number(asked) || autoRuns(line.quantity, line.engagement_type)))),
					variance: 34,
					curve: [
						.05,
						.16,
						.38,
						.62,
						.84,
						1
					],
					start: start.toISOString()
				};
			}
			await armOrder({
				userId: context.userId,
				orderId,
				platform,
				link: row.link,
				lines: lines.map((line) => ({
					engagement_type: line.engagement_type,
					quantity: line.quantity
				})),
				plans,
				drops: row.drops
			});
			await sql`
          insert into wallet_transactions (id, user_id, kind, amount_paise, note)
          values (${crypto.randomUUID()}, ${context.userId}, 'debit', ${-total}, ${`Mass ${orderNumber} · ${data.campaignName}`})
        `;
			await sql`
          insert into mass_batch_links (id, batch_id, user_id, link, order_id, order_number, status, total_paise)
          values (${crypto.randomUUID()}, ${batchId}, ${context.userId}, ${row.link}, ${orderId}, ${orderNumber}, 'processing', ${total})
        `;
			placed += 1;
			totalPaise += total;
			results.push({
				link: row.link,
				status: "processing",
				error: null,
				total_paise: total,
				order_number: orderNumber
			});
		} catch (err) {
			failed += 1;
			const message = err instanceof Error ? err.message : "Link failed.";
			await sql`
          insert into mass_batch_links (id, batch_id, user_id, link, status, error, total_paise)
          values (${crypto.randomUUID()}, ${batchId}, ${context.userId}, ${row.link}, 'failed', ${message}, 0)
        `;
			results.push({
				link: row.link,
				status: "failed",
				error: message,
				total_paise: 0,
				order_number: null
			});
		}
	}
	const status = placed === 0 ? "failed" : failed > 0 ? "partial" : "processing";
	await sql`
      insert into mass_batches (
        id, user_id, campaign_name, platform, bundle_id, base_quantity, timeframe,
        link_count, placed_count, failed_count, total_paise, status
      ) values (
        ${batchId}, ${context.userId}, ${data.campaignName}, ${platform}, ${data.bundleId},
        ${data.links[0]?.views ?? 0}, ${data.timeframe}, ${data.links.length}, ${placed}, ${failed},
        ${totalPaise}, ${status}
      )
    `;
	return {
		id: batchId,
		status,
		placed,
		failed,
		total_paise: totalPaise,
		links: results
	};
});
var completeMassBatch_createServerFn_handler = createServerRpc({
	id: "aafca77407b378ecf1b60565d25960732ba4402fc175dac369c419ee819c7cc5",
	name: "completeMassBatch",
	filename: "src/lib/panel.functions.ts"
}, (opts) => completeMassBatch.__executeServer(opts));
var completeMassBatch = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (typeof id !== "string" || id.length < 8) throw new Error("Missing batch.");
	return id;
}).handler(completeMassBatch_createServerFn_handler, async ({ context, data }) => {
	const sql = await ensureMassTables();
	if ((await sql`
      update mass_batches
      set status = 'completed'
      where id = ${data} and user_id = ${context.userId} and status = 'processing'
      returning id
    `).length === 0) throw new Error("That batch is not processing.");
	await sql`
      update mass_batch_links
      set status = 'completed'
      where batch_id = ${data} and user_id = ${context.userId} and status = 'processing'
    `;
	const orders = await sql`
      select order_id from mass_batch_links
      where batch_id = ${data} and user_id = ${context.userId} and order_id is not null
    `;
	for (const row of orders) {
		await sql`update engagement_orders set status = 'complete' where id = ${row.order_id} and user_id = ${context.userId}`;
		await sql`update engagement_order_items set delivered = quantity, status = 'complete' where order_id = ${row.order_id} and user_id = ${context.userId}`;
	}
	return { ok: true };
});
var placeSingleOrder_createServerFn_handler = createServerRpc({
	id: "87995d9c4d6e2008fd7d74a5132318db419bdce7cdf364199a7f9a75d0946da6",
	name: "placeSingleOrder",
	filename: "src/lib/panel.functions.ts"
}, (opts) => placeSingleOrder.__executeServer(opts));
var placeSingleOrder = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const managedId = String(input?.managedId || "").trim();
	const serviceId = Math.floor(Number(input?.serviceId) || 0);
	const link = String(input?.link ?? "").trim();
	const amount = Math.floor(Number(input?.amount));
	const runs = Math.max(1, Math.min(200, Math.floor(Number(input?.runs) || 1)));
	const intervalMinutes = Math.max(1, Math.min(10080, Math.floor(Number(input?.intervalMinutes) || 1)));
	if (!managedId && !serviceId) throw new Error("Pick a service.");
	if (!/^https?:\/\//i.test(link)) throw new Error("Paste a valid link.");
	if (!Number.isFinite(amount) || amount < 1) throw new Error("Enter an amount.");
	return {
		managedId,
		serviceId,
		link,
		amount,
		drip: Boolean(input?.drip),
		runs,
		intervalMinutes
	};
}).handler(placeSingleOrder_createServerFn_handler, async ({ context, data }) => {
	const { findManagedById, findManagedByProviderId, providerKeys } = await import("./admin.server-B6p1lYbS.mjs").then((n) => n.r);
	const managed = data.managedId ? await findManagedById(data.managedId) : await findManagedByProviderId(String(data.serviceId));
	if (!managed || managed.enabled === false) throw new Error("That service is disabled.");
	if (data.drip && !managed.drip_allowed) throw new Error("Drip-feed is not available on this service.");
	if (data.amount < managed.min_quantity || data.amount > managed.max_quantity) throw new Error(`Amount must be between ${managed.min_quantity} and ${managed.max_quantity}.`);
	const keys = await providerKeys(managed.provider_row_id || "");
	if (!keys?.api_key || !keys.api_url) throw new Error("No Provider Available");
	const pieces = data.drip ? data.runs : 1;
	const totalQty = data.amount * pieces;
	const sql = await ensureWallet(context.userId);
	await sql`
      insert into bundles (id, name, platform, tagline)
      values ('bundle-single', 'Single order', 'multi', 'One service at a time.')
      on conflict (id) do nothing
    `;
	const total = Math.max(1, Math.round(totalQty / 1e3 * Math.max(1, managed.price_per_1k_paise)));
	const wallet = await sql`
      select balance_paise from wallets where user_id = ${context.userId}
    `;
	if ((wallet[0]?.balance_paise ?? 0) < total) throw new Error("The wallet does not cover this order. Add credit first.");
	const orderId = crypto.randomUUID();
	const orderNumber = `MAG-${Math.floor(1e5 + Math.random() * 9e5)}`;
	let providerOrderId = data.drip ? "drip" : "";
	if (!data.drip) {
		const { placeExactOnProvider } = await import("./providers.server-BTYWPfD2.mjs").then((n) => n.i).then((n) => n.r);
		providerOrderId = (await placeExactOnProvider({
			serviceId: managed.provider_service_id,
			link: data.link,
			quantity: data.amount,
			apiUrl: keys.api_url,
			apiKey: keys.api_key
		})).orderId;
	}
	if ((await sql`
      update wallets
      set balance_paise = balance_paise - ${total}, updated_at = now()
      where user_id = ${context.userId} and balance_paise >= ${total}
      returning user_id
    `).length === 0) {
		if (providerOrderId && providerOrderId !== "drip") {
			const { cancelProviderOrder } = await import("./providers.server-BTYWPfD2.mjs").then((n) => n.i).then((n) => n.r);
			await cancelProviderOrder(providerOrderId);
		}
		throw new Error("The wallet does not cover this order. Add credit first.");
	}
	await sql`
      insert into engagement_orders (
        id, user_id, order_number, bundle_id, platform, link, base_quantity, total_paise,
        status, organic, interval_hours, variance_percent, provider_state
      ) values (
        ${orderId}, ${context.userId}, ${orderNumber}, 'bundle-single', ${managed.platform}, ${data.link},
        ${data.amount}, ${total}, 'processing', false, 1, 0, 'provider'
      )
    `;
	await sql`
      insert into engagement_order_items (
        id, order_id, user_id, engagement_type, service_name, quantity, delivered, price_paise, status
      ) values (
        ${crypto.randomUUID()}, ${orderId}, ${context.userId}, ${managed.category},
        ${`#${managed.provider_service_id} ${managed.name}${data.drip ? "" : ` · #${providerOrderId}`}`}, ${totalQty}, 0, ${total}, 'processing'
      )
    `;
	await sql`
      insert into wallet_transactions (id, user_id, kind, amount_paise, note)
      values (${crypto.randomUUID()}, ${context.userId}, 'debit', ${-total}, ${data.drip ? `Single ${orderNumber} drip ${pieces} runs.` : `Single ${orderNumber} sent once #${providerOrderId}.`})
    `;
	if (!data.drip) await sql`
        insert into delivery_drops (
          id, order_id, user_id, platform, link, engagement_type, quantity, place_at, status,
          provider_order_id, service_label, provider_service_id, api_url, api_key
        ) values (
          ${crypto.randomUUID()}, ${orderId}, ${context.userId}, ${managed.platform}, ${data.link},
          ${managed.category}, ${data.amount}, now(), 'placed',
          ${providerOrderId}, ${`#${managed.provider_service_id} ${managed.name}`}, ${String(managed.provider_service_id)}, ${keys.api_url}, ${keys.api_key}
        )
      `;
	if (data.drip) {
		const { scheduleFixed } = await import("./drip.server-C0TUW5wc.mjs").then((n) => n.t);
		await scheduleFixed({
			userId: context.userId,
			orderId,
			platform: managed.platform,
			link: data.link,
			engagementType: managed.category || "single",
			providerServiceId: String(managed.provider_service_id),
			apiUrl: keys.api_url,
			apiKey: keys.api_key,
			amount: data.amount,
			runs: pieces,
			intervalMinutes: data.intervalMinutes
		});
	}
	return {
		id: orderId,
		order_number: orderNumber,
		total_paise: total,
		provider_order_id: providerOrderId,
		balance_paise: (wallet[0]?.balance_paise ?? 0) - total
	};
});
var browseLiveServices_createServerFn_handler = createServerRpc({
	id: "f921deca845381bd70b80b03a9dc493f82ba1e26f49804e5fc98050528895093",
	name: "browseLiveServices",
	filename: "src/lib/panel.functions.ts"
}, (opts) => browseLiveServices.__executeServer(opts));
var browseLiveServices = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	platform: String(input?.platform || "instagram").slice(0, 32),
	category: String(input?.category || "").slice(0, 160),
	query: String(input?.query || "").slice(0, 80)
})).handler(browseLiveServices_createServerFn_handler, async ({ data }) => {
	const { enabledCatalog, managedToLive } = await import("./admin.server-B6p1lYbS.mjs").then((n) => n.r);
	const { browseProvider, providerBalance } = await import("./providers.server-BTYWPfD2.mjs").then((n) => n.i).then((n) => n.r);
	const managed = await enabledCatalog();
	if (managed && managed.length > 0) {
		const cards = managed.map((row) => managedToLive(row));
		const platform = data.platform;
		const rows = cards.filter((row) => platform === "all" || row.platform === platform);
		const names = Array.from(new Set(rows.map((row) => row.category))).sort((a, b) => a.localeCompare(b));
		const categories = platform === "all" ? ["All categories", ...names] : names;
		const category = categories.includes(data.category) ? data.category : categories[0] || "";
		const query = data.query.trim().toLowerCase();
		const pool = category === "All categories" || !category ? rows : rows.filter((row) => row.category === category);
		return {
			categories,
			category,
			services: (query ? pool.filter((row) => `${row.id} ${row.name} ${row.category} ${row.providerName || ""}`.toLowerCase().includes(query)) : pool).slice(0, 800),
			balanceUsd: 0,
			currency: "USD"
		};
	}
	const [catalog, balance] = await Promise.all([browseProvider(data), providerBalance()]);
	return {
		...catalog,
		balanceUsd: balance.balanceUsd,
		currency: balance.currency
	};
});
var engagementFloors_createServerFn_handler = createServerRpc({
	id: "d1e4bdf765d192cc84b4f39d27c52ae7125513cc8dff62ab1a820904dfe7be0c",
	name: "engagementFloors",
	filename: "src/lib/panel.functions.ts"
}, (opts) => engagementFloors.__executeServer(opts));
var engagementFloors = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((platform) => String(platform || "instagram").slice(0, 32)).handler(engagementFloors_createServerFn_handler, async ({ data }) => {
	const { listBindings } = await import("./admin.server-B6p1lYbS.mjs").then((n) => n.r);
	const rows = await listBindings();
	const out = {};
	for (const type of [
		"views",
		"likes",
		"saves",
		"shares",
		"reposts",
		"comments"
	]) {
		const row = rows.find((item) => item.slot === `${data}:${type}`);
		if (row) out[type] = row.min_quantity;
	}
	return out;
});
var engagementSections_createServerFn_handler = createServerRpc({
	id: "dafffd431854029bafee17a1cab5c900adc90a214efd481a424d06d06632e1fe",
	name: "engagementSections",
	filename: "src/lib/panel.functions.ts"
}, (opts) => engagementSections.__executeServer(opts));
var engagementSections = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((platform) => String(platform || "instagram").slice(0, 32)).handler(engagementSections_createServerFn_handler, async ({ data }) => {
	const { listBindings } = await import("./admin.server-B6p1lYbS.mjs").then((n) => n.r);
	const rows = await listBindings();
	const out = {};
	for (const type of [
		"views",
		"likes",
		"saves",
		"shares",
		"reposts",
		"comments"
	]) {
		const row = rows.find((item) => item.slot === `${data}:${type}`);
		out[type] = row ? row.section_enabled !== false : type !== "comments";
	}
	return out;
});
var panelRates_createServerFn_handler = createServerRpc({
	id: "6b023a162ab3f3e3384cd081dcc074c485585a1c3d4df39c50e5d92ff7ee00c1",
	name: "panelRates",
	filename: "src/lib/panel.functions.ts"
}, (opts) => panelRates.__executeServer(opts));
var panelRates = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((platform) => String(platform || "instagram").slice(0, 32)).handler(panelRates_createServerFn_handler, async ({ data }) => {
	const { panelTypeRates } = await import("./admin.server-B6p1lYbS.mjs").then((n) => n.r);
	return panelTypeRates(data);
});
var aiSmartMix_createServerFn_handler = createServerRpc({
	id: "38133f825e8703711c4006ea0906e4351b521f1db2ba5a12eb1f1864ffaf98fb",
	name: "aiSmartMix",
	filename: "src/lib/panel.functions.ts"
}, (opts) => aiSmartMix.__executeServer(opts));
var aiSmartMix = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const views = Math.floor(Number(input?.views));
	if (views < 100) throw new Error("Enter at least 100 views.");
	return {
		views,
		platform: String(input?.platform || "instagram").slice(0, 32)
	};
}).handler(aiSmartMix_createServerFn_handler, async ({ context, data }) => {
	const { mixFromRatios, SETTINGS_RATIO_DEFAULTS } = await import("./organic-DU6S6wDh.mjs").then((n) => n.y).then((n) => n.g);
	const rows = await (await getSql())`select ratios_json from user_prefs where user_id = ${context.userId}`;
	let ratios = SETTINGS_RATIO_DEFAULTS;
	try {
		ratios = {
			...SETTINGS_RATIO_DEFAULTS,
			...JSON.parse(rows[0]?.ratios_json || "{}")
		};
	} catch {
		ratios = SETTINGS_RATIO_DEFAULTS;
	}
	return {
		mix: mixFromRatios(data.views, ratios),
		source: "settings"
	};
});
var askPanelAi_createServerFn_handler = createServerRpc({
	id: "7cc9aa28c0338131d66d443cf22c4c3d456536b0ce5abaf0bbeec1ca970668fe",
	name: "askPanelAi",
	filename: "src/lib/panel.functions.ts"
}, (opts) => askPanelAi.__executeServer(opts));
var askPanelAi = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const question = String(input?.question ?? "").trim().slice(0, 800);
	if (!question) throw new Error("Ask something first.");
	return {
		question,
		context: String(input?.context ?? "").slice(0, 1200)
	};
}).handler(askPanelAi_createServerFn_handler, async ({ data }) => {
	const { askFreeModel } = await import("./providers.server-BTYWPfD2.mjs").then((n) => n.i).then((n) => n.r);
	const text = await askFreeModel("You are the organic growth assistant inside Magiciansmm. Reply in 2 to 4 short sentences using only the numbers given. Do not claim you opened the live post. If the user wants a ratio or mix, end with one line exactly like APPLY {\"likes\":700,\"shares\":80,\"reposts\":40,\"saves\":160}.", `${data.context}\n\nQuestion: ${data.question}`);
	const match = text.match(/APPLY\s*(\{[\s\S]*?\})/);
	let mix = null;
	if (match) try {
		const parsed = JSON.parse(match[1]);
		mix = {};
		for (const key of [
			"likes",
			"shares",
			"reposts",
			"saves"
		]) {
			const value = Number(parsed[key]);
			if (Number.isFinite(value) && value > 0) mix[key] = Math.round(value);
		}
	} catch {
		mix = null;
	}
	return {
		text: text.replace(/APPLY\s*\{[\s\S]*?\}/, "").trim(),
		apply: Boolean(mix && Object.keys(mix).length > 0),
		mix
	};
});
//#endregion
export { aiSmartMix_createServerFn_handler, apiBalances_createServerFn_handler, askPanelAi_createServerFn_handler, browseLiveServices_createServerFn_handler, changeAdminLogin_createServerFn_handler, changeDeskPassword_createServerFn_handler, checkDropStatus_createServerFn_handler, completeMassBatch_createServerFn_handler, creditWallet_createServerFn_handler, editScheduledDrop_createServerFn_handler, engagementFloors_createServerFn_handler, engagementSections_createServerFn_handler, getCatalog_createServerFn_handler, getDashboard_createServerFn_handler, getDeskCurrency_createServerFn_handler, getDeskLook_createServerFn_handler, getMoneyConfig_createServerFn_handler, getOrder_createServerFn_handler, getPrefs_createServerFn_handler, getWallet_createServerFn_handler, linkInstagram_createServerFn_handler, listGrowthTemplates_createServerFn_handler, listInstagram_createServerFn_handler, listMassBatches_createServerFn_handler, listOrderDrops_createServerFn_handler, listOrders_createServerFn_handler, listTickets_createServerFn_handler, openTicket_createServerFn_handler, panelRates_createServerFn_handler, placeOrder_createServerFn_handler, placeSingleOrder_createServerFn_handler, refillEngagement_createServerFn_handler, refreshFx_createServerFn_handler, saveBaseCurrency_createServerFn_handler, saveDeskCurrency_createServerFn_handler, saveDeskLook_createServerFn_handler, saveDisplayCurrency_createServerFn_handler, savePrefs_createServerFn_handler, setOrderFlow_createServerFn_handler, setRunState_createServerFn_handler, simulateDelivery_createServerFn_handler, submitMassBatch_createServerFn_handler };
