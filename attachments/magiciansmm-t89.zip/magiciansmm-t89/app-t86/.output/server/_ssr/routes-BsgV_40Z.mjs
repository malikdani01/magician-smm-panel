import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { B as House, C as Rocket, H as Headphones, at as ArrowRight, i as Wallet, m as ShieldCheck, t as Zap } from "../_libs/lucide-react.mjs";
import { r as Mark, s as Starfield } from "./shell-CfBlaVSk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BsgV_40Z.js
var import_jsx_runtime = require_jsx_runtime();
var hero_guy_default = "/assets/hero-guy-Bxk-w5_e.jpg";
var hero_mobile_default = "/assets/hero-mobile-BXTgMdfy.jpg";
var LOGOS = [
	{
		name: "Instagram",
		src: "/assets/logo-ig-VmDOpGx_.png"
	},
	{
		name: "YouTube",
		src: "/assets/logo-yt-weoBzgG4.png"
	},
	{
		name: "TikTok",
		src: "/assets/logo-tt-Catrxedm.png"
	},
	{
		name: "Facebook",
		src: "/assets/logo-fb-CMV1M8gs.png"
	}
];
var NAV = [
	{
		label: "Home",
		to: "/"
	},
	{
		label: "Services",
		to: "/catalog"
	},
	{
		label: "API",
		to: "/catalog"
	},
	{
		label: "Contact",
		to: "/support"
	}
];
function HomePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-screen overflow-hidden text-white",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: hero_guy_default,
				alt: "",
				className: "pointer-events-none absolute inset-0 hidden h-full w-full object-cover object-[70%_center] md:block"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: hero_mobile_default,
				alt: "",
				className: "pointer-events-none absolute inset-0 h-full w-full object-cover object-top md:hidden"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-gradient-to-r from-[#070312] via-[#070312]/80 to-[#070312]/5" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-gradient-to-t from-[#070312] via-[#070312]/20 to-[#070312]/45 md:to-transparent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Starfield, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "relative z-10 px-3 py-3 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sm:hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { compact: true })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:block",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex shrink-0 items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/login",
								className: "btn-pop inline-flex h-10 items-center rounded-full bg-violet-600 px-3 text-[12px] font-semibold sm:px-4 sm:text-[13px]",
								children: "Login"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/login",
								className: "btn-live inline-flex h-10 items-center gap-1 rounded-full bg-gradient-to-r from-violet-500 to-sky-500 px-3 text-[12px] font-semibold sm:px-4 sm:text-[13px]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rocket, { className: "size-3.5" }), " Register"]
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "mt-2 flex gap-1.5 overflow-x-auto pb-1 text-[12px] [-ms-overflow-style:none] [scrollbar-width:none] lg:justify-center [&::-webkit-scrollbar]:hidden",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/",
							className: "inline-flex h-9 shrink-0 items-center gap-1 rounded-full bg-violet-600 px-3 font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: "size-3.5" }), " Home"]
						}),
						NAV.slice(1).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: item.to,
							className: "inline-flex h-9 shrink-0 items-center rounded-full border border-white/15 bg-black/40 px-3 font-semibold text-white/90",
							children: item.label
						}, item.label)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#features",
							className: "inline-flex h-9 shrink-0 items-center rounded-full border border-white/15 bg-black/40 px-3 font-semibold text-white/90",
							children: "Blog"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "relative z-10 flex flex-col px-4 pb-8 pt-4 sm:px-8 md:max-w-[680px] md:min-h-[calc(100vh-120px)] md:justify-center lg:px-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rise-in mb-3 inline-flex w-fit items-center gap-2 rounded-full border border-white/15 bg-black/40 px-3 py-1 text-[12px] text-white/80",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rocket, { className: "size-3.5 text-fuchsia-300" }), " Fast · Secure · Affordable"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "rise-in rise-d1 text-[40px] font-extrabold leading-[0.92] tracking-tight text-white sm:text-[64px]",
						children: ["Magician", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block bg-gradient-to-r from-fuchsia-400 to-violet-300 bg-clip-text text-transparent",
							children: "SMM Panel"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rise-in rise-d2 mt-3 text-[18px] font-semibold text-white sm:text-[22px]",
						children: ["Grow Your Social Media", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-fuchsia-300",
							children: "Faster & Smarter"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex flex-col gap-2 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/dashboard",
							className: "btn-live inline-flex h-12 w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-violet-600 to-sky-500 px-4 text-[14px] font-semibold shadow-lg shadow-violet-600/40 sm:w-auto",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rocket, { className: "size-4" }),
								" Open the Panel ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/wallet",
							className: "btn-pop rise-d4 inline-flex h-12 w-full items-center justify-center gap-2 rounded-full border border-white/25 bg-black/30 px-4 text-[14px] font-semibold backdrop-blur sm:w-auto",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-4" }), " Add Credit"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 rounded-[24px] border border-white/10 bg-black/50 p-3 backdrop-blur-md sm:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-center text-[11px] font-semibold tracking-[0.22em] text-white/70",
							children: "SUPPORTED PLATFORMS"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex justify-center gap-3",
								children: LOGOS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: item.src,
									alt: item.name,
									title: item.name,
									className: "logo-3d size-11 rounded-xl object-contain sm:size-12"
								}, item.name))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-3 gap-2 text-[11px] sm:text-[12px]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-4 shrink-0 text-amber-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: "block",
											children: "Instant"
										}), "Delivery"] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 shrink-0 text-emerald-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: "block",
											children: "100%"
										}), "Safe & Secure"] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Headphones, { className: "size-4 shrink-0 text-violet-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: "block",
											children: "24/7"
										}), "Support"] })]
									})
								]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "features",
						className: "mt-4 grid gap-2 sm:grid-cols-3",
						children: [
							["Staged drip", "Runs spread over time so the graph looks natural."],
							["Own rates", "Set per-1,000 prices. Orders use your rates."],
							["One wallet", "Credit once, spend on views, likes, saves and shares."]
						].map(([title, body]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-2xl border border-white/10 bg-black/40 p-3 backdrop-blur",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-[15px] font-bold text-white",
								children: title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-[12px] text-white/75",
								children: body
							})]
						}, title))
					})
				]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomePage, {});
}
//#endregion
export { Home as component };
