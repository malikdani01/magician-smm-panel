// ==================== CONFIG ====================
const API_KEY = '590931a9fd0efdd3cb09b31ed165620ed6d06e91496087d30f52cc7ed641d4f2';
const API_URL = '/api';
const AI_PROXY = '/ai';


const ORDERS_KEY = 'organic_smm_orders';

let allServices = [];
let selectedService = null;
let currentPlatform = 'instagram';
let engagementState = {
  views: true,
  likes: true,
  comments: true,
  shares: true,
  saves: true,
  reposts: true
};

let ratios = {
  likes: 0.031,
  comments: 0.002,
  shares: 0.013,
  saves: 0.011,
  reposts: 0.008
};

// YoYo Media hard minimums (must respect when breaking curve)
const HARD_MIN = {
  Views: 100,
  Likes: 10,
  Comments: 10,
  Shares: 10,
  Saves: 10,
  Reposts: 10
};

// Known working YoYo Media service IDs (tested with this API key)
const PREFERRED_SERVICES = {
  Views: [14218, 12876, 14177, 14048, 13636, 11271, 12626],
  Likes: [14103, 14214, 13973, 13562, 13576],
  Comments: [14041, 14042],
  Shares: [10026, 13343, 4304],
  Saves: [11674, 11276, 12619],
  Reposts: [14126, 14127, 13251]
};

// ==================== NAVIGATION ====================
function showPage(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
  document.getElementById('page-' + page).classList.remove('hidden');
  
  document.querySelectorAll('.nav-btn').forEach(b => {
    b.classList.remove('bg-gradient-to-r', 'from-purple-600/20', 'to-pink-600/20', 'border', 'border-purple-500/30');
  });
  const active = document.querySelector(`[data-page="${page}"]`);
  if (active) active.classList.add('bg-gradient-to-r', 'from-purple-600/20', 'to-pink-600/20', 'border', 'border-purple-500/30');

  const titles = {
    dashboard: ['Dashboard', 'Welcome back'],
    'real-engagement': ['Real Engagement', 'AI-powered organic delivery'],
    'new-order': ['New Order', 'Place any service'],
    orders: ['Orders', 'Track your deliveries'],
    services: ['All Services', 'Full catalog'],
    settings: ['Settings', 'Configuration']
  };
  document.getElementById('page-title').textContent = titles[page][0];
  document.getElementById('page-subtitle').textContent = titles[page][1];

  if (page === 'orders') loadOrders();
  if (page === 'services') renderAllServices();
  if (page === 'real-engagement') {
    updateEngagementPreview();
    drawGraph();
    renderEngagementToggles();
  }
}

// ==================== API HELPERS ====================
async function apiCall(params) {
  const body = new URLSearchParams({ key: API_KEY, ...params });
  const res = await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body
  });
  return res.json();
}

async function loadServices() {
  try {
    const data = await apiCall({ action: 'services' });
    if (Array.isArray(data)) {
      allServices = data;
      document.getElementById('stat-services').textContent = data.length.toLocaleString();
      document.getElementById('api-status').textContent = 'Connected';
      document.getElementById('api-status').className = 'text-green-400 font-medium';
      populateCategories();
      filterServices();
      renderAllServices();
    } else {
      console.error('Services error', data);
      document.getElementById('service-list').innerHTML = '<div class="text-red-400 text-center py-6">Failed to load services.</div>';
      document.getElementById('api-status').textContent = 'Error';
      document.getElementById('api-status').className = 'text-red-400 font-medium';
    }
  } catch (e) {
    console.error(e);
    document.getElementById('api-status').textContent = 'Error';
    document.getElementById('api-status').className = 'text-red-400 font-medium';
  }
}

function populateCategories() {
  const cats = [...new Set(allServices.map(s => s.category))].sort();
  const sel = document.getElementById('service-category');
  if (sel) sel.innerHTML = '<option value="">All Categories</option>' + cats.map(c => `<option value="${c}">${c}</option>`).join('');
}

function filterServices() {
  const q = (document.getElementById('service-search')?.value || '').toLowerCase();
  const cat = document.getElementById('service-category')?.value || '';
  let list = allServices;
  if (cat) list = list.filter(s => s.category === cat);
  if (q) list = list.filter(s => s.name.toLowerCase().includes(q) || (s.category || '').toLowerCase().includes(q));
  list = list.slice(0, 80);

  const container = document.getElementById('service-list');
  if (!container) return;
  if (!list.length) {
    container.innerHTML = '<div class="text-center text-gray-500 py-8">No services found</div>';
    return;
  }
  container.innerHTML = list.map(s => `
    <div onclick="selectService(${s.service})" class="bg-dark-700 border border-dark-500 rounded-xl p-4 cursor-pointer hover:border-purple-500 transition ${selectedService?.service === s.service ? 'border-purple-500 bg-purple-500/10' : ''}">
      <div class="flex justify-between items-start gap-2">
        <div>
          <div class="font-medium text-sm">${escapeHtml(s.name)}</div>
          <div class="text-xs text-gray-500 mt-1">${escapeHtml(s.category || '')}</div>
        </div>
        <div class="text-right text-xs">
          <div class="text-purple-300 font-semibold">$${parseFloat(s.rate).toFixed(4)}</div>
          <div class="text-gray-500">Min ${s.min}</div>
        </div>
      </div>
    </div>
  `).join('');
}

function selectService(id) {
  selectedService = allServices.find(s => s.service == id);
  const el = document.getElementById('selected-service-name');
  if (el) el.textContent = selectedService ? selectedService.name : 'None';
  filterServices();
}

function renderAllServices() {
  const q = (document.getElementById('all-service-search')?.value || '').toLowerCase();
  let list = allServices;
  if (q) list = list.filter(s => s.name.toLowerCase().includes(q) || (s.category || '').toLowerCase().includes(q));
  list = list.slice(0, 60);
  const cont = document.getElementById('all-services-container');
  if (!cont) return;
  cont.innerHTML = list.map(s => `
    <div class="bg-dark-800 border border-dark-600 rounded-xl p-4">
      <div class="text-sm font-medium mb-1 line-clamp-2">${escapeHtml(s.name)}</div>
      <div class="text-xs text-gray-500 mb-2">${escapeHtml(s.category || '')}</div>
      <div class="flex justify-between text-xs">
        <span class="text-purple-300">$${parseFloat(s.rate).toFixed(4)} / 1k</span>
        <span class="text-gray-500">${s.min}–${s.max}</span>
      </div>
    </div>
  `).join('') || '<div class="text-gray-500 col-span-3 text-center py-10">No services</div>';
}

// ==================== REAL ENGAGEMENT ====================
function selectPlatform(p) {
  currentPlatform = p;
  document.getElementById('plat-instagram').className = p === 'instagram'
    ? 'platform-btn flex-1 py-3 rounded-xl border-2 border-purple-500 bg-purple-500/10 flex items-center justify-center gap-2 font-medium'
    : 'platform-btn flex-1 py-3 rounded-xl border-2 border-dark-500 bg-dark-700 flex items-center justify-center gap-2 font-medium text-gray-400';
  document.getElementById('plat-tiktok').className = p === 'tiktok'
    ? 'platform-btn flex-1 py-3 rounded-xl border-2 border-purple-500 bg-purple-500/10 flex items-center justify-center gap-2 font-medium'
    : 'platform-btn flex-1 py-3 rounded-xl border-2 border-dark-500 bg-dark-700 flex items-center justify-center gap-2 font-medium text-gray-400';
}

function setViews(v) {
  document.getElementById('re-views').value = v;
  updateEngagementPreview();
}

function setTime(h) {
  document.getElementById('re-hours').value = h;
  document.querySelectorAll('.time-btn').forEach(b => {
    b.classList.remove('bg-purple-600', 'border-purple-500');
    b.classList.add('bg-dark-700', 'border-dark-500');
  });
  if (event && event.target) {
    event.target.classList.remove('bg-dark-700', 'border-dark-500');
    event.target.classList.add('bg-purple-600', 'border-purple-500');
  }
}

function drawGraph() {
  const type = document.getElementById('re-graph')?.value || 'scurve';
  const container = document.getElementById('graph-visual');
  if (!container) return;
  const points = 12;
  let heights = [];
  for (let i = 0; i < points; i++) {
    const t = i / (points - 1);
    let h;
    if (type === 'scurve') h = 1 / (1 + Math.exp(-10 * (t - 0.5)));
    else if (type === 'linear') h = t;
    else if (type === 'spike') h = t < 0.3 ? t * 3 : Math.max(0.15, 1 - (t - 0.3) * 0.9);
    else if (type === 'viral') h = Math.pow(t, 0.35);
    else h = Math.pow(t, 2.2);
    heights.push(Math.max(0.08, Math.min(1, h)));
  }
  container.innerHTML = heights.map(h => `<div class="w-2 rounded-t bg-gradient-to-t from-purple-600 to-pink-400" style="height:${h * 100}%"></div>`).join('');
}

function updateEngagementPreview() {
  const views = parseInt(document.getElementById('re-views')?.value) || 10000;
  const graph = document.getElementById('re-graph')?.value || 'scurve';
  let likeR = 0.031, comR = 0.002, shareR = 0.013, saveR = 0.011, repR = 0.008;
  if (graph === 'viral') { likeR = 0.055; comR = 0.004; shareR = 0.022; }
  if (graph === 'slow') { likeR = 0.025; comR = 0.0015; }
  if (graph === 'spike') { likeR = 0.045; comR = 0.003; }

  ratios = { likes: likeR, comments: comR, shares: shareR, saves: saveR, reposts: repR };

  const ids = ['ratio-likes','ratio-comments','ratio-shares','ratio-saves','ratio-reposts'];
  const vals = [likeR, comR, shareR, saveR, repR];
  ids.forEach((id, i) => {
    const el = document.getElementById(id);
    if (el) el.textContent = (vals[i] * 100).toFixed(1) + '%';
  });

  const likes = Math.round(views * likeR);
  const comments = Math.max(1, Math.round(views * comR));
  const shares = Math.max(1, Math.round(views * shareR));
  const saves = Math.max(1, Math.round(views * saveR));
  const reposts = Math.max(1, Math.round(views * repR));

  let total = 0, types = 0;
  if (engagementState.views) { total += views; types++; }
  if (engagementState.likes) { total += likes; types++; }
  if (engagementState.comments) { total += comments; types++; }
  if (engagementState.shares) { total += shares; types++; }
  if (engagementState.saves) { total += saves; types++; }
  if (engagementState.reposts) { total += reposts; types++; }

  const sumEl = document.getElementById('re-summary');
  if (sumEl) sumEl.textContent = `${total.toLocaleString()} engagements • ${types} types`;
  const health = document.getElementById('health-score');
  if (health) health.textContent = `Health ${Math.min(95, 70 + Math.round(likeR * 400))}/100`;

  renderEngagementToggles(views, likes, comments, shares, saves, reposts);
}

function renderEngagementToggles(views, likes, comments, shares, saves, reposts) {
  views = views || parseInt(document.getElementById('re-views')?.value) || 10000;
  likes = likes || Math.round(views * ratios.likes);
  comments = comments || Math.max(1, Math.round(views * ratios.comments));
  shares = shares || Math.max(1, Math.round(views * ratios.shares));
  saves = saves || Math.max(1, Math.round(views * ratios.saves));
  reposts = reposts || Math.max(1, Math.round(views * ratios.reposts));

  const items = [
    { key: 'views', icon: 'fa-eye', label: 'Views', qty: views, color: 'text-purple-400' },
    { key: 'likes', icon: 'fa-heart', label: 'Likes', qty: likes, color: 'text-pink-400' },
    { key: 'comments', icon: 'fa-comment', label: 'Comments', qty: comments, color: 'text-blue-400' },
    { key: 'shares', icon: 'fa-share', label: 'Shares', qty: shares, color: 'text-green-400' },
    { key: 'saves', icon: 'fa-bookmark', label: 'Saves', qty: saves, color: 'text-yellow-400' },
    { key: 'reposts', icon: 'fa-retweet', label: 'Reposts', qty: reposts, color: 'text-cyan-400' }
  ];

  const cont = document.getElementById('engagement-toggles');
  if (!cont) return;
  cont.innerHTML = items.map(it => `
    <div class="flex items-center justify-between bg-dark-700 rounded-xl px-4 py-3 border border-dark-500">
      <div class="flex items-center gap-3">
        <i class="fas ${it.icon} ${it.color}"></i>
        <div>
          <div class="font-medium text-sm">${it.label}</div>
          <div class="text-xs text-gray-500">${it.qty.toLocaleString()}</div>
        </div>
      </div>
      <label class="relative inline-flex items-center cursor-pointer">
        <input type="checkbox" class="sr-only peer" ${engagementState[it.key] ? 'checked' : ''} onchange="toggleEng('${it.key}', this.checked)">
        <div class="w-11 h-6 bg-dark-500 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-gradient-to-r peer-checked:from-purple-500 peer-checked:to-pink-500"></div>
      </label>
    </div>
  `).join('');
}

function toggleEng(key, val) {
  engagementState[key] = val;
  updateEngagementPreview();
}

// Strict single-metric service finder — prefer known working IDs
function findService(keywords, excludeExtra = [], typeHint = null) {
  const kws = Array.isArray(keywords) ? keywords : [keywords];
  const platformHint = currentPlatform === 'instagram' ? 'instagram' : 'tiktok';

  // 1) Try preferred known-good IDs first
  if (typeHint && PREFERRED_SERVICES[typeHint] && PREFERRED_SERVICES[typeHint].length) {
    for (const id of PREFERRED_SERVICES[typeHint]) {
      const s = allServices.find(x => Number(x.service) === Number(id));
      if (s) {
        console.log('[findService] Using preferred', typeHint, id, s.name);
        return s;
      }
    }
  }

  const bad = [
    'free likes', 'free comment', 'free save', 'free share', 'free repost',
    'with likes', 'with comment', 'with save', 'with share',
    '+ free', '+like', '+ like', '+comment', '+ comment',
    'package', 'combo', 'bundle', 'mix',
    'views +', 'view +', 'likes +', 'like +', 'followers'
  ].concat((excludeExtra || []).map(x => x.toLowerCase()));

  function isClean(s) {
    const name = (s.name || '').toLowerCase();
    return !bad.some(b => name.includes(b));
  }

  function score(s) {
    const name = (s.name || '').toLowerCase();
    const cat = (s.category || '').toLowerCase();
    let sc = 0;
    if (kws.some(k => name.includes(k.toLowerCase()))) sc += 10;
    if (cat.includes(platformHint) || name.includes(platformHint)) sc += 5;
    sc -= Math.min(5, parseFloat(s.rate) || 0);
    const min = parseInt(s.min) || 100;
    if (min <= 10) sc += 3;
    else if (min <= 50) sc += 2;
    else if (min <= 100) sc += 1;
    return sc;
  }

  let candidates = allServices.filter(s => {
    const name = (s.name || '').toLowerCase();
    const cat = (s.category || '').toLowerCase();
    const matchKw = kws.some(k => name.includes(k.toLowerCase()));
    const matchPlat = cat.includes(platformHint) || name.includes(platformHint);
    return matchKw && matchPlat && isClean(s);
  });

  if (!candidates.length) {
    candidates = allServices.filter(s => {
      const name = (s.name || '').toLowerCase();
      return kws.some(k => name.includes(k.toLowerCase())) && isClean(s);
    });
  }

  if (!candidates.length) return null;
  candidates.sort((a, b) => score(b) - score(a));
  console.log('[findService] picked', candidates[0].service, candidates[0].name);
  return candidates[0];
}

function buildCurveChunks(totalQty, hours, graphType, minQ) {
  minQ = Math.max(1, parseInt(minQ) || 10);
  totalQty = parseInt(totalQty) || 0;

  // Cannot place if total below hard minimum
  if (totalQty < minQ) {
    return [];
  }

  // Max possible placements = floor(total / min)
  let maxPoints = Math.floor(totalQty / minQ);
  if (maxPoints < 1) return [];

  // Desired points from curve density
  let points = Math.max(2, Math.min(maxPoints, Math.round(hours * 1.5)));
  if (graphType === 'spike') points = Math.max(2, Math.min(maxPoints, Math.round(hours * 1.2)));
  if (graphType === 'viral') points = Math.max(2, Math.min(maxPoints, Math.round(hours * 2)));
  if (graphType === 'slow') points = Math.max(2, Math.min(maxPoints, Math.round(hours * 1.0)));
  if (graphType === 'scurve') points = Math.max(3, Math.min(maxPoints, Math.round(hours * 1.5)));
  if (graphType === 'linear') points = Math.max(2, Math.min(maxPoints, Math.round(hours * 1.3)));

  // Small totals → fewer placements
  if (totalQty < minQ * 3) points = Math.min(points, 2);
  if (totalQty < minQ * 2) points = 1;
  points = Math.min(points, maxPoints);

  // Curve weights (uneven)
  const weights = [];
  for (let i = 0; i < points; i++) {
    const t = points === 1 ? 0.5 : (i + 0.5) / points;
    let w;
    if (graphType === 'scurve') w = 1 / (1 + Math.exp(-12 * (t - 0.5)));
    else if (graphType === 'linear') w = 0.25 + t;
    else if (graphType === 'spike') w = t < 0.25 ? t * 5 : Math.max(0.08, 1.15 - (t - 0.25) * 1.35);
    else if (graphType === 'viral') w = Math.pow(t, 0.4);
    else w = Math.pow(t, 2.0); // slow
    weights.push(Math.max(0.06, w));
  }
  const sumW = weights.reduce((a, b) => a + b, 0);

  // Raw proportional quantities
  let raw = weights.map(w => (w / sumW) * totalQty);

  // Round but enforce minQ on each, then fix total
  let chunks = raw.map((q, i) => ({
    quantity: Math.max(minQ, Math.round(q)),
    delay_seconds: points === 1 ? 0 : Math.round((i / points) * hours * 3600),
    idx: i
  }));

  // Adjust sum to exactly totalQty (pull from peak / edges)
  let sum = chunks.reduce((s, c) => s + c.quantity, 0);
  let diff = totalQty - sum;

  if (diff !== 0) {
    // Sort indices by quantity descending to adjust largest first
    const order = chunks.map((c, i) => i).sort((a, b) => chunks[b].quantity - chunks[a].quantity);
    for (const i of order) {
      if (diff === 0) break;
      if (diff > 0) {
        chunks[i].quantity += diff;
        diff = 0;
      } else {
        // need to reduce
        const canReduce = chunks[i].quantity - minQ;
        if (canReduce <= 0) continue;
        const take = Math.min(canReduce, -diff);
        chunks[i].quantity -= take;
        diff += take;
      }
    }
  }

  // If still over (edge case), drop smallest extra chunks by merging
  // Final filter: only keep qty >= minQ
  chunks = chunks.filter(c => c.quantity >= minQ);

  // Re-spread delays evenly across surviving chunks for clean curve timing
  if (chunks.length >= 2) {
    const totalSec = hours * 3600;
    for (let i = 0; i < chunks.length; i++) {
      chunks[i].delay_seconds = Math.round((i / chunks.length) * totalSec);
    }
  } else if (chunks.length === 1) {
    chunks[0].delay_seconds = 0;
  }

  // Final sum safety: if sum != totalQty, put remainder on last chunk
  let finalSum = chunks.reduce((s, c) => s + c.quantity, 0);
  if (chunks.length && finalSum !== totalQty) {
    const fix = totalQty - finalSum;
    chunks[chunks.length - 1].quantity += fix;
    if (chunks[chunks.length - 1].quantity < minQ) {
      // merge into previous
      if (chunks.length >= 2) {
        chunks[chunks.length - 2].quantity += chunks[chunks.length - 1].quantity;
        chunks.pop();
      }
    }
  }

  return chunks.filter(c => c.quantity >= minQ);
}

// ==================== LIVE AI RATIOS ====================
async function getAIRatios(views, platform, graph, hours, link) {
  const prompt = `You are an Instagram/TikTok growth expert. 
Given:
- Platform: ${platform}
- Post link: ${link}
- Target views: ${views}
- Delivery window: ${hours} hours
- Desired growth curve: ${graph}

Return ONLY a valid JSON object with natural organic engagement ratios (as decimals between 0 and 0.15) that would look 100% real and not get flagged. Example format:
{"likes":0.045,"comments":0.003,"shares":0.012,"saves":0.015,"reposts":0.008,"reason":"short reason"}

Rules:
- Likes usually 3-8% of views for good content
- Comments 0.2-1.5%
- Shares/Saves 0.5-2%
- Keep it realistic for the curve type
- No markdown, only pure JSON`;

  try {
    const res = await fetch(AI_PROXY, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'openai/gpt-4o-mini',
        messages: [
          { role: 'system', content: 'You only reply with pure JSON. No markdown.' },
          { role: 'user', content: prompt }
        ],
        temperature: 0.4,
        max_tokens: 200
      })
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error.message || data.error);
    const text = data.choices?.[0]?.message?.content || '';
    // Extract JSON even if wrapped
    const match = text.match(/\{[\s\S]*\}/);
    if (!match) throw new Error('No JSON in AI response');
    const parsed = JSON.parse(match[0]);
    return {
      likes: Math.min(0.12, Math.max(0.015, parseFloat(parsed.likes) || 0.031)),
      comments: Math.min(0.03, Math.max(0.001, parseFloat(parsed.comments) || 0.002)),
      shares: Math.min(0.04, Math.max(0.005, parseFloat(parsed.shares) || 0.013)),
      saves: Math.min(0.04, Math.max(0.005, parseFloat(parsed.saves) || 0.011)),
      reposts: Math.min(0.03, Math.max(0.003, parseFloat(parsed.reposts) || 0.008)),
      reason: parsed.reason || 'AI organic mix'
    };
  } catch (e) {
    console.warn('AI ratios failed, using smart defaults:', e.message);
    // fallback
    let likeR = 0.031, comR = 0.002, shareR = 0.013, saveR = 0.011, repR = 0.008;
    if (graph === 'viral') { likeR = 0.055; comR = 0.004; shareR = 0.022; }
    if (graph === 'slow') { likeR = 0.025; comR = 0.0015; }
    if (graph === 'spike') { likeR = 0.045; comR = 0.003; }
    return { likes: likeR, comments: comR, shares: shareR, saves: saveR, reposts: repR, reason: 'Fallback smart ratios' };
  }
}

async function placeRealEngagement() {
  const link = document.getElementById('re-link')?.value.trim();
  if (!link) {
    alert('Please enter a post/video link');
    return;
  }
  const views = parseInt(document.getElementById('re-views')?.value) || 10000;
  const hours = parseInt(document.getElementById('re-hours')?.value) || 24;
  const graph = document.getElementById('re-graph')?.value || 'scurve';

  const btn = document.getElementById('btn-place-re');
  btn.disabled = true;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> AI thinking...';

  const resultBox = document.getElementById('re-result');
  resultBox.classList.remove('hidden');
  resultBox.innerHTML = '<div class="bg-dark-800 border border-purple-500/40 rounded-xl p-4 text-sm"><i class="fas fa-brain text-purple-400"></i> AI is deciding natural ratios for this post...</div>';

  // LIVE AI ratios
  const aiRatios = await getAIRatios(views, currentPlatform, graph, hours, link);
  ratios = {
    likes: aiRatios.likes,
    comments: aiRatios.comments,
    shares: aiRatios.shares,
    saves: aiRatios.saves,
    reposts: aiRatios.reposts
  };

  // Update UI badges live
  const map = { likes: 'ratio-likes', comments: 'ratio-comments', shares: 'ratio-shares', saves: 'ratio-saves', reposts: 'ratio-reposts' };
  for (const [k, id] of Object.entries(map)) {
    const el = document.getElementById(id);
    if (el) el.textContent = (ratios[k] * 100).toFixed(1) + '%';
  }
  updateEngagementPreview();

  resultBox.innerHTML = `<div class="bg-dark-800 border border-green-500/30 rounded-xl p-4 text-sm mb-3">
    <i class="fas fa-check text-green-400"></i> AI decided: ${aiRatios.reason || 'organic mix'}
    <div class="text-xs text-gray-400 mt-1">Likes ${(ratios.likes*100).toFixed(1)}% • Comments ${(ratios.comments*100).toFixed(1)}% • Shares ${(ratios.shares*100).toFixed(1)}% • Saves ${(ratios.saves*100).toFixed(1)}% • Reposts ${(ratios.reposts*100).toFixed(1)}%</div>
  </div>
  <div class="bg-dark-800 border border-dark-600 rounded-xl p-4 text-sm">Building curve schedule & sending to server...</div>`;

  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Scheduling curve orders...';

  const toPlace = [];

  if (engagementState.views) {
    const svc = findService(['views', 'reel views', 'video views'], ['like', 'comment', 'save', 'share', 'repost'], 'Views');
    if (svc) toPlace.push({ type: 'Views', service: svc, qty: views });
    else console.warn('No clean Views service found');
  }
  if (engagementState.likes) {
    const qty = Math.max(1, Math.round(views * ratios.likes));
    const svc = findService(['likes'], ['view', 'comment', 'save', 'share', 'repost', 'follower'], 'Likes');
    if (svc) toPlace.push({ type: 'Likes', service: svc, qty });
    else console.warn('No clean Likes service found');
  }
  if (engagementState.comments) {
    const qty = Math.max(1, Math.round(views * ratios.comments));
    const svc = findService(['comments'], ['view', 'like', 'save', 'share', 'repost', 'follower'], 'Comments');
    if (svc) toPlace.push({ type: 'Comments', service: svc, qty });
    else console.warn('No clean Comments service found');
  }
  if (engagementState.shares) {
    const qty = Math.max(1, Math.round(views * ratios.shares));
    const svc = findService(['shares', 'share'], ['view', 'like', 'comment', 'save', 'repost', 'follower'], 'Shares');
    if (svc) toPlace.push({ type: 'Shares', service: svc, qty });
  }
  if (engagementState.saves) {
    const qty = Math.max(1, Math.round(views * ratios.saves));
    const svc = findService(['saves', 'save', 'bookmark'], ['view', 'like', 'comment', 'share', 'repost', 'follower'], 'Saves');
    if (svc) toPlace.push({ type: 'Saves', service: svc, qty });
  }
  if (engagementState.reposts) {
    const qty = Math.max(1, Math.round(views * ratios.reposts));
    const svc = findService(['reposts', 'repost'], ['view', 'like', 'comment', 'save', 'share', 'follower'], 'Reposts');
    if (svc) toPlace.push({ type: 'Reposts', service: svc, qty });
  }

  if (!toPlace.length) {
    resultBox.innerHTML = '<div class="bg-red-900/30 border border-red-500/40 rounded-xl p-4 text-red-300">No matching services found. Load services first.</div>';
    btn.disabled = false;
    btn.innerHTML = '<i class="fas fa-rocket"></i> Place Order';
    return;
  }

  // Build curve-based schedule (NO drip-feed)
  const allJobs = [];
  let scheduleHtml = '<div class="space-y-2 max-h-60 overflow-y-auto">';

  for (const item of toPlace) {
    const serviceMin = parseInt(item.service.min) || 10;
    const hardMin = HARD_MIN[item.type] || 10;
    const minQ = Math.max(serviceMin, hardMin);
    const chunks = buildCurveChunks(item.qty, hours, graph, minQ);
    if (!chunks.length) {
      scheduleHtml += `<div class="bg-dark-700 rounded-lg px-3 py-2 text-sm">
        <span class="text-yellow-400">${item.type}</span>
        <span class="text-xs text-gray-500"> — skipped (qty ${item.qty} < service min ${minQ})</span>
      </div>`;
      continue;
    }
    for (const ch of chunks) {
      allJobs.push({
        type: item.type,
        service: item.service.service,
        quantity: ch.quantity,
        delay_seconds: ch.delay_seconds
      });
    }
    const totalChunkQty = chunks.reduce((s, c) => s + c.quantity, 0);
    const times = chunks.map(c => {
      const m = Math.round(c.delay_seconds / 60);
      return m === 0 ? 'now' : (m < 60 ? m + 'm' : (m/60).toFixed(1) + 'h');
    }).join(', ');
    scheduleHtml += `<div class="bg-dark-700 rounded-lg px-3 py-2 text-sm">
      <div class="flex justify-between">
        <span class="text-purple-300 font-medium">${item.type}</span>
        <span class="text-xs text-gray-400">${chunks.length} placements • ${totalChunkQty.toLocaleString()}</span>
      </div>
      <div class="text-xs text-gray-500 mt-1">Service #${item.service.service} (min ${minQ}) • Times: ${times}</div>
    </div>`;
  }
  scheduleHtml += '</div>';

  if (!allJobs.length) {
    resultBox.innerHTML = '<div class="bg-red-900/30 border border-red-500/40 rounded-xl p-4 text-red-300">Could not build schedule (quantities too small for service mins).</div>';
    btn.disabled = false;
    btn.innerHTML = '<i class="fas fa-rocket"></i> Place Order';
    return;
  }

  // Send schedule to server - server will place orders over time
  try {
    const res = await fetch('/schedule', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        link,
        platform: currentPlatform,
        graph,
        hours,
        views,
        ai_reason: aiRatios.reason || '',
        jobs: allJobs
      })
    });
    const data = await res.json();

    if (data.ok) {
      // Also save a local record
      const order = {
        id: data.campaign_id,
        type: 'Real Engagement Campaign',
        name: `AI + ${graph} curve`,
        qty: views,
        status: 'Running',
        link,
        time: Date.now(),
        drip: `${allJobs.length} timed placements over ${hours}h`,
        hours,
        isCampaign: true
      };
      const existing = JSON.parse(localStorage.getItem(ORDERS_KEY) || '[]');
      localStorage.setItem(ORDERS_KEY, JSON.stringify([order, ...existing].slice(0, 150)));
      updateStats();

      resultBox.innerHTML = `
        <div class="bg-dark-800 border border-green-500/40 rounded-xl p-5">
          <h4 class="font-semibold mb-2 text-green-400"><i class="fas fa-check-circle"></i> Campaign Scheduled</h4>
          <p class="text-sm text-gray-300 mb-3">Campaign ID: <b>${data.campaign_id}</b></p>
          <p class="text-xs text-gray-400 mb-3">${data.message}</p>
          ${scheduleHtml}
          <p class="text-xs text-yellow-400/80 mt-4">
            <i class="fas fa-exclamation-triangle"></i> Keep the <b>server.py</b> window open. 
            Server will place each chunk at the right time according to the ${graph} curve.
          </p>
        </div>`;
    } else {
      resultBox.innerHTML = `<div class="bg-red-900/30 border border-red-500/40 rounded-xl p-4 text-red-300">${data.error || 'Schedule failed'}</div>`;
    }
  } catch (e) {
    resultBox.innerHTML = `<div class="bg-red-900/30 border border-red-500/40 rounded-xl p-4 text-red-300">${e.message}</div>`;
  }

  btn.disabled = false;
  btn.innerHTML = '<i class="fas fa-rocket"></i> Place Order';
}


// ==================== NORMAL ORDER ====================
async function placeNormalOrder() {
  if (!selectedService) {
    alert('Select a service first');
    return;
  }
  const link = document.getElementById('order-link')?.value.trim();
  const qty = parseInt(document.getElementById('order-qty')?.value);
  if (!link || !qty) {
    alert('Enter link and quantity');
    return;
  }

  const box = document.getElementById('order-result');
  box.classList.remove('hidden');
  box.innerHTML = '<div class="text-sm text-gray-400">Placing order...</div>';

  try {
    const res = await apiCall({
      action: 'add',
      service: selectedService.service,
      link,
      quantity: qty
    });
    if (res.order) {
      const order = {
        id: String(res.order),
        type: selectedService.name,
        name: selectedService.name,
        qty,
        status: 'Pending',
        link,
        time: Date.now(),
        drip: 'Instant'
      };
      const existing = JSON.parse(localStorage.getItem(ORDERS_KEY) || '[]');
      localStorage.setItem(ORDERS_KEY, JSON.stringify([order, ...existing].slice(0, 150)));
      updateStats();
      box.innerHTML = `<div class="bg-green-900/30 border border-green-500/40 rounded-xl p-4 text-green-300"><i class="fas fa-check-circle"></i> Order #${res.order} placed successfully!</div>`;
    } else {
      box.innerHTML = `<div class="bg-red-900/30 border border-red-500/40 rounded-xl p-4 text-red-300">${res.error || JSON.stringify(res)}</div>`;
    }
  } catch (e) {
    box.innerHTML = `<div class="text-red-400">${e.message}</div>`;
  }
}

// ==================== ORDERS + LIVE STATUS ====================
function loadOrders() {
  const orders = JSON.parse(localStorage.getItem(ORDERS_KEY) || '[]');
  const cont = document.getElementById('orders-list');
  if (!cont) return;

  if (!orders.length) {
    cont.innerHTML = '<div class="text-center text-gray-500 py-16"><i class="fas fa-inbox text-4xl mb-3 opacity-30"></i><p>No orders yet.</p></div>';
    return;
  }

  cont.innerHTML = `
    <div class="mb-4 flex gap-2">
      <button onclick="refreshAllStatuses()" class="px-4 py-2 rounded-xl bg-purple-600 text-sm font-medium hover:opacity-90">
        <i class="fas fa-sync-alt mr-1"></i> Refresh All Statuses
      </button>
    </div>
  ` + orders.map(o => {
    const statusColor = {
      'Completed': 'bg-green-500/20 text-green-300',
      'Partial': 'bg-yellow-500/20 text-yellow-300',
      'In progress': 'bg-blue-500/20 text-blue-300',
      'Processing': 'bg-blue-500/20 text-blue-300',
      'Pending': 'bg-gray-500/20 text-gray-300',
      'Canceled': 'bg-red-500/20 text-red-300',
      'Cancelled': 'bg-red-500/20 text-red-300'
    }[o.status] || 'bg-gray-500/20 text-gray-300';

    return `
    <div class="bg-dark-800 border border-dark-600 rounded-xl p-4 flex justify-between items-center gap-4">
      <div class="min-w-0">
        <div class="font-medium text-sm truncate">#${o.id} — ${escapeHtml(o.type || o.name || '')}</div>
        <div class="text-xs text-gray-500 mt-1">${(o.qty || 0).toLocaleString()} • ${new Date(o.time).toLocaleString()}</div>
        <div class="text-xs text-gray-600 truncate max-w-md">${escapeHtml(o.link || '')}</div>
        ${o.drip ? `<div class="text-xs text-purple-400 mt-1"><i class="fas fa-clock"></i> ${o.drip}</div>` : ''}
      </div>
      <div class="text-right shrink-0">
        <span class="text-xs px-2 py-1 rounded-full ${statusColor}" id="status-${o.id}">${o.status || 'Pending'}</span>
        <button onclick="checkStatus('${o.id}')" class="block mt-2 text-xs text-purple-400 hover:underline">Check Status</button>
      </div>
    </div>`;
  }).join('');
}

async function checkStatus(orderId) {
  const statusEl = document.getElementById('status-' + orderId);
  if (statusEl) statusEl.textContent = 'Checking...';

  try {
    const res = await apiCall({ action: 'status', order: orderId });
    let newStatus = res.status || res.error || 'Unknown';
    
    // Update localStorage
    const orders = JSON.parse(localStorage.getItem(ORDERS_KEY) || '[]');
    const idx = orders.findIndex(o => String(o.id) === String(orderId));
    if (idx !== -1) {
      orders[idx].status = newStatus;
      if (res.remains !== undefined) orders[idx].remains = res.remains;
      if (res.charge !== undefined) orders[idx].charge = res.charge;
      if (res.start_count !== undefined) orders[idx].start_count = res.start_count;
      localStorage.setItem(ORDERS_KEY, JSON.stringify(orders));
    }

    if (statusEl) {
      statusEl.textContent = newStatus;
      statusEl.className = 'text-xs px-2 py-1 rounded-full ' + ({
        'Completed': 'bg-green-500/20 text-green-300',
        'Partial': 'bg-yellow-500/20 text-yellow-300',
        'In progress': 'bg-blue-500/20 text-blue-300',
        'Processing': 'bg-blue-500/20 text-blue-300',
        'Pending': 'bg-gray-500/20 text-gray-300',
        'Canceled': 'bg-red-500/20 text-red-300',
        'Cancelled': 'bg-red-500/20 text-red-300'
      }[newStatus] || 'bg-gray-500/20 text-gray-300');
    }

    updateStats();
  } catch (e) {
    if (statusEl) statusEl.textContent = 'Error';
    alert('Status check failed: ' + e.message);
  }
}

async function refreshAllStatuses() {
  const orders = JSON.parse(localStorage.getItem(ORDERS_KEY) || '[]');
  if (!orders.length) return;

  const btn = event?.target;
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-1"></i> Refreshing...';
  }

  // Batch status check (API supports multiple)
  const ids = orders.map(o => o.id).slice(0, 50).join(',');
  try {
    const res = await apiCall({ action: 'status', orders: ids });
    // res is object keyed by order id
    if (res && typeof res === 'object') {
      for (const o of orders) {
        const info = res[o.id] || res[String(o.id)];
        if (info && !info.error) {
          o.status = info.status || o.status;
          o.remains = info.remains;
          o.charge = info.charge;
          o.start_count = info.start_count;
        }
      }
      localStorage.setItem(ORDERS_KEY, JSON.stringify(orders));
    }
  } catch (e) {
    // fallback: check one by one
    for (const o of orders.slice(0, 15)) {
      await checkStatus(o.id);
    }
  }

  loadOrders();
  updateStats();
  if (btn) {
    btn.disabled = false;
    btn.innerHTML = '<i class="fas fa-sync-alt mr-1"></i> Refresh All Statuses';
  }
}

function updateStats() {
  const orders = JSON.parse(localStorage.getItem(ORDERS_KEY) || '[]');
  const el = (id) => document.getElementById(id);
  if (el('stat-orders')) el('stat-orders').textContent = orders.length;
  if (el('stat-active')) el('stat-active').textContent = orders.filter(o => 
    ['Pending', 'In progress', 'Processing', 'Partial'].includes(o.status)
  ).length;
  if (el('stat-completed')) el('stat-completed').textContent = orders.filter(o => 
    o.status === 'Completed'
  ).length;
}

// ==================== UTILS ====================
function escapeHtml(str) {
  if (!str) return '';
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// ==================== INIT ====================
document.addEventListener('DOMContentLoaded', () => {
  showPage('dashboard');
  loadServices();
  updateStats();
  drawGraph();
  updateEngagementPreview();
});
