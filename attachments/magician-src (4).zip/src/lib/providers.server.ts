import { readFileSync } from "node:fs";

const FREE_MODELS = [
  "google/gemma-4-26b-a4b-it:free",
  "nvidia/nemotron-3-super-120b-a12b:free",
  "thinkingmachines/inkling-small:free",
];

type Secrets = { openrouter: string; yoyomedia: string };

export type LiveService = {
  id: number;
  platform: string;
  category: string;
  name: string;
  min: number;
  max: number;
  rateUsd: number;
  note: string;
  dripAllowed: boolean;
  managedId?: string;
  providerName?: string;
};

type RawService = {
  service: number | string;
  name: string;
  type?: string;
  category: string;
  rate: string | number;
  min: string | number;
  max: string | number;
  refill?: boolean;
  dripfeed?: boolean;
  description?: string;
};

type ProviderLine = {
  engagement_type: string;
  quantity: number;
  runs?: number;
  intervalMinutes?: number;
  serviceId?: string;
  apiUrl?: string;
  apiKey?: string;
};
export type PlacedLine = { engagement_type: string; providerOrderId: string; label: string };

let catalogCache: { at: number; rows: RawService[] } | null = null;
let balanceCache: { at: number; balanceUsd: number; currency: string } | null = null;

function secrets(): Secrets {
  const fromEnv = {
    openrouter: process.env.OPENROUTER_API_KEY || "",
    yoyomedia: process.env.YOYOMEDIA_API_KEY || "",
  };
  if (fromEnv.openrouter && fromEnv.yoyomedia) return fromEnv;
  const candidates = [
    process.env.PROVIDERS_FILE || "",
    `${process.cwd()}/.secrets/providers.json`,
    "/workspace/.secrets/providers.json",
  ].filter(Boolean);
  let file: Secrets = { openrouter: "", yoyomedia: "" };
  for (const path of candidates) {
    try {
      file = JSON.parse(readFileSync(path, "utf8")) as Secrets;
      break;
    } catch {
      /* try the next location */
    }
  }
  return {
    openrouter: fromEnv.openrouter || file.openrouter,
    yoyomedia: fromEnv.yoyomedia || file.yoyomedia,
  };
}

async function yoyo(fields: Record<string, string>, apiUrl?: string, apiKey?: string) {
  const sent = await yoyoRaw(fields, apiUrl, apiKey);
  if (fields.action === "add") {
    if (!sent.order) throw new Error(sent.error || "Provider rejected the order.");
    return { order: sent.order } as Record<string, unknown>;
  }
  if (sent.error && !sent.raw.trim().startsWith("[") && !sent.raw.trim().startsWith("{")) {
    throw new Error(sent.error);
  }
  try {
    return JSON.parse(sent.raw) as Record<string, unknown>;
  } catch {
    throw new Error(sent.error || "Provider returned an unreadable response.");
  }
}

export const NO_PROVIDER = "No Provider Available";

const catalogMemo = new Map<string, { at: number; rows: RawService[] }>();

async function yoyoRaw(fields: Record<string, string>, apiUrl?: string, apiKey?: string) {
  const key = String(apiKey || "").trim();
  const url = String(apiUrl || "").trim();
  if (!key || !url) return { order: "", error: NO_PROVIDER, raw: "" };
  const body = new URLSearchParams({ key, ...fields });
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body,
    });
    const raw = await response.text();
    let json: Record<string, unknown> = {};
    try {
      json = JSON.parse(raw) as Record<string, unknown>;
    } catch {
      return { order: "", error: raw.slice(0, 180) || `HTTP ${response.status}`, raw };
    }
    const order = json.order != null && String(json.order) !== "" && String(json.order) !== "0" ? String(json.order) : "";
    const error = typeof json.error === "string" && json.error ? json.error : "";
    return { order, error, raw };
  } catch (error) {
    return { order: "", error: error instanceof Error ? error.message : "Network error", raw: "" };
  }
}

export function readRemains(status: string, remains: string) {
  const text = String(status || "").toLowerCase();
  if (text.includes("complete")) return 0;
  const raw = String(remains ?? "").trim();
  if (!raw) return null;
  const value = Number(raw);
  if (!Number.isFinite(value)) return null;
  return Math.max(0, value);
}

export async function providerOrderStatus(orderId: string, apiUrl?: string, apiKey?: string) {
  const json = await yoyo({ action: "status", order: orderId }, apiUrl, apiKey);
  return {
    status: String(json.status || "unknown"),
    remains: String(json.remains ?? ""),
    startCount: String(json.start_count ?? ""),
  };
}

export async function fetchProviderCatalog(apiUrl?: string, apiKey?: string) {
  const url = String(apiUrl || "").trim();
  const key = String(apiKey || "").trim();
  const cacheKey = `${url}|${key}`;
  const hit = catalogMemo.get(cacheKey);
  if (hit && Date.now() - hit.at < 60_000) return hit.rows;
  const rows = (await yoyo({ action: "services" }, url, key)) as unknown as RawService[];
  if (!Array.isArray(rows)) throw new Error("Provider did not return a service list.");
  catalogMemo.set(cacheKey, { at: Date.now(), rows });
  return rows;
}

export function detectPlatform(category: string, name: string) {
  const text = `${category} ${name}`.toLowerCase();
  if (/instagram|\bigtv\b/.test(text)) return "instagram";
  if (/tik\s?tok/.test(text)) return "tiktok";
  if (/you\s?tube/.test(text)) return "youtube";
  if (/facebook/.test(text)) return "facebook";
  if (/twitter|retweet/.test(text)) return "twitter";
  if (/telegram/.test(text)) return "telegram";
  if (/whats\s?app/.test(text)) return "whatsapp";
  if (/spotify/.test(text)) return "spotify";
  if (/linkedin/.test(text)) return "linkedin";
  if (/discord/.test(text)) return "discord";
  if (/twitch/.test(text)) return "twitch";
  if (/snapchat/.test(text)) return "snapchat";
  if (/kwai/.test(text)) return "kwai";
  return "other";
}

export async function savedProviderKeys() {
  const { bindingMap } = await import("@/lib/admin.server");
  const map = await bindingMap();
  const found: { apiUrl: string; apiKey: string }[] = [];
  for (const slot of Object.values(map)) {
    for (const item of slot.providers || []) {
      const apiKey = String(item.api_key || "").trim();
      const apiUrl = String(item.api_url || "").trim();
      if (!apiKey || !apiUrl) continue;
      if (found.some((row) => row.apiKey === apiKey && row.apiUrl === apiUrl)) continue;
      found.push({ apiUrl, apiKey });
    }
  }
  return found;
}

async function rawServices() {
  if (catalogCache && Date.now() - catalogCache.at < 60_000) return catalogCache.rows;
  const keys = await savedProviderKeys();
  if (keys.length === 0) return [] as RawService[];
  const merged: RawService[] = [];
  for (const key of keys) {
    try {
      const rows = await fetchProviderCatalog(key.apiUrl, key.apiKey);
      for (const row of rows) merged.push(row);
    } catch {
      /* skip a provider that does not answer */
    }
  }
  catalogCache = { at: Date.now(), rows: merged };
  return merged;
}

function toLive(row: RawService): LiveService {
  const note = String(row.description || row.type || "").split("\n").map((line) => line.trim()).filter(Boolean)[0] || "";
  return {
    id: Number(row.service),
    platform: detectPlatform(row.category, row.name),
    category: row.category,
    name: row.name,
    min: Number(row.min) || 1,
    max: Number(row.max) || 1,
    rateUsd: Number(row.rate) || 0,
    note: note.slice(0, 180),
    dripAllowed: Boolean(row.dripfeed),
  };
}

export async function providerBalance() {
  if (balanceCache && Date.now() - balanceCache.at < 60 * 1000) return balanceCache;
  const keys = await savedProviderKeys();
  const first = keys[0];
  if (!first) return { at: Date.now(), balanceUsd: 0, currency: "USD" };
  const json = await yoyo({ action: "balance" }, first.apiUrl, first.apiKey);
  balanceCache = { at: Date.now(), balanceUsd: Number(json.balance) || 0, currency: String(json.currency || "USD") };
  return balanceCache;
}

export type ApiBalance = {
  label: string;
  host: string;
  keyTail: string;
  balance: number;
  currency: string;
  low: boolean;
  error: string;
};

function hostOf(url: string) {
  try {
    return new URL(url).host;
  } catch {
    return url.slice(0, 42);
  }
}

export async function listApiBalances(): Promise<ApiBalance[]> {
  const found: { label: string; apiUrl: string; apiKey: string }[] = [];
  const push = (label: string, apiUrl?: string | null, apiKey?: string | null) => {
    const url = String(apiUrl || "").trim();
    const key = String(apiKey || "").trim();
    if (!url || !key) return;
    const existing = found.find((item) => item.apiUrl === url && item.apiKey === key);
    if (existing) {
      if (!existing.label.includes(label)) existing.label = `${existing.label} · ${label}`;
      return;
    }
    found.push({ label, apiUrl: url, apiKey: key });
  };
  try {
    const { bindingMap } = await import("@/lib/admin.server");
    const map = await bindingMap();
    for (const [slot, row] of Object.entries(map)) {
      const providers = row.providers?.length ? row.providers : [{ api_url: row.api_url, api_key: row.api_key }];
      providers.forEach((item, index) => push(providers.length > 1 ? `${slot} #${index + 1}` : slot, item.api_url, item.api_key));
    }
  } catch {
    /* bindings optional */
  }
  try {
    const { getSql } = await import("@/lib/db");
    const sql = await getSql();
    const extra = await sql<{ name: string; api_url: string; api_key: string }>`select name, api_url, api_key from smm_providers where enabled = true`;
    for (const row of extra) push(row.name || "Service API", row.api_url, row.api_key);
  } catch {
    /* provider table can be empty */
  }
  const rows = await Promise.all(found.map(async (item) => {
    try {
      const json = await yoyo({ action: "balance" }, item.apiUrl, item.apiKey);
      const balance = Number(json.balance);
      const amount = Number.isFinite(balance) ? balance : 0;
      return {
        label: item.label,
        host: hostOf(item.apiUrl),
        keyTail: item.apiKey.slice(-4),
        balance: amount,
        currency: String(json.currency || "USD"),
        low: amount < 5,
        error: "",
      };
    } catch (error) {
      return {
        label: item.label,
        host: hostOf(item.apiUrl),
        keyTail: item.apiKey.slice(-4),
        balance: 0,
        currency: "",
        low: true,
        error: error instanceof Error ? error.message : "Balance failed",
      };
    }
  }));
  return rows.sort((a, b) => Number(a.error !== "") - Number(b.error !== "") || a.balance - b.balance);
}

export async function browseProvider(input: { platform: string; category: string; query: string }) {
  const rows = (await rawServices()).map(toLive).filter((row) => input.platform === "all" || row.platform === input.platform);
  const names = Array.from(new Set(rows.map((row) => row.category))).sort((a, b) => a.localeCompare(b));
  const categories = input.platform === "all" ? ["All categories", ...names] : names;
  const category = categories.includes(input.category) ? input.category : categories[0] || "";
  const query = input.query.trim().toLowerCase();
  let services = category === "All categories" ? rows : rows.filter((row) => row.category === category);
  if (query) {
    services = rows.filter((row) => `${row.id} ${row.name} ${row.category}`.toLowerCase().includes(query));
  }
  const cap = category === "All categories" && !query ? rows.length : 200;
  return { categories, category, services: services.slice(0, cap) };
}

export async function findLiveService(id: number) {
  const row = (await rawServices()).find((item) => Number(item.service) === id);
  return row ? toLive(row) : null;
}

const TYPE_RULE: Record<string, { yes: RegExp; no: RegExp }> = {
  views: { yes: /\bviews?\b/, no: /\b(likes?|shares?|saves?|favourites?|favorites?|comments?|followers?|reposts?|subscribers?)\b/ },
  likes: { yes: /\blikes?\b/, no: /\b(views?|shares?|saves?|favourites?|favorites?|comments?|followers?|reposts?|subscribers?|live)\b/ },
  comments: { yes: /\bcomments?\b/, no: /\b(views?|likes?|shares?|saves?|favourites?|favorites?|followers?|reposts?|live)\b/ },
  shares: { yes: /\bshares?\b/, no: /\b(views?|likes?|saves?|favourites?|favorites?|comments?|followers?|reposts?|live)\b/ },
  saves: { yes: /\b(saves?|favourites?|favorites?)\b/, no: /\b(views?|likes?|shares?|comments?|followers?|reposts?|live)\b/ },
  reposts: { yes: /\breposts?\b/, no: /\b(views?|likes?|shares?|saves?|favourites?|favorites?|comments?|followers?|live)\b/ },
  followers: { yes: /\bfollowers?\b/, no: /\b(views?|likes?|shares?|saves?|favourites?|favorites?|comments?|reposts?)\b/ },
};

export async function pickRandomService(platform: string, type: string, quantity: number, apiUrl?: string, apiKey?: string) {
  const rows = await fetchProviderCatalog(apiUrl, apiKey);
  const rule = TYPE_RULE[type] || { yes: new RegExp(`\\b${type}\\b`, "i"), no: /$^/ };
  const candidates = rows.filter((row) => {
    if (detectPlatform(row.category, row.name) !== platform) return false;
    if (row.type && row.type !== "Default") return false;
    const name = String(row.name || "").toLowerCase();
    if (!rule.yes.test(name) || rule.no.test(name)) return false;
    if (/combo|package|\+|free /.test(name)) return false;
    if (serviceTier(row) === "reject") return false;
    const min = Number(row.min);
    const max = Number(row.max);
    return quantity >= min && quantity <= max;
  });
  if (candidates.length === 0) return null;
  candidates.sort((a, b) => {
    const tier = (row: RawService) => (serviceTier(row) === "good" ? 1 : 0);
    return tier(b) - tier(a) || stableScore(b) - stableScore(a) || Number(a.rate) - Number(b.rate);
  });
  const choice = candidates[0];
  return { serviceId: String(choice.service), name: String(choice.name) };
}

type DropRead = { nonDrop: boolean; unknown: boolean; maxPct: number | null; noRefill: boolean };

function readDrop(text: string): DropRead {
  const nonDrop = /non[-\s]?drop|no[-\s]?drop|nondrop|drop\s*:\s*non\s*drop/.test(text);
  const unknown = /drop\s*:\s*unknown/.test(text);
  const noRefill = /no[-\s]?refill|without refill|non[-\s]?refill/.test(text);
  let maxPct: number | null = null;
  for (const match of text.matchAll(/drop\s*:\s*(\d+(?:\.\d+)?)\s*(?:-|–|to)?\s*(\d+(?:\.\d+)?)?\s*%/gi)) {
    const low = Number(match[1]);
    const high = match[2] ? Number(match[2]) : low;
    const top = Math.max(low, high);
    if (Number.isFinite(top)) maxPct = maxPct == null ? top : Math.max(maxPct, top);
  }
  return { nonDrop, unknown, maxPct, noRefill };
}

function qualityScore(text: string, refillFlag: boolean) {
  let score = 0;
  if (/non[-\s]?drop|no[-\s]?drop|nondrop|drop\s*:\s*non\s*drop/.test(text)) score += 100;
  if (/\bstable\b/.test(text)) score += 80;
  if (/guaranteed|guarantee/.test(text)) score += 70;
  if (/\brefill\b/.test(text) || refillFlag) score += 40;
  return score;
}

/** good = non-drop / stable / guaranteed / refill and drop % is missing or ≤ 15. soft = last resort, drop 10–15% only. */
export function serviceTier(row: RawService): "good" | "soft" | "reject" {
  const text = `${row.name || ""} ${row.category || ""} ${row.description || ""}`.toLowerCase();
  const info = readDrop(text);
  if (info.noRefill || info.unknown) return "reject";
  if (info.maxPct != null && info.maxPct > 15) return "reject";
  const quality = qualityScore(text, Boolean(row.refill));
  if (quality > 0) return "good";
  if (info.maxPct != null && info.maxPct >= 10 && info.maxPct <= 15) return "soft";
  return "reject";
}

function stableScore(row: RawService) {
  if (serviceTier(row) === "reject") return 0;
  const text = `${row.name || ""} ${row.category || ""} ${row.description || ""}`.toLowerCase();
  return qualityScore(text, Boolean(row.refill)) || (serviceTier(row) === "soft" ? 1 : 0);
}

function matchService(rows: RawService[], platform: string, type: string, quantity: number, preferDrip = false) {
  const rule = TYPE_RULE[type] || { yes: new RegExp(`\\b${type}\\b`, "i"), no: /$^/ };
  const candidates = rows.filter((row) => {
    if (detectPlatform(row.category, row.name) !== platform) return false;
    if (row.type && row.type !== "Default") return false;
    const name = String(row.name || "").toLowerCase();
    if (!rule.yes.test(name) || rule.no.test(name)) return false;
    if (/combo|package|\+|free /.test(name)) return false;
    if (serviceTier(row) === "reject") return false;
    const min = Number(row.min);
    const max = Number(row.max);
    return quantity >= min && quantity <= max;
  });
  candidates.sort((a, b) => {
    const tier = (row: RawService) => (serviceTier(row) === "good" ? 1 : 0);
    return tier(b) - tier(a) || stableScore(b) - stableScore(a) || Number(a.rate) - Number(b.rate);
  });
  const pool = preferDrip && candidates.some((row) => row.dripfeed) ? candidates.filter((row) => row.dripfeed) : candidates;
  return pool[0] || null;
}

type RoutedChoice = {
  id: string;
  name: string;
  score: number;
  tier: "good" | "soft";
  rate: number;
  apiUrl: string;
  apiKey: string;
  ms: number;
  fresh: boolean;
  pending: number;
  reusedService: boolean;
};

export async function placeChunk(input: {
  platform: string;
  type: string;
  link: string;
  quantity: number;
  providers?: { apiUrl?: string; apiKey?: string }[];
  apiUrl?: string;
  apiKey?: string;
  usedKeys?: string[];
  usedServiceIds?: Record<string, string[]>;
  pendingByKey?: Record<string, number>;
}) {
  const qty = Math.max(1, Math.floor(input.quantity));
  const providers = (input.providers?.length ? input.providers : [{ apiUrl: input.apiUrl, apiKey: input.apiKey }])
    .map((item) => ({ apiUrl: String(item.apiUrl || "").trim(), apiKey: String(item.apiKey || "").trim() }))
    .filter((item) => item.apiKey && item.apiUrl);
  if (providers.length === 0) throw new Error(NO_PROVIDER);
  const rule = TYPE_RULE[input.type] || { yes: new RegExp(`\\b${input.type}\\b`, "i"), no: /$^/ };
  const used = new Set((input.usedKeys || []).map((key) => key.trim()).filter(Boolean));
  const pendingByKey = input.pendingByKey || {};
  const usedServices = input.usedServiceIds || {};
  const scans = await Promise.all(providers.map(async (provider) => {
    const started = Date.now();
    try {
      const rows = await fetchProviderCatalog(provider.apiUrl, provider.apiKey);
      return { provider, rows, ms: Date.now() - started };
    } catch (error) {
      const message = error instanceof Error ? error.message : "catalog failed";
      console.log(`[drops] catalog skip ${provider.apiUrl}: ${message}`);
      return { provider, rows: [] as RawService[], ms: Date.now() - started };
    }
  }));
  const choices: RoutedChoice[] = [];
  for (const scan of scans) {
    const fresh = !used.has(scan.provider.apiKey);
    const pending = pendingByKey[scan.provider.apiKey] ?? 0;
    const seen = new Set(usedServices[scan.provider.apiKey] || []);
    for (const row of scan.rows) {
      if (detectPlatform(row.category, row.name) !== input.platform) continue;
      if (row.type && row.type !== "Default") continue;
      const name = String(row.name || "").toLowerCase();
      if (!rule.yes.test(name) || rule.no.test(name)) continue;
      if (/combo|package|\+|free /.test(name)) continue;
      const tier = serviceTier(row);
      if (tier === "reject") continue;
      if (qty < Number(row.min) || qty > Number(row.max)) continue;
      const id = String(row.service);
      choices.push({
        id,
        name: String(row.name || `Service ${row.service}`),
        score: stableScore(row),
        tier,
        rate: Number(row.rate) || 0,
        apiUrl: scan.provider.apiUrl,
        apiKey: scan.provider.apiKey,
        ms: scan.ms,
        fresh,
        pending,
        reusedService: seen.has(id),
      });
    }
  }
  const ranked = [...choices].sort((a, b) => {
    if (a.tier !== b.tier) return a.tier === "good" ? -1 : 1;
    if (a.fresh !== b.fresh) return a.fresh ? -1 : 1;
    if (a.pending !== b.pending) return a.pending - b.pending;
    if (a.reusedService !== b.reusedService) return a.reusedService ? 1 : -1;
    if (b.score !== a.score) return b.score - a.score;
    if (a.ms !== b.ms) return a.ms - b.ms;
    return a.rate - b.rate;
  });
  const unique: RoutedChoice[] = [];
  for (const choice of ranked) {
    if (unique.some((item) => item.apiKey === choice.apiKey && item.id === choice.id)) continue;
    unique.push(choice);
    if (unique.length === 8) break;
  }
  if (unique.length === 0) throw new Error(`No non-drop ${input.platform} ${input.type} service accepts quantity ${qty}.`);
  const goods = unique.filter((item) => item.tier === "good");
  const softs = unique.filter((item) => item.tier === "soft");
  const queue = goods.length ? goods.slice(0, 4) : softs.slice(0, 2);
  console.log(`[drops] ${input.type} x${qty} queue: ${queue.slice(0, 3).map((item) => `#${item.id} ${item.fresh ? "fresh" : "return"} ${item.tier} ${item.name}`).join(" | ")}`);
  let last = "Provider rejected the order.";
  const tryChoice = async (choice: RoutedChoice) => {
    const sent = await yoyoRaw({
      action: "add",
      service: choice.id,
      link: input.link.trim(),
      quantity: String(qty),
    }, choice.apiUrl, choice.apiKey);
    if (sent.order) {
      console.log(`[drops] placed once on #${choice.id} via ${choice.apiUrl}. Other APIs were not used.`);
      return { orderId: sent.order, serviceId: choice.id, label: choice.name, apiUrl: choice.apiUrl, apiKey: choice.apiKey };
    }
    last = sent.error || last;
    console.log(`[drops] #${choice.id} refused, trying next eligible only: ${last}`);
    return null;
  };
  for (const choice of queue) {
    const placed = await tryChoice(choice);
    if (placed) return placed;
  }
  if (goods.length) {
    for (const choice of softs.slice(0, 2)) {
      const placed = await tryChoice(choice);
      if (placed) return placed;
    }
  }
  throw new Error(last);
}

async function cancelOrders(ids: string[]) {
  await Promise.all(ids.map(async (id) => {
    try {
      await yoyo({ action: "cancel", order: id });
    } catch {
      /* provider may reject cancel; the caller still surfaces the original error */
    }
  }));
}

export async function placeProviderLines(platform: string, link: string, lines: ProviderLine[]): Promise<PlacedLine[]> {
  const placed: PlacedLine[] = [];
  try {
    for (const line of lines) {
      if (!line.apiKey || !line.apiUrl) throw new Error(NO_PROVIDER);
      const sent = await placeChunk({
        platform,
        type: line.engagement_type,
        link,
        quantity: line.quantity,
        providers: [{ apiUrl: line.apiUrl, apiKey: line.apiKey }],
      });
      placed.push({
        engagement_type: line.engagement_type,
        providerOrderId: sent.orderId,
        label: sent.label,
      });
    }
    return placed;
  } catch (error) {
    await cancelOrders(placed.map((line) => line.providerOrderId));
    throw error;
  }
}

export async function placeExactOnProvider(input: {
  serviceId: string;
  link: string;
  quantity: number;
  apiUrl?: string;
  apiKey?: string;
}) {
  const sent = await yoyoRaw({
    action: "add",
    service: String(input.serviceId),
    link: input.link.trim(),
    quantity: String(Math.max(1, Math.floor(input.quantity))),
  }, input.apiUrl, input.apiKey);
  if (!sent.order) throw new Error(sent.error || "Provider rejected this order.");
  return { orderId: sent.order, serviceId: String(input.serviceId) };
}

export async function placeExactService() {
  throw new Error(NO_PROVIDER);
}

export async function liveRateMap() {
  const keys = await savedProviderKeys();
  try {
    const { getSql } = await import("@/lib/db");
    const sql = await getSql();
    const extra = await sql<{ api_url: string; api_key: string }>`select api_url, api_key from smm_providers where enabled = true`;
    for (const row of extra) {
      const apiUrl = String(row.api_url || "").trim();
      const apiKey = String(row.api_key || "").trim();
      if (!apiUrl || !apiKey) continue;
      if (keys.some((item) => item.apiKey === apiKey && item.apiUrl === apiUrl)) continue;
      keys.push({ apiUrl, apiKey });
    }
  } catch {
    /* managed provider table can be empty */
  }
  const map: Record<string, number> = {};
  for (const key of keys) {
    try {
      const rows = await fetchProviderCatalog(key.apiUrl, key.apiKey);
      for (const row of rows) {
        const id = String(row.service);
        const rate = Number(row.rate) || 0;
        if (rate > 0 && (map[id] == null || rate < map[id])) map[id] = rate;
      }
    } catch {
      /* one provider can be down */
    }
  }
  return map;
}

export async function liveTypeRates(platform: string) {
  const { bindingMap } = await import("@/lib/admin.server");
  const map = await bindingMap();
  const rates: Record<string, number> = {};
  for (const type of ["views", "likes", "saves", "shares", "reposts"]) {
    const slot = map[`${platform}:${type}`];
    const providers = (slot?.providers || []).filter((item) => item.api_key && item.api_url);
    let best = 0;
    for (const provider of providers) {
      try {
        const rows = await fetchProviderCatalog(provider.api_url, provider.api_key);
        for (const row of rows) {
          if (detectPlatform(row.category, row.name) !== platform) continue;
          if (serviceTier(row) !== "good") continue;
          const rule = TYPE_RULE[type];
          const name = String(row.name || "").toLowerCase();
          if (!rule?.yes.test(name) || rule.no.test(name)) continue;
          const rate = Number(row.rate) || 0;
          if (rate > 0 && (best === 0 || rate < best)) best = rate;
        }
      } catch {
        /* one provider can be down */
      }
    }
    if (best > 0) rates[type] = best;
  }
  return rates;
}

export async function cancelProviderOrder(id: string) {
  await cancelOrders([id]);
}

export async function askFreeModel(system: string, prompt: string) {
  const key = secrets().openrouter;
  if (!key) throw new Error("OpenRouter key is missing.");
  let last = "The free model did not answer.";
  for (const model of FREE_MODELS) {
    try {
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${key}`,
          "Content-Type": "application/json",
          "HTTP-Referer": "http://127.0.0.1:8080",
          "X-Title": "Magiciansmm",
        },
        body: JSON.stringify({
          model,
          messages: [
            { role: "system", content: system },
            { role: "user", content: prompt },
          ],
          max_tokens: 400,
          temperature: 0.2,
        }),
      });
      const json = (await response.json()) as {
        error?: { message?: string };
        choices?: { message?: { content?: string | null; reasoning?: string | null } }[];
      };
      if (!response.ok) throw new Error(json.error?.message || `${model} failed.`);
      const message = json.choices?.[0]?.message;
      const text = (message?.content || message?.reasoning || "").trim();
      if (!text) throw new Error(`${model} returned an empty reply.`);
      return text;
    } catch (error) {
      last = error instanceof Error ? error.message : last;
    }
  }
  throw new Error(last);
}
