import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import {
  addCustomService,
  adminGateways,
  creditCustomer,
  deskRole,
  listBindings,
  listClaims,
  listCustomers,
  listManaged,
  myClaims,
  paymentDesk,
  publicGateways,
  removeCustomer,
  requireAdmin,
  reviewClaim,
  saveBindings,
  saveGateway,
  saveManaged,
  savePaymentDesk,
  saveProvider,
  listProviders,
  syncProviderCatalog,
  submitClaim,
  syncManagedServices,
  type Binding,
} from "@/lib/admin.server";

export const getDeskRole = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => deskRole(context.userId));

export const adminBindings = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    return listBindings();
  });

export const adminSaveBindings = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: Binding[]) => {
    if (!Array.isArray(input)) throw new Error("Missing configuration.");
    return input.slice(0, 16).map((row) => ({
      slot: String(row.slot || ""),
      api_url: String(row.api_url || ""),
      api_key: String(row.api_key || ""),
      service_id: "",
      pick_mode: "auto",
      min_quantity: Math.max(1, Math.floor(Number(row.min_quantity) || 1)),
      price_per_1k_paise: Math.max(0, Math.round(Number(row.price_per_1k_paise) || 0)),
      providers: (Array.isArray(row.providers) ? row.providers : [])
        .slice(0, 8)
        .map((item) => ({
          api_url: String(item?.api_url || ""),
          api_key: String(item?.api_key || ""),
        }))
        .filter((item) => item.api_key.trim()),
    }));
  })
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    await saveBindings(data);
    return { ok: true as const };
  });

export const adminProviders = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    return listProviders();
  });

export const adminSaveProvider = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id?: string; name: string; api_url: string; api_key: string; enabled: boolean }) => input)
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    const id = await saveProvider(data);
    return { id };
  });

export const adminFetchProvider = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: string) => {
    if (!id) throw new Error("Missing provider.");
    return String(id);
  })
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    return syncProviderCatalog(data);
  });

export const adminServices = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((query: string) => String(query || "").slice(0, 80))
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    return listManaged(data);
  });

export const adminSyncServices = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    return syncManagedServices();
  });

export const adminSaveService = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: {
    id: string;
    provider_service_id: string;
    platform: string;
    category: string;
    name: string;
    description: string;
    price_per_1k_paise: number;
    min_quantity: number;
    max_quantity: number;
    drip_allowed: boolean;
    enabled: boolean;
  }) => input)
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    await saveManaged(data);
    return { ok: true as const };
  });

export const adminAddService = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: {
    provider_service_id: string;
    platform: string;
    category: string;
    name: string;
    description: string;
    price_per_1k_paise: number;
    min_quantity: number;
    max_quantity: number;
    drip_allowed: boolean;
    enabled: boolean;
  }) => {
    if (!input?.name?.trim() || !input?.provider_service_id?.trim()) throw new Error("Service id and name are required.");
    return input;
  })
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    const id = await addCustomService(data);
    return { id };
  });

export const adminCustomers = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    return listCustomers();
  });

export const adminCredit = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { userId: string; rupees: number }) => {
    const rupees = Math.floor(Number(input?.rupees));
    if (!input?.userId || !Number.isFinite(rupees) || rupees < 1 || rupees > 100000) throw new Error("Enter a credit between ₹1 and ₹100,000.");
    return { userId: String(input.userId), rupees };
  })
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    await creditCustomer(data.userId, data.rupees * 100, `Admin credit ₹${data.rupees}.`);
    return { ok: true as const };
  });

export const adminDeleteCustomer = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((userId: string) => {
    if (!userId) throw new Error("Missing customer.");
    return String(userId);
  })
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    await removeCustomer(context.userId, data);
    return { ok: true as const };
  });

export const getPaymentDesk = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async () => {
    const desk = await paymentDesk();
    return { upi_id: desk.upi_id, note: desk.note, qr_image: desk.qr_image };
  });

export const listPaymentGateways = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async () => publicGateways());

export const submitPaymentClaim = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { amountPaise: number; screenshot: string; reference: string; gatewayId: string }) => {
    const amountPaise = Math.floor(Number(input?.amountPaise));
    const screenshot = String(input?.screenshot || "");
    if (amountPaise < 1000) throw new Error("Enter a valid amount.");
    if (!screenshot.startsWith("data:image/") || screenshot.length > 700000) throw new Error("Screenshot is missing or too large.");
    if (!input?.gatewayId) throw new Error("Choose a payment method.");
    return { amountPaise, screenshot, reference: String(input?.reference || "").slice(0, 80), gatewayId: String(input.gatewayId) };
  })
  .handler(async ({ context, data }) => {
    const id = await submitClaim(context.userId, data.amountPaise, data.screenshot, data.reference, data.gatewayId);
    return { id };
  });

export const myPaymentClaims = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => myClaims(context.userId));

export const adminSaveQr = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { qr_image: string; upi_id: string; note: string }) => input)
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    await savePaymentDesk(data);
    return { ok: true as const };
  });

export const adminPaymentClaims = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const [desk, claims, gateways] = await Promise.all([paymentDesk(), listClaims(), adminGateways()]);
    return { desk, claims, gateways };
  });

export const adminSaveGateway = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: {
    id: string;
    name: string;
    account_title: string;
    account_number: string;
    ifsc: string;
    instructions: string;
    qr_image: string;
    min_rupees: number;
    max_rupees: number;
    enabled: boolean;
    archived: boolean;
  }) => input)
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    if (!data.name?.trim()) throw new Error("Gateway name is required.");
    const id = await saveGateway({
      id: data.id || crypto.randomUUID(),
      name: data.name.trim(),
      account_title: data.account_title || "",
      account_number: data.account_number || "",
      ifsc: data.ifsc || "",
      instructions: data.instructions || "",
      qr_image: data.qr_image || "",
      min_paise: Math.max(100, Math.floor(Number(data.min_rupees) || 100) * 100),
      max_paise: Math.max(100, Math.floor(Number(data.max_rupees) || 100000) * 100),
      enabled: Boolean(data.enabled),
      sort_order: 0,
      archived: Boolean(data.archived),
    });
    return { id };
  });

export const adminReviewPayment = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: string; approve: boolean; reason?: string }) => ({
    id: String(input?.id || ""),
    approve: Boolean(input?.approve),
    reason: String(input?.reason || "").slice(0, 180),
  }))
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    await reviewClaim(data.id, data.approve, data.reason);
    return { ok: true as const };
  });
