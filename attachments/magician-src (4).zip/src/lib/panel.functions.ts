import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { hashPassword } from "better-auth/crypto";
import { getSql } from "@/lib/db";
import { listGrowthCatalog } from "@/lib/organic";

export type ServiceRow = {
  id: string;
  platform: string;
  engagement_type: string;
  name: string;
  price_per_1k_paise: number;
  price_per_10k_paise: number;
  min_quantity: number;
  max_quantity: number;
};

export type BundleItem = {
  id: string;
  engagement_type: string;
  ratio_bps: number;
  is_base: boolean;
  service_id: string;
  name: string;
  price_per_1k_paise: number;
  price_per_10k_paise: number;
  min_quantity: number;
  max_quantity: number;
};

export type BundleRow = {
  id: string;
  name: string;
  platform: string;
  tagline: string;
  items: BundleItem[];
};

export type OrderItem = {
  id: string;
  engagement_type: string;
  service_name: string;
  quantity: number;
  delivered: number;
  price_paise: number;
  status: string;
};

export type OrderRow = {
  id: string;
  order_number: string;
  bundle_id: string;
  platform: string;
  link: string;
  base_quantity: number;
  total_paise: number;
  status: string;
  organic: boolean;
  interval_hours: number;
  variance_percent: number;
  provider_state: string;
  created_at: string;
  items: OrderItem[];
};

export type TxnRow = {
  id: string;
  kind: string;
  amount_paise: number;
  note: string;
  created_at: string;
};

export type DashboardData = {
  balance_paise: number;
  order_count: number;
  queued_count: number;
  spend_paise: number;
  recent: OrderRow[];
  days: { day: string; spend_paise: number }[];
};

type CreateInput = {
  bundleId: string;
  link: string;
  baseQuantity: number;
  organic: boolean;
  intervalHours: number;
  variancePercent: number;
  enabledTypes: string[];
  quantities?: Record<string, number>;
  delivery?: Record<string, { hours: number; runs: number; variance?: number; peak?: boolean; curve?: number[] }>;
};

async function ensureWallet(userId: string) {
  const sql = await getSql();
  await sql`
    insert into wallets (user_id, balance_paise)
    values (${userId}, 0)
    on conflict (user_id) do nothing
  `;
  return sql;
}

function moneyLines(
  items: {
    engagement_type: string;
    ratio_bps: number;
    is_base: boolean;
    name: string;
    price_per_1k_paise: number;
    price_per_10k_paise: number;
    min_quantity: number;
    max_quantity: number;
  }[],
  baseQuantity: number,
  enabled: Set<string>,
  quantities?: Record<string, number>,
) {
  const lines = [];
  for (const item of items) {
    if (!item.is_base && !enabled.has(item.engagement_type)) continue;
    const override = quantities?.[item.engagement_type];
    if (!item.is_base && override === 0) continue;
    const raw =
      typeof override === "number" && Number.isFinite(override) && override > 0
        ? override
        : item.is_base
          ? baseQuantity
          : Math.round((baseQuantity * item.ratio_bps) / 10000);
    if (!item.is_base && raw <= 0) continue;
    const quantity = Math.min(item.max_quantity, Math.max(item.min_quantity, Math.round(raw)));
    const rate = item.price_per_10k_paise || item.price_per_1k_paise * 10;
    const price_paise = Math.max(1, Math.round((quantity * rate) / 10000));
    lines.push({
      engagement_type: item.engagement_type,
      service_name: item.name,
      quantity,
      price_paise,
    });
  }
  return lines;
}

async function withPanelPrices<T extends { engagement_type: string; quantity: number; price_paise: number }>(platform: string, lines: T[]) {
  const { panelTypeRates } = await import("@/lib/admin.server");
  const rates = await panelTypeRates(platform);
  return lines.map((line) => {
    const paise = rates[line.engagement_type];
    if (!paise) return line;
    return { ...line, price_paise: Math.max(1, Math.round((line.quantity / 1000) * paise)) };
  });
}

let catalogMemo: { services: ServiceRow[]; bundles: BundleRow[]; providers_connected: 0 } | null = null;

export const apiBalances = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const { deskRole } = await import("@/lib/admin.server");
    if ((await deskRole(context.userId)) !== "admin") return [];
    const { listApiBalances } = await import("@/lib/providers.server");
    return listApiBalances();
  });

export const getCatalog = createServerFn({ method: "GET" }).handler(async () => {
  if (catalogMemo) return catalogMemo;
  const sql = await getSql();
  const services = await sql<ServiceRow>`
    select id, platform, engagement_type, name, price_per_1k_paise, coalesce(price_per_10k_paise, price_per_1k_paise * 10) as price_per_10k_paise, min_quantity, max_quantity
    from services
    order by platform, engagement_type
  `;
  const bundles = await sql<{
    id: string;
    name: string;
    platform: string;
    tagline: string;
  }>`select id, name, platform, tagline from bundles order by name`;
  const items = await sql<
    BundleItem & { bundle_id: string }
  >`
    select
      bi.id,
      bi.bundle_id,
      bi.engagement_type,
      bi.ratio_bps,
      bi.is_base,
      s.id as service_id,
      s.name,
      s.price_per_1k_paise,
      coalesce(s.price_per_10k_paise, s.price_per_1k_paise * 10) as price_per_10k_paise,
      s.min_quantity,
      s.max_quantity
    from bundle_items bi
    join services s on s.id = bi.service_id
    order by bi.is_base desc, bi.engagement_type
  `;
  const grouped: BundleRow[] = bundles.map((bundle) => ({
    ...bundle,
    items: items
      .filter((item) => item.bundle_id === bundle.id)
      .map(({ bundle_id: _bundleId, ...item }) => item),
  }));
  catalogMemo = { services, bundles: grouped, providers_connected: 0 as const };
  return catalogMemo;
});

export const getDashboard = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<DashboardData> => {
    const sql = await ensureWallet(context.userId);
    const wallet = await sql<{ balance_paise: number }>`
      select balance_paise from wallets where user_id = ${context.userId}
    `;
    const counts = await sql<{ order_count: number; queued_count: number; spend_paise: number }>`
      select
        count(*)::int as order_count,
        count(*) filter (where status = 'queued')::int as queued_count,
        coalesce(sum(total_paise), 0)::int as spend_paise
      from engagement_orders
      where user_id = ${context.userId}
    `;
    const recent = await loadOrders(context.userId, 5);
    const days = await sql<{ day: string; spend_paise: number }>`
      select to_char(created_at, 'YYYY-MM-DD') as day, coalesce(sum(total_paise), 0)::int as spend_paise
      from engagement_orders
      where user_id = ${context.userId}
      group by 1
      order by 1 asc
      limit 14
    `;
    const row = counts[0];
    return {
      balance_paise: wallet[0]?.balance_paise ?? 0,
      order_count: row?.order_count ?? 0,
      queued_count: row?.queued_count ?? 0,
      spend_paise: row?.spend_paise ?? 0,
      recent,
      days,
    };
  });

async function loadOrders(userId: string, limit: number, orderId?: string): Promise<OrderRow[]> {
  const sql = await getSql();
  const orders = orderId
    ? await sql<Omit<OrderRow, "items">>`
        select id, order_number, bundle_id, platform, link, base_quantity, total_paise, status,
               organic, interval_hours, variance_percent, provider_state, created_at::text as created_at
        from engagement_orders
        where user_id = ${userId} and id = ${orderId}
      `
    : await sql<Omit<OrderRow, "items">>`
        select id, order_number, bundle_id, platform, link, base_quantity, total_paise, status,
               organic, interval_hours, variance_percent, provider_state, created_at::text as created_at
        from engagement_orders
        where user_id = ${userId}
        order by created_at desc
        limit ${limit}
      `;
  if (orders.length === 0) return [];
  const items = orderId
    ? await sql<OrderItem & { order_id: string }>`
        select id, order_id, engagement_type, service_name, quantity, delivered, price_paise, status
        from engagement_order_items
        where user_id = ${userId} and order_id = ${orderId}
        order by engagement_type
      `
    : await sql<OrderItem & { order_id: string }>`
        select id, order_id, engagement_type, service_name, quantity, delivered, price_paise, status
        from engagement_order_items
        where user_id = ${userId}
        order by engagement_type
      `;
  return orders.map((order) => ({
    ...order,
    organic: Boolean(order.organic),
    items: items
      .filter((item) => item.order_id === order.id)
      .map(({ order_id: _orderId, ...item }) => item),
  }));
}

export const listOrders = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { t?: number } | undefined) => input ?? {})
  .handler(async ({ context }) => loadOrders(context.userId, 50));

export const getOrder = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: string | { id?: string; t?: number }) => {
    const id = typeof input === "string" ? input : String(input?.id || "");
    if (id.length < 8) throw new Error("Missing order.");
    return id;
  })
  .handler(async ({ context, data }) => {
    const rows = await loadOrders(context.userId, 1, data);
    return rows[0] ?? null;
  });

export const listOrderDrops = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: string | { id?: string; t?: number }) => {
    const id = typeof input === "string" ? input : String(input?.id || "");
    if (id.length < 8) throw new Error("Missing order.");
    return id;
  })
  .handler(async ({ context, data }) => {
    const { listOrderDrops: load } = await import("@/lib/drip.server");
    return load(context.userId, data);
  });

export const editScheduledDrop = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: string; quantity: number; placeAt: string }) => {
    const quantity = Math.floor(Number(input?.quantity));
    const placeAt = new Date(String(input?.placeAt || ""));
    if (!input?.id || quantity < 1) throw new Error("Enter a quantity.");
    if (Number.isNaN(placeAt.getTime())) throw new Error("Pick a valid time.");
    return { id: String(input.id), quantity, placeAt: placeAt.toISOString() };
  })
  .handler(async ({ context, data }) => {
    const { editDrop } = await import("@/lib/drip.server");
    await editDrop(context.userId, data.id, data.quantity, data.placeAt);
    return { ok: true as const };
  });

export const refillEngagement = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { orderId: string; type: string }) => {
    if (!input?.orderId || !input?.type) throw new Error("Missing refill.");
    return { orderId: String(input.orderId), type: String(input.type) };
  })
  .handler(async ({ context, data }) => {
    const { refillType } = await import("@/lib/drip.server");
    await refillType(context.userId, data.orderId, data.type);
    return { ok: true as const };
  });

export const checkDropStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: string) => {
    if (!id) throw new Error("Missing run.");
    return String(id);
  })
  .handler(async ({ context, data }) => {
    const sql = (await import("@/lib/db")).getSql;
    const db = await sql();
    const rows = await db<{ provider_order_id: string | null; api_url: string | null; api_key: string | null }>`
      select provider_order_id, api_url, api_key from delivery_drops
      where id = ${data} and user_id = ${context.userId}
      limit 1
    `;
    const drop = rows[0];
    if (!drop?.provider_order_id) throw new Error("This run has no provider order yet.");
    const { providerOrderStatus } = await import("@/lib/providers.server");
    return providerOrderStatus(drop.provider_order_id, drop.api_url || undefined, drop.api_key || undefined);
  });

export const setRunState = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id?: string; orderId?: string; type?: string; status: "waiting" | "paused" | "cancelled" }) => {
    if (!["waiting", "paused", "cancelled"].includes(input?.status)) throw new Error("Bad status.");
    return input;
  })
  .handler(async ({ context, data }) => {
    const { setDropState, setTypeState } = await import("@/lib/drip.server");
    if (data.id) await setDropState(context.userId, data.id, data.status);
    else if (data.orderId && data.type) await setTypeState(context.userId, data.orderId, data.type, data.status);
    else throw new Error("Missing run.");
    return { ok: true as const };
  });

export const getWallet = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await ensureWallet(context.userId);
    const wallet = await sql<{ balance_paise: number }>`
      select balance_paise from wallets where user_id = ${context.userId}
    `;
    const transactions = await sql<TxnRow>`
      select id, kind, amount_paise, note, created_at::text as created_at
      from wallet_transactions
      where user_id = ${context.userId}
      order by created_at desc
      limit 40
    `;
    return { balance_paise: wallet[0]?.balance_paise ?? 0, transactions };
  });

const TOPUPS_MIN = 10000;
const TOPUPS_MAX = 50_000_000;

export const creditWallet = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((amountPaise: number) => {
    const amount = Math.floor(Number(amountPaise));
    if (!Number.isFinite(amount) || amount < TOPUPS_MIN || amount > TOPUPS_MAX) {
      throw new Error("Amount must be between ₹100 and ₹5,00,000.");
    }
    return amount;
  })
  .handler(async ({ context, data }) => {
    const sql = await ensureWallet(context.userId);
    const id = crypto.randomUUID();
    await sql`
      update wallets
      set balance_paise = balance_paise + ${data}, updated_at = now()
      where user_id = ${context.userId}
    `;
    await sql`
      insert into wallet_transactions (id, user_id, kind, amount_paise, note)
      values (
        ${id},
        ${context.userId},
        'credit',
        ${data},
        'UPI desk credit. No payment gateway is connected — balance is on your ledger.'
      )
    `;
    const wallet = await sql<{ balance_paise: number }>`
      select balance_paise from wallets where user_id = ${context.userId}
    `;
    return { balance_paise: wallet[0]?.balance_paise ?? 0 };
  });

export const placeOrder = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: CreateInput) => {
    const link = String(input?.link ?? "").trim();
    let parsed: URL;
    try {
      parsed = new URL(link);
    } catch {
      throw new Error("Paste a full link, including https://.");
    }
    if (parsed.protocol !== "https:" && parsed.protocol !== "http:") {
      throw new Error("The link needs to start with http or https.");
    }
    const baseQuantity = Math.floor(Number(input.baseQuantity));
    if (!Number.isFinite(baseQuantity) || baseQuantity < 100 || baseQuantity > 10_000_000) {
      throw new Error("Base quantity must be between 100 and 10,000,000.");
    }
    const enabledTypes = Array.isArray(input.enabledTypes)
      ? input.enabledTypes.filter((type) => typeof type === "string")
      : [];
    const quantities: Record<string, number> = {};
    if (input.quantities && typeof input.quantities === "object") {
      for (const [type, value] of Object.entries(input.quantities)) {
        const quantity = Math.floor(Number(value));
        if (Number.isFinite(quantity) && quantity > 0 && quantity <= 50_000_000) quantities[type] = quantity;
      }
    }
    const delivery: Record<string, { hours: number; runs: number; variance?: number; peak?: boolean; curve?: number[] }> = {};
    if (input.delivery && typeof input.delivery === "object") {
      for (const [type, value] of Object.entries(input.delivery)) {
        const hours = Number(value?.hours);
        const runs = Math.floor(Number(value?.runs));
        if (!Number.isFinite(hours) || hours <= 0 || !Number.isFinite(runs) || runs <= 0) continue;
        const curve = Array.isArray(value.curve) ? value.curve.map(Number).filter((point) => Number.isFinite(point)).slice(0, 12) : [];
        delivery[type] = {
          hours: Math.min(24 * 30, hours),
          runs: Math.min(500, runs),
          variance: Math.min(50, Math.max(0, Math.floor(Number(value.variance) || 0))),
          peak: Boolean(value.peak),
          curve,
        };
      }
    }
    return {
      bundleId: String(input.bundleId ?? ""),
      link,
      baseQuantity,
      organic: Boolean(input.organic),
      intervalHours: Math.min(24 * 30, Math.max(1, Math.floor(Number(input.intervalHours) || 1))),
      variancePercent: Math.min(50, Math.max(0, Math.floor(Number(input.variancePercent) || 0))),
      enabledTypes,
      quantities,
      delivery,
    };
  })
  .handler(async ({ context, data }) => {
    const sql = await ensureWallet(context.userId);
    const items = await sql<{
      engagement_type: string;
      ratio_bps: number;
      is_base: boolean;
      name: string;
      price_per_1k_paise: number;
      price_per_10k_paise: number;
      min_quantity: number;
      max_quantity: number;
      platform: string;
    }>`
      select
        bi.engagement_type,
        bi.ratio_bps,
        bi.is_base,
        s.name,
        s.price_per_1k_paise,
        coalesce(s.price_per_10k_paise, s.price_per_1k_paise * 10) as price_per_10k_paise,
        s.min_quantity,
        s.max_quantity,
        b.platform
      from bundle_items bi
      join services s on s.id = bi.service_id
      join bundles b on b.id = bi.bundle_id
      where bi.bundle_id = ${data.bundleId}
    `;
    if (items.length === 0) throw new Error("That cue set is not on the book.");
    const platform = items[0]?.platform ?? "instagram";
    const { bindingMap } = await import("@/lib/admin.server");
    const { PROVIDER_MIN } = await import("@/lib/organic");
    const bindings = await bindingMap();
    const drafted = moneyLines(items, data.baseQuantity, new Set(data.enabledTypes), data.quantities).map((line) => {
      const min = bindings[`${platform}:${line.engagement_type}`]?.min_quantity || PROVIDER_MIN[line.engagement_type] || 1;
      if (line.quantity < min) throw new Error(`Below ${min} not allowed for ${line.engagement_type}.`);
      return line;
    });
    const lines = await withPanelPrices(platform, drafted);
    if (lines.length === 0) throw new Error("Turn on at least the base line.");
    for (const line of lines) {
      const slot = bindings[`${platform}:${line.engagement_type}`];
      const ready = (slot?.providers || []).some((item) => item.api_key && item.api_url) || Boolean(slot?.api_key && slot?.api_url);
      if (!ready) throw new Error("No Provider Available");
    }
    const total = lines.reduce((sum, line) => sum + line.price_paise, 0);
    const wallet = await sql<{ balance_paise: number }>`
      select balance_paise from wallets where user_id = ${context.userId}
    `;
    const balance = wallet[0]?.balance_paise ?? 0;
    if (balance < total) {
      throw new Error("The wallet does not cover this order. Add credit first.");
    }
    const { askFreeModel } = await import("@/lib/providers.server");
    const { armOrder } = await import("@/lib/drip.server");
    const orderId = crypto.randomUUID();
    const orderNumber = `MAG-${Math.floor(100000 + Math.random() * 900000)}`;
    const charged = await sql<{ user_id: string }>`
      update wallets
      set balance_paise = balance_paise - ${total}, updated_at = now()
      where user_id = ${context.userId} and balance_paise >= ${total}
      returning user_id
    `;
    if (charged.length === 0) {
      throw new Error("The wallet does not cover this order. Add credit first.");
    }
    await sql`
      insert into engagement_orders (
        id, user_id, order_number, bundle_id, platform, link, base_quantity, total_paise,
        status, organic, interval_hours, variance_percent, provider_state
      ) values (
        ${orderId}, ${context.userId}, ${orderNumber}, ${data.bundleId}, ${platform}, ${data.link},
        ${data.baseQuantity}, ${total}, 'queued', ${data.organic}, ${data.intervalHours},
        ${data.variancePercent}, 'provider'
      )
    `;
    for (const line of lines) {
      await sql`
        insert into engagement_order_items (
          id, order_id, user_id, engagement_type, service_name, quantity, delivered, price_paise, status
        ) values (
          ${crypto.randomUUID()}, ${orderId}, ${context.userId}, ${line.engagement_type},
          ${line.service_name}, ${line.quantity}, 0, ${line.price_paise}, 'queued'
        )
      `;
    }
    await armOrder({
      userId: context.userId,
      orderId,
      platform,
      link: data.link,
      lines: lines.map((line) => ({ engagement_type: line.engagement_type, quantity: line.quantity })),
      plans: data.delivery ?? {},
    });
    await sql`
      insert into wallet_transactions (id, user_id, kind, amount_paise, note)
      values (
        ${crypto.randomUUID()},
        ${context.userId},
        'debit',
        ${-total},
        ${`Cue ${orderNumber} queued in timed drops.`}
      )
    `;
    if (data.organic) {
      try {
        const aiNote = await askFreeModel(
          "You plan organic social delivery. One short sentence only.",
          `Platform ${platform}. Quantities: ${lines.map((line) => `${line.engagement_type} ${line.quantity}`).join(", ")}.`,
        );
        if (aiNote) {
          await sql`
            insert into wallet_transactions (id, user_id, kind, amount_paise, note)
            values (${crypto.randomUUID()}, ${context.userId}, 'note', 0, ${aiNote.slice(0, 280)})
          `;
        }
      } catch {
        /* free model can be busy; the YoYoMedia order is already placed */
      }
    }
    return { id: orderId, order_number: orderNumber, total_paise: total };
  });

export const simulateDelivery = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: string) => {
    if (typeof id !== "string" || id.length < 8) throw new Error("Missing order.");
    return id;
  })
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const updated = await sql<{ id: string }>`
      update engagement_orders
      set status = 'complete'
      where id = ${data} and user_id = ${context.userId} and status = 'queued'
      returning id
    `;
    if (updated.length === 0) throw new Error("That cue is not waiting.");
    await sql`
      update engagement_order_items
      set delivered = quantity, status = 'complete'
      where order_id = ${data} and user_id = ${context.userId}
    `;
    return { ok: true as const };
  });

export const listTickets = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    return sql<{ id: string; subject: string; body: string; created_at: string }>`
      select id, subject, body, created_at::text as created_at
      from support_tickets
      where user_id = ${context.userId}
      order by created_at desc
      limit 20
    `;
  });

export const openTicket = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { subject: string; body: string }) => {
    const subject = String(input?.subject ?? "").trim().slice(0, 120);
    const body = String(input?.body ?? "").trim().slice(0, 2000);
    if (subject.length < 3 || body.length < 8) throw new Error("Write a subject and a short note.");
    return { subject, body };
  })
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const id = crypto.randomUUID();
    await sql`
      insert into support_tickets (id, user_id, subject, body)
      values (${id}, ${context.userId}, ${data.subject}, ${data.body})
    `;
    return { id };
  });

async function ensurePrefs(userId: string) {
  const sql = await getSql();
  await sql`alter table user_prefs add column if not exists avatar_url text`;
  await sql`insert into user_prefs (user_id) values (${userId}) on conflict (user_id) do nothing`;
  return sql;
}

export const getPrefs = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await ensurePrefs(context.userId);
    const rows = await sql<{ full_name: string | null; api_key: string | null; organic_enabled: boolean; ratios_json: string; avatar_url: string | null }>`
      select full_name, api_key, organic_enabled, ratios_json, avatar_url from user_prefs where user_id = ${context.userId}
    `;
    return rows[0] ?? { full_name: null, api_key: null, organic_enabled: false, ratios_json: "{}", avatar_url: null };
  });

export const savePrefs = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { full_name?: string; organic_enabled?: boolean; ratios_json?: string; rotateKey?: boolean; avatar_url?: string }) => input)
  .handler(async ({ context, data }) => {
    const sql = await ensurePrefs(context.userId);
    if (typeof data.full_name === "string") {
      const name = data.full_name.trim().slice(0, 80);
      await sql`update user_prefs set full_name = ${name} where user_id = ${context.userId}`;
      await sql`update "user" set name = ${name}, "updatedAt" = now() where id = ${context.userId}`;
    }
    if (typeof data.organic_enabled === "boolean") {
      await sql`update user_prefs set organic_enabled = ${data.organic_enabled} where user_id = ${context.userId}`;
    }
    if (typeof data.ratios_json === "string") {
      await sql`update user_prefs set ratios_json = ${data.ratios_json.slice(0, 4000)} where user_id = ${context.userId}`;
    }
    if (typeof data.avatar_url === "string") {
      const photo = data.avatar_url.startsWith("data:image/") ? data.avatar_url.slice(0, 180000) : "";
      await sql`update user_prefs set avatar_url = ${photo || null} where user_id = ${context.userId}`;
    }
    if (data.rotateKey) {
      const key = `mg_${crypto.randomUUID().replace(/-/g, "")}`;
      await sql`update user_prefs set api_key = ${key} where user_id = ${context.userId}`;
    }
    const rows = await sql<{ full_name: string | null; api_key: string | null; organic_enabled: boolean; ratios_json: string; avatar_url: string | null }>`
      select full_name, api_key, organic_enabled, ratios_json, avatar_url from user_prefs where user_id = ${context.userId}
    `;
    return rows[0];
  });

export const changeDeskPassword = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((password: string) => {
    const next = String(password ?? "");
    if (next.length < 8) throw new Error("Use at least 8 characters.");
    if (next.length > 128) throw new Error("Password is too long.");
    return next;
  })
  .handler(async ({ context, data }) => {
    const hash = await hashPassword(data);
    const sql = await getSql();
    const updated = await sql<{ id: string }>`
      update "account"
      set password = ${hash}, "updatedAt" = now()
      where "userId" = ${context.userId} and "providerId" = 'credential'
      returning id
    `;
    if (updated.length === 0) throw new Error("This account has no password to change.");
    return { ok: true as const };
  });


export const listInstagram = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    return sql<{ id: string; username: string; created_at: string }>`
      select id, username, created_at::text as created_at
      from instagram_accounts
      where user_id = ${context.userId}
      order by created_at desc
    `;
  });

export const linkInstagram = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((username: string) => {
    const name = String(username ?? "").trim().replace(/^@/, "");
    if (!/^[A-Za-z0-9._]{2,30}$/.test(name)) throw new Error("Enter a public username, like your_name.");
    return name;
  })
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const recent = await sql<{ n: number }>`
      select count(*)::int as n from instagram_accounts
      where user_id = ${context.userId} and created_at > now() - interval '30 days'
    `;
    if ((recent[0]?.n ?? 0) >= 5) throw new Error("5 accounts already linked in this 30-day window.");
    const id = crypto.randomUUID();
    await sql`
      insert into instagram_accounts (id, user_id, username)
      values (${id}, ${context.userId}, ${data})
    `;
    return { id, username: data };
  });

export const listGrowthTemplates = createServerFn({ method: "GET" }).handler(async () => listGrowthCatalog());

export type MassLinkInput = {
  link: string;
  views: number;
  extras: Record<string, number>;
};

export type MassBatchLink = {
  link: string;
  status: string;
  error: string | null;
  total_paise: number;
  order_number: string | null;
};

export type MassBatchRow = {
  id: string;
  campaign_name: string;
  platform: string;
  base_quantity: number;
  timeframe: string;
  link_count: number;
  placed_count: number;
  failed_count: number;
  total_paise: number;
  status: string;
  created_at: string;
  links: MassBatchLink[];
};

async function ensureMassTables() {
  const sql = await getSql();
  await sql`
    create table if not exists mass_batches (
      id text primary key,
      user_id text not null,
      campaign_name text not null,
      platform text not null,
      bundle_id text not null,
      base_quantity integer not null,
      timeframe text not null,
      link_count integer not null,
      placed_count integer not null,
      failed_count integer not null,
      total_paise integer not null,
      status text not null,
      created_at timestamptz not null default now()
    )
  `;
  await sql`
    create table if not exists mass_batch_links (
      id text primary key,
      batch_id text not null,
      user_id text not null,
      link text not null,
      order_id text,
      order_number text,
      status text not null,
      error text,
      total_paise integer not null default 0
    )
  `;
  return sql;
}

export const listMassBatches = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await ensureMassTables();
    const batches = await sql<{
      id: string;
      campaign_name: string;
      platform: string;
      base_quantity: number;
      timeframe: string;
      link_count: number;
      placed_count: number;
      failed_count: number;
      total_paise: number;
      status: string;
      created_at: string;
    }>`
      select id, campaign_name, platform, base_quantity, timeframe, link_count, placed_count,
             failed_count, total_paise, status, created_at::text as created_at
      from mass_batches
      where user_id = ${context.userId}
      order by created_at desc
      limit 50
    `;
    if (batches.length === 0) return [] as MassBatchRow[];
    const ids = batches.map((batch) => batch.id);
    const links = await sql<{
      batch_id: string;
      link: string;
      status: string;
      error: string | null;
      total_paise: number;
      order_number: string | null;
    }>`
      select batch_id, link, status, error, total_paise, order_number
      from mass_batch_links
      where user_id = ${context.userId}
    `;
    const idSet = new Set(ids);
    return batches.map((batch) => ({
      ...batch,
      links: links.filter((link) => idSet.has(link.batch_id)).map(({ link, status, error, total_paise, order_number }) => ({
        link,
        status,
        error,
        total_paise,
        order_number,
      })),
    }));
  });

export const submitMassBatch = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: {
    bundleId: string;
    campaignName: string;
    timeframe: string;
    intervalHours: number;
    links: MassLinkInput[];
  }) => {
    const links = (input.links ?? []).filter((row) => /^https?:\/\//.test(String(row.link ?? "").trim())).slice(0, 100);
    if (!input.bundleId) throw new Error("Apna bundle select karo.");
    if (links.length === 0) throw new Error("Kam se kam 1 valid link daalo.");
    const floors: Record<string, number> = { views: 100, likes: 10, comments: 10, shares: 10, saves: 50, reposts: 10 };
    return {
      bundleId: input.bundleId,
      campaignName: String(input.campaignName ?? "").trim().slice(0, 80) || "Untitled campaign",
      timeframe: String(input.timeframe ?? "1-3 days"),
      intervalHours: Math.max(1, Math.min(24 * 90, Math.round(Number(input.intervalHours) || 72))),
      links: links.map((row) => {
        const views = Math.round(Number(row.views) || 0);
        if (views < floors.views) throw new Error("Below 100 not allowed for views.");
        const extras = Object.fromEntries(
          Object.entries(row.extras ?? {})
            .map(([key, value]) => [key, Math.round(Number(value) || 0)])
            .filter((entry) => Number(entry[1]) > 0),
        );
        for (const [key, value] of Object.entries(extras)) {
          const floor = floors[key];
          if (floor && Number(value) < floor) throw new Error(`Below ${floor} not allowed for ${key}.`);
        }
        return { link: row.link.trim(), views, extras };
      }),
    };
  })
  .handler(async ({ context, data }) => {
    const sql = await ensureMassTables();
    await ensureWallet(context.userId);
    const items = await sql<{
      engagement_type: string;
      ratio_bps: number;
      is_base: boolean;
      name: string;
      price_per_1k_paise: number;
      price_per_10k_paise: number;
      min_quantity: number;
      max_quantity: number;
      platform: string;
    }>`
      select bi.engagement_type, bi.ratio_bps, bi.is_base, s.name, s.price_per_1k_paise,
             coalesce(s.price_per_10k_paise, s.price_per_1k_paise * 10) as price_per_10k_paise,
             s.min_quantity, s.max_quantity, b.platform
      from bundle_items bi
      join services s on s.id = bi.service_id
      join bundles b on b.id = bi.bundle_id
      where bi.bundle_id = ${data.bundleId}
    `;
    if (items.length === 0) throw new Error("That bundle is not on the book.");
    const platform = items[0]?.platform ?? "instagram";
    const { bindingMap } = await import("@/lib/admin.server");
    const { PROVIDER_MIN } = await import("@/lib/organic");
    const bindings = await bindingMap();
    const batchId = crypto.randomUUID();
    let placed = 0;
    let failed = 0;
    let totalPaise = 0;
    const results: MassBatchLink[] = [];
    for (const row of data.links) {
      const extras = { ...row.extras };
      if (platform !== "instagram") delete extras.reposts;
      const quantities = { views: row.views, ...extras };
      const enabled = new Set(["views", ...Object.keys(extras)]);
      try {
        const lines = await withPanelPrices(platform, moneyLines(items, row.views, enabled, quantities));
        for (const line of lines) {
          const slot = bindings[`${platform}:${line.engagement_type}`];
          const ready = (slot?.providers || []).some((item) => item.api_key && item.api_url) || Boolean(slot?.api_key && slot?.api_url);
          if (!ready) throw new Error("No Provider Available");
          const min = slot?.min_quantity || PROVIDER_MIN[line.engagement_type] || 1;
          if (line.quantity < min) throw new Error(`Below ${min} not allowed for ${line.engagement_type}.`);
        }
        const total = lines.reduce((sum, line) => sum + line.price_paise, 0);
        const wallet = await sql<{ balance_paise: number }>`
          select balance_paise from wallets where user_id = ${context.userId}
        `;
        if ((wallet[0]?.balance_paise ?? 0) < total) throw new Error("Wallet does not cover this link.");
        const { armOrder } = await import("@/lib/drip.server");
        const orderId = crypto.randomUUID();
        const orderNumber = `MAG-${Math.floor(100000 + Math.random() * 900000)}`;
        const charged = await sql<{ user_id: string }>`
          update wallets
          set balance_paise = balance_paise - ${total}, updated_at = now()
          where user_id = ${context.userId} and balance_paise >= ${total}
          returning user_id
        `;
        if (charged.length === 0) throw new Error("Wallet does not cover this link.");
        await sql`
          insert into engagement_orders (
            id, user_id, order_number, bundle_id, platform, link, base_quantity, total_paise,
            status, organic, interval_hours, variance_percent, provider_state
          ) values (
            ${orderId}, ${context.userId}, ${orderNumber}, ${data.bundleId}, ${platform}, ${row.link},
            ${row.views}, ${total}, 'queued', true, ${data.intervalHours}, 25, 'provider'
          )
        `;
        for (const line of lines) {
          await sql`
            insert into engagement_order_items (
              id, order_id, user_id, engagement_type, service_name, quantity, delivered, price_paise, status
            ) values (
              ${crypto.randomUUID()}, ${orderId}, ${context.userId}, ${line.engagement_type},
              ${line.service_name}, ${line.quantity}, 0, ${line.price_paise}, 'queued'
            )
          `;
        }
        const plans: Record<string, { hours: number; runs: number; variance: number }> = {};
        for (const line of lines) {
          const chunk = line.engagement_type === "saves" ? 50 : line.engagement_type === "views" ? 100 : 10;
          plans[line.engagement_type] = {
            hours: data.intervalHours,
            runs: Math.max(1, Math.floor(line.quantity / chunk)),
            variance: 25,
          };
        }
        await armOrder({
          userId: context.userId,
          orderId,
          platform,
          link: row.link,
          lines: lines.map((line) => ({ engagement_type: line.engagement_type, quantity: line.quantity })),
          plans,
        });
        await sql`
          insert into wallet_transactions (id, user_id, kind, amount_paise, note)
          values (${crypto.randomUUID()}, ${context.userId}, 'debit', ${-total}, ${`Mass ${orderNumber} · ${data.campaignName}`})
        `;
        await sql`
          insert into mass_batch_links (id, batch_id, user_id, link, order_id, order_number, status, total_paise)
          values (${crypto.randomUUID()}, ${batchId}, ${context.userId}, ${row.link}, ${orderId}, ${orderNumber}, 'processing', ${total})
        `;
        placed += 1;
        totalPaise += total;
        results.push({ link: row.link, status: "processing", error: null, total_paise: total, order_number: orderNumber });
      } catch (err: unknown) {
        failed += 1;
        const message = err instanceof Error ? err.message : "Link failed.";
        await sql`
          insert into mass_batch_links (id, batch_id, user_id, link, status, error, total_paise)
          values (${crypto.randomUUID()}, ${batchId}, ${context.userId}, ${row.link}, 'failed', ${message}, 0)
        `;
        results.push({ link: row.link, status: "failed", error: message, total_paise: 0, order_number: null });
      }
    }
    const status = placed === 0 ? "failed" : failed > 0 ? "partial" : "processing";
    await sql`
      insert into mass_batches (
        id, user_id, campaign_name, platform, bundle_id, base_quantity, timeframe,
        link_count, placed_count, failed_count, total_paise, status
      ) values (
        ${batchId}, ${context.userId}, ${data.campaignName}, ${platform}, ${data.bundleId},
        ${data.links[0]?.views ?? 0}, ${data.timeframe}, ${data.links.length}, ${placed}, ${failed},
        ${totalPaise}, ${status}
      )
    `;
    return { id: batchId, status, placed, failed, total_paise: totalPaise, links: results };
  });

export const completeMassBatch = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: string) => {
    if (typeof id !== "string" || id.length < 8) throw new Error("Missing batch.");
    return id;
  })
  .handler(async ({ context, data }) => {
    const sql = await ensureMassTables();
    const updated = await sql<{ id: string }>`
      update mass_batches
      set status = 'completed'
      where id = ${data} and user_id = ${context.userId} and status = 'processing'
      returning id
    `;
    if (updated.length === 0) throw new Error("That batch is not processing.");
    await sql`
      update mass_batch_links
      set status = 'completed'
      where batch_id = ${data} and user_id = ${context.userId} and status = 'processing'
    `;
    const orders = await sql<{ order_id: string }>`
      select order_id from mass_batch_links
      where batch_id = ${data} and user_id = ${context.userId} and order_id is not null
    `;
    for (const row of orders) {
      await sql`update engagement_orders set status = 'complete' where id = ${row.order_id} and user_id = ${context.userId}`;
      await sql`update engagement_order_items set delivered = quantity, status = 'complete' where order_id = ${row.order_id} and user_id = ${context.userId}`;
    }
    return { ok: true as const };
  });

export const placeSingleOrder = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { managedId?: string; serviceId?: number; link: string; amount: number; drip?: boolean; runs?: number; intervalMinutes?: number }) => {
    const managedId = String(input?.managedId || "").trim();
    const serviceId = Math.floor(Number(input?.serviceId) || 0);
    const link = String(input?.link ?? "").trim();
    const amount = Math.floor(Number(input?.amount));
    const runs = Math.max(1, Math.min(200, Math.floor(Number(input?.runs) || 1)));
    const intervalMinutes = Math.max(1, Math.min(10080, Math.floor(Number(input?.intervalMinutes) || 1)));
    if (!managedId && !serviceId) throw new Error("Pick a service.");
    if (!/^https?:\/\//i.test(link)) throw new Error("Paste a valid link.");
    if (!Number.isFinite(amount) || amount < 1) throw new Error("Enter an amount.");
    return { managedId, serviceId, link, amount, drip: Boolean(input?.drip), runs, intervalMinutes };
  })
  .handler(async ({ context, data }) => {
    const { findManagedById, findManagedByProviderId, providerKeys } = await import("@/lib/admin.server");
    const managed = data.managedId
      ? await findManagedById(data.managedId)
      : await findManagedByProviderId(String(data.serviceId));
    if (!managed || managed.enabled === false) throw new Error("That service is disabled.");
    if (data.amount < managed.min_quantity || data.amount > managed.max_quantity) {
      throw new Error(`Amount must be between ${managed.min_quantity} and ${managed.max_quantity}.`);
    }
    const keys = await providerKeys(managed.provider_row_id || "");
    if (!keys?.api_key || !keys.api_url) throw new Error("No Provider Available");
    const pieces = data.drip ? data.runs : 1;
    const totalQty = data.amount * pieces;
    const sql = await ensureWallet(context.userId);
    await sql`
      insert into bundles (id, name, platform, tagline)
      values ('bundle-single', 'Single order', 'multi', 'One service at a time.')
      on conflict (id) do nothing
    `;
    const total = Math.max(1, Math.round((totalQty / 1000) * Math.max(1, managed.price_per_1k_paise)));
    const wallet = await sql<{ balance_paise: number }>`
      select balance_paise from wallets where user_id = ${context.userId}
    `;
    if ((wallet[0]?.balance_paise ?? 0) < total) throw new Error("The wallet does not cover this order. Add credit first.");
    const orderId = crypto.randomUUID();
    const orderNumber = `MAG-${Math.floor(100000 + Math.random() * 900000)}`;
    let providerOrderId = data.drip ? "drip" : "";
    if (!data.drip) {
      const { placeExactOnProvider } = await import("@/lib/providers.server");
      const sent = await placeExactOnProvider({
        serviceId: managed.provider_service_id,
        link: data.link,
        quantity: data.amount,
        apiUrl: keys.api_url,
        apiKey: keys.api_key,
      });
      providerOrderId = sent.orderId;
    }
    const charged = await sql<{ user_id: string }>`
      update wallets
      set balance_paise = balance_paise - ${total}, updated_at = now()
      where user_id = ${context.userId} and balance_paise >= ${total}
      returning user_id
    `;
    if (charged.length === 0) {
      if (providerOrderId && providerOrderId !== "drip") {
        const { cancelProviderOrder } = await import("@/lib/providers.server");
        await cancelProviderOrder(providerOrderId);
      }
      throw new Error("The wallet does not cover this order. Add credit first.");
    }
    await sql`
      insert into engagement_orders (
        id, user_id, order_number, bundle_id, platform, link, base_quantity, total_paise,
        status, organic, interval_hours, variance_percent, provider_state
      ) values (
        ${orderId}, ${context.userId}, ${orderNumber}, 'bundle-single', ${managed.platform}, ${data.link},
        ${data.amount}, ${total}, 'processing', false, 1, 0, 'provider'
      )
    `;
    await sql`
      insert into engagement_order_items (
        id, order_id, user_id, engagement_type, service_name, quantity, delivered, price_paise, status
      ) values (
        ${crypto.randomUUID()}, ${orderId}, ${context.userId}, ${managed.category},
        ${`#${managed.provider_service_id} ${managed.name}${data.drip ? "" : ` · #${providerOrderId}`}`}, ${totalQty}, 0, ${total}, 'processing'
      )
    `;
    await sql`
      insert into wallet_transactions (id, user_id, kind, amount_paise, note)
      values (${crypto.randomUUID()}, ${context.userId}, 'debit', ${-total}, ${data.drip ? `Single ${orderNumber} drip ${pieces} runs.` : `Single ${orderNumber} sent once #${providerOrderId}.`})
    `;
    if (!data.drip) {
      await sql`
        insert into delivery_drops (
          id, order_id, user_id, platform, link, engagement_type, quantity, place_at, status,
          provider_order_id, service_label, provider_service_id, api_url, api_key
        ) values (
          ${crypto.randomUUID()}, ${orderId}, ${context.userId}, ${managed.platform}, ${data.link},
          ${managed.category}, ${data.amount}, now(), 'placed',
          ${providerOrderId}, ${`#${managed.provider_service_id} ${managed.name}`}, ${String(managed.provider_service_id)}, ${keys.api_url}, ${keys.api_key}
        )
      `;
    }
    if (data.drip) {
      const { scheduleFixed } = await import("@/lib/drip.server");
      await scheduleFixed({
        userId: context.userId,
        orderId,
        platform: managed.platform,
        link: data.link,
        engagementType: managed.category || "single",
        providerServiceId: String(managed.provider_service_id),
        apiUrl: keys.api_url,
        apiKey: keys.api_key,
        amount: data.amount,
        runs: pieces,
        intervalMinutes: data.intervalMinutes,
      });
    }
    return { id: orderId, order_number: orderNumber, total_paise: total, provider_order_id: providerOrderId, balance_paise: (wallet[0]?.balance_paise ?? 0) - total };
  });

export const browseLiveServices = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { platform?: string; category?: string; query?: string }) => ({
    platform: String(input?.platform || "instagram").slice(0, 32),
    category: String(input?.category || "").slice(0, 160),
    query: String(input?.query || "").slice(0, 80),
  }))
  .handler(async ({ data }) => {
    const { enabledCatalog, managedToLive } = await import("@/lib/admin.server");
    const { browseProvider, providerBalance } = await import("@/lib/providers.server");
    const managed = await enabledCatalog();
    if (managed && managed.length > 0) {
      const cards = managed.map((row) => managedToLive(row));
      const platform = data.platform;
      const rows = cards.filter((row) => platform === "all" || row.platform === platform);
      const names = Array.from(new Set(rows.map((row) => row.category))).sort((a, b) => a.localeCompare(b));
      const categories = platform === "all" ? ["All categories", ...names] : names;
      const category = categories.includes(data.category) ? data.category : categories[0] || "";
      const query = data.query.trim().toLowerCase();
      const pool = category === "All categories" || !category ? rows : rows.filter((row) => row.category === category);
      const services = (query ? pool.filter((row) => `${row.id} ${row.name} ${row.category} ${row.providerName || ""}`.toLowerCase().includes(query)) : pool).slice(0, 800);
      return { categories, category, services, balanceUsd: 0, currency: "USD" };
    }
    const [catalog, balance] = await Promise.all([browseProvider(data), providerBalance()]);
    return { ...catalog, balanceUsd: balance.balanceUsd, currency: balance.currency };
  });

export const engagementFloors = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((platform: string) => String(platform || "instagram").slice(0, 32))
  .handler(async ({ data }) => {
    const { listBindings } = await import("@/lib/admin.server");
    const rows = await listBindings();
    const out: Record<string, number> = {};
    for (const type of ["views", "likes", "saves", "shares", "reposts"]) {
      const row = rows.find((item) => item.slot === `${data}:${type}`);
      if (row) out[type] = row.min_quantity;
    }
    return out;
  });

export const panelRates = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((platform: string) => String(platform || "instagram").slice(0, 32))
  .handler(async ({ data }) => {
    const { panelTypeRates } = await import("@/lib/admin.server");
    return panelTypeRates(data);
  });

export const aiSmartMix = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { views: number; platform: string }) => {
    const views = Math.floor(Number(input?.views));
    if (views < 100) throw new Error("Enter at least 100 views.");
    return { views, platform: String(input?.platform || "instagram").slice(0, 32) };
  })
  .handler(async ({ data }) => {
    const { bestOrganicMix } = await import("@/lib/organic");
    return { mix: bestOrganicMix(data.views), source: "ratio" as const };
  });

export const askPanelAi = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { question: string; context: string }) => {
    const question = String(input?.question ?? "").trim().slice(0, 800);
    if (!question) throw new Error("Ask something first.");
    return { question, context: String(input?.context ?? "").slice(0, 1200) };
  })
  .handler(async ({ data }) => {
    const { askFreeModel } = await import("@/lib/providers.server");
    const text = await askFreeModel(
      "You are the organic growth assistant inside Magiciansmm. Reply in 2 to 4 short sentences using only the numbers given. Do not claim you opened the live post. If the user wants a ratio or mix, end with one line exactly like APPLY {\"likes\":700,\"shares\":80,\"reposts\":40,\"saves\":160}.",
      `${data.context}\n\nQuestion: ${data.question}`,
    );
    const match = text.match(/APPLY\s*(\{[\s\S]*?\})/);
    let mix: Record<string, number> | null = null;
    if (match) {
      try {
        const parsed = JSON.parse(match[1]) as Record<string, unknown>;
        mix = {};
        for (const key of ["likes", "shares", "reposts", "saves"]) {
          const value = Number(parsed[key]);
          if (Number.isFinite(value) && value > 0) mix[key] = Math.round(value);
        }
      } catch {
        mix = null;
      }
    }
    return {
      text: text.replace(/APPLY\s*\{[\s\S]*?\}/, "").trim(),
      apply: Boolean(mix && Object.keys(mix).length > 0),
      mix,
    };
  });



