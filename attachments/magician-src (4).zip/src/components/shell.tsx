import { useEffect, useState, type ButtonHTMLAttributes, ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  Activity,
  LayoutDashboard,
  Library,
  LifeBuoy,
  ListPlus,
  MessageCircle,
  PlusSquare,
  Receipt,
  Settings,
  Sparkles,
  Wallet,
  Wand2,
  Users,
  Boxes,
  KeyRound,
  QrCode,
} from "lucide-react";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getWallet } from "@/lib/panel.functions";
import { getDeskRole } from "@/lib/admin.functions";
import { inr } from "@/lib/money";

const walletCache = { at: 0, value: null as number | null };

const LINKS = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard, hot: false },
  { to: "/engagement-order", label: "Full Engagement", icon: Wand2, hot: false },
  { to: "/single-order", label: "Single Order", icon: PlusSquare, hot: false },
  { to: "/mass", label: "Mass Order", icon: ListPlus, hot: true },
  { to: "/engagement-orders", label: "All Orders", icon: Receipt, hot: false },
  { to: "/instagram", label: "Instagram Accounts", icon: Library, hot: false },
  { to: "/tiktok", label: "TikTok Accounts", icon: Library, hot: false },
  { to: "/detect", label: "Bot Detection", icon: Activity, hot: false },
  { to: "/wallet", label: "Wallet", icon: Wallet, hot: false },
  { to: "/telegram-bot", label: "Telegram Bot", icon: MessageCircle, hot: false },
  { to: "/support", label: "Support", icon: LifeBuoy, hot: false },
  { to: "/settings", label: "Settings", icon: Settings, hot: false },
] as const;

const ADMIN_LINKS = [
  { to: "/admin/services", label: "Services", icon: Boxes, hot: false },
  { to: "/admin/engagement", label: "Engagement APIs", icon: KeyRound, hot: false },
  { to: "/admin/payments", label: "Payments", icon: QrCode, hot: false },
  { to: "/admin/customers", label: "Customers", icon: Users, hot: false },
] as const;

export function Mark({ compact = false }: { compact?: boolean }) {
  return (
    <Link to="/" className="flex items-center gap-2.5">
      <span className="grid size-9 place-items-center rounded-xl bg-[#2563eb] text-white ring-1 ring-[#93c5fd]">
        <Sparkles className="size-4" />
      </span>
      {!compact && (
        <span className="flex flex-col leading-tight">
          <span className="text-[15px] font-bold tracking-tight text-foreground">Magiciansmm</span>
          <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-primary/70">Desk v1</span>
        </span>
      )}
    </Link>
  );
}

export function Wordmark() {
  return <Mark />;
}

export function Shell({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (state) => state.location.pathname });
  const { user, isPending } = useCurrentUserState();
  const [balance, setBalance] = useState<number | null>(null);
  const [admin, setAdmin] = useState(false);

  useEffect(() => {
    getDeskRole().then((role) => setAdmin(role === "admin")).catch(() => setAdmin(false));
    if (walletCache.value != null && Date.now() - walletCache.at < 20000) {
      setBalance(walletCache.value);
      return;
    }
    getWallet()
      .then((wallet) => {
        walletCache.at = Date.now();
        walletCache.value = wallet.balance_paise;
        setBalance(wallet.balance_paise);
      })
      .catch(() => setBalance(null));
  }, [path]);

  const links = admin ? [...LINKS, ...ADMIN_LINKS] : LINKS;

  const initial = (user?.displayName || user?.primaryEmail || "M").slice(0, 1).toUpperCase();

  return (
    <div className="min-h-screen md:grid md:grid-cols-[260px_1fr]">
      <aside className="sticky top-0 hidden h-screen flex-col border-r border-line bg-card/95 backdrop-blur-xl md:flex">
        <div className="flex items-center justify-between px-5 pb-3 pt-4">
          <Mark />
        </div>
        <div className="mx-4 mb-3 flex items-center gap-2.5 rounded-xl border border-line bg-secondary px-3 py-2.5">
          <div className="grid size-8 shrink-0 place-items-center rounded-full bg-gradient-to-br from-primary to-accent text-[11px] font-bold text-white">
            {initial}
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-[12px] font-semibold">{user?.displayName || "Member"}</p>
            <p className="truncate text-[10px] text-mute">{user?.primaryEmail || "Signed in"}</p>
          </div>
        </div>
        <div className="mx-4 mb-4">
          <div className="relative overflow-hidden rounded-xl border border-primary/20 bg-gradient-to-b from-primary/10 to-primary/5 p-4">
            <p className="mb-1 flex items-center gap-1.5 text-[9px] font-semibold uppercase tracking-wider text-primary/80">
              <Wallet className="size-3" /> Wallet balance
            </p>
            <p className="mb-3 text-[22px] font-extrabold tracking-tight">{balance == null ? "—" : inr(balance)}</p>
            <Link
              to="/wallet"
              className="flex h-8 w-full items-center justify-center gap-1.5 rounded-lg bg-primary text-[11px] font-semibold text-primary-fg"
            >
              <Wallet className="size-3" /> Add credit
            </Link>
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto px-3 pb-3">
          <p className="mb-2 px-3 text-[9px] font-semibold uppercase tracking-[0.22em] text-mute">Menu</p>
          {links.map((link) => {
            const active = path === link.to || (link.to !== "/dashboard" && path.startsWith(`${link.to}/`));
            const Icon = link.icon;
            return (
              <Link
                key={link.to}
                to={link.to}
                className={
                  "mb-0.5 flex min-h-10 items-center gap-2.5 rounded-xl border px-3 py-2 text-[13px] " +
                  (active
                    ? "border-primary/20 bg-primary/10 font-semibold text-primary"
                    : "border-transparent text-mute hover:bg-muted hover:text-foreground")
                }
              >
                <Icon className="size-4" />
                <span className="flex-1">{link.label}</span>
                {link.hot && !active && (
                  <span className="rounded-full border border-primary/25 bg-primary/15 px-1.5 py-0.5 text-[8px] font-bold text-primary">
                    HOT
                  </span>
                )}
              </Link>
            );
          })}
        </nav>
        <div className="px-3 pb-4">
          <div className="flex items-center justify-between rounded-xl border border-line bg-secondary px-3 py-2 text-[12px] font-medium">
            <span className="uppercase tracking-wider">INR</span>
            <span className="text-[10px] text-mute">₹</span>
          </div>
        </div>
      </aside>

      <div className="min-w-0 pb-20 md:pb-0">
        <header className="sticky top-0 z-20 flex items-center justify-center border-b border-[#e7eef6] bg-white/90 px-4 py-3 backdrop-blur">
          <p className="text-[13px] font-semibold text-[#334155]">Magiciansmm</p>
          <div className="absolute right-4">{isPending ? <div className="size-8" /> : <UserButton />}</div>
        </header>
        <main className="mx-auto max-w-6xl px-4 py-6 md:px-8 md:py-8">{children}</main>
      </div>

      <Link
        to="/support"
        className="fixed bottom-24 right-4 z-30 grid size-14 place-items-center rounded-full bg-primary text-primary-fg shadow-2xl md:bottom-6"
        aria-label="Support"
      >
        <MessageCircle className="size-6" />
      </Link>

      <nav className="fixed inset-x-0 bottom-0 z-20 grid grid-cols-5 border-t border-line bg-card/95 backdrop-blur md:hidden">
        {links.slice(0, 5).map((link) => {
          const active = path === link.to || (link.to !== "/dashboard" && path.startsWith(`${link.to}/`));
          const Icon = link.icon;
          return (
            <Link
              key={link.to}
              to={link.to}
              className={
                "flex min-h-14 flex-col items-center justify-center gap-1 text-[10px] font-medium " +
                (active ? "text-primary" : "text-mute")
              }
            >
              <Icon className="size-4" />
              {link.label.split(" ")[0]}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}

export function Panel({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <section className={`glass-card p-5 ${className}`}>{children}</section>;
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block space-y-2">
      <span className="text-xs font-semibold tracking-wide text-mute">{label}</span>
      {children}
    </label>
  );
}

export const inputClass =
  "w-full rounded-xl border border-line bg-card px-4 py-3 text-sm text-foreground outline-none focus:border-primary focus:ring-2 focus:ring-primary/30";

export function PrimaryButton({
  children,
  className = "",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...props}
      className={
        "btn-gradient inline-flex min-h-11 items-center justify-center rounded-xl px-5 text-sm font-semibold disabled:opacity-50 " +
        className
      }
    >
      {children}
    </button>
  );
}

export function GhostButton({
  children,
  className = "",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...props}
      className={
        "inline-flex min-h-11 items-center justify-center rounded-xl border border-line bg-card px-5 text-sm font-semibold text-foreground " +
        className
      }
    >
      {children}
    </button>
  );
}
