import { getSql } from "@/lib/db";
import { planDrops } from "@/lib/organic";

export type DropPlan = {
  hours: number;
  runs: number;
  variance?: number;
  peak?: boolean;
  curve?: number[];
  start?: string;
};

export type DropRow = {
  id: string;
  order_id: string;
  engagement_type: string;
  quantity: number;
  place_at: string;
  status: string;
  provider_order_id: string | null;
  service_label: string | null;
  error: string | null;
};

const globalWorker = globalThis as typeof globalThis & { __dropWorker?: ReturnType<typeof setInterval> };

const CORE_TYPES = new Set(["views", "likes", "saves", "shares", "reposts", "comments", "followers"]);

function guessKind(text: string) {
  const name = text.toLowerCase();
  if (/\breposts?\b/.test(name)) return "reposts";
  if (/\b(saves?|favourites?|favorites?)\b/.test(name)) return "saves";
  if (/\bshares?\b/.test(name)) return "shares";
  if (/\bcomments?\b/.test(name)) return "comments";
  if (/\bfollowers?\b/.test(name)) return "followers";
  if (/\blikes?\b/.test(name)) return "likes";
  if (/\bviews?\b/.test(name)) return "views";
  return "views";
}

async function providersFor(platform: string, kind: string, drop: { api_url: string | null; api_key: string | null }) {
  const { bindingMap, listProviders } = await import("@/lib/admin.server");
  const found: { apiUrl: string; apiKey: string }[] = [];
  const push = (apiUrl?: string | null, apiKey?: string | null) => {
    const key = String(apiKey || "").trim();
    if (!key || found.some((item) => item.apiKey === key)) return;
    found.push({ apiUrl: String(apiUrl || "").trim() || "https://yoyomedia.in/api/v2", apiKey: key });
  };
  push(drop.api_url, drop.api_key);
  try {
    for (const provider of await listProviders()) {
      if (provider.enabled) push(provider.api_url, provider.api_key);
    }
  } catch {
    /* no provider rows yet */
  }
  try {
    const bindings = await bindingMap();
    const slot = bindings[`${platform}:${kind}`];
    for (const item of slot?.providers || []) push(item.api_url, item.api_key);
    push(slot?.api_url, slot?.api_key);
  } catch {
    /* bindings optional */
  }
  return found;
}

export async function armOrder(input: {
  userId: string;
  orderId: string;
  platform: string;
  link: string;
  lines: { engagement_type: string; quantity: number }[];
  plans: Record<string, DropPlan>;
}) {
  const sql = await getSql();
  const { bindingMap } = await import("@/lib/admin.server");
  let bindings: Record<string, { pick_mode?: string; service_id?: string; api_url?: string; api_key?: string; min_quantity?: number }> = {};
  try {
    bindings = await bindingMap();
  } catch (error) {
    console.error("[drops] bindings", error);
  }
  for (const line of input.lines) {
    const plan = input.plans[line.engagement_type];
    const binding = bindings[`${input.platform}:${line.engagement_type}`];
    const serviceId = binding?.pick_mode === "random" ? "random" : binding?.service_id || null;
    const start = plan?.start ? new Date(plan.start) : new Date();
    const drops = planDrops({
      quantity: line.quantity,
      type: line.engagement_type,
      runs: plan?.runs ?? 4,
      hours: plan?.hours ?? 24,
      curve: plan?.curve,
      variance: plan?.variance ?? 25,
      peak: Boolean(plan?.peak),
      min: binding?.min_quantity || undefined,
      start: Number.isNaN(start.getTime()) ? new Date() : start,
    });
    for (const drop of drops) {
      await sql`
        insert into delivery_drops (
          id, order_id, user_id, platform, link, engagement_type, quantity, place_at, status,
          provider_service_id, api_url, api_key
        ) values (
          ${crypto.randomUUID()}, ${input.orderId}, ${input.userId}, ${input.platform}, ${input.link},
          ${line.engagement_type}, ${drop.amount}, ${drop.at.toISOString()}, 'waiting',
          ${serviceId}, ${binding?.api_url || null}, ${binding?.api_key || null}
        )
      `;
    }
  }
  await flushDueDrops(input.orderId);
}

export async function listOrderDrops(userId: string, orderId: string) {
  const sql = await getSql();
  const read = () => sql<DropRow>`
    select id, order_id, engagement_type, quantity, place_at::text as place_at, status, provider_order_id, service_label, error
    from delivery_drops
    where user_id = ${userId} and order_id = ${orderId}
    order by place_at asc
  `;
  let rows = await read();
  if (rows.length === 0) {
    await backfillDrops(userId, orderId);
    rows = await read();
  }
  // Place any due runs on every poll, so tracking updates even if the background interval died.
  try {
    await flushDueDrops(orderId);
  } catch (error) {
    console.error("[drops] flush on list", error);
  }
  return read();
}

async function backfillDrops(userId: string, orderId: string) {
  const sql = await getSql();
  const existing = await sql<{ id: string }>`select id from delivery_drops where user_id = ${userId} and order_id = ${orderId} limit 1`;
  if (existing.length > 0) return;
  const orders = await sql<{ platform: string; link: string; interval_hours: number; variance_percent: number; created_at: string }>`
    select platform, link, interval_hours, variance_percent, created_at::text as created_at
    from engagement_orders
    where id = ${orderId} and user_id = ${userId}
  `;
  const order = orders[0];
  if (!order) return;
  const created = new Date(order.created_at).getTime();
  if (!Number.isFinite(created) || Date.now() - created > 6 * 60 * 60 * 1000) return;
  const items = await sql<{ engagement_type: string; quantity: number }>`
    select engagement_type, quantity from engagement_order_items
    where order_id = ${orderId} and user_id = ${userId} and quantity > 0
  `;
  if (items.length === 0) return;
  const plans: Record<string, DropPlan> = {};
  for (const item of items) {
    const chunk = item.engagement_type === "views" ? 100 : item.engagement_type === "saves" ? 50 : 10;
    const runs = Math.max(1, Math.floor(item.quantity / chunk));
    const gap = Math.max(1, Number(order.interval_hours) || 1);
    plans[item.engagement_type] = {
      hours: Math.max(gap, gap * Math.max(runs - 1, 1)),
      runs,
      variance: order.variance_percent ?? 25,
      start: new Date().toISOString(),
    };
  }
  await armOrder({
    userId,
    orderId,
    platform: order.platform,
    link: order.link,
    lines: items,
    plans,
  });
}

type DueDrop = {
  id: string;
  order_id: string;
  user_id: string;
  platform: string;
  link: string;
  engagement_type: string;
  quantity: number;
  provider_service_id: string | null;
  api_url: string | null;
  api_key: string | null;
  place_at?: string;
  error?: string | null;
};

export async function flushDueDrops(orderId?: string) {
  const sql = await getSql();
  await sql`
    update delivery_drops
    set status = 'failed', error = ${"gaveup: quantity is below the provider minimum"}
    where status = 'waiting' and coalesce(error, '') ilike '%accepts quantity%'
  `;
  await sql`
    update delivery_drops set status = 'waiting'
    where status = 'placing' and place_at < now() - interval '2 minutes'
  `;
  await sql`
    update delivery_drops set status = 'waiting', error = 'retry 1: recovered'
    where status = 'failed'
      and place_at > now() - interval '12 hours'
      and coalesce(error, '') not like 'gaveup%'
      and coalesce(error, '') not like 'retry%'
  `;
  const due = orderId
    ? await sql<DueDrop>`
        select id, order_id, user_id, platform, link, engagement_type, quantity, provider_service_id, api_url, api_key, error
        from delivery_drops
        where status = 'waiting' and place_at <= now() and order_id = ${orderId}
        order by place_at asc
        limit 30
      `
    : await sql<DueDrop>`
        select id, order_id, user_id, platform, link, engagement_type, quantity, provider_service_id, api_url, api_key, error
        from delivery_drops
        where status = 'waiting' and place_at <= now()
        order by place_at asc
        limit 30
      `;
  if (due.length > 0) console.log(`[drops] ${due.length} due${orderId ? ` for ${orderId.slice(0, 8)}` : ""}`);
  else if (orderId) {
    const waiting = await sql<DueDrop>`
      select id, order_id, user_id, platform, link, engagement_type, quantity, provider_service_id, api_url, api_key, error, place_at::text as place_at
      from delivery_drops
      where order_id = ${orderId} and status = 'waiting'
      order by place_at asc
    `;
    const now = Date.now();
    const overdue = waiting.filter((drop) => new Date(drop.place_at).getTime() <= now + 5000);
    if (overdue.length > 0) {
      console.log(`[drops] ${overdue.length} overdue by clock for ${orderId.slice(0, 8)}`);
      due.push(...overdue);
    } else if (waiting[0]) {
      const mins = Math.round((new Date(waiting[0].place_at).getTime() - now) / 60000);
      if (mins <= 2) console.log(`[drops] next ${waiting[0].engagement_type} in ${mins}m`);
    }
  }
  const { placeChunk } = await import("@/lib/providers.server");
  const { bindingMap } = await import("@/lib/admin.server");
  let bindings: Record<string, { api_url?: string; api_key?: string; providers?: { api_url: string; api_key: string }[] }> = {};
  try {
    bindings = await bindingMap();
  } catch (error) {
    console.error("[drops] bindings", error);
  }
  for (const drop of due) {
    const claimed = await sql<{ id: string }>`
      update delivery_drops set status = 'placing' where id = ${drop.id} and status = 'waiting' returning id
    `;
    if (claimed.length === 0) {
      console.log(`[drops] skip ${drop.engagement_type} ${drop.id.slice(0, 8)} — already claimed`);
      continue;
    }
    try {
      const core = CORE_TYPES.has(drop.engagement_type);
      const sent = core
        ? await (async () => {
            const binding = bindings[`${drop.platform}:${drop.engagement_type}`];
            const saved = binding?.providers?.filter((item) => item.api_key) || [];
            const providers = saved.length
              ? saved.map((item) => ({ apiUrl: item.api_url, apiKey: item.api_key }))
              : await providersFor(drop.platform, drop.engagement_type, drop);
            return placeChunk({
              platform: drop.platform,
              type: drop.engagement_type,
              link: drop.link,
              quantity: drop.quantity,
              providers,
            });
          })()
        : await (async () => {
            const kind = guessKind(drop.engagement_type);
            const providers = await providersFor(drop.platform, kind, drop);
            console.log(`[drops] single ${kind} x${drop.quantity} searching ${providers.length} APIs`);
            return placeChunk({
              platform: drop.platform,
              type: kind,
              link: drop.link,
              quantity: drop.quantity,
              providers,
            });
          })();
      await sql`
        update delivery_drops
        set status = 'placed', provider_order_id = ${sent.orderId}, service_label = ${sent.label}, provider_service_id = ${sent.serviceId}, api_url = ${sent.apiUrl || null}, error = null
        where id = ${drop.id}
      `;
      console.log(`[drops] placed ${drop.engagement_type} x${drop.quantity} via #${sent.serviceId} for order ${drop.order_id.slice(0, 8)} → ${sent.orderId}`);
      await sql`
        update engagement_order_items
        set delivered = coalesce((
          select sum(quantity)::int from delivery_drops
          where order_id = ${drop.order_id} and user_id = ${drop.user_id} and engagement_type = ${drop.engagement_type} and status = 'placed'
        ), 0),
            status = case
              when coalesce((
                select sum(quantity)::int from delivery_drops
                where order_id = ${drop.order_id} and user_id = ${drop.user_id} and engagement_type = ${drop.engagement_type} and status = 'placed'
              ), 0) >= quantity then 'complete'
              else 'processing'
            end
        where order_id = ${drop.order_id} and user_id = ${drop.user_id} and engagement_type = ${drop.engagement_type}
      `;
    } catch (error) {
      const message = error instanceof Error ? error.message : "Provider rejected this drop.";
      const permanent = /accepts quantity|no api key|disabled/i.test(message);
      const attempts = Number((drop.error || "").match(/^retry (\d+)/)?.[1] || 0);
      if (!permanent && attempts < 2) {
        const when = new Date(Date.now() + 2 * 60 * 1000).toISOString();
        console.error(`[drops] retry ${attempts + 1} ${drop.engagement_type} x${drop.quantity}: ${message}`);
        await sql`
          update delivery_drops
          set status = 'waiting', place_at = ${when}, error = ${`retry ${attempts + 1}: ${message}`.slice(0, 280)}
          where id = ${drop.id}
        `;
      } else {
        console.error(`[drops] FAIL ${drop.engagement_type} x${drop.quantity}: ${message}`);
        await sql`update delivery_drops set status = 'failed', error = ${`gaveup: ${message}`.slice(0, 280)} where id = ${drop.id}`;
      }
    }
    await refreshOrderStatus(drop.order_id, drop.user_id);
  }
}

async function refreshOrderStatus(orderId: string, userId: string) {
  const sql = await getSql();
  const counts = await sql<{ waiting: number; failed: number; placed: number }>`
    select
      count(*) filter (where status = 'waiting' or status = 'placing')::int as waiting,
      count(*) filter (where status = 'failed')::int as failed,
      count(*) filter (where status = 'placed')::int as placed
    from delivery_drops
    where order_id = ${orderId} and user_id = ${userId}
  `;
  const row = counts[0];
  const status = !row || row.waiting > 0 ? "processing" : row.failed > 0 && row.placed === 0 ? "failed" : row.failed > 0 ? "partial" : "complete";
  await sql`update engagement_orders set status = ${status} where id = ${orderId} and user_id = ${userId}`;
}

export async function scheduleFixed(input: {
  userId: string;
  orderId: string;
  platform: string;
  link: string;
  engagementType: string;
  providerServiceId: string;
  apiUrl: string;
  apiKey: string;
  amount: number;
  runs: number;
  intervalMinutes: number;
}) {
  const sql = await getSql();
  const start = Date.now();
  const runs = Math.max(1, Math.min(200, input.runs));
  const gap = Math.max(1, input.intervalMinutes) * 60 * 1000;
  for (let index = 0; index < runs; index += 1) {
    await sql`
      insert into delivery_drops (
        id, order_id, user_id, platform, link, engagement_type, quantity, place_at, status,
        provider_service_id, api_url, api_key
      ) values (
        ${crypto.randomUUID()}, ${input.orderId}, ${input.userId}, ${input.platform}, ${input.link},
        ${input.engagementType}, ${input.amount}, ${new Date(start + gap * index).toISOString()}, 'waiting',
        ${input.providerServiceId}, ${input.apiUrl}, ${input.apiKey}
      )
    `;
  }
  await flushDueDrops(input.orderId);
}

export async function editDrop(userId: string, id: string, quantity: number, placeAt: string) {
  const sql = await getSql();
  const rows = await sql<{ id: string }>`
    update delivery_drops
    set quantity = ${quantity}, place_at = ${placeAt}
    where id = ${id} and user_id = ${userId} and status in ('waiting', 'paused')
    returning id
  `;
  if (rows.length === 0) throw new Error("Only a pending run can be edited.");
}

export async function setDropState(userId: string, id: string, status: "waiting" | "paused" | "cancelled") {
  const sql = await getSql();
  const rows = await sql<{ id: string }>`
    update delivery_drops
    set status = ${status}
    where id = ${id} and user_id = ${userId} and status in ('waiting', 'paused')
    returning id
  `;
  if (rows.length === 0) throw new Error("That run is already placed.");
}

export async function setTypeState(userId: string, orderId: string, type: string, status: "waiting" | "paused" | "cancelled") {
  const sql = await getSql();
  await sql`
    update delivery_drops
    set status = ${status}
    where user_id = ${userId} and order_id = ${orderId} and engagement_type = ${type} and status in ('waiting', 'paused')
  `;
}

export async function refillType(userId: string, orderId: string, type: string) {
  const sql = await getSql();
  const items = await sql<{ quantity: number }>`
    select quantity from engagement_order_items
    where user_id = ${userId} and order_id = ${orderId} and engagement_type = ${type}
    limit 1
  `;
  const target = items[0]?.quantity ?? 0;
  const placed = await sql<{ qty: number }>`
    select coalesce(sum(quantity), 0)::int as qty from delivery_drops
    where user_id = ${userId} and order_id = ${orderId} and engagement_type = ${type} and status = 'placed'
  `;
  const waiting = await sql<{ n: number }>`
    select count(*)::int as n from delivery_drops
    where user_id = ${userId} and order_id = ${orderId} and engagement_type = ${type} and status in ('waiting', 'paused', 'placing')
  `;
  if ((waiting[0]?.n ?? 0) > 0) throw new Error("Pending runs are still scheduled for this type.");
  const remaining = target - (placed[0]?.qty ?? 0);
  if (remaining < 1) throw new Error("Nothing left to refill.");
  const last = await sql<{ platform: string; link: string; provider_service_id: string | null; api_url: string | null; api_key: string | null }>`
    select platform, link, provider_service_id, api_url, api_key
    from delivery_drops
    where user_id = ${userId} and order_id = ${orderId} and engagement_type = ${type}
    order by place_at desc
    limit 1
  `;
  const sample = last[0];
  if (!sample) throw new Error("No earlier run to copy.");
  const at = new Date(Date.now() + 60_000).toISOString();
  await sql`
    insert into delivery_drops (
      id, order_id, user_id, platform, link, engagement_type, quantity, place_at, status,
      provider_service_id, api_url, api_key
    ) values (
      ${crypto.randomUUID()}, ${orderId}, ${userId}, ${sample.platform}, ${sample.link}, ${type}, ${remaining}, ${at}, 'waiting',
      ${sample.provider_service_id}, ${sample.api_url}, ${sample.api_key}
    )
  `;
}

export function startDropWorker() {
  if (globalWorker.__dropWorker) return;
  console.log("[drops] worker started");
  let ticks = 0;
  globalWorker.__dropWorker = setInterval(() => {
    ticks += 1;
    if (ticks % 12 === 0) console.log("[drops] worker alive");
    flushDueDrops().catch((error) => console.error("[drops]", error));
  }, 5000);
  flushDueDrops().catch((error) => console.error("[drops]", error));
}
