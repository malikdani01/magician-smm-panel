import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Clock, Home, Link2, Search, Zap } from "lucide-react";
import { Authed } from "@/components/gate";
import { browseLiveServices, getWallet, placeSingleOrder } from "@/lib/panel.functions";
import { adminFetchProvider, adminSaveProvider, getDeskRole } from "@/lib/admin.functions";
import { usdQtyToPaise } from "@/lib/fx";
import { inr } from "@/lib/money";

export const Route = createFileRoute("/single-order")({
  component: () => (
    <Authed>
      <SingleOrder />
    </Authed>
  ),
});

const PLATFORMS = ["instagram", "tiktok", "youtube", "facebook", "twitter", "telegram", "whatsapp", "spotify", "linkedin", "discord", "twitch", "snapchat", "kwai"] as const;

type LiveCard = {
  id: number;
  category: string;
  name: string;
  min: number;
  max: number;
  rateUsd: number;
  note: string;
  dripAllowed?: boolean;
  managedId?: string;
  providerName?: string;
  platform?: string;
};
const ICONS = {
  instagram: InstagramMark,
  tiktok: TikTokMark,
  youtube: YoutubeMark,
  facebook: FacebookMark,
  twitter: XMark,
  telegram: TelegramMark,
  whatsapp: WhatsAppMark,
  spotify: SpotifyMark,
  linkedin: LinkedInMark,
  discord: DiscordMark,
  twitch: TwitchMark,
  snapchat: SnapchatMark,
  kwai: KwaiMark,
} as const;

function SingleOrder() {
  const [platform, setPlatform] = useState<(typeof PLATFORMS)[number] | "all">("all");
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("");
  const [categories, setCategories] = useState<string[]>([]);
  const [services, setServices] = useState<LiveCard[]>([]);
  const [serviceId, setServiceId] = useState("");
  const [balanceUsd, setBalanceUsd] = useState<number | null>(null);
  const [link, setLink] = useState("");
  const [amount, setAmount] = useState("");
  const [drip, setDrip] = useState(false);
  const [runs, setRuns] = useState("");
  const [intervalMinutes, setIntervalMinutes] = useState("");
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(true);
  const [pending, setPending] = useState(false);
  const [admin, setAdmin] = useState(false);
  const [keys, setKeys] = useState([{ name: "Provider 1", api_url: "https://yoyomedia.in/api/v2", api_key: "" }]);
  const [keyNote, setKeyNote] = useState("");
  const [keyBusy, setKeyBusy] = useState(false);

  useEffect(() => {
    getDeskRole().then((role) => setAdmin(role === "admin")).catch(() => setAdmin(false));
  }, []);

  useEffect(() => {
    let cancel = false;
    const timer = window.setTimeout(() => {
      setLoading(true);
      browseLiveServices({ data: { platform, category, query } })
        .then((result) => {
          if (cancel) return;
          setCategories(result.categories);
          setServices(result.services);
          setBalanceUsd(result.balanceUsd);
          if (result.category !== category) setCategory(result.category);
          setServiceId((current) => result.services.some((service) => service.managedId === current) ? current : result.services[0]?.managedId ?? "");
          setNote("");
        })
        .catch((err: unknown) => {
          if (!cancel) setNote(err instanceof Error ? err.message : "Could not load YoYoMedia services.");
        })
        .finally(() => {
          if (!cancel) setLoading(false);
        });
    }, query ? 250 : 0);
    return () => {
      cancel = true;
      window.clearTimeout(timer);
    };
  }, [platform, category, query]);

  const service = services.find((item) => item.managedId === serviceId) ?? services[0] ?? null;
  const dripOn = drip;
  const runCount = Math.max(1, Math.floor(Number(runs) || 0));
  const qty = Math.floor(Number(amount));
  const totalQty = dripOn && runCount > 0 ? qty * runCount : qty;
  const charge = service && Number.isFinite(qty) && qty > 0 ? usdQtyToPaise(service.rateUsd, totalQty) : 0;
  const inRange = Boolean(service) && Number.isFinite(qty) && qty >= (service?.min ?? 0) && qty <= (service?.max ?? 0);

  function pickPlatform(next: (typeof PLATFORMS)[number] | "all") {
    setPlatform(next);
    setCategory("");
    setQuery("");
    setServiceId("");
  }

  async function submit() {
    if (!service) return;
    if (!inRange) {
      setNote(`Amount must be between ${service.min.toLocaleString("en-IN")} and ${service.max.toLocaleString("en-IN")}.`);
      return;
    }
    setPending(true);
    setNote("");
    try {
      const wallet = await getWallet();
      if (wallet.balance_paise < charge) {
        setNote("Panel wallet does not cover this order. Add credit first. YoYoMedia is charged as well.");
        return;
      }
      const result = await placeSingleOrder({
        data: {
          serviceId: service.id,
          managedId: service.managedId,
          link,
          amount: qty,
          drip: dripOn,
          runs: dripOn ? runCount : 1,
          intervalMinutes: Math.max(1, Math.floor(Number(intervalMinutes) || 1)),
        },
      });
      setNote(dripOn ? `${result.order_number} drip started. First run is placing now, next runs follow the interval.` : `${result.order_number} placed #${result.provider_order_id} · ${inr(result.total_paise)}.`);
      setLink("");
      setAmount("");
    } catch (err: unknown) {
      setNote(err instanceof Error ? err.message : "Order failed.");
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="mx-auto max-w-xl pb-16">
      {admin && (
        <section className="mb-4 rounded-[28px] border border-[#dbeafe] bg-white p-4 shadow-sm">
          <h2 className="text-[16px] font-bold">Single order APIs</h2>
          <p className="mt-1 text-[12px] text-[#64748b]">URL aur API key yahan daalo. Drip ka har run in sab keys mein se Non Drop, Stable, Guaranteed ya Refill service uthayega. Ek run sirf ek API pe jayega.</p>
          <div className="mt-3 grid gap-3">
            {keys.map((item, index) => (
              <div key={index} className="grid gap-2 rounded-2xl bg-[#f8fafc] p-3">
                <div className="flex items-center justify-between">
                  <p className="text-[12px] font-semibold">API {index + 1}</p>
                  {keys.length > 1 && <button type="button" onClick={() => setKeys(keys.filter((_, itemIndex) => itemIndex !== index))} className="text-[12px] font-semibold text-[#b91c1c]">Remove</button>}
                </div>
                <input value={item.api_url} onChange={(event) => setKeys(keys.map((row, itemIndex) => itemIndex === index ? { ...row, api_url: event.target.value } : row))} placeholder="API URL" className="h-11 rounded-xl border border-[#e7eef6] bg-white px-3 text-[13px] outline-none" />
                <input value={item.api_key} onChange={(event) => setKeys(keys.map((row, itemIndex) => itemIndex === index ? { ...row, api_key: event.target.value } : row))} placeholder="API key" className="h-11 rounded-xl border border-[#e7eef6] bg-white px-3 text-[13px] outline-none" />
              </div>
            ))}
            <button type="button" onClick={() => setKeys([...keys, { name: `Provider ${keys.length + 1}`, api_url: "https://yoyomedia.in/api/v2", api_key: "" }])} className="h-10 rounded-xl bg-[#f3f6fa] text-[12px] font-bold text-[#1d4ed8]">Add another API</button>
            <button
              type="button"
              disabled={keyBusy}
              onClick={async () => {
                const filled = keys.filter((item) => item.api_key.trim());
                if (!filled.length) {
                  setKeyNote("API key daalo.");
                  return;
                }
                setKeyBusy(true);
                setKeyNote("");
                const notes: string[] = [];
                for (const item of filled) {
                  try {
                    const saved = await adminSaveProvider({ data: { name: item.name || "Provider", api_url: item.api_url, api_key: item.api_key, enabled: true } });
                    const result = await adminFetchProvider({ data: saved.id });
                    notes.push(`${result.total.toLocaleString("en-IN")} services`);
                  } catch (err: unknown) {
                    notes.push(err instanceof Error ? err.message : "Save failed");
                  }
                }
                setKeyNote(notes.join(" · "));
                setKeyBusy(false);
              }}
              className="h-11 rounded-xl bg-[#2563eb] text-[13px] font-bold text-white disabled:opacity-60"
            >
              {keyBusy ? "Saving…" : "Save APIs and load services"}
            </button>
            {keyNote && <p className="text-[12px] text-[#1e3a8a]">{keyNote}</p>}
          </div>
        </section>
      )}
      <section className="rounded-[28px] border border-[#e7eef6] bg-white p-4 shadow-sm">
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            aria-label="All platforms"
            onClick={() => pickPlatform("all")}
            className={`grid size-11 place-items-center rounded-2xl border ${platform === "all" ? "border-[#2563eb] bg-[#2563eb] text-white ring-2 ring-[#2563eb]" : "border-[#e7eef6] bg-[#eef3f8] text-[#334155]"}`}
          >
            <Home className="size-5" />
          </button>
          {PLATFORMS.map((id) => {
            const Icon = ICONS[id];
            const on = platform === id;
            return (
              <button
                key={id}
                type="button"
                aria-label={id}
                onClick={() => pickPlatform(id)}
                className={`grid size-11 place-items-center rounded-2xl border ${on ? "border-[#2563eb] bg-white ring-2 ring-[#2563eb]" : "border-[#e7eef6] bg-white"}`}
              >
                <Icon />
              </button>
            );
          })}
        </div>
        <p className="mt-3 text-[12px] text-[#64748b]">{loading ? "Loading live YoYoMedia services…" : `YoYoMedia balance $${balanceUsd?.toFixed(2) ?? "—"} · charge uses ₹84 per $1`}</p>

        <label className="mt-4 block text-[13px] font-semibold text-[#334155]">
          Search for a service...
          <span className="mt-1 flex h-11 items-center gap-2 rounded-xl bg-[#e7f0f8] px-3 text-[#94a3b8]">
            <Search className="size-4" />
            <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search..." className="w-full bg-transparent text-[14px] text-[#0f172a] outline-none" />
          </span>
        </label>

        <label className="mt-4 block text-[13px] font-semibold text-[#334155]">
          Category
          <select value={category} onChange={(event) => { setCategory(event.target.value); setServiceId(""); }} className="mt-1 h-11 w-full rounded-xl border border-[#e7eef6] bg-white px-3 text-[14px]">
            {categories.map((item) => <option key={item}>{item}</option>)}
            {categories.length === 0 && <option value="">No category</option>}
          </select>
        </label>

        <label className="mt-4 block text-[13px] font-semibold text-[#334155]">
          Service
          <select
            value={service?.managedId ?? ""}
            onChange={(event) => setServiceId(event.target.value)}
            className="mt-1 h-11 w-full rounded-xl border border-[#e7eef6] bg-white px-3 text-[13px]"
          >
            {services.map((item) => (
              <option key={item.managedId || item.id} value={item.managedId || String(item.id)}>
                {item.id} · {platform === "all" ? `${item.platform || item.category} · ` : ""}{item.name}{item.providerName ? ` · ${item.providerName}` : ""}
              </option>
            ))}
          </select>
        </label>
        {service && <ServiceChip service={service} />}

        <div className="mt-4">
          <p className="text-[13px] font-semibold text-[#334155]">Provider note</p>
          <div className="mt-1 flex items-center gap-3 rounded-xl bg-[#f8fbff] px-3 py-3">
            <span className="grid size-9 place-items-center rounded-full bg-[#e8f1ff] text-[#2563eb]"><Clock className="size-4" /></span>
            <div>
              <p className="text-[14px] font-semibold">{service?.note || (loading ? "Loading…" : "No extra note from the provider")}</p>
              <p className="text-[12px] text-[#94a3b8]">{service ? `$${service.rateUsd} per 1,000` : "Live rate from YoYoMedia"}</p>
            </div>
          </div>
        </div>

        <label className="mt-4 block text-[13px] font-semibold text-[#334155]">
          Enter Link
          <span className="mt-1 flex h-11 items-center gap-2 rounded-xl border border-[#e7eef6] px-3">
            <Link2 className="size-4 text-[#94a3b8]" />
            <input value={link} onChange={(event) => setLink(event.target.value)} placeholder="Paste your link here" className="w-full bg-transparent text-[14px] outline-none" />
          </span>
        </label>

        <label className="mt-4 block text-[13px] font-semibold text-[#334155]">
          Amount
          <input
            value={amount}
            inputMode="numeric"
            onChange={(event) => setAmount(event.target.value.replace(/[^\d]/g, ""))}
            placeholder="Enter amount"
            className="mt-1 h-11 w-full rounded-xl border border-[#e7eef6] px-3 text-[14px] outline-none"
          />
          <span className="mt-1 block text-[12px] font-normal text-[#94a3b8]">Min: {service?.min.toLocaleString("en-IN") ?? "—"} · Max: {service?.max.toLocaleString("en-IN") ?? "—"}</span>
        </label>

        <label className="mt-4 flex items-center gap-2 text-[14px] font-semibold text-[#0f172a]">
          <input
            type="checkbox"
            checked={drip}
            onChange={(event) => setDrip(event.target.checked)}
          />
          Drip-Feed
        </label>
        <p className="text-[12px] text-[#94a3b8]">Runs jitne likhoge, utne orders usi service pe, interval ke gap pe, ek-ek karke place honge.</p>
        {dripOn && (
          <div className="mt-3 grid gap-3">
            <label className="block text-[13px] font-semibold text-[#334155]">
              Runs
              <input value={runs} inputMode="numeric" onChange={(event) => setRuns(event.target.value.replace(/[^\d]/g, ""))} placeholder="How many orders" className="mt-1 h-11 w-full rounded-xl border border-[#e7eef6] px-3 text-[14px] outline-none" />
            </label>
            <label className="block text-[13px] font-semibold text-[#334155]">
              Intervals (in minutes)
              <input value={intervalMinutes} inputMode="numeric" onChange={(event) => setIntervalMinutes(event.target.value.replace(/[^\d]/g, ""))} placeholder="Minutes between runs" className="mt-1 h-11 w-full rounded-xl border border-[#e7eef6] px-3 text-[14px] outline-none" />
            </label>
            <label className="block text-[13px] font-semibold text-[#334155]">
              Total quantity
              <input readOnly value={Number.isFinite(totalQty) ? totalQty : 0} className="mt-1 h-11 w-full rounded-xl border border-[#e7eef6] bg-[#f8fafc] px-3 text-[14px] outline-none" />
            </label>
          </div>
        )}

        <div className="mt-4 flex items-center justify-between text-[14px]">
          <span className="font-semibold">Charge</span>
          <span className="font-bold text-[#2563eb]">{inr(charge)}</span>
        </div>

        <button type="button" disabled={pending || !service} onClick={submit} className="mt-4 inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#2563eb] text-[14px] font-bold tracking-wide text-white disabled:opacity-60">
          <Zap className="size-4" /> {pending ? "SUBMITTING…" : "SUBMIT ORDER"}
        </button>
        {note && <p className="mt-3 text-center text-[13px] text-[#334155]">{note}</p>}
      </section>
    </div>
  );
}

function ServiceChip({ service }: { service: LiveCard }) {
  return (
    <p className="mt-2 flex items-start gap-2 text-[12px] leading-snug text-[#475569]">
      <span className="rounded-md bg-[#2563eb] px-1.5 py-0.5 text-[10px] font-bold text-white">{service.id}</span>
      <span>{service.name}</span>
    </p>
  );
}

function InstagramMark() {
  return (
    <svg viewBox="0 0 32 32" className="size-7" aria-hidden>
      <defs>
        <radialGradient id="ig" cx="30%" cy="110%" r="120%">
          <stop offset="0%" stopColor="#f9ce34" />
          <stop offset="40%" stopColor="#ee2a7b" />
          <stop offset="100%" stopColor="#6228d7" />
        </radialGradient>
      </defs>
      <rect width="32" height="32" rx="8" fill="url(#ig)" />
      <rect x="8" y="8" width="16" height="16" rx="5" fill="none" stroke="#fff" strokeWidth="2" />
      <circle cx="16" cy="16" r="4" fill="none" stroke="#fff" strokeWidth="2" />
      <circle cx="21.5" cy="10.5" r="1.2" fill="#fff" />
    </svg>
  );
}

function TikTokMark() {
  return (
    <svg viewBox="0 0 32 32" className="size-7" aria-hidden>
      <rect width="32" height="32" rx="8" fill="#111" />
      <path d="M18 8c.6 2.4 2.2 4 4.6 4.4v2.4c-1.6 0-3.1-.5-4.4-1.4v6.4a5.8 5.8 0 1 1-5-5.7v2.6a3.3 3.3 0 1 0 2.4 3.1V8H18z" fill="#25f4ee" transform="translate(-.6 .4)" />
      <path d="M18 8c.6 2.4 2.2 4 4.6 4.4v2.4c-1.6 0-3.1-.5-4.4-1.4v6.4a5.8 5.8 0 1 1-5-5.7v2.6a3.3 3.3 0 1 0 2.4 3.1V8H18z" fill="#fe2c55" transform="translate(.6 -.2)" />
      <path d="M18 8c.6 2.4 2.2 4 4.6 4.4v2.4c-1.6 0-3.1-.5-4.4-1.4v6.4a5.8 5.8 0 1 1-5-5.7v2.6a3.3 3.3 0 1 0 2.4 3.1V8H18z" fill="#fff" />
    </svg>
  );
}

function YoutubeMark() {
  return (
    <svg viewBox="0 0 32 32" className="size-7" aria-hidden>
      <rect width="32" height="32" rx="8" fill="#ff0033" />
      <path d="M13 11.5v9l8-4.5-8-4.5z" fill="#fff" />
    </svg>
  );
}

function FacebookMark() {
  return (
    <svg viewBox="0 0 32 32" className="size-7" aria-hidden>
      <rect width="32" height="32" rx="8" fill="#1877f2" />
      <path d="M18.2 16.8H16v8h-3.2v-8H11v-2.7h1.8v-1.8c0-2.2 1-3.5 3.6-3.5h2.2v2.7h-1.4c-.8 0-1 .3-1 .9v1.7h2.5l-.5 2.7z" fill="#fff" />
    </svg>
  );
}

function XMark() {
  return (
    <svg viewBox="0 0 32 32" className="size-7" aria-hidden>
      <rect width="32" height="32" rx="8" fill="#111" />
      <path d="M9 9.5h3.2l3.2 4.3 3.6-4.3H22l-5 5.8L22.4 22h-3.1l-3.5-4.6L12 22H9.2l5.3-6.2L9 9.5z" fill="#fff" />
    </svg>
  );
}

function TelegramMark() {
  return (
    <svg viewBox="0 0 32 32" className="size-7" aria-hidden>
      <circle cx="16" cy="16" r="14" fill="#2aa3e0" />
      <path d="M8 15.6 22.2 10l-2.2 12.2-4.6-3.4-2.4 2.3.2-3.6 8.2-7.4-10.2 6.1L8 15.6z" fill="#fff" />
    </svg>
  );
}

function WhatsAppMark() {
  return (
    <svg viewBox="0 0 32 32" className="size-7" aria-hidden>
      <circle cx="16" cy="16" r="14" fill="#25d366" />
      <path d="M16 8.2a7.6 7.6 0 0 0-6.5 11.5L8.6 23l3.4-.9A7.6 7.6 0 1 0 16 8.2zm4.3 10.7c-.2.5-1 .9-1.4 1-.4 0-.8.2-2.7-.6-2.3-.9-3.7-3.2-3.8-3.4-.1-.2-1-1.3-1-2.5s.6-1.8.9-2c.2-.2.5-.3.7-.3h.5c.2 0 .4 0 .5.4.2.5.7 1.8.7 1.9.1.1 0 .3-.1.5l-.3.4c-.1.1-.2.3-.1.5.2.3.7 1.2 1.5 1.9 1 .9 1.8 1.1 2.1 1.3.2.1.4.1.5-.1l.6-.7c.2-.2.3-.2.5-.1l1.6.8c.2.1.4.2.4.3 0 .2-.1.8-.4 1.1z" fill="#fff" />
    </svg>
  );
}

function SpotifyMark() {
  return (
    <svg viewBox="0 0 32 32" className="size-7" aria-hidden>
      <circle cx="16" cy="16" r="14" fill="#1db954" />
      <path d="M10 13.2c3.6-1.1 8-.8 11.2 1.1" fill="none" stroke="#fff" strokeWidth="1.7" strokeLinecap="round" />
      <path d="M11 16.4c2.8-.8 6.2-.6 8.6.8" fill="none" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" />
      <path d="M12 19.4c2.1-.5 4.4-.3 6 .6" fill="none" stroke="#fff" strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  );
}

function LinkedInMark() {
  return (
    <svg viewBox="0 0 32 32" className="size-7" aria-hidden>
      <rect width="32" height="32" rx="6" fill="#0a66c2" />
      <path d="M9 13h3v10H9zM10.5 8.2a1.7 1.7 0 1 1 0 3.4 1.7 1.7 0 0 1 0-3.4zM15 13h2.9v1.4h.1c.4-.8 1.4-1.6 2.9-1.6 3.1 0 3.6 2 3.6 4.6V23H21v-4.8c0-1.1 0-2.6-1.6-2.6s-1.8 1.2-1.8 2.5V23H15v-10z" fill="#fff" />
    </svg>
  );
}

function DiscordMark() {
  return (
    <svg viewBox="0 0 32 32" className="size-7" aria-hidden>
      <rect width="32" height="32" rx="8" fill="#5865f2" />
      <path d="M21.6 11.2a10 10 0 0 0-2.5-1l-.2.5a8 8 0 0 1 2.2.8 11 11 0 0 0-8.2 0 8 8 0 0 1 2.2-.8l-.2-.5a10 10 0 0 0-2.5 1C9.4 13.6 8.8 16 8.6 18.3c1.3 1 2.6 1.6 3.9 2l.8-1.2a6 6 0 0 1-1.2-.6l.3-.2c2.4 1.1 5 1.1 7.3 0l.3.2c-.4.2-.8.4-1.2.6l.8 1.2c1.3-.4 2.6-1 3.9-2-.3-2.4-1-4.8-2.9-7.1zM13.6 17.2c-.6 0-1.1-.6-1.1-1.3s.5-1.3 1.1-1.3 1.1.6 1.1 1.3-.5 1.3-1.1 1.3zm4.8 0c-.6 0-1.1-.6-1.1-1.3s.5-1.3 1.1-1.3 1.1.6 1.1 1.3-.5 1.3-1.1 1.3z" fill="#fff" />
    </svg>
  );
}

function TwitchMark() {
  return (
    <svg viewBox="0 0 32 32" className="size-7" aria-hidden>
      <rect width="32" height="32" rx="8" fill="#9146ff" />
      <path d="M10 8h12v10l-3 3h-3l-2 2h-2v-2H10V8zm3 2v6h1.5V10H13zm4 0v6H18.5V10H17z" fill="#fff" />
    </svg>
  );
}

function KwaiMark() {
  return (
    <svg viewBox="0 0 32 32" className="size-7" aria-hidden>
      <rect width="32" height="32" rx="8" fill="#ff4906" />
      <path d="M9 22V10h3.2l3.3 6.2L18.8 10H22v12h-2.6v-6.8L16.4 22h-1.7l-3.1-6.8V22H9z" fill="#fff" />
    </svg>
  );
}

function SnapchatMark() {
  return (
    <svg viewBox="0 0 32 32" className="size-7" aria-hidden>
      <rect width="32" height="32" rx="8" fill="#fffc00" />
      <path d="M16 7.5c2.2 0 3.6 1.6 3.6 3.8 0 1.2-.2 2.2 0 2.8.3.6 1.4.7 2 .9.4.1.3.6-.2.7-.8.1-1.3.5-1.4 1.1 0 .3.4.5 1.1.7.5.2.7.5.4.8-.6.5-1.6.6-2.2 1.2-.3.3-.2.7.4 1 .8.4 1.6 1 1.2 1.6-.5.7-2 .4-3.1.2-.4 0-.7.3-.8.7-.2.8-1 1.3-1.9 1.3s-1.7-.5-1.9-1.3c-.1-.4-.4-.7-.8-.7-1.1.2-2.6.5-3.1-.2-.4-.6.4-1.2 1.2-1.6.6-.3.7-.7.4-1-.6-.6-1.6-.7-2.2-1.2-.3-.3-.1-.6.4-.8.7-.2 1.1-.4 1.1-.7-.1-.6-.6-1-1.4-1.1-.5-.1-.6-.6-.2-.7.6-.2 1.7-.3 2-.9.2-.6 0-1.6 0-2.8 0-2.2 1.4-3.8 3.6-3.8z" fill="#111" />
    </svg>
  );
}
