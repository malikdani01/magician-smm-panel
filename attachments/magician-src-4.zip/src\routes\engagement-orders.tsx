import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Bookmark, Eye, Heart, Share2 } from "lucide-react";
import { Authed } from "@/components/gate";
import { listOrderDrops, listOrders, type OrderRow } from "@/lib/panel.functions";
import { inr } from "@/lib/money";

export const Route = createFileRoute("/engagement-orders")({
  component: () => (
    <Authed>
      <Orders />
    </Authed>
  ),
});

type Drop = { status: string; place_at: string; quantity: number; engagement_type: string };

function Orders() {
  const [rows, setRows] = useState<OrderRow[]>([]);
  const [drops, setDrops] = useState<Record<string, Drop[]>>({});
  const [q, setQ] = useState("");

  function load() {
    const stamp = Date.now();
    listOrders({ data: { t: stamp } }).then(async (orders) => {
      setRows(orders);
      const pairs = await Promise.all(orders.slice(0, 20).map(async (order) => {
        const res = await fetch(`/api/drops/${order.id}?t=${stamp}`, { cache: "no-store" }).catch(() => null);
        const data = res?.ok ? await res.json().catch(() => ({ drops: [] })) : { drops: [] };
        return [order.id, data.drops || []] as const;
      }));
      setDrops(Object.fromEntries(pairs));
    }).catch(() => setRows([]));
  }

  useEffect(() => {
    load();
    const timer = window.setInterval(load, 8000);
    return () => window.clearInterval(timer);
  }, []);

  const shown = rows.filter((row) => `${row.order_number} ${row.link}`.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="text-[22px] font-bold">All Orders</h1>
          <p className="text-[13px] text-[#64748b]">Single, drip and full engagement orders, with live tracking</p>
        </div>
        <div className="flex gap-2">
          <button type="button" onClick={load} className="rounded-full border bg-white px-3 py-2 text-[12px] font-semibold">Refresh</button>
          <Link to="/engagement-order" className="rounded-xl bg-[#2563eb] px-3 py-2 text-[12px] font-semibold text-white">+ New Order</Link>
        </div>
      </div>
      <input value={q} onChange={(event) => setQ(event.target.value)} placeholder="Search by order number or video link..." className="h-12 w-full rounded-2xl bg-[#e7f0fa] px-4 outline-none" />
      {shown.length === 0 ? (
        <section className="rounded-3xl border border-[#e7eef6] bg-white py-16 text-center">
          <p>No orders yet</p>
          <Link to="/engagement-order" className="mt-3 inline-flex h-10 items-center rounded-xl bg-[#2563eb] px-4 text-[13px] font-semibold text-white">Place Your First Order</Link>
        </section>
      ) : (
        <ul className="space-y-3">
          {shown.map((row) => <OrderCard key={row.id} order={row} drops={drops[row.id] ?? []} />)}
        </ul>
      )}
    </div>
  );
}

function OrderCard({ order, drops }: { order: OrderRow; drops: Drop[] }) {
  const placed = drops.filter((drop) => drop.status === "placed").length;
  const pending = drops.filter((drop) => drop.status === "waiting" || drop.status === "paused").length;
  const active = drops.filter((drop) => drop.status === "placing").length;
  const delivered = drops.filter((drop) => drop.status === "placed").reduce((sum, drop) => sum + drop.quantity, 0);
  const total = order.items.reduce((sum, item) => sum + item.quantity, 0);
  const next = drops.filter((drop) => drop.status === "waiting").sort((a, b) => a.place_at.localeCompare(b.place_at))[0];
  const pct = total ? Math.round((delivered / total) * 100) : 0;
  return (
    <li>
      <Link to="/orders/$id" params={{ id: order.id }} className="block rounded-[24px] border border-[#e7eef6] bg-white p-4 shadow-sm">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="font-semibold">Order #{order.order_number.replace("MAG-", "")} <span className="ml-1 rounded-full bg-[#111827] px-2 py-0.5 text-[10px] font-bold text-white">{order.status}</span> {order.organic && <span className="ml-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-700">Organic</span>}</p>
            <p className="mt-1 max-w-md truncate text-[12px] text-[#64748b]">{order.link}</p>
          </div>
          <div className="text-right">
            <p className="font-bold">{inr(order.total_paise)}</p>
            <p className="text-[11px] font-semibold text-[#2563eb]">Open live tracking ›</p>
            <p className="text-[11px] text-[#94a3b8]">{ago(order.created_at)}</p>
          </div>
        </div>
        <div className="mt-3 grid grid-cols-4 gap-2">
          <Stat label="Delivered" value={delivered} />
          <Stat label="Complete" value={placed} />
          <Stat label="Pending" value={pending} />
          <Stat label="Active" value={active} />
        </div>
        <div className="mt-3 flex justify-between text-[12px] text-[#64748b]">
          <span>{placed} / {drops.length || order.items.length} runs</span>
          <span>{delivered.toLocaleString("en-IN")} / {total.toLocaleString("en-IN")} ({pct}%)</span>
        </div>
        <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-[#e7eef6]"><div className="h-full bg-[#93c5fd]" style={{ width: `${pct}%` }} /></div>
        {next && <p className="mt-3 rounded-xl bg-[#f4f8fc] px-3 py-2 text-[13px] text-[#334155]">Next run: {clock(next.place_at)} (in {fromNow(next.place_at)})</p>}
        <div className="mt-3 flex flex-wrap gap-2 text-[12px]">
          {order.items.map((item) => {
            const sent = drops.filter((drop) => drop.engagement_type === item.engagement_type && drop.status === "placed").reduce((sum, drop) => sum + drop.quantity, 0);
            return (
              <span key={item.id} className="inline-flex items-center gap-1 rounded-full bg-[#f8fafc] px-2 py-1">
                <TypeIcon type={item.engagement_type} /> {item.engagement_type}: {sent}/{item.quantity}
              </span>
            );
          })}
        </div>
      </Link>
    </li>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-2xl bg-[#f4f8fc] px-2 py-3 text-center">
      <p className="text-[18px] font-bold">{value.toLocaleString("en-IN")}</p>
      <p className="text-[11px] text-[#64748b]">{label}</p>
    </div>
  );
}

function TypeIcon({ type }: { type: string }) {
  if (type === "likes") return <Heart className="size-3 text-rose-500" />;
  if (type === "shares" || type === "reposts") return <Share2 className="size-3 text-sky-500" />;
  if (type === "saves") return <Bookmark className="size-3 text-amber-500" />;
  return <Eye className="size-3 text-emerald-500" />;
}

function clock(iso: string) {
  return new Date(iso).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });
}

function ago(iso: string) {
  const min = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
  if (min < 1) return "less than a minute ago";
  if (min < 60) return `${min} min ago`;
  return `${Math.round(min / 60)}h ago`;
}

function fromNow(iso: string) {
  const min = Math.round((new Date(iso).getTime() - Date.now()) / 60000);
  if (min <= 0) return "less than a minute";
  if (min < 60) return `${min} minute${min === 1 ? "" : "s"}`;
  const hours = Math.round(min / 60);
  return hours === 1 ? "about 1 hour" : `about ${hours} hours`;
}
