/** Provider rates are USD per 1,000. The desk shows INR. */
export const USD_TO_INR = 84;

/** ₹3, ₹4, or ₹5 extra per 1,000, stable for the same service. */
export function sellMarkupPaise(seed: string | number) {
  const digits = String(seed).replace(/\D/g, "");
  const n = Number(digits.slice(-4) || "0");
  return (3 + (n % 3)) * 100;
}

export function usdQtyToPaise(ratePerThousandUsd: number, quantity: number) {
  if (!Number.isFinite(ratePerThousandUsd) || !Number.isFinite(quantity) || quantity <= 0) return 0;
  return Math.max(1, Math.round((quantity / 1000) * ratePerThousandUsd * USD_TO_INR * 100));
}
